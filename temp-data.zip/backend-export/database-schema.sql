-- Database schema export for project: xonxdkvdbjmxawdyeemt
-- Generated on: 2025-01-17

-- Extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA extensions;
CREATE EXTENSION IF NOT EXISTS "pg_cron" WITH SCHEMA extensions;
CREATE EXTENSION IF NOT EXISTS "pg_net" WITH SCHEMA extensions;

-- Custom types
CREATE TYPE app_role AS ENUM ('admin', 'user');
CREATE TYPE annotation_type AS ENUM ('highlight', 'note', 'comment');

-- Tables

-- Academic discount verifications table
CREATE TABLE public.academic_discount_verifications (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id UUID,
    email TEXT NOT NULL,
    institution_name TEXT NOT NULL,
    student_id TEXT,
    verification_document_url TEXT,
    verification_status TEXT DEFAULT 'pending'::text,
    discount_percentage INTEGER DEFAULT 20,
    verified_at TIMESTAMP WITH TIME ZONE,
    expires_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Admin audit logs table
CREATE TABLE public.admin_audit_logs (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    action TEXT NOT NULL,
    user_identifier TEXT,
    ip_address INET,
    user_agent TEXT,
    success BOOLEAN NOT NULL,
    error_message TEXT,
    metadata JSONB,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Annotation tags table
CREATE TABLE public.annotation_tags (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    annotation_id UUID NOT NULL,
    tag_id UUID NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Annotations table
CREATE TABLE public.annotations (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    paper_id UUID NOT NULL,
    user_id UUID NOT NULL,
    type annotation_type NOT NULL DEFAULT 'highlight'::annotation_type,
    content TEXT,
    page_number INTEGER NOT NULL,
    position_data JSONB,
    is_public BOOLEAN NOT NULL DEFAULT false,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Auth tokens table
CREATE TABLE public.auth_tokens (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    token TEXT NOT NULL,
    user_id UUID,
    telegram_id BIGINT,
    used BOOLEAN NOT NULL DEFAULT false,
    used_at TIMESTAMP WITH TIME ZONE,
    expires_at TIMESTAMP WITH TIME ZONE NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Consent logs table
CREATE TABLE public.consent_logs (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id UUID,
    consent_type TEXT NOT NULL,
    granted BOOLEAN NOT NULL,
    ip_address INET,
    user_agent TEXT,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Data subject requests table
CREATE TABLE public.data_subject_requests (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id UUID,
    request_type TEXT NOT NULL,
    description TEXT,
    status TEXT DEFAULT 'pending'::text,
    response_data JSONB,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Deposit requests table
CREATE TABLE public.deposit_requests (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id UUID NOT NULL,
    amount NUMERIC NOT NULL,
    receipt_image_url TEXT,
    status TEXT NOT NULL DEFAULT 'pending'::text,
    rejection_reason TEXT,
    admin_telegram_id BIGINT,
    admin_username TEXT,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- DMCA takedown requests table
CREATE TABLE public.dmca_takedown_requests (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    claimant_name TEXT NOT NULL,
    claimant_email TEXT NOT NULL,
    content_url TEXT NOT NULL,
    description TEXT NOT NULL,
    status TEXT DEFAULT 'pending'::text,
    response TEXT,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enterprise leads table
CREATE TABLE public.enterprise_leads (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    company_name TEXT NOT NULL,
    contact_name TEXT NOT NULL,
    email TEXT NOT NULL,
    phone TEXT,
    company_size TEXT,
    industry TEXT,
    use_case TEXT,
    budget_range TEXT,
    timeline TEXT,
    status TEXT DEFAULT 'new'::text,
    assigned_to UUID,
    notes TEXT,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Knowledge connections table
CREATE TABLE public.knowledge_connections (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id UUID NOT NULL,
    source_id UUID NOT NULL,
    target_id UUID NOT NULL,
    source_type TEXT NOT NULL,
    target_type TEXT NOT NULL,
    connection_type TEXT NOT NULL DEFAULT 'references'::text,
    strength NUMERIC DEFAULT 1.0,
    notes TEXT,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Newsletter subscriptions table
CREATE TABLE public.newsletter_subscriptions (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    email TEXT NOT NULL,
    subscribed BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Notifications table
CREATE TABLE public.notifications (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id UUID NOT NULL,
    type TEXT NOT NULL,
    title TEXT NOT NULL,
    message TEXT NOT NULL,
    metadata JSONB DEFAULT '{}'::jsonb,
    is_read BOOLEAN DEFAULT false,
    action_url TEXT,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Page analytics table
CREATE TABLE public.page_analytics (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id UUID,
    session_id TEXT,
    page_path TEXT NOT NULL,
    referrer TEXT,
    ip_address INET,
    user_agent TEXT,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Paper categories table
CREATE TABLE public.paper_categories (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    name TEXT NOT NULL,
    description TEXT,
    color TEXT DEFAULT '#3B82F6'::text,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Paper category assignments table
CREATE TABLE public.paper_category_assignments (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    paper_id UUID NOT NULL,
    category_id UUID NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Paper PDF pages table
CREATE TABLE public.paper_pdf_pages (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    paper_id UUID NOT NULL,
    original_pdf_path TEXT NOT NULL,
    pages_folder_path TEXT NOT NULL,
    page_paths TEXT[] NOT NULL DEFAULT '{}'::text[],
    total_pages INTEGER NOT NULL,
    source TEXT NOT NULL DEFAULT 'arxiv'::text,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Paper recommendations table
CREATE TABLE public.paper_recommendations (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id UUID NOT NULL,
    paper_id UUID NOT NULL,
    recommendation_type TEXT NOT NULL,
    score NUMERIC NOT NULL,
    reason TEXT,
    expires_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Paper references table
CREATE TABLE public.paper_references (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    source_paper_id UUID NOT NULL,
    target_paper_id UUID NOT NULL,
    created_by UUID NOT NULL,
    reference_context TEXT,
    annotation_id UUID,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Papers table
CREATE TABLE public.papers (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    title TEXT NOT NULL,
    authors TEXT[],
    abstract TEXT,
    publication_date DATE,
    venue TEXT,
    doi_url TEXT,
    download_url TEXT,
    keywords TEXT[],
    openalex_id TEXT,
    oa_url TEXT,
    type_crossref TEXT,
    institutions TEXT[],
    topics_field TEXT[],
    concepts TEXT[],
    related_works TEXT[],
    event TEXT,
    event_location TEXT,
    event_acronym TEXT,
    container_title TEXT,
    link_pdf TEXT,
    source TEXT DEFAULT 'mindarion'::text,
    extraction_progress JSONB,
    last_accessed TIMESTAMP WITH TIME ZONE,
    is_oa BOOLEAN DEFAULT false,
    cited_by_count INTEGER,
    is_referenced_by_count INTEGER,
    publication_year INTEGER,
    pdf_storage_path TEXT,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- PDF split locks table
CREATE TABLE public.pdf_split_locks (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    lock_key TEXT NOT NULL,
    lock_value TEXT NOT NULL,
    expires_at TIMESTAMP WITH TIME ZONE NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Profiles table
CREATE TABLE public.profiles (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id UUID NOT NULL,
    display_name TEXT,
    email TEXT,
    avatar_url TEXT,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Reading sessions table
CREATE TABLE public.reading_sessions (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id UUID NOT NULL,
    paper_id UUID NOT NULL,
    start_time TIMESTAMP WITH TIME ZONE NOT NULL,
    end_time TIMESTAMP WITH TIME ZONE,
    total_pages INTEGER NOT NULL DEFAULT '-1'::integer,
    pages_read INTEGER[] DEFAULT '{}'::integer[],
    reading_goals TEXT[] DEFAULT '{}'::text[],
    highlights_count INTEGER DEFAULT 0,
    notes_count INTEGER DEFAULT 0,
    comprehension_rating INTEGER,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Reading spaces table
CREATE TABLE public.reading_spaces (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id UUID NOT NULL,
    name TEXT NOT NULL,
    description TEXT,
    color TEXT DEFAULT '#3B82F6'::text,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Referral codes table
CREATE TABLE public.referral_codes (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id UUID NOT NULL,
    code TEXT NOT NULL,
    uses_remaining INTEGER DEFAULT '-1'::integer,
    expires_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Referrals table
CREATE TABLE public.referrals (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    referrer_user_id UUID NOT NULL,
    referred_user_id UUID NOT NULL,
    referral_code TEXT NOT NULL,
    bonus_earned NUMERIC DEFAULT 0.0,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Search analytics table
CREATE TABLE public.search_analytics (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id UUID,
    query TEXT NOT NULL,
    search_type TEXT DEFAULT 'paper'::text,
    result_count INTEGER,
    ip_address INET,
    user_agent TEXT,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Search cache table
CREATE TABLE public.search_cache (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    query_text TEXT NOT NULL,
    query_hash TEXT NOT NULL,
    query TEXT,
    source TEXT DEFAULT 'arxiv'::text,
    sources TEXT[],
    results JSONB,
    result_count INTEGER,
    expires_at TIMESTAMP WITH TIME ZONE,
    last_accessed TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Search history table
CREATE TABLE public.search_history (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id UUID NOT NULL,
    query TEXT NOT NULL,
    filters JSONB,
    results_count INTEGER,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Space invitations table
CREATE TABLE public.space_invitations (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    space_id UUID NOT NULL,
    invited_email TEXT NOT NULL,
    invited_by UUID NOT NULL,
    role TEXT DEFAULT 'viewer'::text,
    status TEXT DEFAULT 'pending'::text,
    expires_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Space members table
CREATE TABLE public.space_members (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    space_id UUID NOT NULL,
    user_id UUID NOT NULL,
    role TEXT DEFAULT 'viewer'::text,
    joined_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Space papers table
CREATE TABLE public.space_papers (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    space_id UUID NOT NULL,
    paper_id UUID NOT NULL,
    added_by UUID NOT NULL,
    added_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Subscribers table
CREATE TABLE public.subscribers (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    email TEXT NOT NULL,
    stripe_customer_id TEXT,
    subscribed BOOLEAN DEFAULT true,
    student_verified BOOLEAN DEFAULT false,
    student_verification_expires TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Support ticket responses table
CREATE TABLE public.support_ticket_responses (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    ticket_id UUID NOT NULL,
    user_id UUID NOT NULL,
    content TEXT NOT NULL,
    is_internal BOOLEAN DEFAULT false,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Support tickets table
CREATE TABLE public.support_tickets (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id UUID NOT NULL,
    subject TEXT NOT NULL,
    description TEXT NOT NULL,
    category TEXT NOT NULL,
    priority TEXT NOT NULL DEFAULT 'medium'::text,
    status TEXT NOT NULL DEFAULT 'open'::text,
    assigned_to UUID,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Tags table
CREATE TABLE public.tags (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id UUID NOT NULL,
    name TEXT NOT NULL,
    color TEXT DEFAULT '#6B7280'::text,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Telegram users table
CREATE TABLE public.telegram_users (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id UUID NOT NULL,
    telegram_id BIGINT NOT NULL,
    telegram_username TEXT,
    telegram_first_name TEXT,
    telegram_last_name TEXT,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Trending papers cache table
CREATE TABLE public.trending_papers_cache (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    paper_id UUID NOT NULL,
    trending_score NUMERIC NOT NULL,
    views_count INTEGER DEFAULT 0,
    saves_count INTEGER DEFAULT 0,
    comments_count INTEGER DEFAULT 0,
    category TEXT,
    expires_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- User documents table
CREATE TABLE public.user_documents (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id UUID NOT NULL,
    title TEXT NOT NULL,
    content TEXT,
    description TEXT,
    document_type TEXT NOT NULL DEFAULT 'note'::text,
    file_url TEXT,
    file_name TEXT,
    file_size INTEGER,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- User engagement metrics table
CREATE TABLE public.user_engagement_metrics (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id UUID NOT NULL,
    engagement_score NUMERIC DEFAULT 0.0,
    papers_read INTEGER DEFAULT 0,
    annotations_created INTEGER DEFAULT 0,
    comments_posted INTEGER DEFAULT 0,
    groups_joined INTEGER DEFAULT 0,
    last_active TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- User library stats table
CREATE TABLE public.user_library_stats (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id UUID NOT NULL,
    papers_count INTEGER DEFAULT 0,
    annotations_count INTEGER DEFAULT 0,
    documents_count INTEGER DEFAULT 0,
    connections_count INTEGER DEFAULT 0,
    spaces_count INTEGER DEFAULT 0,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- User paper files table
CREATE TABLE public.user_paper_files (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id UUID NOT NULL,
    paper_id UUID NOT NULL,
    source TEXT NOT NULL,
    storage_path TEXT NOT NULL,
    file_size BIGINT,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- User preferences table
CREATE TABLE public.user_preferences (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id UUID NOT NULL,
    theme TEXT DEFAULT 'light'::text,
    language TEXT DEFAULT 'en'::text,
    notifications_enabled BOOLEAN DEFAULT true,
    email_notifications BOOLEAN DEFAULT true,
    reading_preferences JSONB DEFAULT '{}'::jsonb,
    search_preferences JSONB DEFAULT '{}'::jsonb,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- User roles table
CREATE TABLE public.user_roles (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id UUID NOT NULL,
    role app_role NOT NULL DEFAULT 'user'::app_role,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- User usage tracking table
CREATE TABLE public.user_usage_tracking (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id UUID NOT NULL,
    usage_type TEXT NOT NULL,
    date DATE NOT NULL DEFAULT CURRENT_DATE,
    count INTEGER DEFAULT 1,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Unique constraints
ALTER TABLE public.auth_tokens ADD CONSTRAINT auth_tokens_token_key UNIQUE (token);
ALTER TABLE public.pdf_split_locks ADD CONSTRAINT pdf_split_locks_lock_key_key UNIQUE (lock_key);
ALTER TABLE public.profiles ADD CONSTRAINT profiles_user_id_key UNIQUE (user_id);
ALTER TABLE public.telegram_users ADD CONSTRAINT telegram_users_user_id_key UNIQUE (user_id);
ALTER TABLE public.telegram_users ADD CONSTRAINT telegram_users_telegram_id_key UNIQUE (telegram_id);

-- Enable Row Level Security
ALTER TABLE public.academic_discount_verifications ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.admin_audit_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.annotation_tags ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.annotations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.auth_tokens ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.consent_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.data_subject_requests ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.deposit_requests ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.dmca_takedown_requests ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.enterprise_leads ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.knowledge_connections ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.newsletter_subscriptions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.page_analytics ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.paper_categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.paper_category_assignments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.paper_pdf_pages ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.paper_recommendations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.paper_references ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.papers ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.pdf_split_locks ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.reading_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.reading_spaces ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.referral_codes ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.referrals ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.search_analytics ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.search_cache ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.search_history ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.space_invitations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.space_members ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.space_papers ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.subscribers ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.support_ticket_responses ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.support_tickets ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.tags ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.telegram_users ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.trending_papers_cache ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_documents ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_engagement_metrics ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_library_stats ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_paper_files ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_preferences ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_usage_tracking ENABLE ROW LEVEL SECURITY;

-- Storage buckets
INSERT INTO storage.buckets (id, name, public) VALUES ('papers', 'papers', false);
INSERT INTO storage.buckets (id, name, public) VALUES ('receipts', 'receipts', false);
INSERT INTO storage.buckets (id, name, public) VALUES ('avatars', 'avatars', true);