-- Row Level Security Policies
-- Project: xonxdkvdbjmxawdyeemt

-- Annotations policies
CREATE POLICY "Users can view their own annotations and public annotations" 
ON public.annotations 
FOR SELECT 
USING ((auth.uid() = user_id) OR (is_public = true));

CREATE POLICY "Users can create their own annotations" 
ON public.annotations 
FOR INSERT 
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own annotations" 
ON public.annotations 
FOR UPDATE 
USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own annotations" 
ON public.annotations 
FOR DELETE 
USING (auth.uid() = user_id);

-- Auth tokens policies
CREATE POLICY "Service role can manage auth tokens" 
ON public.auth_tokens 
FOR ALL 
USING (auth.role() = 'service_role'::text);

CREATE POLICY "Users can view their own auth tokens" 
ON public.auth_tokens 
FOR SELECT 
USING (auth.uid() = user_id);

-- Telegram users policies
CREATE POLICY "Service role can manage telegram users" 
ON public.telegram_users 
FOR ALL 
USING (auth.role() = 'service_role'::text);

CREATE POLICY "Users can view their own telegram data" 
ON public.telegram_users 
FOR SELECT 
USING (auth.uid() = user_id);

-- Profiles policies
CREATE POLICY "Users can view their own profile" 
ON public.profiles 
FOR SELECT 
USING (auth.uid() = user_id);

CREATE POLICY "Users can update their own profile" 
ON public.profiles 
FOR UPDATE 
USING (auth.uid() = user_id);

-- Deposit requests policies
CREATE POLICY "Users can view their own deposit requests" 
ON public.deposit_requests 
FOR SELECT 
USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own deposit requests" 
ON public.deposit_requests 
FOR INSERT 
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Service role can manage deposit requests" 
ON public.deposit_requests 
FOR ALL 
USING (auth.role() = 'service_role'::text);

-- Papers policies
CREATE POLICY "Anyone can view papers" 
ON public.papers 
FOR SELECT 
USING (true);

CREATE POLICY "Authenticated users can create papers" 
ON public.papers 
FOR INSERT 
WITH CHECK (auth.role() = 'authenticated'::text);

-- PDF pages policies
CREATE POLICY "Anyone can view page metadata" 
ON public.paper_pdf_pages 
FOR SELECT 
USING (true);

-- Reading spaces policies
CREATE POLICY "Users can manage their own reading spaces" 
ON public.reading_spaces 
FOR ALL 
USING (auth.uid() = user_id);

-- Space papers policies
CREATE POLICY "Users can view papers in their spaces" 
ON public.space_papers 
FOR SELECT 
USING (EXISTS (
  SELECT 1 FROM reading_spaces 
  WHERE reading_spaces.id = space_papers.space_id 
  AND reading_spaces.user_id = auth.uid()
));

-- Reading sessions policies
CREATE POLICY "Users can manage their own reading sessions" 
ON public.reading_sessions 
FOR ALL 
USING (auth.uid() = user_id);

-- Tags policies
CREATE POLICY "Users can manage their own tags" 
ON public.tags 
FOR ALL 
USING (auth.uid() = user_id);

-- User roles policies
CREATE POLICY "Users can view their own roles" 
ON public.user_roles 
FOR SELECT 
USING (auth.uid() = user_id);

-- User paper files policies
CREATE POLICY "Users can view their own paper files" 
ON public.user_paper_files 
FOR ALL 
USING (auth.uid() = user_id);

-- PDF split locks policies
CREATE POLICY "Service role can manage locks" 
ON public.pdf_split_locks 
FOR ALL 
USING (auth.role() = 'service_role'::text);

-- Storage policies for papers bucket
CREATE POLICY "Service role can manage papers storage" 
ON storage.objects 
FOR ALL 
USING (bucket_id = 'papers' AND auth.role() = 'service_role'::text);

CREATE POLICY "Authenticated users can view papers" 
ON storage.objects 
FOR SELECT 
USING (bucket_id = 'papers' AND auth.uid() IS NOT NULL);

-- Storage policies for receipts bucket
CREATE POLICY "Service role can manage receipts storage" 
ON storage.objects 
FOR ALL 
USING (bucket_id = 'receipts' AND auth.role() = 'service_role'::text);

-- Storage policies for avatars bucket
CREATE POLICY "Anyone can view avatars" 
ON storage.objects 
FOR SELECT 
USING (bucket_id = 'avatars');

CREATE POLICY "Service role can manage avatars storage" 
ON storage.objects 
FOR ALL 
USING (bucket_id = 'avatars' AND auth.role() = 'service_role'::text);