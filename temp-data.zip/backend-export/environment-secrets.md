# Environment Secrets and Configuration

## Required Secrets
These secrets need to be configured in your Supabase project:

### API Keys
- `OPENAI_API_KEY` - OpenAI API key for AI functionality
- `GEMINI_API_KEY` - Google Gemini API key
- `RESEND_API_KEY` - Resend API key for email sending

### Authentication
- `ADMIN_PASSWORD` - Admin authentication password
- `ADMIN_TOKEN_SECRET` - Secret for admin token generation
- `TELEGRAM_BOT_TOKEN` - Telegram bot authentication token
- `TELEGRAM_ADMIN_BOT_TOKEN` - Telegram admin bot token

### Payment Processing
- `STRIPE_SECRET_KEY` - Stripe secret key for payments

### Supabase Configuration
- `SUPABASE_URL` - Your Supabase project URL
- `SUPABASE_ANON_KEY` - Supabase anonymous key
- `SUPABASE_PUBLISHABLE_KEY` - Supabase publishable key
- `SUPABASE_SERVICE_ROLE_KEY` - Supabase service role key
- `SUPABASE_DB_URL` - Direct database connection URL

## Project Configuration
- Project ID: `xonxdkvdbjmxawdyeemt`
- Project URL: `https://xonxdkvdbjmxawdyeemt.supabase.co`

## Frontend Environment Variables
```env
VITE_SUPABASE_PROJECT_ID="xonxdkvdbjmxawdyeemt"
VITE_SUPABASE_PUBLISHABLE_KEY="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Inhvbnhka3ZkYmpteGF3ZHllZW10Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTY0NzkyODQsImV4cCI6MjA3MjA1NTI4NH0.kF2_FKaRXDsNViUM3QTq3VD777I2kwaQCy0M58uIJ58"
VITE_SUPABASE_URL="https://xonxdkvdbjmxawdyeemt.supabase.co"
```