# Backend Export - Complete Project Backup

This directory contains a complete export of all backend components from the Supabase project.

## Contents

### Database
- `database-schema.sql` - Complete database schema with all tables and types
- `database-functions.sql` - All custom database functions
- `rls-policies.sql` - Row Level Security policies
- `triggers.sql` - Database triggers

### Edge Functions
- `edge-functions/telegram-bot.ts` - Telegram bot edge function
- `edge-functions/create-deposit-request.ts` - Deposit request creation function
- `edge-functions/manage-deposit-request.ts` - Deposit request management function
- `edge-functions/webhook-setup.ts` - Webhook setup function

### Configuration
- `supabase-config.toml` - Supabase project configuration
- `environment-secrets.md` - List of required environment variables and secrets

## Deployment Instructions

### 1. Local Development Setup

1. Install Supabase CLI:
```bash
npm install -g supabase
```

2. Initialize new Supabase project:
```bash
supabase init
```

3. Replace the generated files with exported ones:
```bash
cp backend-export/supabase-config.toml supabase/config.toml
cp -r backend-export/edge-functions/* supabase/functions/
```

4. Start local development:
```bash
supabase start
```

5. Apply database schema:
```bash
psql -h localhost -p 54322 -U postgres -d postgres -f backend-export/database-schema.sql
psql -h localhost -p 54322 -U postgres -d postgres -f backend-export/database-functions.sql
psql -h localhost -p 54322 -U postgres -d postgres -f backend-export/rls-policies.sql
```

### 2. Production Deployment

1. Create new Supabase project at https://supabase.com

2. Set up secrets in Supabase dashboard:
   - Go to Project Settings > Edge Functions
   - Add all secrets listed in `environment-secrets.md`

3. Deploy edge functions:
```bash
supabase functions deploy telegram-bot --project-ref YOUR_PROJECT_REF
supabase functions deploy create-deposit-request --project-ref YOUR_PROJECT_REF
supabase functions deploy manage-deposit-request --project-ref YOUR_PROJECT_REF
supabase functions deploy webhook-setup --project-ref YOUR_PROJECT_REF
```

4. Run database migrations in SQL Editor:
   - Copy and execute `database-schema.sql`
   - Copy and execute `database-functions.sql`
   - Copy and execute `rls-policies.sql`

### 3. Storage Setup

1. Create storage buckets in Supabase dashboard:
   - `papers` (private bucket)
   - `receipts` (private bucket)
   - `avatars` (public bucket)

2. Apply storage policies (included in rls-policies.sql)

## Database Statistics

- **Total Tables**: 43
- **Main Tables**:
  - `papers` (~500 records)
  - `profiles` (~5 records)
  - `auth_tokens` (dynamic)
  - `telegram_users` (dynamic)
  - `deposit_requests` (dynamic)
  - `annotations` (dynamic)
  - `reading_sessions` (dynamic)

- **Functions**: 20+ custom functions
- **Storage Buckets**: 3 (papers, receipts, avatars)
- **Edge Functions**: 4 (telegram-bot, create-deposit-request, manage-deposit-request, webhook-setup)

## Security Notes

- All tables have Row Level Security (RLS) enabled
- Admin functions require special authentication
- Storage buckets have appropriate access policies
- Secrets are managed through Supabase's secret management system

## Migration Notes

- Replace all project references (xonxdkvdbjmxawdyeemt) with your new project ID
- Update environment variables in your frontend application
- Test all authentication flows after migration
- Verify edge function deployments
- Check storage bucket access and policies

## Support

For issues with the backup or deployment, check:
1. Supabase logs in the dashboard
2. Edge function logs
3. Database connection and permissions
4. RLS policy conflicts