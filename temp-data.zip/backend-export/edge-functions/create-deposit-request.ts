import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type, x-telegram-id',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
  'Access-Control-Max-Age': '86400',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    console.log('=== CREATE DEPOSIT REQUEST START ===');
    console.log('Request method:', req.method);
    console.log('Request headers:', Object.fromEntries(req.headers.entries()));
    
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    
    console.log('Environment check:');
    console.log('- SUPABASE_URL:', supabaseUrl ? 'SET' : 'MISSING');
    console.log('- SUPABASE_SERVICE_ROLE_KEY:', supabaseKey ? 'SET' : 'MISSING');
    console.log('- TELEGRAM_BOT_TOKEN:', Deno.env.get('TELEGRAM_BOT_TOKEN') ? 'SET' : 'MISSING');
    
    // Use service role key to bypass RLS
    const supabase = createClient(supabaseUrl, supabaseKey, {
      auth: {
        autoRefreshToken: false,
        persistSession: false
      }
    });
    console.log('Supabase client created with service role');
    
    let userId: string | null = null;
    const authHeader = req.headers.get('Authorization');
    const telegramIdHeader = req.headers.get('x-telegram-id');

    // Process authentication
    if (authHeader?.includes('telegram_session') && telegramIdHeader) {
      let telegramId: number;
      try {
        // Принудительное преобразование из любого формата (включая научную нотацию) в целое число
        const numericValue = parseFloat(telegramIdHeader);
        if (isNaN(numericValue) || numericValue <= 0) {
          throw new Error('Invalid telegram ID format');
        }
        telegramId = Math.floor(numericValue); // Убираем дробную часть если есть
        console.log(`Converted telegram_id from ${telegramIdHeader} to ${telegramId}`);
      } catch (error) {
        return new Response(JSON.stringify({ 
          error: 'Invalid Telegram ID format',
          details: `Received: ${telegramIdHeader}` 
        }), { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
      }
      
      // Look up user by telegram_id
      const { data: telegramUser, error: telegramError } = await supabase
        .from('telegram_users')
        .select('user_id')
        .eq('telegram_id', telegramId)
        .maybeSingle();
      
      if (telegramError) {
        console.error('Error querying telegram_users:', telegramError);
        return new Response(JSON.stringify({ error: 'Database error' }), { 
          status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        });
      }
      
      if (telegramUser?.user_id) {
        userId = telegramUser.user_id;
      } else {
        // Try fallback search in auth_tokens
        const { data: authToken, error: tokenError } = await supabase
          .from('auth_tokens')
          .select('user_id')
          .eq('telegram_id', telegramId)
          .maybeSingle();
        
        if (authToken?.user_id) {
          userId = authToken.user_id;
        } else {
          return new Response(JSON.stringify({ error: 'User not found' }), { 
            status: 404, headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
          });
        }
      }
      
    } else if (authHeader?.startsWith('Bearer ') && !authHeader?.includes('telegram_session')) {
      // Handle Supabase JWT token
      const { data: { user }, error: authError } = await supabase.auth.getUser(authHeader.replace('Bearer ', ''));
      
      if (authError || !user) {
        return new Response(JSON.stringify({ 
          error: 'Invalid authentication token',
          details: authError?.message 
        }), { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
      }
      
      userId = user.id;
      
    } else {
      return new Response(JSON.stringify({ 
        error: 'No valid authorization header found'
      }), { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
    }

    // Parse request data
    console.log('=== PARSING REQUEST DATA ===');
    const formData = await req.formData();
    console.log('FormData keys:', Array.from(formData.keys()));
    
    const amount = formData.get('amount') as string;
    const receipt = formData.get('receipt') as File;
    
    console.log('Parsed data:');
    console.log('- amount:', amount);
    console.log('- receipt:', receipt ? `${receipt.name} (${receipt.size} bytes, ${receipt.type})` : 'NULL');

    // Validate data
    if (!amount || !receipt) {
      return new Response(JSON.stringify({ 
        error: 'Missing required fields: amount and receipt'
      }), { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
    }

    const numericAmount = parseFloat(amount);
    if (isNaN(numericAmount) || numericAmount <= 0) {
      return new Response(JSON.stringify({ 
        error: 'Invalid amount'
      }), { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
    }

    // Validate file
    if (!['image/jpeg', 'image/jpg', 'image/png', 'image/webp'].includes(receipt.type)) {
      return new Response(JSON.stringify({ 
        error: 'Invalid file type. Only images are allowed.'
      }), { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
    }

    if (receipt.size > 5 * 1024 * 1024) { // 5MB
      return new Response(JSON.stringify({ 
        error: 'File too large. Maximum size is 5MB.'
      }), { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
    }

    // Upload receipt to storage
    const fileExt = receipt.name.split('.').pop() || 'jpg';
    const fileName = `${userId}_${Date.now()}.${fileExt}`;
    const filePath = `receipts/${fileName}`;

    const { data: uploadData, error: uploadError } = await supabase.storage
      .from('receipts')
      .upload(filePath, receipt, {
        contentType: receipt.type,
        upsert: false
      });

    if (uploadError) {
      console.error('Upload error:', uploadError);
      return new Response(JSON.stringify({ 
        error: 'Failed to upload receipt',
        details: uploadError.message 
      }), { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
    }

    // Get public URL for the uploaded file
    const { data: { publicUrl } } = supabase.storage
      .from('receipts')
      .getPublicUrl(filePath);

    // Create deposit request
    console.log('=== CREATING DEPOSIT REQUEST ===');
    console.log('Insert data:');
    console.log('- user_id:', userId);
    console.log('- amount:', numericAmount);
    console.log('- receipt_image_url:', publicUrl);
    console.log('- status: pending');
    
    const { data: depositRequest, error: depositError } = await supabase
      .from('deposit_requests')
      .insert({
        user_id: userId,
        amount: numericAmount,
        receipt_image_url: publicUrl,
        status: 'pending'
      })
      .select()
      .single();
    
    console.log('Database insert result:');
    console.log('- data:', depositRequest);
    console.log('- error:', depositError);

    if (depositError) {
      console.error('=== DEPOSIT CREATION FAILED ===');
      console.error('Error details:', JSON.stringify(depositError, null, 2));
      console.error('Error code:', depositError.code);
      console.error('Error message:', depositError.message);
      console.error('Error hint:', depositError.hint);
      return new Response(JSON.stringify({ 
        error: 'Failed to create deposit request',
        details: depositError.message,
        code: depositError.code,
        hint: depositError.hint
      }), { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
    }
    
    console.log('=== DEPOSIT REQUEST CREATED SUCCESSFULLY ===');
    console.log('Created deposit request:', JSON.stringify(depositRequest, null, 2));

    // Send notification to admin via Telegram bot
    const telegramBotToken = Deno.env.get('TELEGRAM_BOT_TOKEN');
    const adminTelegramIds = ['7260860474']; // Admin IDs

    if (telegramBotToken && adminTelegramIds.length > 0) {
      const message = `🔔 Новый запрос на пополнение баланса

💰 Сумма: ${numericAmount} руб.
👤 Пользователь ID: ${userId}
📅 Время: ${new Date().toLocaleString('ru-RU')}
🆔 ID запроса: ${depositRequest.id}

Требует проверки администратора.`;

      const keyboard = {
        inline_keyboard: [
          [
            { text: "✅ Одобрить", callback_data: `approve_${depositRequest.id}` },
            { text: "❌ Отклонить", callback_data: `reject_${depositRequest.id}` }
          ],
          [
            { text: "📋 Подробнее", callback_data: `details_${depositRequest.id}` }
          ]
        ]
      };

      // Send message and photo to each admin
      for (const adminId of adminTelegramIds) {
        try {
          // Send the message first
          await fetch(`https://api.telegram.org/bot${telegramBotToken}/sendMessage`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              chat_id: adminId,
              text: message,
              reply_markup: keyboard,
              parse_mode: 'HTML'
            }),
          });

          // Send the receipt photo
          await fetch(`https://api.telegram.org/bot${telegramBotToken}/sendPhoto`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              chat_id: adminId,
              photo: publicUrl,
              caption: `Чек к запросу #${depositRequest.id}`
            }),
          });
        } catch (error) {
          console.error(`Failed to send Telegram notification to admin ${adminId}:`, error);
        }
      }
    }

    console.log('Deposit request created successfully:', depositRequest.id);

    return new Response(JSON.stringify({
      success: true,
      data: depositRequest
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });

  } catch (error) {
    console.error('=== UNEXPECTED ERROR ===');
    console.error('Error type:', typeof error);
    console.error('Error name:', error.name);
    console.error('Error message:', error.message);
    console.error('Error stack:', error.stack);
    console.error('Full error object:', JSON.stringify(error, Object.getOwnPropertyNames(error)));
    
    return new Response(JSON.stringify({ 
      error: 'Internal server error',
      details: error.message,
      stack: error.stack 
    }), { 
      status: 500, 
      headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
    });
  }
});