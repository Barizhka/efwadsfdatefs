import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
const telegramBotToken = Deno.env.get('TELEGRAM_BOT_TOKEN')!;

const supabase = createClient(supabaseUrl, supabaseKey);

// Автоматическая установка webhook при старте
async function setupWebhookIfNeeded() {
  try {
    const webhookUrl = 'https://xonxdkvdbjmxawdyeemt.supabase.co/functions/v1/telegram-bot';
    
    // Проверяем текущий webhook
    const checkResponse = await fetch(`https://api.telegram.org/bot${telegramBotToken}/getWebhookInfo`);
    const webhookInfo = await checkResponse.json();
    
    console.log('Current webhook info:', webhookInfo);
    
    // Если webhook не установлен или неправильный, устанавливаем
    if (!webhookInfo.result?.url || webhookInfo.result.url !== webhookUrl) {
      console.log('Setting up webhook:', webhookUrl);
      
      const setResponse = await fetch(`https://api.telegram.org/bot${telegramBotToken}/setWebhook`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          url: webhookUrl
        }),
      });
      
      const result = await setResponse.json();
      console.log('Webhook setup result:', result);
      
      if (result.ok) {
        console.log('✅ Webhook successfully configured');
      } else {
        console.error('❌ Failed to configure webhook:', result);
      }
    } else {
      console.log('✅ Webhook already configured correctly');
    }
  } catch (error) {
    console.error('Error checking/setting webhook:', error);
  }
}

// Запускаем установку webhook при старте
setupWebhookIfNeeded();

interface TelegramUpdate {
  update_id: number;
  message?: {
    message_id: number;
    from: {
      id: number;
      is_bot: boolean;
      first_name: string;
      last_name?: string;
      username?: string;
    };
    chat: {
      id: number;
      type: string;
    };
    text?: string;
  };
  callback_query?: {
    id: string;
    from: { id: number; username?: string; first_name?: string };
    message?: { message_id: number; chat: { id: number }; caption?: string };
    data?: string;
  };
}

async function sendTelegramMessage(chatId: number, text: string, replyMarkup?: any) {
  try {
    const response = await fetch(`https://api.telegram.org/bot${telegramBotToken}/sendMessage`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        chat_id: chatId,
        text,
        parse_mode: 'HTML',
        reply_markup: replyMarkup,
      }),
    });
    
    const result = await response.json();
    
    if (!result.ok) {
      console.error('Telegram API error:', result);
    }
    
    return result;
  } catch (error) {
    console.error('Error sending telegram message:', error);
    return { ok: false, error: error.message };
  }
}

async function handleStartCommand(chatId: number, userId: number, firstName: string, lastName?: string, username?: string, startParam?: string) {
  console.log('Handling start command:', { chatId, userId, firstName, startParam });
  
  try {
    if (!startParam) {
      const message = `🔐 Добро пожаловать в Splitter!\n\n` +
        `Это единственный способ авторизации в приложении.\n\n` +
        `Для входа в систему перейдите на сайт и нажмите кнопку "Войти через Telegram".`;
      
      await sendTelegramMessage(chatId, message);
      return;
    }

    // Обрабатываем токен авторизации через новую функцию
    console.log('Processing telegram auth with params:', {
      auth_token: startParam,
      tg_id: userId,
      tg_username: username,
      tg_first_name: firstName,
      tg_last_name: lastName
    });

    const { data, error } = await supabase.rpc('process_telegram_auth_v2', {
      auth_token: startParam,
      tg_id: parseInt(userId.toString()), // Принудительное преобразование к целому числу
      tg_username: username || null,
      tg_first_name: firstName,
      tg_last_name: lastName || null
    });

    console.log('RPC response:', { data, error });

    if (error) {
      console.error('Error processing telegram auth:', error);
      await sendTelegramMessage(chatId, `❌ Ошибка авторизации: ${error.message}. Попробуйте снова.`);
      return;
    }

    if (data?.success) {
      // Если это новый пользователь, создаем реального пользователя Supabase
      if (data.is_new_user) {
        console.log('Creating new Supabase user for Telegram user:', userId);
        
        try {
          // Сначала проверяем, существует ли пользователь с таким email
          const { data: existingUsers, error: listError } = await supabase.auth.admin.listUsers();
          
          let newUser = null;
          let createError = null;
          
          if (listError) {
            console.error('Error listing users:', listError);
            await sendTelegramMessage(chatId, '❌ Ошибка проверки пользователей. Попробуйте позже.');
            return;
          }
          
          // Ищем существующего пользователя по email
          const existingUser = existingUsers.users.find(u => u.email === data.email);
          
          if (existingUser) {
            console.log('User already exists, using existing user:', existingUser.id);
            newUser = { user: existingUser };
          } else {
            // Создаем нового пользователя только если его нет
            const createResult = await supabase.auth.admin.createUser({
              email: data.email,
              password: crypto.randomUUID(), // Случайный пароль, не будет использоваться
              email_confirm: true,
              user_metadata: {
                telegram_id: parseInt(userId.toString()),
                telegram_username: username,
                telegram_first_name: firstName,
                telegram_last_name: lastName,
                display_name: data.display_name
              }
            });
            
            newUser = createResult.data;
            createError = createResult.error;
            
            if (createError) {
              console.error('Error creating Supabase user:', createError);
              await sendTelegramMessage(chatId, '❌ Ошибка создания аккаунта. Попробуйте позже.');
              return;
            }
          }

          console.log('New Supabase user created:', newUser.user?.id);

          // Создаем или обновляем запись в telegram_users
          const { error: telegramUpdateError } = await supabase
            .from('telegram_users')
            .upsert({
              user_id: newUser.user!.id,
              telegram_id: parseInt(userId.toString()), // Принудительное преобразование к целому числу
              telegram_username: username || null,
              telegram_first_name: firstName,
              telegram_last_name: lastName || null,
              created_at: new Date().toISOString(),
              updated_at: new Date().toISOString()
            }, { 
              onConflict: 'telegram_id'
            });

          if (telegramUpdateError) {
            console.error('Error creating/updating telegram_users:', telegramUpdateError);
          }

          // Обновляем profiles
          const { error: profileUpdateError } = await supabase
            .from('profiles')
            .upsert({
              user_id: newUser.user!.id,
              email: data.email,
              display_name: data.display_name
            });

          if (profileUpdateError) {
            console.error('Error updating profile:', profileUpdateError);
          }

          // Обновляем токен как использованный и связываем с пользователем
          const { error: authTokenError } = await supabase
            .from('auth_tokens')
            .update({ 
              user_id: newUser.user!.id,
              used_at: new Date().toISOString()
            })
            .eq('token', startParam);

          if (authTokenError) {
            console.error('Error updating auth token:', authTokenError);
          }

          const message = `🎉 Добро пожаловать в Splitter!\n\n` +
            `✅ Ваш аккаунт успешно создан\n` +
            `👤 Имя: ${data.display_name}\n\n` +
            `Теперь вы можете использовать все функции приложения!`;
          
          const keyboard = {
            inline_keyboard: [[
              { text: '🌐 Перейти на сайт', url: 'https://preview--resurrect-my-site.lovable.app/' }
            ]]
          };
          
          await sendTelegramMessage(chatId, message, keyboard);

        } catch (error) {
          console.error('Error in user creation process:', error);
          await sendTelegramMessage(chatId, '❌ Ошибка создания аккаунта. Попробуйте позже.');
          return;
        }
      } else {
        // Существующий пользователь
        const message = `🎉 С возвращением!\n\n` +
          `✅ Вы успешно авторизованы\n` +
          `👤 ${data.display_name}\n\n` +
          `Добро пожаловать обратно в Splitter!`;
        
        const keyboard = {
          inline_keyboard: [[
            { text: '🌐 Перейти на сайт', url: 'https://preview--resurrect-my-site.lovable.app/' }
          ]]
        };
        
        await sendTelegramMessage(chatId, message, keyboard);
      }
    } else {
      await sendTelegramMessage(chatId, `❌ ${data?.message || 'Ошибка авторизации'}`);
    }
  } catch (error) {
    console.error('Error in handleStartCommand:', error);
    try {
      await sendTelegramMessage(chatId, '❌ Произошла ошибка. Попробуйте снова.');
    } catch (sendError) {
      console.error('Failed to send error message:', sendError);
    }
  }
}

// Переменная для отслеживания админ-режима для каждого пользователя
const adminUsers = new Set<number>();

async function handleAccountCommand(chatId: number, userId: number) {
  try {
    // Получаем информацию о пользователе
    const { data: telegramUser, error } = await supabase
      .from('telegram_users')
      .select('user_id, telegram_username')
      .eq('telegram_id', parseInt(userId.toString()))
      .maybeSingle();

    if (error || !telegramUser) {
      await sendTelegramMessage(chatId, '❌ Пользователь не найден. Сначала авторизуйтесь на сайте.');
      return;
    }

    let message = `👤 Информация об аккаунте\n\n`;
    message += `🆔 Telegram: @${telegramUser.telegram_username || 'не указан'}\n`;

    const keyboard = {
      inline_keyboard: [
        [{ text: '🌐 Открыть сайт', url: 'https://preview--resurrect-my-site.lovable.app/' }],
        [{ text: '📞 Поддержка', callback_data: 'support' }]
      ]
    };

    await sendTelegramMessage(chatId, message, keyboard);
  } catch (error) {
    console.error('Error in handleAccountCommand:', error);
    await sendTelegramMessage(chatId, '❌ Ошибка получения информации об аккаунте.');
  }
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const url = new URL(req.url);
    
    console.log('Incoming request:', req.method, url.pathname);

    // Обработка POST запросов
    if (req.method === 'POST') {
      const body = await req.text();
      console.log('POST request body:', body);
      
      try {
        const parsedBody = JSON.parse(body);
        
        // Проверяем, что это Telegram webhook (есть update_id)
        if (parsedBody.update_id !== undefined) {
          const update: TelegramUpdate = parsedBody;
          console.log('Received webhook:', JSON.stringify(update, null, 2));

          // Обработка callback query (для админ функций)
          if (update.callback_query) {
            console.log('Processing callback query');
            return new Response('OK', { status: 200 });
          }

          if (!update.message) {
            return new Response('OK', { status: 200 });
          }

          const { message } = update;
          const chatId = message.chat.id;
          const userId = message.from.id;
          const firstName = message.from.first_name;
          const lastName = message.from.last_name;
          const username = message.from.username;
          const text = message.text || '';

          try {
            if (text.startsWith('/start')) {
              const startParam = text.split(' ')[1];
              await handleStartCommand(chatId, userId, firstName, lastName, username, startParam);
            } else if (text === '/account' || text === '/аккаунт') {
              await handleAccountCommand(chatId, userId);
            } else if (text === '/help' || text === '/помощь') {
              const helpMessage = `🤖 Бот yasplit.ai\n\n` +
                `📋 Доступные команды:\n` +
                `/start - начать работу с ботом\n` +
                `/account - информация об аккаунте\n` +
                `/help - это сообщение\n\n` +
                `💡 Для авторизации в приложении перейдите на сайт и нажмите "Войти через Telegram"`;
              
              await sendTelegramMessage(chatId, helpMessage);
            } else {
              // Проверяем, является ли сообщение секретным кодом для админ-панели
              if (text === 'FDGSFHDSJ7736' || text === '!admin') {
                // Проверяем, является ли пользователь администратором
                const isAdmin = username === 'phantasmgg' || username === 'grevsplitatp';
                
                if (isAdmin) {
                  const adminMessage = `🔐 Админ-панель активирована\n\n` +
                    `👤 Администратор: @${username}\n` +
                    `🆔 ID: ${userId}\n\n` +
                    `📋 Доступные команды:\n` +
                    `/admin_stats - статистика системы\n` +
                    `/admin_users - управление пользователями\n` +
                    `/admin_deposits - заявки на депозиты\n` +
                    `/admin_help - помощь по админке`;
                  
                  const adminKeyboard = {
                    inline_keyboard: [
                      [{ text: '📊 Статистика', callback_data: 'admin_stats' }],
                      [{ text: '👥 Пользователи', callback_data: 'admin_users' }],
                      [{ text: '💰 Депозиты', callback_data: 'admin_deposits' }],
                      [{ text: '🌐 Открыть сайт', url: 'https://preview--resurrect-my-site.lovable.app/' }]
                    ]
                  };
                  
                  await sendTelegramMessage(chatId, adminMessage, adminKeyboard);
                } else {
                  await sendTelegramMessage(chatId, '❌ У вас нет прав доступа к админ-панели.');
                }
              } else {
                // Обработка обычных неизвестных команд/сообщений
                await sendTelegramMessage(chatId, '🤖 Привет! Я бот yasplit.ai.\n\n📋 Доступные команды:\n/start - начать\n/account - информация об аккаунте\n/help - помощь\n\n💡 Для авторизации перейдите на сайт.');
              }
            }
          } catch (messageError) {
            console.error('Error processing message:', messageError);
            try {
              await sendTelegramMessage(chatId, '❌ Произошла ошибка при обработке вашего сообщения. Попробуйте позже.');
            } catch (sendError) {
              console.error('Failed to send error message:', sendError);
            }
          }
          
          // Обязательно возвращаем ответ Telegram
          return new Response('OK', { status: 200 });
        }
        
        // Если это не webhook, то это API вызов
        const { action } = parsedBody;
        
        if (action === 'generate-token') {
          console.log('Generating auth token...');
          
          const token = crypto.randomUUID();
          const expiresAt = new Date(Date.now() + 10 * 60 * 1000); // 10 минут
          
          const { error } = await supabase
            .from('auth_tokens')
            .insert({
              token,
              expires_at: expiresAt.toISOString(),
              used: false
            });
          
          if (error) {
            console.error('Error creating auth token:', error);
            return new Response(JSON.stringify({ error: 'Failed to create token' }), {
              status: 500,
              headers: { ...corsHeaders, 'Content-Type': 'application/json' }
            });
          }
          
          const deepLinkUrl = `https://t.me/yasplitai_bot?start=${token}`;
          
          return new Response(JSON.stringify({
            token,
            expires_at: expiresAt.toISOString(),
            telegram_url: deepLinkUrl
          }), {
            headers: { ...corsHeaders, 'Content-Type': 'application/json' }
          });
        }
        
        if (action === 'check-token') {
          const { token } = parsedBody;
          console.log('Checking token:', token);
          
          if (!token) {
            return new Response(JSON.stringify({ error: 'Token is required' }), {
              status: 400,
              headers: { ...corsHeaders, 'Content-Type': 'application/json' }
            });
          }
          
          const { data: tokenData, error } = await supabase
            .from('auth_tokens')
            .select('*')
            .eq('token', token)
            .maybeSingle();
          
          if (error) {
            console.error('Error checking token:', error);
            return new Response(JSON.stringify({ error: 'Database error' }), {
              status: 500,
              headers: { ...corsHeaders, 'Content-Type': 'application/json' }
            });
          }
          
          if (!tokenData) {
            return new Response(JSON.stringify({ 
              authenticated: false, 
              error: 'Token not found' 
            }), {
              headers: { ...corsHeaders, 'Content-Type': 'application/json' }
            });
          }
          
          // Проверяем, не истек ли токен
          if (new Date(tokenData.expires_at) < new Date()) {
            return new Response(JSON.stringify({ 
              authenticated: false, 
              error: 'Token expired' 
            }), {
              headers: { ...corsHeaders, 'Content-Type': 'application/json' }
            });
          }
          
          // Проверяем, был ли токен уже использован
          if (tokenData.used) {
            // Если токен использован и связан с пользователем, возвращаем информацию о пользователе
            if (tokenData.user_id) {
              const { data: userData, error: userError } = await supabase
                .from('telegram_users')
                .select('*')
                .eq('user_id', tokenData.user_id)
                .maybeSingle();
              
              if (!userError && userData) {
                const displayName = [userData.telegram_first_name, userData.telegram_last_name]
                  .filter(Boolean)
                  .join(' ') || userData.telegram_username || 'Пользователь';
                
                return new Response(JSON.stringify({
                  authenticated: true,
                  user_id: tokenData.user_id,
                  telegram_id: userData.telegram_id,
                  display_name: displayName,
                  telegram_username: userData.telegram_username,
                  telegram_first_name: userData.telegram_first_name,
                  telegram_last_name: userData.telegram_last_name
                }), {
                  headers: { ...corsHeaders, 'Content-Type': 'application/json' }
                });
              }
            }
            
            return new Response(JSON.stringify({ 
              authenticated: false, 
              error: 'Token already used' 
            }), {
              headers: { ...corsHeaders, 'Content-Type': 'application/json' }
            });
          }
          
          // Токен действителен, но еще не использован
          return new Response(JSON.stringify({ 
            authenticated: false, 
            pending: true,
            message: 'Waiting for Telegram authentication' 
          }), {
            headers: { ...corsHeaders, 'Content-Type': 'application/json' }
          });
        }
        
        return new Response(JSON.stringify({ error: 'Unknown action' }), {
          status: 400,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
        
      } catch (parseError) {
        console.error('Error parsing JSON:', parseError);
        return new Response(JSON.stringify({ error: 'Invalid JSON' }), {
          status: 400,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
      }
    }
    
    // Если метод не POST
    return new Response(JSON.stringify({ error: 'Method not allowed' }), {
      status: 404,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });
    
  } catch (error) {
    console.error('General error:', error);
    return new Response(JSON.stringify({ 
      error: 'Internal server error',
      details: error.message 
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });
  }
});