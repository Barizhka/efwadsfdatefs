import { serve } from "https://deno.land/std@0.190.0/http/server.ts";

const BOT_TOKEN = Deno.env.get('TELEGRAM_BOT_TOKEN');

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

async function forceSetupWebhook() {
  try {
    if (!BOT_TOKEN) {
      return { success: false, error: 'TELEGRAM_BOT_TOKEN not found' };
    }
    
    console.log('🔧 Force cleaning all webhooks and setting up main bot...');
    
    // 1. Test bot token first
    const getMeResponse = await fetch(`https://api.telegram.org/bot${BOT_TOKEN}/getMe`);
    const getMeResult = await getMeResponse.json();
    console.log('🤖 Bot info:', getMeResult);
    
    if (!getMeResult.ok) {
      return { success: false, error: `Invalid bot token: ${getMeResult.description}` };
    }
    
    // 2. Delete ALL existing webhooks to clean up
    console.log('🗑️ Deleting ALL existing webhooks...');
    const deleteResponse = await fetch(`https://api.telegram.org/bot${BOT_TOKEN}/deleteWebhook`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        drop_pending_updates: true // This clears all pending updates
      })
    });
    const deleteResult = await deleteResponse.json();
    console.log('Delete result:', deleteResult);
    
    // 3. Wait longer to ensure cleanup
    await new Promise(resolve => setTimeout(resolve, 5000));
    
    // 4. Set new webhook ONLY for main bot
    const webhookUrl = 'https://xonxdkvdbjmxawdyeemt.supabase.co/functions/v1/telegram-bot';
    console.log('🔗 Setting webhook ONLY for main bot:', webhookUrl);
    
    const setResponse = await fetch(`https://api.telegram.org/bot${BOT_TOKEN}/setWebhook`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        url: webhookUrl,
        max_connections: 40,
        allowed_updates: ['message', 'callback_query'],
        drop_pending_updates: true
      })
    });
    
    const setResult = await setResponse.json();
    console.log('📝 Set webhook result:', setResult);
    
    // 5. Verify webhook
    const verifyResponse = await fetch(`https://api.telegram.org/bot${BOT_TOKEN}/getWebhookInfo`);
    const verifyResult = await verifyResponse.json();
    console.log('✅ Verification result:', verifyResult);
    
    // 6. Send test message to confirm it works
    const testChatId = 8264781238; // Admin chat ID from logs
    const testResponse = await fetch(`https://api.telegram.org/bot${BOT_TOKEN}/sendMessage`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        chat_id: testChatId,
        text: '✅ Webhook очищен и настроен заново!\n\nТолько основной бот теперь активен. Проверьте команду /start с новым аккаунтом.'
      })
    });
    
    const testResult = await testResponse.json();
    console.log('📨 Test message result:', testResult);
    
    return {
      success: setResult.ok,
      botInfo: getMeResult.result,
      webhookDelete: deleteResult,
      webhookSet: setResult,
      webhookVerify: verifyResult.result,
      testMessage: testResult,
      message: 'All old webhooks deleted, main bot configured'
    };
    
  } catch (error) {
    console.error('❌ Error in force setup:', error);
    return { success: false, error: error.message };
  }
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }
  
  try {
    const result = await forceSetupWebhook();
    
    return new Response(JSON.stringify(result, null, 2), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });
  } catch (error) {
    console.error('Function error:', error);
    return new Response(JSON.stringify({ 
      success: false,
      error: error.message 
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });
  }
});