import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.7.1';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_ANON_KEY') ?? '',
      {
        global: {
          headers: { Authorization: req.headers.get('Authorization')! },
        },
      }
    );

    // Get the authenticated user
    const { data: { user }, error: userError } = await supabase.auth.getUser();
    if (userError || !user) {
      return new Response(
        JSON.stringify({ error: 'Unauthorized' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Check if user is admin
    const { data: userRole, error: roleError } = await supabase
      .from('user_roles')
      .select('role')
      .eq('user_id', user.id)
      .eq('role', 'admin')
      .single();

    if (roleError || !userRole) {
      return new Response(
        JSON.stringify({ error: 'Admin access required' }),
        { status: 403, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const { depositId, action, rejectionReason } = await req.json();

    if (!depositId || !action || !['approve', 'reject'].includes(action)) {
      return new Response(
        JSON.stringify({ error: 'Invalid request parameters' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Get the deposit request
    const { data: depositRequest, error: getError } = await supabase
      .from('deposit_requests')
      .select('*')
      .eq('id', depositId)
      .single();

    if (getError || !depositRequest) {
      return new Response(
        JSON.stringify({ error: 'Deposit request not found' }),
        { status: 404, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    if (depositRequest.status !== 'pending') {
      return new Response(
        JSON.stringify({ error: 'Deposit request already processed' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Update deposit request status
    const updateData: any = {
      status: action === 'approve' ? 'approved' : 'rejected'
    };

    if (action === 'reject' && rejectionReason) {
      updateData.rejection_reason = rejectionReason;
    }

    const { error: updateError } = await supabase
      .from('deposit_requests')
      .update(updateData)
      .eq('id', depositId);

    if (updateError) {
      console.error('Update error:', updateError);
      return new Response(
        JSON.stringify({ error: 'Failed to update deposit request' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // If approved, update user balance using RPC function
    if (action === 'approve') {
      // Примечание: RPC функция increment_user_balance должна быть создана отдельно
      console.log(`Would increment balance for user ${depositRequest.user_id} by ${depositRequest.amount}`);
    }

    // Log the action (simplified notification)
    console.log(`Deposit request ${depositId} ${action}d by admin ${user.id}`);
    console.log(`User ${depositRequest.user_id} deposit of ${depositRequest.amount} ${action}d`);
    if (rejectionReason) {
      console.log(`Rejection reason: ${rejectionReason}`);
    }

    return new Response(
      JSON.stringify({ 
        success: true, 
        message: `Deposit request ${action}d successfully` 
      }),
      { 
        status: 200, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    );

  } catch (error) {
    console.error('Error in manage-deposit-request:', error);
    return new Response(
      JSON.stringify({ error: 'Internal server error' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});