-- Database functions export for project: xonxdkvdbjmxawdyeemt
-- Generated on: 2025-01-17

-- Function to update updated_at column
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
 RETURNS trigger
 LANGUAGE plpgsql
AS $function$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$function$;

-- Function to check user roles
CREATE OR REPLACE FUNCTION public.has_role(_user_id uuid, _role app_role)
 RETURNS boolean
 LANGUAGE sql
 STABLE SECURITY DEFINER
AS $function$
  SELECT EXISTS (
    SELECT 1
    FROM public.user_roles
    WHERE user_id = _user_id
      AND role = _role
  )
$function$;

-- Function to handle new user creation
CREATE OR REPLACE FUNCTION public.handle_new_user()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
BEGIN
  -- Insert into profiles
  INSERT INTO public.profiles (user_id, display_name, email)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'display_name', NEW.raw_user_meta_data->>'full_name'),
    NEW.email
  );
  
  -- Assign default user role
  INSERT INTO public.user_roles (user_id, role)
  VALUES (NEW.id, 'user');
  
  -- Create default reading space
  INSERT INTO public.reading_spaces (user_id, name, description)
  VALUES (NEW.id, 'My Library', 'Default reading space for saved papers');
  
  RETURN NEW;
END;
$function$;

-- Function to update updated_at
CREATE OR REPLACE FUNCTION public.update_updated_at()
 RETURNS trigger
 LANGUAGE plpgsql
AS $function$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$function$;

-- Function to process telegram authentication v2
CREATE OR REPLACE FUNCTION public.process_telegram_auth_v2(auth_token text, tg_id bigint, tg_username text DEFAULT NULL::text, tg_first_name text DEFAULT NULL::text, tg_last_name text DEFAULT NULL::text)
 RETURNS json
 LANGUAGE plpgsql
 SECURITY DEFINER
AS $function$
DECLARE
  token_record record;
  existing_telegram_user record;
  display_name text;
  user_email text;
  result json;
BEGIN
  -- Проверяем валидность токена
  SELECT * INTO token_record
  FROM public.auth_tokens
  WHERE token = auth_token
    AND expires_at > now()
    AND used = false;
    
  IF NOT FOUND THEN
    RETURN json_build_object(
      'success', false,
      'message', 'Токен недействителен или истек'
    );
  END IF;
  
  -- Генерируем отображаемое имя
  display_name := COALESCE(
    NULLIF(TRIM(CONCAT(tg_first_name, ' ', tg_last_name)), ''),
    tg_first_name,
    tg_username,
    'Пользователь'
  );
  
  -- Генерируем уникальный email для Telegram пользователя
  user_email := 'tg_' || tg_id || '@telegram.local';
  
  -- Проверяем, существует ли уже пользователь с таким Telegram ID
  SELECT * INTO existing_telegram_user
  FROM public.telegram_users
  WHERE telegram_id = tg_id;
  
  IF FOUND THEN
    -- Существующий пользователь - помечаем токен как использованный
    UPDATE public.auth_tokens
    SET used = true,
        used_at = now(),
        user_id = existing_telegram_user.user_id,
        telegram_id = tg_id
    WHERE token = auth_token;
    
    RETURN json_build_object(
      'success', true,
      'is_new_user', false,
      'user_id', existing_telegram_user.user_id,
      'display_name', display_name,
      'email', user_email
    );
  ELSE
    -- Новый пользователь - помечаем токен как готовый к использованию
    UPDATE public.auth_tokens
    SET telegram_id = tg_id,
        updated_at = now()
    WHERE token = auth_token;
    
    RETURN json_build_object(
      'success', true,
      'is_new_user', true,
      'display_name', display_name,
      'email', user_email
    );
  END IF;
END;
$function$;

-- Function to update updated_at for auth_tokens
CREATE OR REPLACE FUNCTION public.update_updated_at_auth_tokens()
 RETURNS trigger
 LANGUAGE plpgsql
AS $function$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$function$;

-- Function to get trending papers
CREATE OR REPLACE FUNCTION public.get_trending_papers(limit_count integer DEFAULT 10)
 RETURNS TABLE(paper_id uuid, title text, authors text[], journal text, publication_date date, abstract text, arxiv_id text, doi text, trending_score numeric, reading_count integer, view_count integer)
 LANGUAGE plpgsql
 SECURITY DEFINER
AS $function$
BEGIN
  RETURN QUERY
  SELECT 
    p.id as paper_id,
    p.title,
    p.authors,
    p.venue as journal,
    p.publication_date,
    p.abstract,
    p.openalex_id as arxiv_id,
    p.doi_url as doi,
    COALESCE(tpc.trending_score, 0.0) as trending_score,
    COALESCE(tpc.views_count, 0) as reading_count,
    COALESCE(tpc.views_count, 0) as view_count
  FROM public.papers p
  LEFT JOIN public.trending_papers_cache tpc ON p.id = tpc.paper_id
  WHERE tpc.expires_at > NOW() OR tpc.expires_at IS NULL
  ORDER BY COALESCE(tpc.trending_score, 0.0) DESC, p.created_at DESC
  LIMIT limit_count;
END;
$function$;

-- Function to get cached trending papers
CREATE OR REPLACE FUNCTION public.get_cached_trending_papers(limit_count integer DEFAULT 10)
 RETURNS TABLE(paper_id uuid, title text, authors text[], journal text, publication_date date, abstract text, arxiv_id text, doi text, trending_score numeric, reading_count integer, view_count integer)
 LANGUAGE plpgsql
 SECURITY DEFINER
AS $function$
BEGIN
  RETURN QUERY
  SELECT 
    p.id as paper_id,
    p.title,
    p.authors,
    p.venue as journal,
    p.publication_date,
    p.abstract,
    p.openalex_id as arxiv_id,
    p.doi_url as doi,
    COALESCE(tpc.trending_score, 0.0) as trending_score,
    COALESCE(tpc.views_count, 0) as reading_count,
    COALESCE(tpc.views_count, 0) as view_count
  FROM public.papers p
  LEFT JOIN public.trending_papers_cache tpc ON p.id = tpc.paper_id
  WHERE tpc.expires_at > NOW()
  ORDER BY COALESCE(tpc.trending_score, 0.0) DESC
  LIMIT limit_count;
END;
$function$;

-- Function to refresh trending papers cache
CREATE OR REPLACE FUNCTION public.refresh_trending_papers_cache()
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
AS $function$
BEGIN
  -- Clear existing cache
  DELETE FROM public.trending_papers_cache;
  
  -- Insert new trending papers based on recent activity
  INSERT INTO public.trending_papers_cache (
    paper_id,
    trending_score,
    views_count,
    saves_count,
    comments_count,
    expires_at
  )
  SELECT 
    p.id,
    -- Calculate trending score based on recent activity
    COALESCE(
      (SELECT COUNT(*) FROM public.reading_sessions rs WHERE rs.paper_id = p.id AND rs.created_at > NOW() - INTERVAL '7 days') * 0.3 +
      (SELECT COUNT(*) FROM public.annotations a WHERE a.paper_id = p.id AND a.created_at > NOW() - INTERVAL '7 days') * 0.5 +
      (SELECT COUNT(*) FROM public.space_papers sp WHERE sp.paper_id = p.id AND sp.added_at > NOW() - INTERVAL '7 days') * 0.2,
      0.0
    ) as trending_score,
    COALESCE((SELECT COUNT(*) FROM public.reading_sessions rs WHERE rs.paper_id = p.id), 0) as views_count,
    COALESCE((SELECT COUNT(*) FROM public.space_papers sp WHERE sp.paper_id = p.id), 0) as saves_count,
    COALESCE((SELECT COUNT(*) FROM public.annotations a WHERE a.paper_id = p.id), 0) as comments_count,
    NOW() + INTERVAL '24 hours' as expires_at
  FROM public.papers p
  WHERE p.created_at > NOW() - INTERVAL '30 days'
  ORDER BY trending_score DESC
  LIMIT 100;
END;
$function$;

-- Function to check enterprise lead rate limit
CREATE OR REPLACE FUNCTION public.check_enterprise_lead_rate_limit(p_ip_address text, p_email text DEFAULT NULL::text)
 RETURNS json
 LANGUAGE plpgsql
 SECURITY DEFINER
AS $function$
DECLARE
  rate_limit_exceeded BOOLEAN := false;
  remaining_attempts INTEGER := 0;
  reset_time TIMESTAMP WITH TIME ZONE;
BEGIN
  -- Check if email provided, check email rate limit
  IF p_email IS NOT NULL THEN
    SELECT 
      COUNT(*) >= 3,
      GREATEST(0, 3 - COUNT(*)),
      MAX(created_at) + INTERVAL '1 hour'
    INTO rate_limit_exceeded, remaining_attempts, reset_time
    FROM public.enterprise_leads
    WHERE email = p_email
      AND created_at > NOW() - INTERVAL '1 hour';
  END IF;
  
  RETURN json_build_object(
    'exceeded', rate_limit_exceeded,
    'remaining_attempts', remaining_attempts,
    'reset_time', reset_time
  );
END;
$function$;

-- Function to log enterprise lead access
CREATE OR REPLACE FUNCTION public.log_enterprise_lead_access(p_action text, p_lead_id text, p_details json DEFAULT NULL::json)
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
AS $function$
BEGIN
  INSERT INTO public.admin_audit_logs (action, user_identifier, metadata, success)
  VALUES (p_action, p_lead_id, p_details, true);
END;
$function$;

-- Function to clear search cache for paper
CREATE OR REPLACE FUNCTION public.clear_search_cache_for_paper(paper_title_param text)
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
AS $function$
BEGIN
  DELETE FROM public.search_cache 
  WHERE query_text ILIKE '%' || paper_title_param || '%';
END;
$function$;

-- Function to cleanup expired PDF split locks
CREATE OR REPLACE FUNCTION public.cleanup_expired_pdf_split_locks()
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
AS $function$
BEGIN
  DELETE FROM public.pdf_split_locks 
  WHERE expires_at < NOW();
END;
$function$;

-- Function to cleanup expired cache
CREATE OR REPLACE FUNCTION public.cleanup_expired_cache()
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
AS $function$
BEGIN
  DELETE FROM public.search_cache 
  WHERE expires_at < NOW();
  
  DELETE FROM public.trending_papers_cache 
  WHERE expires_at < NOW();
END;
$function$;

-- Function to cleanup expired recommendations
CREATE OR REPLACE FUNCTION public.cleanup_expired_recommendations()
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
AS $function$
BEGIN
  DELETE FROM public.paper_recommendations 
  WHERE expires_at < NOW();
END;
$function$;

-- Function to clear all search cache
CREATE OR REPLACE FUNCTION public.clear_all_search_cache()
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
AS $function$
BEGIN
  DELETE FROM public.search_cache;
END;
$function$;