import { serve } from 'https://deno.land/std@0.168.0/http/server.ts'
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type, x-telegram-id',
}

interface PurchaseRequest {
  selectedAccountIds: string[]
  telegramId?: number
}

interface Account {
  id: string
  username: string
  city: string
  split: number
  price: number
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders })
  }

  try {
    // Create Supabase client with service role for database operations
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
    
    const supabase = createClient(supabaseUrl, supabaseServiceKey, {
      auth: {
        autoRefreshToken: false,
        persistSession: false
      }
    })

    // Parse request body to get telegram ID if provided
    const { selectedAccountIds, telegramId }: PurchaseRequest = await req.json()
    
    console.log('🛒 Purchase request received:', { 
      accountCount: selectedAccountIds?.length, 
      telegramId,
      hasAccountIds: !!selectedAccountIds,
      accountIds: selectedAccountIds
    })
    
    if (!selectedAccountIds || selectedAccountIds.length === 0) {
      console.error('❌ No accounts selected for purchase')
      return new Response(
        JSON.stringify({ 
          success: false,
          error: 'Не выбраны аккаунты для покупки' 
        }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    // Use the unified purchase function that handles both auth methods
    // Fix parameter name to match the function signature
    console.log('🔄 Calling purchase_accounts_unified with:', {
      selected_account_ids: selectedAccountIds,
      telegram_id: telegramId
    })
    
    const { data, error } = await supabase.rpc('purchase_accounts_unified', {
      selected_account_ids: selectedAccountIds,
      telegram_id: telegramId
    })

    if (error) {
      console.error('❌ Purchase RPC function error:', error)
      return new Response(
        JSON.stringify({ 
          success: false, 
          message: `Ошибка покупки: ${error.message}`,
          debug_info: {
            error_code: error.code,
            error_details: error.details,
            error_hint: error.hint
          }
        }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    console.log('✅ Purchase RPC completed, result:', data)
    
    const result = data as any
    if (!result?.success) {
      console.error('❌ Purchase failed:', result?.message, result?.debug_info)
      return new Response(
        JSON.stringify({ 
          success: false, 
          message: result?.message || 'Неизвестная ошибка при покупке',
          debug_info: result?.debug_info
        }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    console.log('✅ Purchase completed successfully:', result)

    return new Response(
      JSON.stringify(result),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )

  } catch (error) {
    console.error('❌ Purchase function error:', error)
    return new Response(
      JSON.stringify({ error: 'Внутренняя ошибка сервера' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )
  }
})