import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface ProductData {
  name: string;
  price: number;
  description: string;
  imageUrl?: string;
  availability: boolean;
}

async function parseYandexMarketUrl(url: string): Promise<ProductData> {
  try {
    console.log('Parsing Yandex Market URL:', url);
    
    // Fetch the page with proper headers to avoid blocking
    const response = await fetch(url, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
        'Accept-Language': 'ru-RU,ru;q=0.8,en-US;q=0.5,en;q=0.3',
        'Accept-Encoding': 'gzip, deflate',
        'DNT': '1',
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1',
      }
    });

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    const html = await response.text();
    console.log('Fetched HTML length:', html.length);

    // Parse HTML to extract product information
    // Using regex patterns since we can't use cheerio in Deno easily
    
    // Extract product name
    let name = '';
    const nameMatch = html.match(/<h1[^>]*data-auto="productCardTitle"[^>]*>([^<]+)<\/h1>/i) ||
                     html.match(/<h1[^>]*class="[^"]*title[^"]*"[^>]*>([^<]+)<\/h1>/i) ||
                     html.match(/<title>([^<]+)/i);
    
    if (nameMatch) {
      name = nameMatch[1].trim().replace(/\s+/g, ' ');
      // Remove "купить" and other marketing text
      name = name.replace(/\s*—\s*купить.*$/i, '').replace(/\s*-\s*Яндекс\.Маркет.*$/i, '');
    }

    // Extract price
    let price = 0;
    const priceMatch = html.match(/data-auto="price-value"[^>]*>([0-9\s]+)/i) ||
                      html.match(/class="[^"]*price[^"]*"[^>]*>.*?([0-9\s]+).*?₽/i) ||
                      html.match(/([0-9\s]+)\s*₽/i);
    
    if (priceMatch) {
      const priceStr = priceMatch[1].replace(/\s/g, '');
      price = parseInt(priceStr, 10);
    }

    // Extract description
    let description = '';
    const descMatch = html.match(/data-auto="productCardDescription"[^>]*>([^<]+)/i) ||
                     html.match(/class="[^"]*description[^"]*"[^>]*>([^<]+)/i);
    
    if (descMatch) {
      description = descMatch[1].trim().substring(0, 200);
    }

    // Extract image URL
    let imageUrl = '';
    const imgMatch = html.match(/data-auto="main-image"[^>]*src="([^"]+)"/i) ||
                    html.match(/<img[^>]*class="[^"]*product[^"]*"[^>]*src="([^"]+)"/i);
    
    if (imgMatch) {
      imageUrl = imgMatch[1];
      if (imageUrl.startsWith('//')) {
        imageUrl = 'https:' + imageUrl;
      }
    }

    // Check availability
    const availability = !html.includes('товара нет в наличии') && 
                        !html.includes('под заказ') && 
                        price > 0;

    console.log('Parsed product data:', { name, price, description: description.substring(0, 50) + '...', availability });

    return {
      name: name || 'Товар с Яндекс.Маркет',
      price: price || 0,
      description: description || 'Описание недоступно',
      imageUrl,
      availability
    };

  } catch (error) {
    console.error('Error parsing Yandex Market URL:', error);
    
    // Fallback: try to extract basic info from URL
    const urlParams = new URL(url);
    const pathParts = urlParams.pathname.split('/');
    const productName = pathParts[pathParts.length - 1]?.replace(/-/g, ' ') || 'Товар с Яндекс.Маркет';
    
    return {
      name: productName,
      price: 0,
      description: 'Не удалось загрузить описание товара',
      availability: false
    };
  }
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { url } = await req.json();

    if (!url) {
      return new Response(
        JSON.stringify({ error: 'URL is required' }),
        { 
          status: 400, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      );
    }

    // Validate that it's a Yandex Market URL
    if (!url.includes('market.yandex.ru')) {
      return new Response(
        JSON.stringify({ error: 'Only Yandex Market URLs are supported' }),
        { 
          status: 400, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      );
    }

    const productData = await parseYandexMarketUrl(url);

    return new Response(
      JSON.stringify({ success: true, product: productData }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    );

  } catch (error) {
    console.error('Error in parse-yandex-product function:', error);
    return new Response(
      JSON.stringify({ 
        error: 'Failed to parse product URL',
        details: error.message 
      }),
      { 
        status: 500, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    );
  }
});