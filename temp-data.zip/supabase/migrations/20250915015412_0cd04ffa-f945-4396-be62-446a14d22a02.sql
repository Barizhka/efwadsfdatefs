-- Создаем функцию для генерации отображаемого имени пользователя Telegram
CREATE OR REPLACE FUNCTION public.generate_telegram_display_name(
  tg_first_name TEXT,
  tg_last_name TEXT,
  tg_username TEXT,
  tg_id BIGINT
) RETURNS TEXT
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  -- Приоритет отображения имени:
  -- 1. first_name + last_name (если есть)
  IF tg_first_name IS NOT NULL AND tg_first_name != '' THEN
    IF tg_last_name IS NOT NULL AND tg_last_name != '' THEN
      RETURN tg_first_name || ' ' || tg_last_name;
    ELSIF tg_username IS NOT NULL AND tg_username != '' THEN
      RETURN tg_first_name || ' (@' || tg_username || ')';
    ELSE
      RETURN tg_first_name;
    END IF;
  -- 2. username (если first_name пустой)
  ELSIF tg_username IS NOT NULL AND tg_username != '' THEN
    RETURN '@' || tg_username;
  -- 3. "Пользователь Telegram" + telegram_id (если все пустое)
  ELSE
    RETURN 'Пользователь Telegram ' || tg_id::TEXT;
  END IF;
END;
$$;

-- Создаем функцию для создания Supabase пользователя для Telegram пользователя
CREATE OR REPLACE FUNCTION public.create_supabase_user_for_telegram(
  tg_id BIGINT,
  tg_username TEXT,
  tg_first_name TEXT,
  tg_last_name TEXT
) RETURNS UUID
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  new_user_id UUID;
  display_name TEXT;
  user_email TEXT;
BEGIN
  -- Генерируем отображаемое имя
  display_name := generate_telegram_display_name(tg_first_name, tg_last_name, tg_username, tg_id);
  
  -- Создаем email-фолбэк для Supabase
  user_email := 'tg_' || tg_id || '@telegram.local';
  
  -- Создаем пользователя в auth.users (через admin API)
  -- Здесь используем случайный UUID, который будет заменен в Edge функции
  new_user_id := gen_random_uuid();
  
  -- Создаем или обновляем запись в telegram_users
  INSERT INTO public.telegram_users (
    user_id,
    telegram_id,
    telegram_username,
    telegram_first_name,
    telegram_last_name,
    created_at,
    updated_at
  ) VALUES (
    new_user_id,
    tg_id,
    tg_username,
    tg_first_name,
    tg_last_name,
    NOW(),
    NOW()
  )
  ON CONFLICT (telegram_id) 
  DO UPDATE SET
    user_id = EXCLUDED.user_id,
    telegram_username = EXCLUDED.telegram_username,
    telegram_first_name = EXCLUDED.telegram_first_name,
    telegram_last_name = EXCLUDED.telegram_last_name,
    updated_at = NOW()
  RETURNING user_id INTO new_user_id;
  
  -- Создаем или обновляем профиль
  INSERT INTO public.profiles (
    user_id,
    email,
    display_name,
    created_at,
    updated_at
  ) VALUES (
    new_user_id,
    user_email,
    display_name,
    NOW(),
    NOW()
  )
  ON CONFLICT (user_id)
  DO UPDATE SET
    display_name = EXCLUDED.display_name,
    updated_at = NOW();
  
  RETURN new_user_id;
END;
$$;

-- Обновляем функцию process_telegram_auth для создания реальных пользователей
CREATE OR REPLACE FUNCTION public.process_telegram_auth_v2(
  auth_token TEXT,
  tg_id BIGINT,
  tg_username TEXT,
  tg_first_name TEXT,
  tg_last_name TEXT
) RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  token_record auth_tokens%ROWTYPE;
  existing_user_id UUID;
  user_email TEXT;
  display_name TEXT;
BEGIN
  -- Проверяем токен
  SELECT * INTO token_record
  FROM public.auth_tokens
  WHERE token = auth_token 
    AND expires_at > now() 
    AND used_at IS NULL;
  
  IF token_record.id IS NULL THEN
    RETURN jsonb_build_object('success', false, 'message', 'Invalid or expired token');
  END IF;
  
  -- Проверяем, есть ли уже пользователь с таким Telegram ID
  SELECT user_id INTO existing_user_id
  FROM public.telegram_users
  WHERE telegram_id = tg_id;
  
  -- Генерируем отображаемое имя и email
  display_name := generate_telegram_display_name(tg_first_name, tg_last_name, tg_username, tg_id);
  user_email := 'tg_' || tg_id || '@telegram.local';
  
  IF existing_user_id IS NOT NULL THEN
    -- Пользователь уже существует, обновляем токен и данные
    UPDATE public.auth_tokens 
    SET user_id = existing_user_id, telegram_id = tg_id, used_at = now()
    WHERE token = auth_token;
    
    -- Обновляем информацию о пользователе
    UPDATE public.telegram_users
    SET telegram_username = tg_username,
        telegram_first_name = tg_first_name,
        telegram_last_name = tg_last_name,
        updated_at = now()
    WHERE telegram_id = tg_id;
    
    -- Обновляем профиль
    UPDATE public.profiles
    SET display_name = display_name,
        updated_at = now()
    WHERE user_id = existing_user_id;
    
    RETURN jsonb_build_object(
      'success', true, 
      'message', 'User authenticated',
      'user_id', existing_user_id,
      'telegram_id', tg_id,
      'email', user_email,
      'display_name', display_name,
      'token', auth_token
    );
  ELSE
    -- Новый пользователь - создаем временную запись, реальный пользователь будет создан в Edge функции
    UPDATE public.auth_tokens 
    SET telegram_id = tg_id, used_at = now()
    WHERE token = auth_token;
    
    RETURN jsonb_build_object(
      'success', true,
      'message', 'Ready to create new user',
      'is_new_user', true,
      'email', user_email,
      'telegram_id', tg_id,
      'telegram_username', tg_username,
      'telegram_first_name', tg_first_name,
      'telegram_last_name', tg_last_name,
      'display_name', display_name,
      'token', auth_token
    );
  END IF;
END;
$$;

-- Функция для получения пользователя по telegram_id (для Edge функций)
CREATE OR REPLACE FUNCTION public.get_user_by_telegram_id(tg_id BIGINT)
RETURNS TABLE(
  user_id UUID,
  email TEXT,
  display_name TEXT,
  telegram_username TEXT,
  telegram_first_name TEXT,
  telegram_last_name TEXT
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  RETURN QUERY
  SELECT 
    tu.user_id,
    p.email,
    p.display_name,
    tu.telegram_username,
    tu.telegram_first_name,
    tu.telegram_last_name
  FROM public.telegram_users tu
  LEFT JOIN public.profiles p ON tu.user_id = p.user_id
  WHERE tu.telegram_id = tg_id;
END;
$$;