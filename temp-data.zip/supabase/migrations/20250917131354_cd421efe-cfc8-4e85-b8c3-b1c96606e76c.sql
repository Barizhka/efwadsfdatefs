-- Исправляем функцию process_telegram_auth_v2 для предотвращения повторного использования токенов
CREATE OR REPLACE FUNCTION public.process_telegram_auth_v2(auth_token text, tg_id bigint, tg_username text DEFAULT NULL::text, tg_first_name text DEFAULT NULL::text, tg_last_name text DEFAULT NULL::text)
 RETURNS json
 LANGUAGE plpgsql
 SECURITY DEFINER
AS $function$
DECLARE
  token_record record;
  existing_telegram_user record;
  display_name text;
  user_email text;
  result json;
BEGIN
  -- Проверяем валидность токена (теперь с дополнительной проверкой на уникальность)
  SELECT * INTO token_record
  FROM public.auth_tokens
  WHERE token = auth_token
    AND expires_at > now()
    AND used = false
    AND (telegram_id IS NULL OR telegram_id = tg_id); -- Либо токен свободен, либо уже привязан к этому telegram_id
    
  IF NOT FOUND THEN
    RETURN json_build_object(
      'success', false,
      'message', 'Токен недействителен, истек или уже используется другим пользователем'
    );
  END IF;
  
  -- Генерируем отображаемое имя
  display_name := COALESCE(
    NULLIF(TRIM(CONCAT(tg_first_name, ' ', tg_last_name)), ''),
    tg_first_name,
    tg_username,
    'Пользователь'
  );
  
  -- Генерируем уникальный email для Telegram пользователя
  user_email := 'tg_' || tg_id || '@telegram.local';
  
  -- Проверяем, существует ли уже пользователь с таким Telegram ID
  SELECT * INTO existing_telegram_user
  FROM public.telegram_users
  WHERE telegram_id = tg_id;
  
  IF FOUND THEN
    -- Существующий пользователь - помечаем токен как использованный
    UPDATE public.auth_tokens
    SET used = true,
        used_at = now(),
        user_id = existing_telegram_user.user_id,
        telegram_id = tg_id
    WHERE token = auth_token;
    
    RETURN json_build_object(
      'success', true,
      'is_new_user', false,
      'user_id', existing_telegram_user.user_id,
      'display_name', display_name,
      'email', user_email
    );
  ELSE
    -- Новый пользователь - сразу помечаем токен как использованный для предотвращения повторного использования
    UPDATE public.auth_tokens
    SET used = true,
        used_at = now(),
        telegram_id = tg_id,
        updated_at = now()
    WHERE token = auth_token;
    
    RETURN json_build_object(
      'success', true,
      'is_new_user', true,
      'display_name', display_name,
      'email', user_email,
      'telegram_id', tg_id
    );
  END IF;
END;
$function$;