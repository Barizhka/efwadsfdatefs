-- Create function to check if current user is authorized for emulator access
CREATE OR REPLACE FUNCTION public.is_emulator_authorized()
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
BEGIN
  -- Check if user is authenticated
  IF auth.uid() IS NULL THEN
    RETURN false;
  END IF;
  
  -- Check if user is one of the authorized telegram users
  RETURN EXISTS (
    SELECT 1 
    FROM public.telegram_users tu
    WHERE tu.user_id = auth.uid()
    AND tu.telegram_username IN ('phantasmgg', 'grevsplitatp')
  );
END;
$function$;