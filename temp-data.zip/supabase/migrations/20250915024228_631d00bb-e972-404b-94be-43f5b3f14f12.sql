-- Исправляем синтаксис UPDATE в функции process_telegram_auth_v2
CREATE OR REPLACE FUNCTION public.process_telegram_auth_v2(auth_token text, tg_id bigint, tg_username text, tg_first_name text, tg_last_name text)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path = 'public'
AS $function$
DECLARE
  token_record auth_tokens%ROWTYPE;
  existing_user_id UUID;
  user_email TEXT;
  generated_display_name TEXT;
BEGIN
  -- Логирование для отладки
  RAISE LOG 'Processing telegram auth: token=%, tg_id=%, username=%, first_name=%', 
    auth_token, tg_id, tg_username, tg_first_name;

  -- Проверяем токен
  SELECT * INTO token_record
  FROM public.auth_tokens
  WHERE token = auth_token 
    AND expires_at > now() 
    AND used_at IS NULL;
  
  IF token_record.id IS NULL THEN
    RAISE LOG 'Token validation failed: token=%, expires_at check passed=%, used_at is null=%', 
      auth_token, 
      (SELECT COUNT(*) FROM public.auth_tokens WHERE token = auth_token AND expires_at > now()),
      (SELECT COUNT(*) FROM public.auth_tokens WHERE token = auth_token AND used_at IS NULL);
    RETURN jsonb_build_object('success', false, 'message', 'Invalid or expired token');
  END IF;
  
  -- Проверяем, есть ли уже пользователь с таким Telegram ID
  SELECT user_id INTO existing_user_id
  FROM public.telegram_users
  WHERE telegram_id = tg_id;
  
  -- Генерируем отображаемое имя и email
  generated_display_name := generate_telegram_display_name(tg_first_name, tg_last_name, tg_username, tg_id);
  user_email := 'tg_' || tg_id || '@telegram.local';
  
  RAISE LOG 'User lookup result: existing_user_id=%, generated_display_name=%, email=%', 
    existing_user_id, generated_display_name, user_email;
  
  IF existing_user_id IS NOT NULL THEN
    -- Пользователь уже существует, обновляем токен и данные
    UPDATE public.auth_tokens 
    SET user_id = existing_user_id, telegram_id = tg_id, used_at = now()
    WHERE token = auth_token;
    
    -- Обновляем информацию о пользователе
    UPDATE public.telegram_users
    SET telegram_username = tg_username,
        telegram_first_name = tg_first_name,
        telegram_last_name = tg_last_name,
        updated_at = now()
    WHERE telegram_id = tg_id;
    
    -- Обновляем профиль (исправляем синтаксис UPDATE)
    UPDATE public.profiles
    SET display_name = generated_display_name,
        updated_at = now()
    WHERE user_id = existing_user_id;
    
    RAISE LOG 'Existing user updated successfully: user_id=%', existing_user_id;
    
    RETURN jsonb_build_object(
      'success', true, 
      'message', 'User authenticated',
      'user_id', existing_user_id,
      'telegram_id', tg_id,
      'email', user_email,
      'display_name', generated_display_name,
      'token', auth_token
    );
  ELSE
    -- Новый пользователь - создаем временную запись, реальный пользователь будет создан в Edge функции
    UPDATE public.auth_tokens 
    SET telegram_id = tg_id, used_at = now()
    WHERE token = auth_token;
    
    RAISE LOG 'New user detected, returning creation data';
    
    RETURN jsonb_build_object(
      'success', true,
      'message', 'Ready to create new user',
      'is_new_user', true,
      'email', user_email,
      'telegram_id', tg_id,
      'telegram_username', tg_username,
      'telegram_first_name', tg_first_name,
      'telegram_last_name', tg_last_name,
      'display_name', generated_display_name,
      'token', auth_token
    );
  END IF;
EXCEPTION
  WHEN OTHERS THEN
    RAISE LOG 'Exception in process_telegram_auth_v2: %', SQLERRM;
    RETURN jsonb_build_object('success', false, 'message', 'Database error: ' || SQLERRM);
END;
$function$;