-- Create admin users table with proper security
CREATE TABLE IF NOT EXISTS public.admin_users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  admin_code TEXT NOT NULL UNIQUE,
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  last_login TIMESTAMP WITH TIME ZONE,
  login_attempts INTEGER DEFAULT 0,
  locked_until TIMESTAMP WITH TIME ZONE
);

-- Enable RLS
ALTER TABLE public.admin_users ENABLE ROW LEVEL SECURITY;

-- Only authenticated users can check their own admin status
CREATE POLICY "Users can check their own admin status" ON public.admin_users
  FOR SELECT 
  USING (auth.uid() = user_id);

-- Only service role can manage admin users
CREATE POLICY "Service role can manage admin users" ON public.admin_users
  FOR ALL 
  USING (auth.role() = 'service_role');

-- Create admin sessions table for secure session management
CREATE TABLE IF NOT EXISTS public.admin_sessions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  admin_user_id UUID REFERENCES public.admin_users(id) ON DELETE CASCADE,
  session_token TEXT NOT NULL UNIQUE,
  expires_at TIMESTAMP WITH TIME ZONE NOT NULL,
  ip_address INET,
  user_agent TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Enable RLS for admin sessions
ALTER TABLE public.admin_sessions ENABLE ROW LEVEL SECURITY;

-- Only service role can manage admin sessions
CREATE POLICY "Service role can manage admin sessions" ON public.admin_sessions
  FOR ALL 
  USING (auth.role() = 'service_role');

-- Function to verify admin access
CREATE OR REPLACE FUNCTION public.verify_admin_access(input_code TEXT)
RETURNS TABLE(
  is_valid BOOLEAN,
  admin_id UUID,
  session_token TEXT,
  message TEXT
) 
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  admin_record public.admin_users%ROWTYPE;
  new_session_token TEXT;
  max_attempts INTEGER := 5;
  lockout_duration INTERVAL := '1 hour';
BEGIN
  -- Check if user is authenticated
  IF auth.uid() IS NULL THEN
    RETURN QUERY SELECT false, NULL::UUID, NULL::TEXT, 'Authentication required'::TEXT;
    RETURN;
  END IF;

  -- Get admin record
  SELECT * INTO admin_record
  FROM public.admin_users
  WHERE admin_code = input_code AND user_id = auth.uid();

  -- Check if admin exists
  IF admin_record.id IS NULL THEN
    RETURN QUERY SELECT false, NULL::UUID, NULL::TEXT, 'Invalid admin code'::TEXT;
    RETURN;
  END IF;

  -- Check if account is locked
  IF admin_record.locked_until IS NOT NULL AND admin_record.locked_until > now() THEN
    RETURN QUERY SELECT false, NULL::UUID, NULL::TEXT, 'Account temporarily locked'::TEXT;
    RETURN;
  END IF;

  -- Check if admin is active
  IF NOT admin_record.is_active THEN
    RETURN QUERY SELECT false, NULL::UUID, NULL::TEXT, 'Admin account disabled'::TEXT;
    RETURN;
  END IF;

  -- Generate session token
  new_session_token := encode(gen_random_bytes(32), 'base64');

  -- Create admin session
  INSERT INTO public.admin_sessions (
    admin_user_id,
    session_token,
    expires_at,
    ip_address,
    user_agent
  ) VALUES (
    admin_record.id,
    new_session_token,
    now() + INTERVAL '8 hours',
    inet_client_addr(),
    current_setting('request.headers', true)::json->>'user-agent'
  );

  -- Update last login and reset attempts
  UPDATE public.admin_users 
  SET 
    last_login = now(),
    login_attempts = 0,
    locked_until = NULL,
    updated_at = now()
  WHERE id = admin_record.id;

  -- Log successful admin access
  INSERT INTO public.admin_audit_logs (
    action,
    user_identifier,
    success,
    ip_address,
    user_agent,
    metadata
  ) VALUES (
    'admin_login',
    auth.uid()::TEXT,
    true,
    inet_client_addr(),
    current_setting('request.headers', true)::json->>'user-agent',
    jsonb_build_object(
      'admin_id', admin_record.id,
      'admin_code_used', input_code
    )
  );

  RETURN QUERY SELECT true, admin_record.id, new_session_token, 'Access granted'::TEXT;
END;
$$;

-- Function to validate admin session
CREATE OR REPLACE FUNCTION public.validate_admin_session(session_token_input TEXT)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  session_valid BOOLEAN := false;
BEGIN
  -- Check if user is authenticated
  IF auth.uid() IS NULL THEN
    RETURN false;
  END IF;

  -- Check if session exists and is valid
  SELECT EXISTS(
    SELECT 1 
    FROM public.admin_sessions s
    JOIN public.admin_users a ON s.admin_user_id = a.id
    WHERE s.session_token = session_token_input
      AND s.expires_at > now()
      AND a.user_id = auth.uid()
      AND a.is_active = true
  ) INTO session_valid;

  -- Update session last activity if valid
  IF session_valid THEN
    UPDATE public.admin_sessions 
    SET expires_at = now() + INTERVAL '8 hours'
    WHERE session_token = session_token_input;
  END IF;

  RETURN session_valid;
END;
$$;

-- Insert the default admin user with the secret code
INSERT INTO public.admin_users (admin_code, is_active)
VALUES ('RiL-Jni-WUK-v9D', true)
ON CONFLICT (admin_code) DO NOTHING;

-- Function to cleanup expired sessions
CREATE OR REPLACE FUNCTION public.cleanup_expired_admin_sessions()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  DELETE FROM public.admin_sessions 
  WHERE expires_at < now();
END;
$$;