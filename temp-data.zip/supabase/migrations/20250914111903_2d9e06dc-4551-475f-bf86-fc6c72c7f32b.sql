-- Исправляем функцию process_telegram_auth для правильной работы с Supabase Auth
CREATE OR REPLACE FUNCTION public.process_telegram_auth(auth_token text, tg_id bigint, tg_username text, tg_first_name text, tg_last_name text)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
AS $function$
DECLARE
  token_record auth_tokens%ROWTYPE;
  existing_user_id UUID;
  user_email TEXT;
BEGIN
  -- Проверяем токен
  SELECT * INTO token_record
  FROM public.auth_tokens
  WHERE token = auth_token 
    AND expires_at > now() 
    AND used_at IS NULL;
  
  IF token_record.id IS NULL THEN
    RETURN jsonb_build_object('success', false, 'message', 'Invalid or expired token');
  END IF;
  
  -- Проверяем, есть ли уже пользователь с таким Telegram ID
  SELECT user_id INTO existing_user_id
  FROM public.telegram_users
  WHERE telegram_id = tg_id;
  
  IF existing_user_id IS NOT NULL THEN
    -- Пользователь уже существует, обновляем токен
    UPDATE public.auth_tokens 
    SET user_id = existing_user_id, telegram_id = tg_id, used_at = now()
    WHERE token = auth_token;
    
    -- Обновляем информацию о пользователе
    UPDATE public.telegram_users
    SET telegram_username = tg_username,
        telegram_first_name = tg_first_name,
        telegram_last_name = tg_last_name,
        updated_at = now()
    WHERE telegram_id = tg_id;
    
    RETURN jsonb_build_object(
      'success', true, 
      'message', 'User authenticated',
      'user_id', existing_user_id,
      'token', auth_token
    );
  ELSE
    -- Для новых пользователей возвращаем информацию о том, что нужно создать пользователя
    user_email := 'tg_' || tg_id || '@telegram.local';
    
    -- Отмечаем токен как использованный, но без user_id (будет обновлен из Edge Function)
    UPDATE public.auth_tokens 
    SET telegram_id = tg_id, used_at = now()
    WHERE token = auth_token;
    
    RETURN jsonb_build_object(
      'success', true,
      'message', 'Ready to create new user',
      'is_new_user', true,
      'email', user_email,
      'telegram_id', tg_id,
      'telegram_username', tg_username,
      'telegram_first_name', tg_first_name,
      'telegram_last_name', tg_last_name,
      'token', auth_token
    );
  END IF;
END;
$function$;