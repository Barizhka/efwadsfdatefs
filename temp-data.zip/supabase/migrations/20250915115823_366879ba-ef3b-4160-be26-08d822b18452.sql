-- Create accounts table for the application
CREATE TABLE public.accounts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  city TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'available',
  type TEXT NOT NULL DEFAULT 'facebook',
  limit_value INTEGER NOT NULL DEFAULT 100,
  split_value NUMERIC NOT NULL DEFAULT 0,
  price NUMERIC NOT NULL DEFAULT 0,
  emulation_status TEXT NOT NULL DEFAULT 'off',
  user_id UUID REFERENCES auth.users(id),
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.accounts ENABLE ROW LEVEL SECURITY;

-- Create RLS policies
CREATE POLICY "Anyone can view available accounts" 
ON public.accounts 
FOR SELECT 
USING (true);

CREATE POLICY "Service role can manage accounts" 
ON public.accounts 
FOR ALL 
USING (auth.role() = 'service_role'::text);

-- Create trigger for updated_at
CREATE TRIGGER update_accounts_updated_at
  BEFORE UPDATE ON public.accounts
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

-- Create indexes
CREATE INDEX idx_accounts_status ON public.accounts(status);
CREATE INDEX idx_accounts_city ON public.accounts(city);
CREATE INDEX idx_accounts_user_id ON public.accounts(user_id);