-- Создаем таблицу для токенов авторизации через Telegram
CREATE TABLE public.auth_tokens (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  token text NOT NULL UNIQUE,
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  telegram_id bigint,
  expires_at timestamp with time zone NOT NULL,
  used boolean NOT NULL DEFAULT false,
  used_at timestamp with time zone,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Создаем таблицу для связи пользователей Telegram с пользователями Supabase
CREATE TABLE IF NOT EXISTS public.telegram_users (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  telegram_id bigint NOT NULL UNIQUE,
  telegram_username text,
  telegram_first_name text,
  telegram_last_name text,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Включаем RLS для обеих таблиц
ALTER TABLE public.auth_tokens ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.telegram_users ENABLE ROW LEVEL SECURITY;

-- Создаем политики RLS для auth_tokens
CREATE POLICY "Service role can manage auth tokens" ON public.auth_tokens
  FOR ALL USING (auth.role() = 'service_role');

CREATE POLICY "Users can view their own auth tokens" ON public.auth_tokens
  FOR SELECT USING (auth.uid() = user_id);

-- Создаем политики RLS для telegram_users  
CREATE POLICY "Service role can manage telegram users" ON public.telegram_users
  FOR ALL USING (auth.role() = 'service_role');

CREATE POLICY "Users can view their own telegram data" ON public.telegram_users
  FOR SELECT USING (auth.uid() = user_id);

-- Создаем функцию для обработки авторизации через Telegram
CREATE OR REPLACE FUNCTION public.process_telegram_auth_v2(
  auth_token text,
  tg_id bigint,
  tg_username text DEFAULT NULL,
  tg_first_name text DEFAULT NULL,
  tg_last_name text DEFAULT NULL
)
RETURNS json
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  token_record record;
  existing_telegram_user record;
  display_name text;
  user_email text;
  result json;
BEGIN
  -- Проверяем валидность токена
  SELECT * INTO token_record
  FROM public.auth_tokens
  WHERE token = auth_token
    AND expires_at > now()
    AND used = false;
    
  IF NOT FOUND THEN
    RETURN json_build_object(
      'success', false,
      'message', 'Токен недействителен или истек'
    );
  END IF;
  
  -- Генерируем отображаемое имя
  display_name := COALESCE(
    NULLIF(TRIM(CONCAT(tg_first_name, ' ', tg_last_name)), ''),
    tg_first_name,
    tg_username,
    'Пользователь'
  );
  
  -- Генерируем уникальный email для Telegram пользователя
  user_email := 'tg_' || tg_id || '@telegram.local';
  
  -- Проверяем, существует ли уже пользователь с таким Telegram ID
  SELECT * INTO existing_telegram_user
  FROM public.telegram_users
  WHERE telegram_id = tg_id;
  
  IF FOUND THEN
    -- Существующий пользователь - помечаем токен как использованный
    UPDATE public.auth_tokens
    SET used = true,
        used_at = now(),
        user_id = existing_telegram_user.user_id,
        telegram_id = tg_id
    WHERE token = auth_token;
    
    RETURN json_build_object(
      'success', true,
      'is_new_user', false,
      'user_id', existing_telegram_user.user_id,
      'display_name', display_name,
      'email', user_email
    );
  ELSE
    -- Новый пользователь - помечаем токен как готовый к использованию
    UPDATE public.auth_tokens
    SET telegram_id = tg_id,
        updated_at = now()
    WHERE token = auth_token;
    
    RETURN json_build_object(
      'success', true,
      'is_new_user', true,
      'display_name', display_name,
      'email', user_email
    );
  END IF;
END;
$$;

-- Создаем триггер для автоматического обновления updated_at
CREATE OR REPLACE FUNCTION public.update_updated_at_auth_tokens()
RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

CREATE TRIGGER update_auth_tokens_updated_at
  BEFORE UPDATE ON public.auth_tokens
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_auth_tokens();

CREATE TRIGGER update_telegram_users_updated_at
  BEFORE UPDATE ON public.telegram_users
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();