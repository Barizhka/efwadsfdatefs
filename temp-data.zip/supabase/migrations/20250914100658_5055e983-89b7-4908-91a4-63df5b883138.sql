-- Исправляем функцию генерации токена для использования hex вместо base64url
CREATE OR REPLACE FUNCTION public.generate_auth_token()
RETURNS text
LANGUAGE plpgsql
SECURITY DEFINER
AS $function$
DECLARE
  new_token TEXT;
BEGIN
  -- Генерируем уникальный токен используя hex кодировку
  new_token := encode(gen_random_bytes(32), 'hex');
  
  -- Сохраняем токен с временем жизни 10 минут
  INSERT INTO public.auth_tokens (token, expires_at)
  VALUES (new_token, now() + INTERVAL '10 minutes');
  
  RETURN new_token;
END;
$function$;