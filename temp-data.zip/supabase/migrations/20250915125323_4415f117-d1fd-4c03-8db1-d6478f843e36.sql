-- Update cities for accounts with "Предварительный прогрев" status to "Неизвестно"
UPDATE accounts 
SET city = 'Неизвестно' 
WHERE emulation_status = 'Предварительный прогрев';

-- Verify the logic matches mockup: accounts with "Предварительный прогрев" should have city "Неизвестно"
-- and accounts with other statuses should have real cities