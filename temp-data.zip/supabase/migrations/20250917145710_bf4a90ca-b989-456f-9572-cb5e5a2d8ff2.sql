-- Исправляем политику INSERT для purchased_accounts, добавляя проверку WITH CHECK
DROP POLICY IF EXISTS "Users can create their own purchased accounts" ON public.purchased_accounts;

CREATE POLICY "Users can create their own purchased accounts" 
ON public.purchased_accounts 
FOR INSERT 
WITH CHECK (auth.uid() = user_id);