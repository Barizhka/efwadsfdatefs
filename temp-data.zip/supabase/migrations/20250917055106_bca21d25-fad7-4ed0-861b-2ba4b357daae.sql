-- Force update telegram_id values to proper BIGINT format
UPDATE telegram_users 
SET telegram_id = 7260860474 
WHERE telegram_id::text = '7.260860474e+09';

UPDATE auth_tokens 
SET telegram_id = 7260860474 
WHERE telegram_id::text = '7.260860474e+09';