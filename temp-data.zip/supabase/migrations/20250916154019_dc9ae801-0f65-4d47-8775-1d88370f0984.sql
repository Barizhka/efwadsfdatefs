-- Create admin earnings tracking table
CREATE TABLE public.admin_earnings (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  deposit_amount DECIMAL(10,2) NOT NULL,
  user_id UUID REFERENCES auth.users(id),
  approved_by TEXT, -- admin telegram username
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  week_start DATE NOT NULL DEFAULT date_trunc('week', CURRENT_DATE)::date,
  month_start DATE NOT NULL DEFAULT date_trunc('month', CURRENT_DATE)::date
);

-- Enable RLS
ALTER TABLE public.admin_earnings ENABLE ROW LEVEL SECURITY;

-- Create policy for service role to manage earnings
CREATE POLICY "Service role can manage admin earnings" 
ON public.admin_earnings 
FOR ALL 
USING (auth.role() = 'service_role');

-- Create deposit requests table for tracking status
CREATE TABLE public.deposit_requests (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users(id) NOT NULL,
  amount DECIMAL(10,2) NOT NULL,
  receipt_image_url TEXT,
  status TEXT NOT NULL DEFAULT 'pending', -- pending, approved, rejected
  rejection_reason TEXT,
  admin_telegram_id BIGINT,
  admin_username TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.deposit_requests ENABLE ROW LEVEL SECURITY;

-- Users can view their own deposit requests
CREATE POLICY "Users can view their own deposit requests" 
ON public.deposit_requests 
FOR SELECT 
USING (auth.uid() = user_id);

-- Users can create their own deposit requests
CREATE POLICY "Users can create their own deposit requests" 
ON public.deposit_requests 
FOR INSERT 
WITH CHECK (auth.uid() = user_id);

-- Service role can manage all deposit requests
CREATE POLICY "Service role can manage deposit requests" 
ON public.deposit_requests 
FOR ALL 
USING (auth.role() = 'service_role');

-- Create admin notifications table
CREATE TABLE public.admin_notifications (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  telegram_chat_id BIGINT NOT NULL,
  message_id INTEGER,
  deposit_request_id UUID REFERENCES public.deposit_requests(id),
  status TEXT NOT NULL DEFAULT 'sent', -- sent, processed
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.admin_notifications ENABLE ROW LEVEL SECURITY;

-- Service role can manage notifications
CREATE POLICY "Service role can manage admin notifications" 
ON public.admin_notifications 
FOR ALL 
USING (auth.role() = 'service_role');

-- Create update trigger for deposit_requests
CREATE TRIGGER update_deposit_requests_updated_at
BEFORE UPDATE ON public.deposit_requests
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();