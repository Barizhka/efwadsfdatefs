-- Fix get_current_user_id function to work with telegram authentication in service role context
CREATE OR REPLACE FUNCTION public.get_current_user_id_unified(p_telegram_id bigint DEFAULT NULL)
 RETURNS uuid
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  supabase_user_id uuid;
  telegram_user_id uuid;
BEGIN
  -- Always try Supabase auth first
  supabase_user_id := auth.uid();
  
  -- If we have Supabase user, return it
  IF supabase_user_id IS NOT NULL THEN
    RETURN supabase_user_id;
  END IF;
  
  -- If telegram_id provided, try to find user by telegram_id
  IF p_telegram_id IS NOT NULL THEN
    SELECT user_id INTO telegram_user_id
    FROM public.telegram_users
    WHERE telegram_id = p_telegram_id
    LIMIT 1;
    
    IF telegram_user_id IS NOT NULL THEN
      RETURN telegram_user_id;
    END IF;
  END IF;
  
  -- Try to get telegram_id from headers as fallback
  DECLARE
    header_telegram_id bigint;
  BEGIN
    header_telegram_id := public.get_current_telegram_id();
    
    IF header_telegram_id IS NOT NULL THEN
      SELECT user_id INTO telegram_user_id
      FROM public.telegram_users
      WHERE telegram_id = header_telegram_id
      LIMIT 1;
      
      IF telegram_user_id IS NOT NULL THEN
        RETURN telegram_user_id;
      END IF;
    END IF;
  EXCEPTION WHEN OTHERS THEN
    -- Ignore header parsing errors
    NULL;
  END;
  
  -- No user found
  RETURN NULL;
END;
$function$;

-- Update the purchase_accounts_unified function to use the new unified function
CREATE OR REPLACE FUNCTION public.purchase_accounts_unified(selected_account_ids text[], telegram_id bigint DEFAULT NULL::bigint)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  current_user_id uuid;
  user_balance numeric;
  total_cost numeric := 0;
  account_record record;
  purchase_result jsonb;
BEGIN
  -- Use the new unified function to determine current user
  current_user_id := public.get_current_user_id_unified(telegram_id);
  
  -- Log for debugging
  RAISE NOTICE 'Purchase attempt: user_id=%, telegram_id=%, account_ids=%', current_user_id, telegram_id, selected_account_ids;
  
  -- If user not determined, return error
  IF current_user_id IS NULL THEN
    RETURN jsonb_build_object(
      'success', false,
      'message', 'Пользователь не авторизован (user_id not found)',
      'debug_info', jsonb_build_object(
        'telegram_id', telegram_id,
        'auth_uid', auth.uid(),
        'has_telegram_users', (SELECT COUNT(*) FROM public.telegram_users WHERE telegram_id = COALESCE(telegram_id, -1))
      )
    );
  END IF;
  
  -- Get current user balance
  SELECT balance INTO user_balance
  FROM public.profiles
  WHERE user_id = current_user_id;
  
  IF user_balance IS NULL THEN
    RETURN jsonb_build_object(
      'success', false,
      'message', 'Профиль пользователя не найден',
      'debug_info', jsonb_build_object(
        'user_id', current_user_id,
        'telegram_id', telegram_id
      )
    );
  END IF;
  
  -- Check account availability and calculate total cost
  FOR account_record IN
    SELECT id, username, city, split, price, available
    FROM public.accounts
    WHERE id = ANY(selected_account_ids)
  LOOP
    IF NOT account_record.available THEN
      RETURN jsonb_build_object(
        'success', false,
        'message', 'Аккаунт ' || account_record.username || ' больше не доступен'
      );
    END IF;
    
    total_cost := total_cost + account_record.price;
  END LOOP;
  
  -- Check sufficient funds
  IF user_balance < total_cost THEN
    RETURN jsonb_build_object(
      'success', false,
      'message', 'Недостаточно средств. Требуется: ' || total_cost || ', доступно: ' || user_balance
    );
  END IF;
  
  -- Execute purchase
  BEGIN
    -- Insert purchased accounts
    FOR account_record IN
      SELECT id, username, city, split, price
      FROM public.accounts
      WHERE id = ANY(selected_account_ids) AND available = true
    LOOP
      INSERT INTO public.purchased_accounts (
        user_id,
        account_id,
        username,
        city,
        split,
        price,
        warmup_status,
        warmup_progress
      ) VALUES (
        current_user_id,
        account_record.id,
        account_record.username,
        account_record.city,
        account_record.split,
        account_record.price,
        'idle',
        0
      );
    END LOOP;
    
    -- Update user balance
    UPDATE public.profiles
    SET balance = balance - total_cost
    WHERE user_id = current_user_id;
    
    -- Mark accounts as unavailable
    UPDATE public.accounts
    SET available = false
    WHERE id = ANY(selected_account_ids);
    
    RETURN jsonb_build_object(
      'success', true,
      'message', 'Покупка завершена успешно',
      'total_cost', total_cost,
      'new_balance', user_balance - total_cost,
      'debug_info', jsonb_build_object(
        'user_id', current_user_id,
        'telegram_id', telegram_id,
        'accounts_purchased', array_length(selected_account_ids, 1)
      )
    );
    
  EXCEPTION WHEN OTHERS THEN
    RETURN jsonb_build_object(
      'success', false,
      'message', 'Ошибка при выполнении покупки: ' || SQLERRM,
      'debug_info', jsonb_build_object(
        'user_id', current_user_id,
        'telegram_id', telegram_id,
        'sql_error', SQLERRM
      )
    );
  END;
END;
$function$;