-- Create auth_tokens table for Telegram authentication
CREATE TABLE public.auth_tokens (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  token TEXT NOT NULL UNIQUE,
  expires_at TIMESTAMP WITH TIME ZONE NOT NULL,
  used BOOLEAN NOT NULL DEFAULT false,
  used_at TIMESTAMP WITH TIME ZONE,
  user_id UUID,
  telegram_id BIGINT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.auth_tokens ENABLE ROW LEVEL SECURITY;

-- Create policies - only for internal use by edge functions
CREATE POLICY "Service role can manage auth tokens"
ON public.auth_tokens
FOR ALL
TO service_role
USING (true)
WITH CHECK (true);

-- Create trigger for automatic timestamp updates
CREATE TRIGGER update_auth_tokens_updated_at
BEFORE UPDATE ON public.auth_tokens
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_auth_tokens();

-- Create telegram_users table if it doesn't exist
CREATE TABLE IF NOT EXISTS public.telegram_users (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL UNIQUE,
  telegram_id BIGINT NOT NULL UNIQUE,
  username TEXT,
  first_name TEXT NOT NULL,
  last_name TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS for telegram_users
ALTER TABLE public.telegram_users ENABLE ROW LEVEL SECURITY;

-- Create policies for telegram_users
CREATE POLICY "Users can view their own telegram data"
ON public.telegram_users
FOR SELECT
USING (auth.uid() = user_id OR has_telegram_access(user_id));

CREATE POLICY "Service role can manage telegram users"
ON public.telegram_users
FOR ALL
TO service_role
USING (true)
WITH CHECK (true);

-- Create trigger for automatic timestamp updates on telegram_users
CREATE TRIGGER update_telegram_users_updated_at
BEFORE UPDATE ON public.telegram_users
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at();