-- Принудительная очистка всех токенов для обновления кэша
DELETE FROM auth_tokens WHERE created_at < NOW();

-- Добавим версионирование для предотвращения кэширования
INSERT INTO auth_tokens (token, expires_at) VALUES ('cache_clear_v2', NOW() + INTERVAL '1 minute');