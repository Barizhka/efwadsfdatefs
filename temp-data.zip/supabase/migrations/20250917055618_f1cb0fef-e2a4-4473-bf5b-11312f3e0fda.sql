-- Force convert scientific notation to proper BIGINT
UPDATE telegram_users SET telegram_id = 7260860474::bigint WHERE id = (SELECT id FROM telegram_users WHERE user_id = '21f882f6-0de0-4364-a6ee-266b72b536c6');
UPDATE auth_tokens SET telegram_id = 7260860474::bigint WHERE user_id = '21f882f6-0de0-4364-a6ee-266b72b536c6';