-- Fix the critical telegram_id scientific notation issue
-- Convert scientific notation values to proper bigint format

UPDATE telegram_users 
SET telegram_id = CAST(telegram_id AS BIGINT)
WHERE telegram_id::text LIKE '%e+%';

-- Update auth_tokens table if it has similar issues
UPDATE auth_tokens 
SET telegram_id = CAST(telegram_id AS BIGINT)
WHERE telegram_id IS NOT NULL AND telegram_id::text LIKE '%e+%';

-- Add constraint to prevent future scientific notation issues
ALTER TABLE telegram_users 
ADD CONSTRAINT telegram_id_valid_format 
CHECK (telegram_id > 0 AND telegram_id < 9223372036854775807);

-- Add similar constraint to auth_tokens
ALTER TABLE auth_tokens 
ADD CONSTRAINT auth_tokens_telegram_id_valid_format 
CHECK (telegram_id IS NULL OR (telegram_id > 0 AND telegram_id < 9223372036854775807));