-- Создаем таблицы для Telegram аутентификации

-- Таблица для связи Telegram пользователей с аккаунтами
CREATE TABLE public.telegram_users (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  telegram_id BIGINT NOT NULL UNIQUE,
  telegram_username TEXT,
  telegram_first_name TEXT,
  telegram_last_name TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Таблица для временных токенов авторизации
CREATE TABLE public.auth_tokens (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  token TEXT NOT NULL UNIQUE,
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  telegram_id BIGINT,
  expires_at TIMESTAMP WITH TIME ZONE NOT NULL,
  used_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Включаем RLS
ALTER TABLE public.telegram_users ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.auth_tokens ENABLE ROW LEVEL SECURITY;

-- Политики для telegram_users
CREATE POLICY "Users can view their own telegram connection" 
ON public.telegram_users 
FOR SELECT 
USING (auth.uid() = user_id);

CREATE POLICY "Service role can manage telegram users" 
ON public.telegram_users 
FOR ALL 
USING (auth.role() = 'service_role');

-- Политики для auth_tokens
CREATE POLICY "Service role can manage auth tokens" 
ON public.auth_tokens 
FOR ALL 
USING (auth.role() = 'service_role');

-- Функция для очистки просроченных токенов
CREATE OR REPLACE FUNCTION public.cleanup_expired_auth_tokens()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  DELETE FROM public.auth_tokens 
  WHERE expires_at < now();
END;
$$;

-- Функция для генерации токена авторизации
CREATE OR REPLACE FUNCTION public.generate_auth_token()
RETURNS text
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  new_token TEXT;
BEGIN
  -- Генерируем уникальный токен
  new_token := encode(gen_random_bytes(32), 'base64url');
  
  -- Сохраняем токен с временем жизни 10 минут
  INSERT INTO public.auth_tokens (token, expires_at)
  VALUES (new_token, now() + INTERVAL '10 minutes');
  
  RETURN new_token;
END;
$$;

-- Функция для обработки успешной авторизации через Telegram
CREATE OR REPLACE FUNCTION public.process_telegram_auth(
  auth_token TEXT,
  tg_id BIGINT,
  tg_username TEXT,
  tg_first_name TEXT,
  tg_last_name TEXT
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  token_record auth_tokens%ROWTYPE;
  existing_user_id UUID;
  new_user_id UUID;
  user_email TEXT;
BEGIN
  -- Проверяем токен
  SELECT * INTO token_record
  FROM public.auth_tokens
  WHERE token = auth_token 
    AND expires_at > now() 
    AND used_at IS NULL;
  
  IF token_record.id IS NULL THEN
    RETURN jsonb_build_object('success', false, 'message', 'Invalid or expired token');
  END IF;
  
  -- Проверяем, есть ли уже пользователь с таким Telegram ID
  SELECT user_id INTO existing_user_id
  FROM public.telegram_users
  WHERE telegram_id = tg_id;
  
  IF existing_user_id IS NOT NULL THEN
    -- Пользователь уже существует, обновляем токен
    UPDATE public.auth_tokens 
    SET user_id = existing_user_id, telegram_id = tg_id, used_at = now()
    WHERE token = auth_token;
    
    -- Обновляем информацию о пользователе
    UPDATE public.telegram_users
    SET telegram_username = tg_username,
        telegram_first_name = tg_first_name,
        telegram_last_name = tg_last_name,
        updated_at = now()
    WHERE telegram_id = tg_id;
    
    RETURN jsonb_build_object(
      'success', true, 
      'message', 'User authenticated',
      'user_id', existing_user_id,
      'token', auth_token
    );
  ELSE
    -- Создаем нового пользователя
    user_email := 'tg_' || tg_id || '@telegram.local';
    
    -- Создаем пользователя в auth.users через функцию
    INSERT INTO auth.users (email, email_confirmed_at, raw_user_meta_data)
    VALUES (
      user_email,
      now(),
      jsonb_build_object(
        'telegram_id', tg_id,
        'telegram_username', tg_username,
        'telegram_first_name', tg_first_name,
        'telegram_last_name', tg_last_name
      )
    )
    RETURNING id INTO new_user_id;
    
    -- Создаем запись в telegram_users
    INSERT INTO public.telegram_users (
      user_id, telegram_id, telegram_username, 
      telegram_first_name, telegram_last_name
    ) VALUES (
      new_user_id, tg_id, tg_username, 
      tg_first_name, tg_last_name
    );
    
    -- Обновляем токен
    UPDATE public.auth_tokens 
    SET user_id = new_user_id, telegram_id = tg_id, used_at = now()
    WHERE token = auth_token;
    
    RETURN jsonb_build_object(
      'success', true,
      'message', 'New user created and authenticated',
      'user_id', new_user_id,
      'token', auth_token
    );
  END IF;
END;
$$;