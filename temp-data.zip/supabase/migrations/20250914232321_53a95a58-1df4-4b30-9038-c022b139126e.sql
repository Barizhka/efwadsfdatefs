UPDATE admin_users 
SET user_id = '2cdb0591-5acc-4abb-b064-1ea9b67e44e1'
WHERE admin_code = 'RiL-Jni-WUK-v9D';