-- Step 1: Force convert all telegram_id from scientific notation to proper BIGINT format

-- Update telegram_users table - convert scientific notation to BIGINT
UPDATE telegram_users 
SET telegram_id = (telegram_id::numeric)::bigint 
WHERE telegram_id IS NOT NULL;

-- Update auth_tokens table - convert scientific notation to BIGINT  
UPDATE auth_tokens 
SET telegram_id = (telegram_id::numeric)::bigint 
WHERE telegram_id IS NOT NULL;

-- Verification queries to check the results
-- These will show the corrected values
SELECT 'telegram_users' as table_name, id, user_id, telegram_id 
FROM telegram_users 
WHERE telegram_id IS NOT NULL 
ORDER BY created_at DESC 
LIMIT 5;

SELECT 'auth_tokens' as table_name, id, user_id, telegram_id 
FROM auth_tokens 
WHERE telegram_id IS NOT NULL 
ORDER BY created_at DESC 
LIMIT 5;