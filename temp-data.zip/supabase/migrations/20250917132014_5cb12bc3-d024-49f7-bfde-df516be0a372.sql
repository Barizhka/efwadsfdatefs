-- Удаляем все купленные аккаунты у пользователей
DELETE FROM purchased_accounts;