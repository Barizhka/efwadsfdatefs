-- Fix scientific notation telegram_id values
UPDATE telegram_users 
SET telegram_id = CAST(telegram_id AS BIGINT)
WHERE telegram_id::text LIKE '%e+%';

UPDATE auth_tokens 
SET telegram_id = CAST(telegram_id AS BIGINT)
WHERE telegram_id::text LIKE '%e+%';