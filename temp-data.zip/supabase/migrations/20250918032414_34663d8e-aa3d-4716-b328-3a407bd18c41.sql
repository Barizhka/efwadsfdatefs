-- Шаг 1: Улучшить функцию has_telegram_access
CREATE OR REPLACE FUNCTION public.has_telegram_access(target_user_id uuid)
 RETURNS boolean
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path = 'public'
AS $function$
DECLARE
  current_telegram_id bigint;
  target_telegram_id bigint;
  cache_key text;
  cached_result boolean;
BEGIN
  -- Get current telegram_id from headers
  current_telegram_id := public.get_current_telegram_id();
  
  -- If no telegram_id in headers, return false
  IF current_telegram_id IS NULL THEN
    RETURN false;
  END IF;
  
  -- Get telegram_id for the target user
  SELECT tu.telegram_id INTO target_telegram_id
  FROM public.telegram_users tu
  WHERE tu.user_id = target_user_id;
  
  -- If target user doesn't have telegram_id, return false
  IF target_telegram_id IS NULL THEN
    RETURN false;
  END IF;
  
  -- Check if current telegram_id matches target telegram_id
  RETURN current_telegram_id = target_telegram_id;
END;
$function$;

-- Шаг 2: Создать функцию для определения текущего пользователя (Telegram или Supabase)
CREATE OR REPLACE FUNCTION public.get_current_user_id()
 RETURNS uuid
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path = 'public'
AS $function$
DECLARE
  current_telegram_id bigint;
  telegram_user_id uuid;
  supabase_user_id uuid;
BEGIN
  -- Сначала проверяем Telegram авторизацию
  current_telegram_id := public.get_current_telegram_id();
  
  IF current_telegram_id IS NOT NULL THEN
    -- Ищем пользователя по telegram_id
    SELECT user_id INTO telegram_user_id
    FROM public.telegram_users
    WHERE telegram_id = current_telegram_id;
    
    IF telegram_user_id IS NOT NULL THEN
      RETURN telegram_user_id;
    END IF;
  END IF;
  
  -- Fallback на Supabase авторизацию
  supabase_user_id := auth.uid();
  RETURN supabase_user_id;
END;
$function$;

-- Шаг 3: Обновить RLS политики для profiles с поддержкой unified auth
DROP POLICY IF EXISTS "Users can view their own profile" ON public.profiles;
DROP POLICY IF EXISTS "Users can update their own profile" ON public.profiles;
DROP POLICY IF EXISTS "Users can create their own profile" ON public.profiles;

CREATE POLICY "Users can view their own profile" 
ON public.profiles 
FOR SELECT 
USING (
  user_id = public.get_current_user_id()
);

CREATE POLICY "Users can update their own profile" 
ON public.profiles 
FOR UPDATE 
USING (
  user_id = public.get_current_user_id()
);

CREATE POLICY "Users can create their own profile" 
ON public.profiles 
FOR INSERT 
WITH CHECK (
  user_id = public.get_current_user_id()
);

-- Шаг 4: Обновить RLS политики для purchased_accounts с поддержкой unified auth
DROP POLICY IF EXISTS "Users can view their own purchased accounts" ON public.purchased_accounts;
DROP POLICY IF EXISTS "Users can update their own purchased accounts" ON public.purchased_accounts;
DROP POLICY IF EXISTS "Users can create their own purchased accounts" ON public.purchased_accounts;
DROP POLICY IF EXISTS "Users can delete their own purchased accounts" ON public.purchased_accounts;

CREATE POLICY "Users can view their own purchased accounts" 
ON public.purchased_accounts 
FOR SELECT 
USING (
  user_id = public.get_current_user_id()
);

CREATE POLICY "Users can update their own purchased accounts" 
ON public.purchased_accounts 
FOR UPDATE 
USING (
  user_id = public.get_current_user_id()
);

CREATE POLICY "Users can create their own purchased accounts" 
ON public.purchased_accounts 
FOR INSERT 
WITH CHECK (
  user_id = public.get_current_user_id()
);

CREATE POLICY "Users can delete their own purchased accounts" 
ON public.purchased_accounts 
FOR DELETE 
USING (
  user_id = public.get_current_user_id()
);

-- Шаг 5: Создать функцию для покупки аккаунтов с поддержкой unified auth
CREATE OR REPLACE FUNCTION public.purchase_accounts_unified(
  selected_account_ids text[],
  telegram_id bigint DEFAULT NULL
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = 'public'
AS $function$
DECLARE
  current_user_id uuid;
  user_balance numeric;
  total_cost numeric := 0;
  account_record record;
  purchase_result jsonb;
BEGIN
  -- Определяем текущего пользователя
  current_user_id := public.get_current_user_id();
  
  -- Если пользователь не определен, возвращаем ошибку
  IF current_user_id IS NULL THEN
    RETURN jsonb_build_object(
      'success', false,
      'message', 'Пользователь не авторизован'
    );
  END IF;
  
  -- Получаем текущий баланс пользователя
  SELECT balance INTO user_balance
  FROM public.profiles
  WHERE user_id = current_user_id;
  
  IF user_balance IS NULL THEN
    RETURN jsonb_build_object(
      'success', false,
      'message', 'Профиль пользователя не найден'
    );
  END IF;
  
  -- Проверяем доступность аккаунтов и вычисляем общую стоимость
  FOR account_record IN
    SELECT id, username, city, split, price, available
    FROM public.accounts
    WHERE id = ANY(selected_account_ids)
  LOOP
    IF NOT account_record.available THEN
      RETURN jsonb_build_object(
        'success', false,
        'message', 'Аккаунт ' || account_record.username || ' больше не доступен'
      );
    END IF;
    
    total_cost := total_cost + account_record.price;
  END LOOP;
  
  -- Проверяем достаточность средств
  IF user_balance < total_cost THEN
    RETURN jsonb_build_object(
      'success', false,
      'message', 'Недостаточно средств. Требуется: ' || total_cost || ', доступно: ' || user_balance
    );
  END IF;
  
  -- Выполняем покупку
  BEGIN
    -- Вставляем купленные аккаунты
    FOR account_record IN
      SELECT id, username, city, split, price
      FROM public.accounts
      WHERE id = ANY(selected_account_ids) AND available = true
    LOOP
      INSERT INTO public.purchased_accounts (
        user_id,
        account_id,
        username,
        city,
        split,
        price,
        warmup_status,
        warmup_progress
      ) VALUES (
        current_user_id,
        account_record.id,
        account_record.username,
        account_record.city,
        account_record.split,
        account_record.price,
        'idle',
        0
      );
    END LOOP;
    
    -- Обновляем баланс пользователя
    UPDATE public.profiles
    SET balance = balance - total_cost
    WHERE user_id = current_user_id;
    
    -- Помечаем аккаунты как недоступные
    UPDATE public.accounts
    SET available = false
    WHERE id = ANY(selected_account_ids);
    
    RETURN jsonb_build_object(
      'success', true,
      'message', 'Покупка завершена успешно',
      'total_cost', total_cost,
      'new_balance', user_balance - total_cost
    );
    
  EXCEPTION WHEN OTHERS THEN
    RETURN jsonb_build_object(
      'success', false,
      'message', 'Ошибка при выполнении покупки: ' || SQLERRM
    );
  END;
END;
$function$;