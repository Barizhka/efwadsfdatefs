-- Insert sample accounts data
INSERT INTO public.accounts (name, city, status, type, limit_value, split_value, price, emulation_status) VALUES
  ('Account_001', 'Moscow', 'available', 'facebook', 100, 0.75, 15.99, 'off'),
  ('Account_002', 'St. Petersburg', 'available', 'facebook', 150, 0.80, 19.99, 'on'),
  ('Account_003', 'Kiev', 'warming', 'instagram', 200, 0.70, 24.99, 'off'),
  ('Account_004', 'Warsaw', 'available', 'facebook', 120, 0.85, 17.99, 'on'),
  ('Account_005', 'Prague', 'available', 'instagram', 180, 0.75, 22.99, 'off'),
  ('Account_006', 'Berlin', 'warming', 'facebook', 160, 0.90, 20.99, 'on'),
  ('Account_007', 'Vienna', 'available', 'instagram', 140, 0.75, 18.99, 'off'),
  ('Account_008', 'Budapest', 'available', 'facebook', 110, 0.80, 16.99, 'on'),
  ('Account_009', 'Minsk', 'warming', 'instagram', 190, 0.70, 23.99, 'off'),
  ('Account_010', 'Riga', 'available', 'facebook', 130, 0.85, 17.49, 'on');