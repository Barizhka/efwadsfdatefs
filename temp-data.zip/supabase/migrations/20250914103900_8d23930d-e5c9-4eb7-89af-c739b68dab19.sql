-- Очистим старые неиспользованные токены авторизации
DELETE FROM auth_tokens WHERE used_at IS NULL AND created_at < NOW() - INTERVAL '10 minutes';