-- Update RLS policies to support Telegram users
-- First, create helper functions to get telegram_id from context

-- Function to get current telegram_id from headers or context
CREATE OR REPLACE FUNCTION public.get_current_telegram_id()
RETURNS bigint AS $$
DECLARE
  telegram_id_header text;
  telegram_id bigint;
BEGIN
  -- Try to get telegram_id from headers
  telegram_id_header := current_setting('request.headers', true)::json->>'x-telegram-id';
  
  IF telegram_id_header IS NOT NULL THEN
    BEGIN
      telegram_id := telegram_id_header::bigint;
      RETURN telegram_id;
    EXCEPTION WHEN OTHERS THEN
      RETURN NULL;
    END;
  END IF;
  
  RETURN NULL;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER STABLE;

-- Function to check if current user has access via telegram_id
CREATE OR REPLACE FUNCTION public.has_telegram_access(target_user_id uuid)
RETURNS boolean AS $$
DECLARE
  current_telegram_id bigint;
  target_telegram_id bigint;
BEGIN
  current_telegram_id := public.get_current_telegram_id();
  
  IF current_telegram_id IS NULL THEN
    RETURN false;
  END IF;
  
  -- Get telegram_id for the target user
  SELECT tu.telegram_id INTO target_telegram_id
  FROM public.telegram_users tu
  WHERE tu.user_id = target_user_id;
  
  RETURN current_telegram_id = target_telegram_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER STABLE;

-- Update profiles policies to support Telegram users
DROP POLICY IF EXISTS "Users can view their own profile" ON public.profiles;
DROP POLICY IF EXISTS "Users can update their own profile" ON public.profiles;

CREATE POLICY "Users can view their own profile" 
ON public.profiles 
FOR SELECT 
USING (auth.uid() = user_id OR public.has_telegram_access(user_id));

CREATE POLICY "Users can update their own profile" 
ON public.profiles 
FOR UPDATE 
USING (auth.uid() = user_id OR public.has_telegram_access(user_id));

-- Add INSERT policy for profiles (in case they don't exist)
CREATE POLICY "Users can create their own profile" 
ON public.profiles 
FOR INSERT 
WITH CHECK (auth.uid() = user_id OR public.has_telegram_access(user_id));

-- Update purchased_accounts policies to support Telegram users
DROP POLICY IF EXISTS "Users can view their own purchased accounts" ON public.purchased_accounts;
DROP POLICY IF EXISTS "Users can create their own purchased accounts" ON public.purchased_accounts;
DROP POLICY IF EXISTS "Users can update their own purchased accounts" ON public.purchased_accounts;
DROP POLICY IF EXISTS "Users can delete their own purchased accounts" ON public.purchased_accounts;

CREATE POLICY "Users can view their own purchased accounts" 
ON public.purchased_accounts 
FOR SELECT 
USING (auth.uid() = user_id OR public.has_telegram_access(user_id));

CREATE POLICY "Users can create their own purchased accounts" 
ON public.purchased_accounts 
FOR INSERT 
WITH CHECK (auth.uid() = user_id OR public.has_telegram_access(user_id));

CREATE POLICY "Users can update their own purchased accounts" 
ON public.purchased_accounts 
FOR UPDATE 
USING (auth.uid() = user_id OR public.has_telegram_access(user_id));

CREATE POLICY "Users can delete their own purchased accounts" 
ON public.purchased_accounts 
FOR DELETE 
USING (auth.uid() = user_id OR public.has_telegram_access(user_id));

-- Function to create profile if it doesn't exist
CREATE OR REPLACE FUNCTION public.ensure_user_profile(p_user_id uuid, p_display_name text DEFAULT 'Пользователь', p_email text DEFAULT '')
RETURNS void AS $$
BEGIN
  INSERT INTO public.profiles (user_id, display_name, email, balance)
  VALUES (p_user_id, p_display_name, p_email, 125000.0)
  ON CONFLICT (user_id) DO NOTHING;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;