-- Полная замена аккаунтов: удаление всех существующих и создание точно 130 аккаунтов по логике мокапа

-- Удаляем все существующие аккаунты
DELETE FROM accounts;

-- Создаем функцию для генерации аккаунтов по логике мокапа
DO $$
DECLARE
    i INTEGER;
    cities TEXT[] := ARRAY['Москва', 'Санкт-Петербург', 'Новосибирск', 'Екатеринбург', 'Казань', 'Нижний Новгород', 'Челябинск', 'Омск', 'Самара', 'Ростов-на-Дону', 'Уфа', 'Красноярск', 'Воронеж', 'Пермь', 'Волгоград'];
    first_names TEXT[] := ARRAY['Александр', 'Анна', 'Дмитрий', 'Мария', 'Сергей', 'Елена', 'Алексей', 'Ольга', 'Андрей', 'Наталья', 'Михаил', 'Татьяна', 'Иван', 'Екатерина', 'Николай'];
    last_names TEXT[] := ARRAY['Иванов', 'Петров', 'Сидоров', 'Козлов', 'Смирнов', 'Новиков', 'Морозов', 'Петрова', 'Иванова', 'Сидорова', 'Козлова', 'Смирнова', 'Новикова', 'Морозова'];
    split_values INTEGER[] := ARRAY[50000, 75000, 100000, 120000, 150000];
    emulation_statuses TEXT[] := ARRAY['Готов к заказу - пассивный прогрев', 'Прогрев аккаунта на ГЕО', 'Предварительный прогрев'];
    
    first_name TEXT;
    last_name TEXT;
    account_name TEXT;
    account_id TEXT;
    account_status TEXT;
    account_city TEXT;
    account_split INTEGER;
    account_price NUMERIC;
    account_emulation_status TEXT;
    
BEGIN
    -- Устанавливаем фиксированный seed для воспроизводимости результатов
    PERFORM setseed(0.123456789);
    
    FOR i IN 0..129 LOOP
        -- Генерируем ID точно по формуле мокапа
        account_id := ((i * 23456789 + 85649104) % 90000000 + 10000000)::TEXT;
        
        -- Выбираем имя и фамилию случайно из списков мокапа
        first_name := first_names[floor(random() * array_length(first_names, 1) + 1)];
        last_name := last_names[floor(random() * array_length(last_names, 1) + 1)];
        account_name := first_name || ' ' || last_name;
        
        -- Генерируем статус точно по логике мокапа: Math.random() > 0.7 ? 'warming' : 'active'
        account_status := CASE WHEN random() > 0.7 THEN 'warming' ELSE 'active' END;
        
        -- Выбираем split случайно из списка
        account_split := split_values[floor(random() * array_length(split_values, 1) + 1)];
        
        -- Рассчитываем цену по логике мокапа
        account_price := CASE 
            WHEN account_split = 50000 THEN 2000
            WHEN account_split = 75000 THEN 3500  
            WHEN account_split = 100000 THEN 5000
            WHEN account_split = 120000 THEN 6000
            WHEN account_split = 150000 THEN 7500
            ELSE 2000
        END;
        
        -- Выбираем статус эмуляции случайно
        account_emulation_status := emulation_statuses[floor(random() * array_length(emulation_statuses, 1) + 1)];
        
        -- Определяем город по логике мокапа: если "Предварительный прогрев" - то "Неизвестно", иначе случайный город
        account_city := CASE 
            WHEN account_emulation_status = 'Предварительный прогрев' THEN 'Неизвестно'
            ELSE cities[floor(random() * array_length(cities, 1) + 1)]
        END;
        
        -- Создаем аккаунт с точными данными из мокапа
        INSERT INTO accounts (
            id,
            name,
            city,
            status,
            split_value,
            price,
            emulation_status,
            type,
            limit_value
        ) VALUES (
            account_id::uuid,
            account_name,
            account_city,
            account_status,
            account_split,
            account_price,
            account_emulation_status,
            'facebook',
            100
        );
    END LOOP;
    
    RAISE NOTICE 'Создано точно 130 аккаунтов по логике мокапа';
END $$;