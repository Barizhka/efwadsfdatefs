-- Add balance column to profiles table
ALTER TABLE public.profiles 
ADD COLUMN balance NUMERIC DEFAULT 125000.0;