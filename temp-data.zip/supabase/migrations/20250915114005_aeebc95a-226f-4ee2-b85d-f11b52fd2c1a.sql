-- Create telegram_users table for Telegram authentication
CREATE TABLE public.telegram_users (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id uuid REFERENCES auth.users NOT NULL,
  telegram_id bigint NOT NULL UNIQUE,
  telegram_username text,
  telegram_first_name text,
  telegram_last_name text,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE public.telegram_users ENABLE ROW LEVEL SECURITY;

-- Create RLS policies
CREATE POLICY "Service role can manage telegram users" 
ON public.telegram_users 
FOR ALL 
USING (auth.role() = 'service_role'::text);

CREATE POLICY "Users can view their own telegram data" 
ON public.telegram_users 
FOR SELECT 
USING (auth.uid() = user_id);

-- Create indexes for performance
CREATE INDEX idx_telegram_users_telegram_id ON public.telegram_users(telegram_id);
CREATE INDEX idx_telegram_users_user_id ON public.telegram_users(user_id);

-- Add trigger for updated_at
CREATE TRIGGER update_telegram_users_updated_at
  BEFORE UPDATE ON public.telegram_users
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();