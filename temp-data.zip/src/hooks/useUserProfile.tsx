import { useState, useEffect } from 'react';
import { useAuthContext } from '@/providers/AuthProvider';

interface UserProfile {
  displayName: string;
  email: string;
  telegramUsername?: string;
  telegramFirstName?: string;
  telegramLastName?: string;
}

export const useUserProfile = () => {
  const { user: authUser, isGuest } = useAuthContext();
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(false);

  const generateDisplayName = (
    firstName?: string | null,
    lastName?: string | null,
    username?: string | null
  ): string => {
    if (firstName && lastName) {
      return `пользователь: ${firstName} ${lastName}`.trim();
    } else if (firstName) {
      return `пользователь: ${firstName}`.trim();
    } else if (username) {
      return `пользователь: ${username}`;
    }
    return 'Пользователь';
  };

  useEffect(() => {
    console.log('useUserProfile: Effect triggered', { isGuest, hasAuthUser: !!authUser, userEmail: authUser?.email });
    
    if (isGuest || !authUser) {
      console.log('useUserProfile: Guest or no user');
      setProfile(null);
      setLoading(false);
      return;
    }

    console.log('useUserProfile: Processing user data', {
      hasTelegramFirstName: !!authUser.user_metadata?.telegram_first_name,
      hasTelegramUsername: !!authUser.user_metadata?.telegram_username,
      email: authUser.email
    });

    // НЕ устанавливаем loading=true, если данные уже есть и они те же
    
    // Используем данные из authUser напрямую, если они есть в metadata
    if (authUser.user_metadata?.telegram_first_name || authUser.user_metadata?.telegram_username) {
      const displayName = generateDisplayName(
        authUser.user_metadata.telegram_first_name,
        authUser.user_metadata.telegram_last_name,
        authUser.user_metadata.telegram_username
      );
      
      console.log('useUserProfile: Setting telegram profile', { displayName });
      
      setProfile({
        displayName,
        email: authUser.email || '',
        telegramUsername: authUser.user_metadata.telegram_username,
        telegramFirstName: authUser.user_metadata.telegram_first_name,
        telegramLastName: authUser.user_metadata.telegram_last_name
      });
      setLoading(false);
      return;
    }

    // Иначе используем fallback на основе email
    const fallbackName = authUser.email?.split('@')[0] || 'Пользователь';
    console.log('useUserProfile: Setting fallback profile', { fallbackName });
    
    setProfile({
      displayName: fallbackName,
      email: authUser.email || ''
    });
    setLoading(false);
  }, [authUser, isGuest]);

  return {
    profile,
    loading,
    isGuest
  };
};