import { useState, useEffect, useCallback } from 'react';
import { toast } from 'sonner';

interface AdminAuthState {
  isAuthenticated: boolean;
  isLoading: boolean;
  canAccessDeveloperMode: boolean;
}

export const useAdminAuth = () => {
  const [authState, setAuthState] = useState<AdminAuthState>({
    isAuthenticated: false,
    isLoading: true,
    canAccessDeveloperMode: false
  });

  // Check access permissions on mount
  useEffect(() => {
    const checkAccess = () => {
      try {
        console.log('🔍 AdminAuth: Checking access permissions...');
        
        // Сначала проверяем сохраненную админскую сессию
        const savedAdminSession = localStorage.getItem('admin_session_active');
        console.log('📋 AdminAuth: Saved admin session:', savedAdminSession);
        
        if (savedAdminSession === 'true') {
          console.log('🎉 AdminAuth: Restoring admin session from localStorage');
          setAuthState({
            isAuthenticated: true,
            isLoading: false,
            canAccessDeveloperMode: true
          });
          return;
        }
        
        // Проверяем telegram username из текущей авторизации
        const storedUser = localStorage.getItem('authenticated_user');
        const authMethod = localStorage.getItem('auth_method');
        const unifiedSession = localStorage.getItem('unified_auth_session');
        
        console.log('📋 AdminAuth: localStorage data:', {
          hasStoredUser: !!storedUser,
          authMethod,
          hasUnifiedSession: !!unifiedSession
        });
        
        let canAccess = false;
        let isAllowedAdmin = false;
        
        // Попробуем разные способы получения username
        let username = null;
        
        // Способ 1: из authenticated_user
        if (storedUser && authMethod === 'telegram') {
          try {
            const userData = JSON.parse(storedUser);
            username = userData.telegram_username;
            console.log('📋 AdminAuth: Username from authenticated_user:', username);
          } catch (error) {
            console.error('Error parsing telegram user data:', error);
          }
        }
        
        // Способ 2: из unified_auth_session
        if (!username && unifiedSession) {
          try {
            const sessionData = JSON.parse(unifiedSession);
            const user = sessionData.user;
            if (user) {
              username = user.user_metadata?.telegram_username || 
                        user.user_metadata?.username ||
                        user.app_metadata?.telegram_username;
              console.log('📋 AdminAuth: Username from unified_auth_session:', username);
              console.log('📋 AdminAuth: User metadata:', user.user_metadata);
              console.log('📋 AdminAuth: App metadata:', user.app_metadata);
            }
          } catch (error) {
            console.error('Error parsing unified session data:', error);
          }
        }
        
        // Проверяем разрешенные usernames
        if (username) {
          isAllowedAdmin = username === 'phantasmgg' || username === 'grevsplitatp';
          canAccess = isAllowedAdmin;
          console.log('✅ AdminAuth: Username check result:', {
            username,
            isAllowedAdmin,
            canAccess
          });
        } else {
          console.log('❌ AdminAuth: No username found in any storage');
        }

        // Для разрешенных админов автоматически устанавливаем аутентификацию
        if (isAllowedAdmin) {
          localStorage.setItem('admin_session_active', 'true');
          console.log('🎉 AdminAuth: Automatic admin access granted!');
          setAuthState({ 
            isAuthenticated: true, 
            isLoading: false, 
            canAccessDeveloperMode: true 
          });
        } else {
          console.log('📋 AdminAuth: Setting non-admin state:', {
            canAccess
          });
          setAuthState({ 
            isAuthenticated: false, 
            isLoading: false, 
            canAccessDeveloperMode: canAccess 
          });
        }
      } catch (error) {
        console.error('Access check error:', error);
        setAuthState({ 
          isAuthenticated: false, 
          isLoading: false, 
          canAccessDeveloperMode: false 
        });
      }
    };

    checkAccess();
  }, []);

  const login = useCallback(async (adminCode: string) => {
    try {
      setAuthState(prev => ({ ...prev, isLoading: true }));

      // Новый код доступа
      const validCode = 'dev228';
      
      if (adminCode !== validCode) {
        toast.error('Неверный код доступа');
        setAuthState(prev => ({ ...prev, isLoading: false }));
        return false;
      }

      // Сохраняем сессию админа
      localStorage.setItem('admin_session_active', 'true');
      
      setAuthState({
        isAuthenticated: true,
        isLoading: false,
        canAccessDeveloperMode: true
      });

      toast.success('Режим разработчика активирован');
      return true;
    } catch (error) {
      console.error('Admin login error:', error);
      toast.error('Ошибка входа в режим разработчика');
      setAuthState(prev => ({ ...prev, isLoading: false }));
      return false;
    }
  }, []);

  const logout = useCallback(async () => {
    try {
      localStorage.removeItem('admin_session_active');
      setAuthState(prev => ({ 
        ...prev, 
        isAuthenticated: false 
      }));
      toast.success('Выход из режима разработчика выполнен');
    } catch (error) {
      console.error('Admin logout error:', error);
    }
  }, []);

  return {
    isAuthenticated: authState.isAuthenticated,
    isLoading: authState.isLoading,
    canAccessDeveloperMode: authState.canAccessDeveloperMode,
    login,
    logout
  };
};