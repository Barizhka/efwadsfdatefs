import React, { createContext, useContext, useEffect, useState, ReactNode } from 'react';
import { User, Session } from '@supabase/supabase-js';
import { supabase } from '@/integrations/supabase/client';
import { useAppStore } from '@/store/appStore';

interface AuthContextType {
  user: User | null;
  session: Session | null;
  isLoading: boolean;
  isGuest: boolean;
  isAuthenticated: boolean;
  isTelegramAuth: boolean;
  logout: () => Promise<void>;
  setTelegramSession: (data: any) => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuthContext = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuthContext must be used within an AuthProvider');
  }
  return context;
};

interface AuthProviderProps {
  children: ReactNode;
}

export const AuthProvider: React.FC<AuthProviderProps> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isTelegramAuth, setIsTelegramAuth] = useState(false);
  const { setUser: setStoreUser, updateUser } = useAppStore();

  // Function to load user profile data from database with unified auth support
  const loadUserProfile = async (userId: string, telegramId?: number) => {
    try {
      console.log('🔍 Loading user profile from database:', userId, telegramId ? `(Telegram: ${telegramId})` : '(Supabase)');
      
      // Set headers for telegram authentication if needed
      let headers = {};
      if (telegramId) {
        headers = { 'x-telegram-id': telegramId.toString() };
      }
      
      const { data: profile, error } = await supabase
        .from('profiles')
        .select('balance, display_name, email')
        .eq('user_id', userId)
        .maybeSingle();
      
      if (error) {
        console.error('❌ Error loading profile:', error);
        return;
      }
      
      if (!profile) {
        console.log('📝 Creating new profile for user:', userId);
        const { error: createError } = await supabase
          .from('profiles')
          .insert({
            user_id: userId,
            balance: 125000, // Default balance
            display_name: 'Пользователь',
            email: ''
          });
        
        if (createError) {
          console.error('❌ Error creating profile:', createError);
        } else {
          // Update store with default balance
          updateUser({ balance: 125000 });
          console.log('✅ Profile created with default balance');
        }
        return;
      }
      
      console.log('✅ Profile loaded:', { balance: profile.balance, display_name: profile.display_name });
      // Update store with real balance from database
      updateUser({ 
        balance: Number(profile.balance) || 0,
        name: profile.display_name || 'Пользователь'
      });
    } catch (error) {
      console.error('❌ Exception loading profile:', error);
    }
  };

  const isGuest = !user && !session;
  const isAuthenticated = !!user || !!session || isTelegramAuth;

  useEffect(() => {
    console.log('🔐 AuthProvider: Initializing authentication...');
    
    // Set up auth state listener FIRST
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      (event, session) => {
        console.log('🔄 AuthProvider: Auth state changed:', event, session ? 'session exists' : 'no session');
        
        // Only synchronous state updates here
        setSession(session);
        setUser(session?.user ?? null);
        
        // Defer profile loading with setTimeout to prevent deadlock
        if (session?.user) {
          setIsTelegramAuth(false);
          console.log('✅ Supabase session found, loading profile...');
          setTimeout(() => {
            loadUserProfile(session.user.id);
            setStoreUser({
              id: session.user.id,
              name: session.user.user_metadata?.full_name || session.user.email || 'Пользователь',
              avatar: session.user.user_metadata?.avatar_url || '',
              balance: 0,
              plan: 'basic'
            });
          }, 0);
        } else if (event === 'SIGNED_OUT') {
          setStoreUser(null);
          setIsTelegramAuth(false);
        }
        
        setIsLoading(false);
      }
    );

    // THEN get initial session
    const getInitialSession = async () => {
      try {
        // Check for Telegram session first
        const unifiedSession = localStorage.getItem('unified_auth_session');
        
        if (unifiedSession) {
          try {
            const parsedData = JSON.parse(unifiedSession);
            const { session: telegramSession, user: telegramUser } = parsedData;
            
            if (telegramSession?.access_token && telegramUser?.id) {
              console.log('✅ AuthProvider: Valid Telegram session found');
              setSession(telegramSession);
              setUser(telegramUser);
              setIsTelegramAuth(true);
              
              setTimeout(() => {
                const telegramId = parseInt(telegramUser.user_metadata?.telegram_id);
                loadUserProfile(telegramUser.id, telegramId);
                setStoreUser({
                  id: telegramUser.id,
                  name: telegramUser.user_metadata?.full_name || telegramUser.email || 'ВОЖДЬ',
                  avatar: telegramUser.user_metadata?.avatar_url || '',
                  balance: 0,
                  plan: 'basic'
                });
              }, 0);
              setIsLoading(false);
              return;
            }
          } catch (parseError) {
            console.error('❌ Invalid unified session, removing:', parseError);
            localStorage.removeItem('unified_auth_session');
          }
        }

        // Fallback to Supabase session
        const { data: { session }, error } = await supabase.auth.getSession();
        
        if (error) {
          console.error('❌ AuthProvider: Error getting session:', error);
        }
        
        setSession(session);
        setUser(session?.user ?? null);
        
        if (session?.user) {
          setIsTelegramAuth(false);
          setTimeout(() => {
            loadUserProfile(session.user.id);
            setStoreUser({
              id: session.user.id,
              name: session.user.user_metadata?.full_name || session.user.email || 'Пользователь',
              avatar: session.user.user_metadata?.avatar_url || '',
              balance: 0,
              plan: 'basic'
            });
          }, 0);
        }
      } catch (error) {
        console.error('❌ AuthProvider: Failed to get initial session:', error);
      } finally {
        setIsLoading(false);
      }
    };

    getInitialSession();
    
    // Listen for localStorage changes (Telegram auth)
    const handleStorageChange = () => {
      const unifiedSession = localStorage.getItem('unified_auth_session');
      
      if (unifiedSession) {
        try {
          const parsedData = JSON.parse(unifiedSession);
          const { session: telegramSession, user: telegramUser } = parsedData;
          
          if (telegramSession?.access_token && telegramUser?.id) {
            setSession(telegramSession);
            setUser(telegramUser);
            setIsTelegramAuth(true);
            
            setTimeout(() => {
              const telegramId = parseInt(telegramUser.user_metadata?.telegram_id);
              loadUserProfile(telegramUser.id, telegramId);
              setStoreUser({
                id: telegramUser.id,
                name: telegramUser.user_metadata?.full_name || telegramUser.email || 'ВОЖДЬ',
                avatar: telegramUser.user_metadata?.avatar_url || '',
                balance: 0,
                plan: 'basic'
              });
            }, 0);
            setIsLoading(false);
          }
        } catch (error) {
          console.error('❌ AuthProvider: Error parsing unified session:', error);
          localStorage.removeItem('unified_auth_session');
        }
      }
    };

    window.addEventListener('storage', handleStorageChange);
    window.addEventListener('authStateChange', handleStorageChange);

    return () => {
      subscription.unsubscribe();
      window.removeEventListener('storage', handleStorageChange);
      window.removeEventListener('authStateChange', handleStorageChange);
    };
  }, []);

  const logout = async () => {
    try {
      console.log('🚪 AuthProvider: Logging out...');
      
      // Очищаем Telegram сессию
      localStorage.removeItem('unified_auth_session');
      localStorage.removeItem('auth_method');
      localStorage.removeItem('last_welcome_shown');
      
      // Очищаем состояние
      setSession(null);
      setUser(null);
      // Clear user from store as well
      setStoreUser(null);
      setIsTelegramAuth(false);
      setIsLoading(false);
      
      // Выходим из Supabase
      const { error } = await supabase.auth.signOut();
      if (error) {
        console.error('❌ AuthProvider: Logout error:', error);
      } else {
        console.log('✅ AuthProvider: Logout successful');
      }
    } catch (error) {
      console.error('❌ AuthProvider: Logout failed:', error);
    }
  };

  const setTelegramSession = (data: any) => {
    console.log('📱 AuthProvider: Setting Telegram session:', data);
    // This would be handled by the auth state change listener
  };

  const value: AuthContextType = {
    user,
    session,
    isLoading,
    isGuest,
    isAuthenticated,
    isTelegramAuth,
    logout,
    setTelegramSession,
  };

  console.log('🔐 AuthProvider render:', {
    hasUser: !!user,
    hasSession: !!session,
    isLoading,
    isGuest,
    isAuthenticated,
    isTelegramAuth,
    userId: user?.id
  });

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
};