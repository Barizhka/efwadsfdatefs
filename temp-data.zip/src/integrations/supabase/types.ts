export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "13.0.4"
  }
  public: {
    Tables: {
      academic_discount_verifications: {
        Row: {
          created_at: string
          discount_percentage: number | null
          email: string
          expires_at: string | null
          id: string
          institution_name: string
          student_id: string | null
          updated_at: string
          user_id: string | null
          verification_document_url: string | null
          verification_status: string | null
          verified_at: string | null
        }
        Insert: {
          created_at?: string
          discount_percentage?: number | null
          email: string
          expires_at?: string | null
          id?: string
          institution_name: string
          student_id?: string | null
          updated_at?: string
          user_id?: string | null
          verification_document_url?: string | null
          verification_status?: string | null
          verified_at?: string | null
        }
        Update: {
          created_at?: string
          discount_percentage?: number | null
          email?: string
          expires_at?: string | null
          id?: string
          institution_name?: string
          student_id?: string | null
          updated_at?: string
          user_id?: string | null
          verification_document_url?: string | null
          verification_status?: string | null
          verified_at?: string | null
        }
        Relationships: []
      }
      accounts: {
        Row: {
          anti_detection: boolean
          available: boolean
          balance: number
          city: string
          created_at: string | null
          emulation_status: string
          id: string
          last_activity: string
          max_tokens: number
          model: string
          name: string
          operator: string
          price: number
          progress: number
          proxy: string
          ready_for_orders: boolean
          split: number
          status: string
          tasks: number
          temperature: number
          two_fa: boolean
          type: string
          updated_at: string | null
          username: string
        }
        Insert: {
          anti_detection?: boolean
          available?: boolean
          balance?: number
          city: string
          created_at?: string | null
          emulation_status: string
          id: string
          last_activity: string
          max_tokens: number
          model: string
          name: string
          operator?: string
          price: number
          progress?: number
          proxy: string
          ready_for_orders?: boolean
          split: number
          status?: string
          tasks?: number
          temperature: number
          two_fa?: boolean
          type?: string
          updated_at?: string | null
          username: string
        }
        Update: {
          anti_detection?: boolean
          available?: boolean
          balance?: number
          city?: string
          created_at?: string | null
          emulation_status?: string
          id?: string
          last_activity?: string
          max_tokens?: number
          model?: string
          name?: string
          operator?: string
          price?: number
          progress?: number
          proxy?: string
          ready_for_orders?: boolean
          split?: number
          status?: string
          tasks?: number
          temperature?: number
          two_fa?: boolean
          type?: string
          updated_at?: string | null
          username?: string
        }
        Relationships: []
      }
      admin_audit_logs: {
        Row: {
          action: string
          created_at: string
          error_message: string | null
          id: string
          ip_address: unknown | null
          metadata: Json | null
          success: boolean
          user_agent: string | null
          user_identifier: string | null
        }
        Insert: {
          action: string
          created_at?: string
          error_message?: string | null
          id?: string
          ip_address?: unknown | null
          metadata?: Json | null
          success: boolean
          user_agent?: string | null
          user_identifier?: string | null
        }
        Update: {
          action?: string
          created_at?: string
          error_message?: string | null
          id?: string
          ip_address?: unknown | null
          metadata?: Json | null
          success?: boolean
          user_agent?: string | null
          user_identifier?: string | null
        }
        Relationships: []
      }
      annotation_comments: {
        Row: {
          annotation_id: string
          content: string
          created_at: string
          created_by: string
          id: string
          parent_comment_id: string | null
          updated_at: string
        }
        Insert: {
          annotation_id: string
          content: string
          created_at?: string
          created_by: string
          id?: string
          parent_comment_id?: string | null
          updated_at?: string
        }
        Update: {
          annotation_id?: string
          content?: string
          created_at?: string
          created_by?: string
          id?: string
          parent_comment_id?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "annotation_comments_annotation_id_fkey"
            columns: ["annotation_id"]
            isOneToOne: false
            referencedRelation: "annotations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "annotation_comments_parent_comment_id_fkey"
            columns: ["parent_comment_id"]
            isOneToOne: false
            referencedRelation: "annotation_comments"
            referencedColumns: ["id"]
          },
        ]
      }
      annotation_tags: {
        Row: {
          annotation_id: string
          created_at: string
          id: string
          tag_id: string
        }
        Insert: {
          annotation_id: string
          created_at?: string
          id?: string
          tag_id: string
        }
        Update: {
          annotation_id?: string
          created_at?: string
          id?: string
          tag_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "annotation_tags_annotation_id_fkey"
            columns: ["annotation_id"]
            isOneToOne: false
            referencedRelation: "annotations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "annotation_tags_tag_id_fkey"
            columns: ["tag_id"]
            isOneToOne: false
            referencedRelation: "tags"
            referencedColumns: ["id"]
          },
        ]
      }
      annotations: {
        Row: {
          color: string | null
          content: string | null
          created_at: string
          id: string
          is_public: boolean
          page_number: number
          paper_id: string
          position_data: Json | null
          type: Database["public"]["Enums"]["annotation_type"]
          updated_at: string
          user_id: string
        }
        Insert: {
          color?: string | null
          content?: string | null
          created_at?: string
          id?: string
          is_public?: boolean
          page_number: number
          paper_id: string
          position_data?: Json | null
          type?: Database["public"]["Enums"]["annotation_type"]
          updated_at?: string
          user_id: string
        }
        Update: {
          color?: string | null
          content?: string | null
          created_at?: string
          id?: string
          is_public?: boolean
          page_number?: number
          paper_id?: string
          position_data?: Json | null
          type?: Database["public"]["Enums"]["annotation_type"]
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "annotations_paper_id_fkey"
            columns: ["paper_id"]
            isOneToOne: false
            referencedRelation: "papers"
            referencedColumns: ["id"]
          },
        ]
      }
      auth_tokens: {
        Row: {
          created_at: string
          expires_at: string
          id: string
          telegram_id: number | null
          token: string
          updated_at: string
          used: boolean
          used_at: string | null
          user_id: string | null
        }
        Insert: {
          created_at?: string
          expires_at: string
          id?: string
          telegram_id?: number | null
          token: string
          updated_at?: string
          used?: boolean
          used_at?: string | null
          user_id?: string | null
        }
        Update: {
          created_at?: string
          expires_at?: string
          id?: string
          telegram_id?: number | null
          token?: string
          updated_at?: string
          used?: boolean
          used_at?: string | null
          user_id?: string | null
        }
        Relationships: []
      }
      consent_logs: {
        Row: {
          consent_type: string
          created_at: string
          granted: boolean
          id: string
          ip_address: unknown | null
          user_agent: string | null
          user_id: string | null
        }
        Insert: {
          consent_type: string
          created_at?: string
          granted: boolean
          id?: string
          ip_address?: unknown | null
          user_agent?: string | null
          user_id?: string | null
        }
        Update: {
          consent_type?: string
          created_at?: string
          granted?: boolean
          id?: string
          ip_address?: unknown | null
          user_agent?: string | null
          user_id?: string | null
        }
        Relationships: []
      }
      data_subject_requests: {
        Row: {
          created_at: string
          description: string | null
          id: string
          request_type: string
          response_data: Json | null
          status: string | null
          updated_at: string
          user_id: string | null
        }
        Insert: {
          created_at?: string
          description?: string | null
          id?: string
          request_type: string
          response_data?: Json | null
          status?: string | null
          updated_at?: string
          user_id?: string | null
        }
        Update: {
          created_at?: string
          description?: string | null
          id?: string
          request_type?: string
          response_data?: Json | null
          status?: string | null
          updated_at?: string
          user_id?: string | null
        }
        Relationships: []
      }
      deposit_requests: {
        Row: {
          admin_telegram_id: number | null
          admin_username: string | null
          amount: number
          created_at: string
          id: string
          receipt_image_url: string | null
          rejection_reason: string | null
          status: string
          updated_at: string
          user_id: string
        }
        Insert: {
          admin_telegram_id?: number | null
          admin_username?: string | null
          amount: number
          created_at?: string
          id?: string
          receipt_image_url?: string | null
          rejection_reason?: string | null
          status?: string
          updated_at?: string
          user_id: string
        }
        Update: {
          admin_telegram_id?: number | null
          admin_username?: string | null
          amount?: number
          created_at?: string
          id?: string
          receipt_image_url?: string | null
          rejection_reason?: string | null
          status?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      discussion_comments: {
        Row: {
          content: string
          created_at: string
          created_by: string
          discussion_id: string
          id: string
          parent_comment_id: string | null
          updated_at: string
        }
        Insert: {
          content: string
          created_at?: string
          created_by: string
          discussion_id: string
          id?: string
          parent_comment_id?: string | null
          updated_at?: string
        }
        Update: {
          content?: string
          created_at?: string
          created_by?: string
          discussion_id?: string
          id?: string
          parent_comment_id?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "discussion_comments_discussion_id_fkey"
            columns: ["discussion_id"]
            isOneToOne: false
            referencedRelation: "paper_discussions"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "discussion_comments_parent_comment_id_fkey"
            columns: ["parent_comment_id"]
            isOneToOne: false
            referencedRelation: "discussion_comments"
            referencedColumns: ["id"]
          },
        ]
      }
      dmca_takedown_requests: {
        Row: {
          claimant_email: string
          claimant_name: string
          content_url: string
          created_at: string
          description: string
          id: string
          response: string | null
          status: string | null
          updated_at: string
        }
        Insert: {
          claimant_email: string
          claimant_name: string
          content_url: string
          created_at?: string
          description: string
          id?: string
          response?: string | null
          status?: string | null
          updated_at?: string
        }
        Update: {
          claimant_email?: string
          claimant_name?: string
          content_url?: string
          created_at?: string
          description?: string
          id?: string
          response?: string | null
          status?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      enterprise_leads: {
        Row: {
          assigned_to: string | null
          budget_range: string | null
          company_name: string
          company_size: string | null
          contact_name: string
          created_at: string
          email: string
          id: string
          industry: string | null
          notes: string | null
          phone: string | null
          status: string | null
          timeline: string | null
          updated_at: string
          use_case: string | null
        }
        Insert: {
          assigned_to?: string | null
          budget_range?: string | null
          company_name: string
          company_size?: string | null
          contact_name: string
          created_at?: string
          email: string
          id?: string
          industry?: string | null
          notes?: string | null
          phone?: string | null
          status?: string | null
          timeline?: string | null
          updated_at?: string
          use_case?: string | null
        }
        Update: {
          assigned_to?: string | null
          budget_range?: string | null
          company_name?: string
          company_size?: string | null
          contact_name?: string
          created_at?: string
          email?: string
          id?: string
          industry?: string | null
          notes?: string | null
          phone?: string | null
          status?: string | null
          timeline?: string | null
          updated_at?: string
          use_case?: string | null
        }
        Relationships: []
      }
      group_invitations: {
        Row: {
          created_at: string
          group_id: string
          id: string
          invited_by: string
          invited_email: string
          invited_user_id: string | null
          status: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          group_id: string
          id?: string
          invited_by: string
          invited_email: string
          invited_user_id?: string | null
          status?: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          group_id?: string
          id?: string
          invited_by?: string
          invited_email?: string
          invited_user_id?: string | null
          status?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "group_invitations_group_id_fkey"
            columns: ["group_id"]
            isOneToOne: false
            referencedRelation: "research_groups"
            referencedColumns: ["id"]
          },
        ]
      }
      group_members: {
        Row: {
          group_id: string
          id: string
          joined_at: string
          role: string
          user_id: string
        }
        Insert: {
          group_id: string
          id?: string
          joined_at?: string
          role?: string
          user_id: string
        }
        Update: {
          group_id?: string
          id?: string
          joined_at?: string
          role?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "group_members_group_id_fkey"
            columns: ["group_id"]
            isOneToOne: false
            referencedRelation: "research_groups"
            referencedColumns: ["id"]
          },
        ]
      }
      group_message_reactions: {
        Row: {
          created_at: string | null
          id: string
          message_id: string
          reaction_type: string
          user_id: string
        }
        Insert: {
          created_at?: string | null
          id?: string
          message_id: string
          reaction_type: string
          user_id: string
        }
        Update: {
          created_at?: string | null
          id?: string
          message_id?: string
          reaction_type?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "group_message_reactions_message_id_fkey"
            columns: ["message_id"]
            isOneToOne: false
            referencedRelation: "group_messages"
            referencedColumns: ["id"]
          },
        ]
      }
      group_message_replies: {
        Row: {
          content: string
          created_at: string | null
          id: string
          message_id: string
          updated_at: string | null
          user_id: string
        }
        Insert: {
          content: string
          created_at?: string | null
          id?: string
          message_id: string
          updated_at?: string | null
          user_id: string
        }
        Update: {
          content?: string
          created_at?: string | null
          id?: string
          message_id?: string
          updated_at?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "group_message_replies_message_id_fkey"
            columns: ["message_id"]
            isOneToOne: false
            referencedRelation: "group_messages"
            referencedColumns: ["id"]
          },
        ]
      }
      group_messages: {
        Row: {
          content: string | null
          created_at: string | null
          group_id: string
          id: string
          is_pinned: boolean | null
          title: string
          updated_at: string | null
          user_id: string
        }
        Insert: {
          content?: string | null
          created_at?: string | null
          group_id: string
          id?: string
          is_pinned?: boolean | null
          title: string
          updated_at?: string | null
          user_id: string
        }
        Update: {
          content?: string | null
          created_at?: string | null
          group_id?: string
          id?: string
          is_pinned?: boolean | null
          title?: string
          updated_at?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "group_messages_group_id_fkey"
            columns: ["group_id"]
            isOneToOne: false
            referencedRelation: "research_groups"
            referencedColumns: ["id"]
          },
        ]
      }
      group_papers: {
        Row: {
          added_at: string
          added_by: string
          group_id: string
          id: string
          paper_id: string
        }
        Insert: {
          added_at?: string
          added_by: string
          group_id: string
          id?: string
          paper_id: string
        }
        Update: {
          added_at?: string
          added_by?: string
          group_id?: string
          id?: string
          paper_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "group_papers_group_id_fkey"
            columns: ["group_id"]
            isOneToOne: false
            referencedRelation: "research_groups"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "group_papers_paper_id_fkey"
            columns: ["paper_id"]
            isOneToOne: false
            referencedRelation: "papers"
            referencedColumns: ["id"]
          },
        ]
      }
      knowledge_connections: {
        Row: {
          connection_type: string
          created_at: string
          id: string
          notes: string | null
          source_id: string
          source_type: string
          strength: number | null
          target_id: string
          target_type: string
          user_id: string
        }
        Insert: {
          connection_type?: string
          created_at?: string
          id?: string
          notes?: string | null
          source_id: string
          source_type: string
          strength?: number | null
          target_id: string
          target_type: string
          user_id: string
        }
        Update: {
          connection_type?: string
          created_at?: string
          id?: string
          notes?: string | null
          source_id?: string
          source_type?: string
          strength?: number | null
          target_id?: string
          target_type?: string
          user_id?: string
        }
        Relationships: []
      }
      newsletter_subscriptions: {
        Row: {
          created_at: string
          email: string
          id: string
          subscribed: boolean | null
        }
        Insert: {
          created_at?: string
          email: string
          id?: string
          subscribed?: boolean | null
        }
        Update: {
          created_at?: string
          email?: string
          id?: string
          subscribed?: boolean | null
        }
        Relationships: []
      }
      notifications: {
        Row: {
          action_url: string | null
          created_at: string
          id: string
          is_read: boolean | null
          message: string
          metadata: Json | null
          title: string
          type: string
          user_id: string
        }
        Insert: {
          action_url?: string | null
          created_at?: string
          id?: string
          is_read?: boolean | null
          message: string
          metadata?: Json | null
          title: string
          type: string
          user_id: string
        }
        Update: {
          action_url?: string | null
          created_at?: string
          id?: string
          is_read?: boolean | null
          message?: string
          metadata?: Json | null
          title?: string
          type?: string
          user_id?: string
        }
        Relationships: []
      }
      page_analytics: {
        Row: {
          created_at: string
          id: string
          ip_address: unknown | null
          page_path: string
          referrer: string | null
          session_id: string | null
          user_agent: string | null
          user_id: string | null
        }
        Insert: {
          created_at?: string
          id?: string
          ip_address?: unknown | null
          page_path: string
          referrer?: string | null
          session_id?: string | null
          user_agent?: string | null
          user_id?: string | null
        }
        Update: {
          created_at?: string
          id?: string
          ip_address?: unknown | null
          page_path?: string
          referrer?: string | null
          session_id?: string | null
          user_agent?: string | null
          user_id?: string | null
        }
        Relationships: []
      }
      paper_bookmarks: {
        Row: {
          created_at: string
          id: string
          notes: string | null
          paper_id: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          notes?: string | null
          paper_id: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          notes?: string | null
          paper_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "paper_bookmarks_paper_id_fkey"
            columns: ["paper_id"]
            isOneToOne: false
            referencedRelation: "papers"
            referencedColumns: ["id"]
          },
        ]
      }
      paper_categories: {
        Row: {
          color: string | null
          created_at: string
          description: string | null
          id: string
          name: string
        }
        Insert: {
          color?: string | null
          created_at?: string
          description?: string | null
          id?: string
          name: string
        }
        Update: {
          color?: string | null
          created_at?: string
          description?: string | null
          id?: string
          name?: string
        }
        Relationships: []
      }
      paper_category_assignments: {
        Row: {
          category_id: string
          created_at: string
          id: string
          paper_id: string
        }
        Insert: {
          category_id: string
          created_at?: string
          id?: string
          paper_id: string
        }
        Update: {
          category_id?: string
          created_at?: string
          id?: string
          paper_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "paper_category_assignments_category_id_fkey"
            columns: ["category_id"]
            isOneToOne: false
            referencedRelation: "paper_categories"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "paper_category_assignments_paper_id_fkey"
            columns: ["paper_id"]
            isOneToOne: false
            referencedRelation: "papers"
            referencedColumns: ["id"]
          },
        ]
      }
      paper_discussions: {
        Row: {
          content: string | null
          created_at: string
          created_by: string
          id: string
          is_pinned: boolean | null
          paper_id: string
          title: string
          updated_at: string
        }
        Insert: {
          content?: string | null
          created_at?: string
          created_by: string
          id?: string
          is_pinned?: boolean | null
          paper_id: string
          title: string
          updated_at?: string
        }
        Update: {
          content?: string | null
          created_at?: string
          created_by?: string
          id?: string
          is_pinned?: boolean | null
          paper_id?: string
          title?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "paper_discussions_paper_id_fkey"
            columns: ["paper_id"]
            isOneToOne: false
            referencedRelation: "papers"
            referencedColumns: ["id"]
          },
        ]
      }
      paper_pdf_pages: {
        Row: {
          created_at: string
          extraction_status: string | null
          id: string
          lock_expires_at: string | null
          original_pdf_path: string
          page_paths: string[]
          pages_folder_path: string
          pages_ready: number | null
          paper_id: string
          source: string
          total_pages: number
          updated_at: string
        }
        Insert: {
          created_at?: string
          extraction_status?: string | null
          id?: string
          lock_expires_at?: string | null
          original_pdf_path: string
          page_paths?: string[]
          pages_folder_path: string
          pages_ready?: number | null
          paper_id: string
          source?: string
          total_pages: number
          updated_at?: string
        }
        Update: {
          created_at?: string
          extraction_status?: string | null
          id?: string
          lock_expires_at?: string | null
          original_pdf_path?: string
          page_paths?: string[]
          pages_folder_path?: string
          pages_ready?: number | null
          paper_id?: string
          source?: string
          total_pages?: number
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "paper_pdf_pages_paper_id_fkey"
            columns: ["paper_id"]
            isOneToOne: true
            referencedRelation: "papers"
            referencedColumns: ["id"]
          },
        ]
      }
      paper_recommendations: {
        Row: {
          created_at: string
          expires_at: string | null
          id: string
          paper_id: string
          reason: string | null
          recommendation_type: string
          score: number
          user_id: string
        }
        Insert: {
          created_at?: string
          expires_at?: string | null
          id?: string
          paper_id: string
          reason?: string | null
          recommendation_type: string
          score: number
          user_id: string
        }
        Update: {
          created_at?: string
          expires_at?: string | null
          id?: string
          paper_id?: string
          reason?: string | null
          recommendation_type?: string
          score?: number
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "paper_recommendations_paper_id_fkey"
            columns: ["paper_id"]
            isOneToOne: false
            referencedRelation: "papers"
            referencedColumns: ["id"]
          },
        ]
      }
      paper_references: {
        Row: {
          annotation_id: string | null
          created_at: string
          created_by: string
          id: string
          reference_context: string | null
          source_paper_id: string
          target_paper_id: string
        }
        Insert: {
          annotation_id?: string | null
          created_at?: string
          created_by: string
          id?: string
          reference_context?: string | null
          source_paper_id: string
          target_paper_id: string
        }
        Update: {
          annotation_id?: string | null
          created_at?: string
          created_by?: string
          id?: string
          reference_context?: string | null
          source_paper_id?: string
          target_paper_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "paper_references_annotation_id_fkey"
            columns: ["annotation_id"]
            isOneToOne: false
            referencedRelation: "annotations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "paper_references_source_paper_id_fkey"
            columns: ["source_paper_id"]
            isOneToOne: false
            referencedRelation: "papers"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "paper_references_target_paper_id_fkey"
            columns: ["target_paper_id"]
            isOneToOne: false
            referencedRelation: "papers"
            referencedColumns: ["id"]
          },
        ]
      }
      papers: {
        Row: {
          abstract: string | null
          authors: string[] | null
          cited_by_count: number | null
          concepts: string[] | null
          container_title: string | null
          created_at: string
          doi_url: string | null
          download_url: string | null
          event: string | null
          event_acronym: string | null
          event_location: string | null
          extraction_progress: Json | null
          id: string
          institutions: string[] | null
          is_oa: boolean | null
          is_referenced_by_count: number | null
          keywords: string[] | null
          last_accessed: string | null
          link_pdf: string | null
          oa_url: string | null
          openalex_id: string | null
          pdf_storage_path: string | null
          publication_date: string | null
          publication_year: number | null
          related_works: string[] | null
          source: string | null
          title: string
          topics_field: string[] | null
          total_pages: number | null
          type_crossref: string | null
          updated_at: string
          venue: string | null
        }
        Insert: {
          abstract?: string | null
          authors?: string[] | null
          cited_by_count?: number | null
          concepts?: string[] | null
          container_title?: string | null
          created_at?: string
          doi_url?: string | null
          download_url?: string | null
          event?: string | null
          event_acronym?: string | null
          event_location?: string | null
          extraction_progress?: Json | null
          id?: string
          institutions?: string[] | null
          is_oa?: boolean | null
          is_referenced_by_count?: number | null
          keywords?: string[] | null
          last_accessed?: string | null
          link_pdf?: string | null
          oa_url?: string | null
          openalex_id?: string | null
          pdf_storage_path?: string | null
          publication_date?: string | null
          publication_year?: number | null
          related_works?: string[] | null
          source?: string | null
          title: string
          topics_field?: string[] | null
          total_pages?: number | null
          type_crossref?: string | null
          updated_at?: string
          venue?: string | null
        }
        Update: {
          abstract?: string | null
          authors?: string[] | null
          cited_by_count?: number | null
          concepts?: string[] | null
          container_title?: string | null
          created_at?: string
          doi_url?: string | null
          download_url?: string | null
          event?: string | null
          event_acronym?: string | null
          event_location?: string | null
          extraction_progress?: Json | null
          id?: string
          institutions?: string[] | null
          is_oa?: boolean | null
          is_referenced_by_count?: number | null
          keywords?: string[] | null
          last_accessed?: string | null
          link_pdf?: string | null
          oa_url?: string | null
          openalex_id?: string | null
          pdf_storage_path?: string | null
          publication_date?: string | null
          publication_year?: number | null
          related_works?: string[] | null
          source?: string | null
          title?: string
          topics_field?: string[] | null
          total_pages?: number | null
          type_crossref?: string | null
          updated_at?: string
          venue?: string | null
        }
        Relationships: []
      }
      pdf_split_locks: {
        Row: {
          created_at: string
          expires_at: string
          id: string
          lock_key: string
          lock_value: string
        }
        Insert: {
          created_at?: string
          expires_at: string
          id?: string
          lock_key: string
          lock_value: string
        }
        Update: {
          created_at?: string
          expires_at?: string
          id?: string
          lock_key?: string
          lock_value?: string
        }
        Relationships: []
      }
      profiles: {
        Row: {
          avatar_url: string | null
          balance: number | null
          created_at: string
          display_name: string | null
          email: string | null
          id: string
          updated_at: string
          user_id: string
        }
        Insert: {
          avatar_url?: string | null
          balance?: number | null
          created_at?: string
          display_name?: string | null
          email?: string | null
          id?: string
          updated_at?: string
          user_id: string
        }
        Update: {
          avatar_url?: string | null
          balance?: number | null
          created_at?: string
          display_name?: string | null
          email?: string | null
          id?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      purchased_accounts: {
        Row: {
          account_id: string
          city: string
          created_at: string
          id: string
          price: number
          purchased_at: string
          split: number
          updated_at: string
          user_id: string
          username: string
          warmup_progress: number | null
          warmup_status: string | null
        }
        Insert: {
          account_id: string
          city: string
          created_at?: string
          id?: string
          price: number
          purchased_at?: string
          split: number
          updated_at?: string
          user_id: string
          username: string
          warmup_progress?: number | null
          warmup_status?: string | null
        }
        Update: {
          account_id?: string
          city?: string
          created_at?: string
          id?: string
          price?: number
          purchased_at?: string
          split?: number
          updated_at?: string
          user_id?: string
          username?: string
          warmup_progress?: number | null
          warmup_status?: string | null
        }
        Relationships: []
      }
      reading_sessions: {
        Row: {
          comprehension_rating: number | null
          created_at: string
          end_time: string | null
          highlights_count: number | null
          id: string
          notes_count: number | null
          pages_read: number[] | null
          paper_id: string
          reading_goals: string[] | null
          start_time: string
          total_pages: number
          updated_at: string | null
          user_id: string
        }
        Insert: {
          comprehension_rating?: number | null
          created_at?: string
          end_time?: string | null
          highlights_count?: number | null
          id?: string
          notes_count?: number | null
          pages_read?: number[] | null
          paper_id: string
          reading_goals?: string[] | null
          start_time: string
          total_pages?: number
          updated_at?: string | null
          user_id: string
        }
        Update: {
          comprehension_rating?: number | null
          created_at?: string
          end_time?: string | null
          highlights_count?: number | null
          id?: string
          notes_count?: number | null
          pages_read?: number[] | null
          paper_id?: string
          reading_goals?: string[] | null
          start_time?: string
          total_pages?: number
          updated_at?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "reading_sessions_paper_id_fkey"
            columns: ["paper_id"]
            isOneToOne: false
            referencedRelation: "papers"
            referencedColumns: ["id"]
          },
        ]
      }
      reading_spaces: {
        Row: {
          color: string | null
          created_at: string
          description: string | null
          id: string
          name: string
          updated_at: string
          user_id: string
        }
        Insert: {
          color?: string | null
          created_at?: string
          description?: string | null
          id?: string
          name: string
          updated_at?: string
          user_id: string
        }
        Update: {
          color?: string | null
          created_at?: string
          description?: string | null
          id?: string
          name?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      referral_codes: {
        Row: {
          code: string | null
          created_at: string
          expires_at: string | null
          id: string
          is_active: boolean
          referral_code: string
          user_id: string
          uses_remaining: number | null
        }
        Insert: {
          code?: string | null
          created_at?: string
          expires_at?: string | null
          id?: string
          is_active?: boolean
          referral_code: string
          user_id: string
          uses_remaining?: number | null
        }
        Update: {
          code?: string | null
          created_at?: string
          expires_at?: string | null
          id?: string
          is_active?: boolean
          referral_code?: string
          user_id?: string
          uses_remaining?: number | null
        }
        Relationships: []
      }
      referrals: {
        Row: {
          bonus_earned: number | null
          bonus_saves_awarded: number
          created_at: string
          id: string
          referral_code: string
          referred_user_id: string
          referrer_user_id: string
        }
        Insert: {
          bonus_earned?: number | null
          bonus_saves_awarded?: number
          created_at?: string
          id?: string
          referral_code: string
          referred_user_id: string
          referrer_user_id: string
        }
        Update: {
          bonus_earned?: number | null
          bonus_saves_awarded?: number
          created_at?: string
          id?: string
          referral_code?: string
          referred_user_id?: string
          referrer_user_id?: string
        }
        Relationships: []
      }
      research_activities: {
        Row: {
          activity_type: string
          created_at: string
          entity_id: string
          entity_type: string
          id: string
          metadata: Json | null
          user_id: string
        }
        Insert: {
          activity_type: string
          created_at?: string
          entity_id: string
          entity_type: string
          id?: string
          metadata?: Json | null
          user_id: string
        }
        Update: {
          activity_type?: string
          created_at?: string
          entity_id?: string
          entity_type?: string
          id?: string
          metadata?: Json | null
          user_id?: string
        }
        Relationships: []
      }
      research_groups: {
        Row: {
          avatar_url: string | null
          created_at: string
          created_by: string
          description: string | null
          id: string
          is_public: boolean | null
          name: string
          updated_at: string
        }
        Insert: {
          avatar_url?: string | null
          created_at?: string
          created_by: string
          description?: string | null
          id?: string
          is_public?: boolean | null
          name: string
          updated_at?: string
        }
        Update: {
          avatar_url?: string | null
          created_at?: string
          created_by?: string
          description?: string | null
          id?: string
          is_public?: boolean | null
          name?: string
          updated_at?: string
        }
        Relationships: []
      }
      search_analytics: {
        Row: {
          created_at: string
          id: string
          ip_address: unknown | null
          query: string
          result_count: number | null
          search_type: string | null
          user_agent: string | null
          user_id: string | null
        }
        Insert: {
          created_at?: string
          id?: string
          ip_address?: unknown | null
          query: string
          result_count?: number | null
          search_type?: string | null
          user_agent?: string | null
          user_id?: string | null
        }
        Update: {
          created_at?: string
          id?: string
          ip_address?: unknown | null
          query?: string
          result_count?: number | null
          search_type?: string | null
          user_agent?: string | null
          user_id?: string | null
        }
        Relationships: []
      }
      search_cache: {
        Row: {
          created_at: string
          expires_at: string | null
          id: string
          last_accessed: string | null
          query: string | null
          query_hash: string
          query_text: string
          result_count: number | null
          results: Json | null
          source: string | null
          sources: string[] | null
        }
        Insert: {
          created_at?: string
          expires_at?: string | null
          id?: string
          last_accessed?: string | null
          query?: string | null
          query_hash: string
          query_text: string
          result_count?: number | null
          results?: Json | null
          source?: string | null
          sources?: string[] | null
        }
        Update: {
          created_at?: string
          expires_at?: string | null
          id?: string
          last_accessed?: string | null
          query?: string | null
          query_hash?: string
          query_text?: string
          result_count?: number | null
          results?: Json | null
          source?: string | null
          sources?: string[] | null
        }
        Relationships: []
      }
      search_history: {
        Row: {
          created_at: string
          filters: Json | null
          id: string
          query: string
          results_count: number | null
          user_id: string
        }
        Insert: {
          created_at?: string
          filters?: Json | null
          id?: string
          query: string
          results_count?: number | null
          user_id: string
        }
        Update: {
          created_at?: string
          filters?: Json | null
          id?: string
          query?: string
          results_count?: number | null
          user_id?: string
        }
        Relationships: []
      }
      space_invitations: {
        Row: {
          created_at: string
          expires_at: string | null
          id: string
          invited_by: string
          invited_email: string
          role: string | null
          space_id: string
          status: string | null
        }
        Insert: {
          created_at?: string
          expires_at?: string | null
          id?: string
          invited_by: string
          invited_email: string
          role?: string | null
          space_id: string
          status?: string | null
        }
        Update: {
          created_at?: string
          expires_at?: string | null
          id?: string
          invited_by?: string
          invited_email?: string
          role?: string | null
          space_id?: string
          status?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "space_invitations_space_id_fkey"
            columns: ["space_id"]
            isOneToOne: false
            referencedRelation: "reading_spaces"
            referencedColumns: ["id"]
          },
        ]
      }
      space_members: {
        Row: {
          id: string
          joined_at: string
          role: string | null
          space_id: string
          user_id: string
        }
        Insert: {
          id?: string
          joined_at?: string
          role?: string | null
          space_id: string
          user_id: string
        }
        Update: {
          id?: string
          joined_at?: string
          role?: string | null
          space_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "space_members_space_id_fkey"
            columns: ["space_id"]
            isOneToOne: false
            referencedRelation: "reading_spaces"
            referencedColumns: ["id"]
          },
        ]
      }
      space_papers: {
        Row: {
          added_at: string
          added_by: string
          created_at: string
          id: string
          paper_id: string
          space_id: string
        }
        Insert: {
          added_at?: string
          added_by: string
          created_at?: string
          id?: string
          paper_id: string
          space_id: string
        }
        Update: {
          added_at?: string
          added_by?: string
          created_at?: string
          id?: string
          paper_id?: string
          space_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "space_papers_paper_id_fkey"
            columns: ["paper_id"]
            isOneToOne: false
            referencedRelation: "papers"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "space_papers_space_id_fkey"
            columns: ["space_id"]
            isOneToOne: false
            referencedRelation: "reading_spaces"
            referencedColumns: ["id"]
          },
        ]
      }
      subscribers: {
        Row: {
          created_at: string
          email: string
          id: string
          stripe_customer_id: string | null
          student_verification_expires: string | null
          student_verified: boolean | null
          subscribed: boolean | null
        }
        Insert: {
          created_at?: string
          email: string
          id?: string
          stripe_customer_id?: string | null
          student_verification_expires?: string | null
          student_verified?: boolean | null
          subscribed?: boolean | null
        }
        Update: {
          created_at?: string
          email?: string
          id?: string
          stripe_customer_id?: string | null
          student_verification_expires?: string | null
          student_verified?: boolean | null
          subscribed?: boolean | null
        }
        Relationships: []
      }
      support_ticket_responses: {
        Row: {
          content: string
          created_at: string
          id: string
          is_internal: boolean | null
          ticket_id: string
          user_id: string
        }
        Insert: {
          content: string
          created_at?: string
          id?: string
          is_internal?: boolean | null
          ticket_id: string
          user_id: string
        }
        Update: {
          content?: string
          created_at?: string
          id?: string
          is_internal?: boolean | null
          ticket_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "support_ticket_responses_ticket_id_fkey"
            columns: ["ticket_id"]
            isOneToOne: false
            referencedRelation: "support_tickets"
            referencedColumns: ["id"]
          },
        ]
      }
      support_tickets: {
        Row: {
          assigned_to: string | null
          category: string
          created_at: string
          description: string
          id: string
          priority: string
          status: string
          subject: string
          updated_at: string
          user_id: string
        }
        Insert: {
          assigned_to?: string | null
          category: string
          created_at?: string
          description: string
          id?: string
          priority?: string
          status?: string
          subject: string
          updated_at?: string
          user_id: string
        }
        Update: {
          assigned_to?: string | null
          category?: string
          created_at?: string
          description?: string
          id?: string
          priority?: string
          status?: string
          subject?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      tags: {
        Row: {
          color: string | null
          created_at: string
          id: string
          name: string
          user_id: string
        }
        Insert: {
          color?: string | null
          created_at?: string
          id?: string
          name: string
          user_id: string
        }
        Update: {
          color?: string | null
          created_at?: string
          id?: string
          name?: string
          user_id?: string
        }
        Relationships: []
      }
      telegram_users: {
        Row: {
          created_at: string
          first_name: string | null
          id: string
          last_name: string | null
          telegram_id: number
          updated_at: string
          user_id: string
          username: string | null
        }
        Insert: {
          created_at?: string
          first_name?: string | null
          id?: string
          last_name?: string | null
          telegram_id: number
          updated_at?: string
          user_id: string
          username?: string | null
        }
        Update: {
          created_at?: string
          first_name?: string | null
          id?: string
          last_name?: string | null
          telegram_id?: number
          updated_at?: string
          user_id?: string
          username?: string | null
        }
        Relationships: []
      }
      trending_papers_cache: {
        Row: {
          category: string | null
          comments_count: number | null
          created_at: string
          expires_at: string | null
          id: string
          paper_id: string
          saves_count: number | null
          trending_score: number
          views_count: number | null
        }
        Insert: {
          category?: string | null
          comments_count?: number | null
          created_at?: string
          expires_at?: string | null
          id?: string
          paper_id: string
          saves_count?: number | null
          trending_score: number
          views_count?: number | null
        }
        Update: {
          category?: string | null
          comments_count?: number | null
          created_at?: string
          expires_at?: string | null
          id?: string
          paper_id?: string
          saves_count?: number | null
          trending_score?: number
          views_count?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "trending_papers_cache_paper_id_fkey"
            columns: ["paper_id"]
            isOneToOne: false
            referencedRelation: "papers"
            referencedColumns: ["id"]
          },
        ]
      }
      user_documents: {
        Row: {
          content: string | null
          created_at: string
          description: string | null
          document_type: string
          file_name: string | null
          file_size: number | null
          file_url: string | null
          id: string
          title: string
          updated_at: string
          user_id: string
        }
        Insert: {
          content?: string | null
          created_at?: string
          description?: string | null
          document_type?: string
          file_name?: string | null
          file_size?: number | null
          file_url?: string | null
          id?: string
          title: string
          updated_at?: string
          user_id: string
        }
        Update: {
          content?: string | null
          created_at?: string
          description?: string | null
          document_type?: string
          file_name?: string | null
          file_size?: number | null
          file_url?: string | null
          id?: string
          title?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      user_engagement_metrics: {
        Row: {
          annotations_created: number | null
          comments_posted: number | null
          created_at: string
          engagement_score: number | null
          groups_joined: number | null
          id: string
          last_active: string | null
          papers_read: number | null
          updated_at: string
          user_id: string
        }
        Insert: {
          annotations_created?: number | null
          comments_posted?: number | null
          created_at?: string
          engagement_score?: number | null
          groups_joined?: number | null
          id?: string
          last_active?: string | null
          papers_read?: number | null
          updated_at?: string
          user_id: string
        }
        Update: {
          annotations_created?: number | null
          comments_posted?: number | null
          created_at?: string
          engagement_score?: number | null
          groups_joined?: number | null
          id?: string
          last_active?: string | null
          papers_read?: number | null
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      user_library_stats: {
        Row: {
          annotations_count: number | null
          connections_count: number | null
          created_at: string
          documents_count: number | null
          id: string
          papers_count: number | null
          spaces_count: number | null
          updated_at: string
          user_id: string
        }
        Insert: {
          annotations_count?: number | null
          connections_count?: number | null
          created_at?: string
          documents_count?: number | null
          id?: string
          papers_count?: number | null
          spaces_count?: number | null
          updated_at?: string
          user_id: string
        }
        Update: {
          annotations_count?: number | null
          connections_count?: number | null
          created_at?: string
          documents_count?: number | null
          id?: string
          papers_count?: number | null
          spaces_count?: number | null
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      user_orders: {
        Row: {
          account_ids: string[] | null
          created_at: string
          id: string
          order_type: string
          status: string
          total_amount: number
          updated_at: string
          user_id: string
        }
        Insert: {
          account_ids?: string[] | null
          created_at?: string
          id?: string
          order_type: string
          status?: string
          total_amount: number
          updated_at?: string
          user_id: string
        }
        Update: {
          account_ids?: string[] | null
          created_at?: string
          id?: string
          order_type?: string
          status?: string
          total_amount?: number
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      user_paper_files: {
        Row: {
          created_at: string
          extraction_status: string | null
          file_size: number | null
          id: string
          pages_ready: number | null
          paper_id: string
          source: string
          storage_path: string
          total_pages: number | null
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          extraction_status?: string | null
          file_size?: number | null
          id?: string
          pages_ready?: number | null
          paper_id: string
          source: string
          storage_path: string
          total_pages?: number | null
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          extraction_status?: string | null
          file_size?: number | null
          id?: string
          pages_ready?: number | null
          paper_id?: string
          source?: string
          storage_path?: string
          total_pages?: number | null
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "user_paper_files_paper_id_fkey"
            columns: ["paper_id"]
            isOneToOne: false
            referencedRelation: "papers"
            referencedColumns: ["id"]
          },
        ]
      }
      user_preferences: {
        Row: {
          created_at: string
          email_notifications: boolean | null
          id: string
          language: string | null
          notifications_enabled: boolean | null
          reading_preferences: Json | null
          search_preferences: Json | null
          theme: string | null
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          email_notifications?: boolean | null
          id?: string
          language?: string | null
          notifications_enabled?: boolean | null
          reading_preferences?: Json | null
          search_preferences?: Json | null
          theme?: string | null
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          email_notifications?: boolean | null
          id?: string
          language?: string | null
          notifications_enabled?: boolean | null
          reading_preferences?: Json | null
          search_preferences?: Json | null
          theme?: string | null
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          created_at: string
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
      user_usage_tracking: {
        Row: {
          count: number | null
          created_at: string
          date: string
          id: string
          referral_bonus_saves: number
          usage_type: string
          user_id: string
        }
        Insert: {
          count?: number | null
          created_at?: string
          date?: string
          id?: string
          referral_bonus_saves?: number
          usage_type: string
          user_id: string
        }
        Update: {
          count?: number | null
          created_at?: string
          date?: string
          id?: string
          referral_bonus_saves?: number
          usage_type?: string
          user_id?: string
        }
        Relationships: []
      }
      warmup_sessions: {
        Row: {
          account_id: string
          activity_level: number | null
          created_at: string
          ended_at: string | null
          id: string
          load_percentage: number | null
          progress: number | null
          requests_per_minute: number | null
          started_at: string | null
          status: string
          temperature: number | null
          updated_at: string
          user_id: string
        }
        Insert: {
          account_id: string
          activity_level?: number | null
          created_at?: string
          ended_at?: string | null
          id?: string
          load_percentage?: number | null
          progress?: number | null
          requests_per_minute?: number | null
          started_at?: string | null
          status?: string
          temperature?: number | null
          updated_at?: string
          user_id: string
        }
        Update: {
          account_id?: string
          activity_level?: number | null
          created_at?: string
          ended_at?: string | null
          id?: string
          load_percentage?: number | null
          progress?: number | null
          requests_per_minute?: number | null
          started_at?: string | null
          status?: string
          temperature?: number | null
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      acquire_pdf_split_lock: {
        Args: { p_lock_duration_minutes?: number; p_paper_id: string }
        Returns: boolean
      }
      append_page_path: {
        Args: { p_page_path: string; p_paper_id: string; p_total_pages: number }
        Returns: undefined
      }
      check_enterprise_lead_rate_limit: {
        Args: { p_email?: string; p_ip_address: string }
        Returns: Json
      }
      cleanup_expired_cache: {
        Args: Record<PropertyKey, never>
        Returns: undefined
      }
      cleanup_expired_pdf_split_locks: {
        Args: Record<PropertyKey, never>
        Returns: number
      }
      cleanup_expired_rate_limits: {
        Args: Record<PropertyKey, never>
        Returns: undefined
      }
      cleanup_expired_recommendations: {
        Args: Record<PropertyKey, never>
        Returns: undefined
      }
      cleanup_expired_verification_codes: {
        Args: Record<PropertyKey, never>
        Returns: undefined
      }
      cleanup_old_admin_attempts: {
        Args: Record<PropertyKey, never>
        Returns: undefined
      }
      clear_all_search_cache: {
        Args: Record<PropertyKey, never>
        Returns: undefined
      }
      clear_search_cache_for_paper: {
        Args: { paper_title_param: string }
        Returns: undefined
      }
      ensure_user_profile: {
        Args: { p_display_name?: string; p_email?: string; p_user_id: string }
        Returns: undefined
      }
      generate_referral_code: {
        Args: { target_user_id: string }
        Returns: string
      }
      get_cached_trending_papers: {
        Args: { category_filter?: string; limit_count?: number }
        Returns: {
          abstract: string
          annotation_count: number
          arxiv_id: string
          authors: string[]
          cache_age_hours: number
          categories: string[]
          doi: string
          paper_id: string
          publication_date: string
          reading_count: number
          title: string
          trending_score: number
          venue: string
          view_count: number
        }[]
      }
      get_current_telegram_id: {
        Args: Record<PropertyKey, never>
        Returns: number
      }
      get_current_user_id: {
        Args: Record<PropertyKey, never>
        Returns: string
      }
      get_current_user_id_unified: {
        Args: { p_telegram_id?: number }
        Returns: string
      }
      get_trending_papers: {
        Args: { limit_count?: number }
        Returns: {
          abstract: string
          arxiv_id: string
          authors: string[]
          doi: string
          journal: string
          paper_id: string
          publication_date: string
          reading_count: number
          title: string
          trending_score: number
          view_count: number
        }[]
      }
      get_user_referral_stats: {
        Args: { target_user_id: string }
        Returns: Json
      }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      has_telegram_access: {
        Args: { target_user_id: string }
        Returns: boolean
      }
      increment_usage_tracking: {
        Args: {
          increment_by?: number
          target_user_id: string
          usage_type: string
        }
        Returns: undefined
      }
      is_group_member: {
        Args: { group_id_param: string; user_id_param: string }
        Returns: boolean
      }
      is_group_owner: {
        Args: { group_id_param: string; user_id_param: string }
        Returns: boolean
      }
      log_enterprise_lead_access: {
        Args: { p_action: string; p_details?: Json; p_lead_id: string }
        Returns: undefined
      }
      process_referral_signup: {
        Args: { referral_code_input: string; referred_user_id: string }
        Returns: Json
      }
      process_telegram_auth_v2: {
        Args: {
          auth_token: string
          tg_first_name?: string
          tg_id: number
          tg_last_name?: string
          tg_username?: string
        }
        Returns: Json
      }
      purchase_accounts_unified: {
        Args: { selected_account_ids: string[]; telegram_id?: number }
        Returns: Json
      }
      purchase_accounts_with_user_id: {
        Args: { selected_account_ids: string[]; user_id_param: string }
        Returns: Json
      }
      refresh_trending_papers_cache: {
        Args: Record<PropertyKey, never>
        Returns: undefined
      }
      release_pdf_split_lock: {
        Args: { p_paper_id: string }
        Returns: undefined
      }
      test_pdf_progress: {
        Args: { paper_id_param: string }
        Returns: {
          actual_page_paths_count: number
          extraction_progress: Json
          extraction_status: string
          pages_ready: number
          paper_id: string
          title: string
          total_pages: number
        }[]
      }
    }
    Enums: {
      annotation_type: "highlight" | "note" | "comment"
      app_role: "admin" | "user"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      annotation_type: ["highlight", "note", "comment"],
      app_role: ["admin", "user"],
    },
  },
} as const
