import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { ThemeProvider } from "./providers/theme-provider";
import { AuthProvider } from "./providers/AuthProvider";
import { AdminGuard } from "./components/AdminGuard";
import Layout from "./components/Layout";
import MainDashboard from "./components/Dashboard/MainDashboard";
import AccountsPage from "./components/Dashboard/AccountsPage";
import WarmupPage from "./components/Dashboard/WarmupPage";
import EmulatorPage from "./components/Dashboard/EmulatorPage";
import FarmConfigPage from "./components/Dashboard/FarmConfigPage";
import DepositPage from "./components/Dashboard/DepositPage";
import { BankTransferPage } from "./components/Dashboard/BankTransferPage";
import { DepositStatusPage } from "./components/Dashboard/DepositStatusPage";
import ChatPage from "./components/Dashboard/ChatPage";
import OrderProductPage from "./components/Dashboard/OrderProductPage";
import FAQPage from "./components/FAQ/FAQPage";
import AdminPanel from "./components/Dashboard/AdminPanel";
import NotFound from "./pages/NotFound";
import { useAppStore } from "./store/appStore";
import { useEffect, useState } from "react";
import ErrorBoundary from "./components/ErrorBoundary";
import { LoadingFallback } from "./components/LoadingFallback";

const queryClient = new QueryClient();

const AppContent = () => {
  const [isLoadingAccounts, setIsLoadingAccounts] = useState(true);
  const [loadingError, setLoadingError] = useState(false);
  const { loadAccounts } = useAppStore();

  useEffect(() => {
    const loadData = async () => {
      try {
        console.log('🚀 App: Starting account loading...');
        setIsLoadingAccounts(true);
        setLoadingError(false);
        
        // Add timeout for account loading
        const timeoutPromise = new Promise((_, reject) => 
          setTimeout(() => reject(new Error('Loading timeout')), 15000)
        );
        
        await Promise.race([loadAccounts(), timeoutPromise]);
        console.log('✅ App: Account loading completed');
      } catch (error) {
        console.error('❌ App: Account loading failed:', error);
        setLoadingError(true);
      } finally {
        setIsLoadingAccounts(false);
      }
    };

    loadData();
  }, [loadAccounts]);

  const handleSkipLoading = () => {
    console.log('⏭️ App: User skipped loading');
    setIsLoadingAccounts(false);
    setLoadingError(false);
  };

  if (isLoadingAccounts && !loadingError) {
    return (
      <LoadingFallback 
        message="Загрузка аккаунтов" 
        onSkip={handleSkipLoading}
      />
    );
  }

  return (
    <ErrorBoundary>
      <Routes>
        <Route path="/" element={<Layout />}>
          <Route index element={<MainDashboard />} />
          <Route path="accounts" element={<AccountsPage />} />
          <Route path="warmup" element={<WarmupPage />} />
          <Route path="emulator" element={<EmulatorPage />} />
          <Route path="farm-config" element={<FarmConfigPage />} />
          <Route path="deposit" element={<DepositPage />} />
          <Route path="deposit/bank-transfer" element={<BankTransferPage />} />
          <Route path="deposit/status/:requestId" element={<DepositStatusPage />} />
          <Route path="chat" element={<ChatPage />} />
          <Route path="faq" element={<FAQPage />} />
          <Route path="order-product" element={<OrderProductPage />} />
          <Route path="admin" element={
            <AdminGuard>
              <AdminPanel />
            </AdminGuard>
          } />
        </Route>
        <Route path="*" element={<NotFound />} />
      </Routes>
    </ErrorBoundary>
  );
};

const App = () => (
  <ThemeProvider defaultTheme="dark">
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <TooltipProvider>
          <Toaster />
          <Sonner />
          <BrowserRouter>
            <AppContent />
          </BrowserRouter>
        </TooltipProvider>
      </AuthProvider>
    </QueryClientProvider>
  </ThemeProvider>
);

export default App;
