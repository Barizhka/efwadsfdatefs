import { create } from 'zustand';
import { supabase } from '@/integrations/supabase/client';

export interface User {
  id?: string;
  name: string;
  avatar: string;
  balance: number;
  plan: string;
}

export interface Account {
  id: string;
  name: string;
  username: string;
  status: 'active' | 'warming' | 'paused' | 'banned';
  type: string;
  proxy: string;
  model: string;
  progress: number;
  lastActivity: string;
  temperature: number;
  maxTokens: number;
  antiDetection: boolean;
  twoFA: boolean;
  operator: string;
  balance: number;
  tasks: number;
  city: string;
  split: number | string;
  emulationStatus: string;
  readyForOrders: boolean;
  price: number;
  selected?: boolean;
  purchased?: boolean;
  warmupProgress?: number;
  warmupStarted?: boolean;
}

export interface PurchasedAccount extends Account {
  warmupProgress: number;
  warmupStarted: boolean;
  warmupStartTime?: number;
  selectedCity?: string;
}

export interface Session {
  id: string;
  account: string;
  status: 'active' | 'paused' | 'completed';
  startTime: string;
  duration: string;
  requests: number;
  tokens: number;
  cost: number;
}

export interface Order {
  id: string;
  accountId: string;
  accountName: string;
  productName: string;
  productPrice: number;
  remainingAmount: number;
  deliveryMethod: 'pickup' | 'courier' | 'postmat';
  deliveryAddress: string;
  status: 'processing' | 'delivery_confirmation' | 'confirmed' | 'shipped' | 'delivered' | 'cancelled';
  createdAt: number;
  updatedAt: number;
  confirmationCreatedAt?: number; // Время создания заявки на подтверждение
}

export interface AppState {
  user: User;
  accounts: Account[];
  purchasedAccounts: PurchasedAccount[];
  sessions: Session[];
  orders: Order[];
  warmupTab: string;
  selectedAccounts: string[];
  isWarmupActive: boolean;
  systemStatus: {
    uptime: string;
    activeAccounts: number;
    totalRequests: number;
    errorRate: number;
  };
  
  // Actions
  loadAccounts: () => Promise<void>;
  updateUser: (user: Partial<User>) => void;
  updateUserBalance: (balance: number) => void;
  setUser: (user: User) => Promise<void>;
  addAccount: (account: Omit<Account, 'id'>) => void;
  updateAccount: (id: string, updates: Partial<Account>) => void;
  removeAccount: (id: string) => void;
  addSession: (session: Omit<Session, 'id'>) => void;
  updateSession: (id: string, updates: Partial<Session>) => void;
  removeSession: (id: string) => void;
  setWarmupTab: (tab: string) => void;
  toggleAccountSelection: (id: string) => void;
  purchaseSelectedAccounts: () => void;
  startWarmup: (id: string, selectedCity?: string) => void;
  updateWarmupProgress: (id: string, progress: number) => void;
  saveWarmupState: () => void;
  loadWarmupState: () => void;
  checkWarmupProgress: () => void;
  createOrder: (orderData: Omit<Order, 'id' | 'createdAt' | 'updatedAt'>) => void;
  updateOrderStatus: (orderId: string, status: Order['status']) => void;
  setWarmupActive: (active: boolean) => void;
  clearPurchasedAccounts: () => void;
}

// Функция для генерации случайных ID
const generateRandomId = () => Math.floor(10000000 + Math.random() * 90000000).toString();

// Функция для определения цены аккаунта
const getAccountPrice = (split: number | string) => {
  if (split === "Неизвестно") return 2000;
  const splitNum = typeof split === 'number' ? split : parseInt(split);
  if (splitNum === 50000) return 2000;
  if (splitNum === 75000) return 3500;
  if (splitNum === 100000) return 5000;
  if (splitNum === 120000) return 6000;
  if (splitNum === 150000) return 7500;
  return 2000;
};

// Расширенный список имен
const RANDOM_NAMES = [
  "Алексей Иванов", "Мария Петрова", "Дмитрий Смирнов", "Елена Кузнецова",
  "Сергей Попов", "Анна Волкова", "Александр Соколов", "Ольга Лебедева",
  "Николай Козлов", "Татьяна Новикова", "Андрей Морозов", "Екатерина Орлова",
  "Владимир Андреев", "Наталья Макарова", "Иван Федоров", "Юлия Михайлова",
  "Павел Борисов", "Светлана Зайцева", "Максим Романов", "Марина Медведева",
  "Роман Фролов", "Валентина Комарова", "Артем Жуков", "Виктория Чернова",
  "Денис Крылов", "Любовь Щербакова", "Константин Баранов", "Надежда Калинина",
  "Михаил Карпов", "Галина Степанова", "Евгений Ефимов", "Лариса Никитина",
  "Станислав Гришин", "Тамара Власова", "Георгий Захаров", "Вера Белова",
  "Артур Громов", "Инна Шестакова", "Леонид Филиппов", "Людмила Виноградова",
  "Кирилл Васильев", "Зоя Сидорова", "Валерий Тимофеев", "Раиса Павлова",
  "Игорь Давыдов", "Клара Симонова", "Олег Тихонов", "Майя Рябова",
  "Виктор Мельников", "Нина Сергеева", "Юрий Куликов", "Альбина Денисова",
  "Борис Терехов", "Полина Богданова", "Федор Назаров", "Жанна Субботина"
];

// Save purchased accounts to localStorage
const savePurchasedAccounts = (accounts: PurchasedAccount[]) => {
  try {
    localStorage.setItem('purchasedAccounts', JSON.stringify(accounts));
  } catch (error) {
    console.error('Failed to save purchased accounts:', error);
  }
};

// Save user balance to Supabase
const saveUserBalance = async (balance: number, userId?: string) => {
  if (!userId) return;
  
  try {
    const { error } = await supabase
      .from('profiles')
      .update({ balance })
      .eq('user_id', userId);
    
    if (error) {
      console.error('Failed to save user balance:', error);
    }
  } catch (error) {
    console.error('Failed to save user balance:', error);
  }
};

// Load purchased accounts from Supabase with unified auth support
const loadPurchasedAccounts = async (): Promise<PurchasedAccount[]> => {
  try {
    // Try to get current user from unified auth first
    let userId: string | null = null;
    
    // Check for Telegram session
    const unifiedSession = localStorage.getItem('unified_auth_session');
    if (unifiedSession) {
      try {
        const sessionData = JSON.parse(unifiedSession);
        if (sessionData.user?.id) {
          userId = sessionData.user.id;
          console.log('Loading purchased accounts for Telegram user:', userId);
        }
      } catch (error) {
        console.error('Failed to parse Telegram session:', error);
      }
    }
    
    // Fallback to Supabase auth
    if (!userId) {
      const { data: { user } } = await supabase.auth.getUser();
      if (user?.id) {
        userId = user.id;
        console.log('Loading purchased accounts for Supabase user:', userId);
      }
    }
    
    if (!userId) return [];

    const { data, error } = await supabase
      .from('purchased_accounts')
      .select('*')
      .eq('user_id', userId);

    if (error) {
      console.error('Failed to load purchased accounts:', error);
      return [];
    }

    // Преобразуем данные из БД в формат PurchasedAccount
    return (data || []).map(dbAccount => ({
      id: dbAccount.account_id,
      name: dbAccount.username,
      username: dbAccount.username,
      status: 'active' as const,
      type: 'account',
      proxy: `proxy_${dbAccount.account_id}`,
      model: 'gpt-4',
      progress: 0,
      lastActivity: 'Recently',
      temperature: 0.7,
      maxTokens: 4096,
      antiDetection: true,
      twoFA: true,
      operator: 'OpenAI',
      balance: 0,
      tasks: 0,
      city: dbAccount.city,
      split: dbAccount.split,
      emulationStatus: 'Готов к заказу',
      readyForOrders: true,
      price: dbAccount.price,
      purchased: true,
      warmupProgress: dbAccount.warmup_progress || 0,
      warmupStarted: dbAccount.warmup_status !== 'idle',
      warmupStartTime: undefined,
      selectedCity: dbAccount.city
    }));
  } catch (error) {
    console.error('Failed to load purchased accounts:', error);
    return [];
  }
};

// Load user balance from Supabase with unified auth support
const loadUserBalance = async (userId?: string): Promise<number> => {
  // Try to get current user from unified auth first if userId not provided
  if (!userId) {
    const unifiedSession = localStorage.getItem('unified_auth_session');
    if (unifiedSession) {
      try {
        const sessionData = JSON.parse(unifiedSession);
        if (sessionData.user?.id) {
          userId = sessionData.user.id;
        }
      } catch (error) {
        console.error('Failed to parse Telegram session:', error);
      }
    }
    
    // Fallback to Supabase auth
    if (!userId) {
      const { data: { user } } = await supabase.auth.getUser();
      if (user?.id) {
        userId = user.id;
      }
    }
  }
  
  if (!userId) return 125000;
  
  try {
    const { data, error } = await supabase
      .from('profiles')
      .select('balance')
      .eq('user_id', userId)
      .maybeSingle();
    
    if (error) {
      console.error('Failed to load user balance:', error);
      return 125000;
    }
    
    return data?.balance || 125000;
  } catch (error) {
    console.error('Failed to load user balance:', error);
    return 125000;
  }
};

export const useAppStore = create<AppState>((set, get) => ({
  user: {
    id: undefined,
    name: "Гость",
    avatar: "/api/placeholder/32/32",
    balance: 125000, // Will be loaded async
    plan: "Pro"
  },
  
  selectedAccounts: [],
  purchasedAccounts: [],
  orders: [],
  isWarmupActive: false,
  
  accounts: Array.from({ length: 130 }, (_, i) => {
    const cities = ["Москва", "Санкт-Петербург", "Новосибирск", "Екатеринбург", "Казань", "Нижний Новгород", "Челябинск", "Омск", "Самара", "Ростов-на-Дону", "Уфа", "Красноярск", "Воронеж", "Пермь", "Волгоград"];
    const maleNames = ["Александр", "Дмитрий", "Сергей", "Алексей", "Андрей", "Михаил", "Иван", "Николай"];
    const femaleNames = ["Анна", "Мария", "Елена", "Ольга", "Наталья", "Татьяна", "Екатерина"];
    const maleLastNames = ["Иванов", "Петров", "Сидоров", "Козлов", "Смирнов", "Новиков", "Морозов"];
    const femaleLastNames = ["Иванова", "Петрова", "Сидорова", "Козлова", "Смирнова", "Новикова", "Морозова"];
    
    const isMale = Math.random() > 0.5;
    const firstName = isMale 
      ? maleNames[Math.floor(Math.random() * maleNames.length)]
      : femaleNames[Math.floor(Math.random() * femaleNames.length)];
    const lastName = isMale
      ? maleLastNames[Math.floor(Math.random() * maleLastNames.length)]
      : femaleLastNames[Math.floor(Math.random() * femaleLastNames.length)];
    const username = `${firstName.toLowerCase()}_${lastName.toLowerCase()}${i}`;
    const splitValues = [50000, 75000, 100000, 120000, 150000];
    const split = splitValues[Math.floor(Math.random() * splitValues.length)];
    const price = getAccountPrice(split);
    const emulationStatuses = ['Готов к заказу - пассивный прогрев', 'Прогрев аккаунта на ГЕО', 'Предварительный прогрев'];
    const emulationStatus = emulationStatuses[Math.floor(Math.random() * emulationStatuses.length)];
    const city = emulationStatus === 'Предварительный прогрев' 
      ? 'Неизвестно' 
      : cities[Math.floor(Math.random() * cities.length)];
    
    return {
      id: ((i * 23456789 + 85649104) % 90000000 + 10000000).toString(),
      name: `${firstName} ${lastName}`,
      username,
      status: Math.random() > 0.7 ? 'warming' : 'active',
      type: 'account',
      proxy: `proxy_${(i + 1).toString().padStart(3, '0')}`,
      model: 'gpt-4',
      progress: Math.floor(Math.random() * 100),
      lastActivity: `${Math.floor(Math.random() * 60)} мин назад`,
      temperature: 0.7,
      maxTokens: 4096,
      antiDetection: true,
      twoFA: true,
      operator: 'OpenAI',
      balance: Math.floor(Math.random() * 100),
      tasks: Math.floor(Math.random() * 300),
      city,
      split,
      price,
      emulationStatus,
      readyForOrders: Math.random() > 0.3
    };
  }),

  // Load accounts from Supabase database (fallback to mock data)
  loadAccounts: async () => {
    console.log('🔄 Starting account loading...');
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 10000);
    
    try {
      // Load available accounts from database
      const { data, error } = await supabase
        .from('accounts')
        .select('*')
        .eq('available', true)
        .abortSignal(controller.signal);
      
      clearTimeout(timeoutId);
      
      if (error || !data || data.length === 0) {
        console.log('📦 Using mock accounts data');
        // Keep existing mock accounts
        return;
      }

      if (data && data.length > 0) {
        // Map database fields to Account interface
        const mappedAccounts: Account[] = data.map(account => ({
          id: account.id,
          name: account.name || account.username,
          username: account.username,
          status: (account.status === 'inactive' ? 'active' : account.status) as 'active' | 'paused' | 'banned' | 'warming',
          type: account.type,
          proxy: account.proxy,
          model: account.model,
          progress: account.progress || 0,
          lastActivity: account.last_activity,
          temperature: account.temperature,
          maxTokens: account.max_tokens,
          antiDetection: account.anti_detection,
          twoFA: account.two_fa,
          operator: account.operator,
          balance: account.balance,
          tasks: account.tasks,
          city: account.city,
          split: account.split,
          emulationStatus: account.emulation_status,
          readyForOrders: account.ready_for_orders,
          price: account.price,
          selected: false,
          purchased: false
        }));

        console.log('✅ Successfully loaded', mappedAccounts.length, 'accounts');
        set({ accounts: mappedAccounts });
      } else {
        console.log('ℹ️ No accounts found, setting empty array');
        set({ accounts: [] });
      }
    } catch (error) {
      console.error('❌ Error in loadAccounts:', error);
      // Don't hang the app, set empty accounts array
      set({ accounts: [] });
    }
  },

  
  sessions: [
    {
      id: "SES-001",
      account: "user_001",
      status: "active",
      startTime: "14:30",
      duration: "2h 15m",
      requests: 156,
      tokens: 12847,
      cost: 4.23
    },
    {
      id: "SES-002",
      account: "user_006",
      status: "active",
      startTime: "13:45",
      duration: "3h 0m",
      requests: 203,
      tokens: 18932,
      cost: 6.78
    },
    {
      id: "SES-003",
      account: "user_003",
      status: "paused",
      startTime: "12:20",
      duration: "1h 30m",
      requests: 89,
      tokens: 7456,
      cost: 2.15
    },
    {
      id: "SES-004",
      account: "user_007",
      status: "completed",
      startTime: "10:15",
      duration: "4h 45m",
      requests: 267,
      tokens: 23561,
      cost: 8.92
    },
    {
      id: "SES-005",
      account: "user_009",
      status: "active",
      startTime: "15:10",
      duration: "45m",
      requests: 67,
      tokens: 5234,
      cost: 1.87
    }
  ],
  
  warmupTab: "individual",
  
  systemStatus: {
    uptime: "99.8%",
    activeAccounts: 15,
    totalRequests: 156789,
    errorRate: 0.2
  },
  
  // Actions
  updateUser: (userUpdates) => {
    set((state) => ({ 
      user: { ...state.user, ...userUpdates } 
    }));
    // Save balance to database if it's being updated
    if (userUpdates.balance !== undefined) {
      const currentUserId = get().user.id;
      saveUserBalance(userUpdates.balance, currentUserId);
    }
  },

  updateUserBalance: (balance: number) => {
    set((state) => ({
      user: { ...state.user, balance }
    }));
  },
    
  setUser: async (user) => {
    set(() => ({ user }));
    if (user && user.id) {
      // Загружаем купленные аккаунты для нового пользователя
      const purchasedAccounts = await loadPurchasedAccounts();
      // Load user balance from database
      const balance = await loadUserBalance(user.id);
      set((state) => ({
        ...state,
        purchasedAccounts,
        user: { ...state.user, balance }
      }));
    }
  },
    
  addAccount: (account) =>
    set((state) => ({
      accounts: [...state.accounts, { ...account, id: generateRandomId() }]
    })),
    
  updateAccount: (id, updates) =>
    set((state) => ({
      accounts: state.accounts.map((account) =>
        account.id === id ? { ...account, ...updates } : account
      ),
      purchasedAccounts: state.purchasedAccounts.map((account) =>
        account.id === id ? { ...account, ...updates } : account
      )
    })),
    
  removeAccount: (id) =>
    set((state) => ({
      accounts: state.accounts.filter((account) => account.id !== id)
    })),
    
  addSession: (session) =>
    set((state) => ({
      sessions: [...state.sessions, { ...session, id: Date.now().toString() }]
    })),
    
  updateSession: (id, updates) =>
    set((state) => ({
      sessions: state.sessions.map((session) =>
        session.id === id ? { ...session, ...updates } : session
      )
    })),
    
  removeSession: (id) =>
    set((state) => ({
      sessions: state.sessions.filter((session) => session.id !== id)
    })),
    
  setWarmupTab: (tab) =>
    set(() => ({ warmupTab: tab })),

  toggleAccountSelection: (id) =>
    set((state) => ({
      selectedAccounts: state.selectedAccounts.includes(id)
        ? state.selectedAccounts.filter(accountId => accountId !== id)
        : [...state.selectedAccounts, id]
    })),

  purchaseSelectedAccounts: async () => {
    const state = get();
    const selectedAccountsData = state.accounts.filter(account => 
      state.selectedAccounts.includes(account.id)
    );
    
    console.log('🚀 Starting purchase process:', {
      user: state.user ? { id: state.user.id, name: state.user.name, balance: state.user.balance } : null,
      selectedAccounts: state.selectedAccounts,
      selectedAccountsData: selectedAccountsData.map(a => ({ id: a.id, username: a.username, price: a.price }))
    });
    
    if (selectedAccountsData.length === 0) {
      console.error('❌ No accounts selected for purchase');
      throw new Error('Выберите аккаунты для покупки');
    }
    
    console.log('🛒 Starting unified account purchase process...', {
      selectedCount: selectedAccountsData.length,
      accountIds: selectedAccountsData.map(a => a.id)
    });
    
    try {
      // Get Telegram ID for unified auth
      let telegramId: number | null = null;
      const unifiedSession = localStorage.getItem('unified_auth_session');
      if (unifiedSession) {
        try {
          const sessionData = JSON.parse(unifiedSession);
          telegramId = parseInt(sessionData.user?.user_metadata?.telegram_id);
        } catch (error) {
          console.error('❌ Failed to parse Telegram session:', error);
        }
      }
      
      console.log('🛒 Calling purchase edge function with:', {
        selectedAccountIds: selectedAccountsData.map(a => a.id),
        telegramId: telegramId,
        accountCount: selectedAccountsData.length
      });

      // Call the purchase edge function instead of direct RPC
      const { data, error } = await supabase.functions.invoke('purchase-accounts', {
        body: {
          selectedAccountIds: selectedAccountsData.map(a => a.id),
          telegramId: telegramId
        }
      });

      console.log('📦 Purchase edge function response:', { data, error });

      if (error) {
        console.error('❌ Purchase function error:', error);
        throw new Error(`Ошибка покупки: ${error.message || 'Неизвестная ошибка'}`);
      }

      const result = data as any;
      console.log('📊 Purchase result:', result);
      
      if (!result?.success) {
        console.error('❌ Purchase failed with result:', result);
        throw new Error(result?.message || 'Неизвестная ошибка при покупке');
      }

      console.log('✅ Purchase successful:', result);
      
      // Update local state
      const purchasedAccountsToAdd: PurchasedAccount[] = selectedAccountsData.map(account => ({
        ...account,
        purchased: true as const,
        warmupProgress: 0,
        warmupStarted: false,
        warmupStartTime: undefined,
        selectedCity: undefined
      }));
      
      set({
        accounts: state.accounts.filter(account => 
          !state.selectedAccounts.includes(account.id)
        ),
        purchasedAccounts: [...state.purchasedAccounts, ...purchasedAccountsToAdd],
        selectedAccounts: [],
        user: {
          ...state.user,
          balance: result.new_balance
        }
      });
      
      console.log('✅ Покупка завершена успешно! Новый баланс:', result.new_balance);
      
    } catch (error) {
      console.error('❌ Ошибка при покупке аккаунтов:', error);
      throw error;
    }
  },

  startWarmup: (id, selectedCity) =>
    set((state) => {
      const newPurchasedAccounts = state.purchasedAccounts.map(account =>
        account.id === id 
          ? { 
              ...account, 
              warmupStarted: true, 
              warmupProgress: 0,
              warmupStartTime: Date.now(),
              selectedCity: selectedCity || account.city
            }
          : account
      );
      
      // Save to localStorage
      savePurchasedAccounts(newPurchasedAccounts);
      
      const newState = {
        purchasedAccounts: newPurchasedAccounts,
        isWarmupActive: true
      };
      // Сохраняем состояние в localStorage
      setTimeout(() => get().saveWarmupState(), 100);
      return newState;
    }),

  updateWarmupProgress: (id, progress) =>
    set((state) => {
      const newPurchasedAccounts = state.purchasedAccounts.map(account =>
        account.id === id 
          ? { 
              ...account, 
              warmupProgress: Math.min(progress, 100),
              emulationStatus: progress >= 100 ? "Готов к заказу" : account.emulationStatus
            }
          : account
      );
      
      // Save to localStorage
      savePurchasedAccounts(newPurchasedAccounts);
      
      const newState = {
        purchasedAccounts: newPurchasedAccounts
      };
      // Сохраняем состояние в localStorage
      setTimeout(() => get().saveWarmupState(), 100);
      return newState;
    }),

  saveWarmupState: () => {
    const state = get();
    const warmupData = state.purchasedAccounts.map(account => ({
      id: account.id,
      warmupProgress: account.warmupProgress,
      warmupStarted: account.warmupStarted,
      warmupStartTime: account.warmupStartTime,
      selectedCity: account.selectedCity,
      emulationStatus: account.emulationStatus
    }));
    localStorage.setItem('warmupState', JSON.stringify(warmupData));
  },

  loadWarmupState: () => {
    try {
      const savedState = localStorage.getItem('warmupState');
      if (savedState) {
        const warmupData = JSON.parse(savedState);
        set((state) => ({
          purchasedAccounts: state.purchasedAccounts.map(account => {
            const saved = warmupData.find((w: any) => w.id === account.id);
            if (saved) {
              return {
                ...account,
                warmupProgress: saved.warmupProgress,
                warmupStarted: saved.warmupStarted,
                warmupStartTime: saved.warmupStartTime,
                selectedCity: saved.selectedCity,
                emulationStatus: saved.emulationStatus
              };
            }
            return account;
          })
        }));
      }
    } catch (error) {
      console.error('Error loading warmup state:', error);
    }
  },

  checkWarmupProgress: () => {
    const state = get();
    const now = Date.now();
    const totalWarmupTime = 3 * 24 * 60 * 60 * 1000; // 3 дня в миллисекундах (а не 5)
    
    state.purchasedAccounts.forEach(account => {
      if (account.warmupStarted && account.warmupStartTime && account.warmupProgress < 100) {
        const elapsed = now - account.warmupStartTime;
        const newProgress = Math.min((elapsed / totalWarmupTime) * 100, 100);
        
        if (newProgress !== account.warmupProgress) {
          get().updateWarmupProgress(account.id, newProgress);
        }
      }
    });
  },

  createOrder: (orderData) =>
    set((state) => {
      const newOrder: Order = {
        ...orderData,
        id: `ORD-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
        createdAt: Date.now(),
        updatedAt: Date.now()
      };
      return {
        orders: [...state.orders, newOrder]
      };
    }),

  updateOrderStatus: (orderId, status) =>
    set((state) => ({
      orders: state.orders.map(order =>
        order.id === orderId 
          ? { ...order, status, updatedAt: Date.now() }
          : order
      )
    })),

  setWarmupActive: (active) =>
    set({ isWarmupActive: active }),

  // Очистка купленных аккаунтов
  clearPurchasedAccounts: () => {
    set({ purchasedAccounts: [] });
    savePurchasedAccounts([]);
  }
}));

// Очищаем купленные аккаунты при загрузке (так как они удалены из БД)
if (typeof window !== 'undefined') {
  setTimeout(() => {
    const store = useAppStore.getState();
    store.clearPurchasedAccounts();
  }, 100);
}