import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ChevronDown, Play, Pause, HelpCircle, Zap, CreditCard, Smartphone, TrendingUp, Shield, AlertTriangle, Cpu, CheckCircle, Users, Gavel, Settings } from 'lucide-react';

const FAQPage = () => {
  const [activeIndex, setActiveIndex] = useState<number | null>(null);
  const [animationsActive, setAnimationsActive] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);

  useEffect(() => {
    if (isPlaying) {
      const interval = setInterval(() => {
        setAnimationsActive(true);
        setTimeout(() => setAnimationsActive(false), 300);
      }, 1500);
      return () => clearInterval(interval);
    }
  }, [isPlaying]);

  const faqData = [
    {
      question: "Что такое Яндекс Сплит и как на нём зарабатывают?",
      answer: "Яндекс Сплит — это способ оплатить товар в рассрочку от Яндекса, деля платёж на 4 части. **Платишь только 25% сразу — остальное списывается позже.**\n\nСхема заработка простая:\n\n**1. Выбираешь ликвидный товар** (смартфоны, ноутбуки, техника)\n**2. Оформляешь заказ через Сплит**, платишь только первый платёж (25%)\n**3. Получаешь товар и сразу продаёшь** на Авито\n**4. Деньги в карман** — никаких дальнейших платежей (сплит оформлен не на нас)\n**5. Запускаешь следующий круг** — новый аккаунт, новый прогрев\n\n**Результат:** берёшь любой товар за 25% от цены, разницу забираешь как чистый профит. **Главное — обойти фрод Яндекса.**",
      icon: CreditCard
    },
    {
      question: "Мне нужно заходить в аккаунт и что-то привязывать?",
      answer: "**Все манипуляции с аккаунтом производятся через сайт.** Все расходники на нас, и они уже включены в стоимость аккаунта.",
      icon: Settings
    },
    {
      question: "А карту для оплаты сплита свою привязывать надо будет?",
      answer: "**К каждому аккаунту уже подключен верифицированный Яндекс Пей**, оплата производится оттуда, ваша карта не потребуется.",
      icon: CreditCard
    },
    {
      question: "Как начать прогрев? Как заказать товар?",
      answer: "**Функционал прогрева станет доступным после первой покупки аккаунта** (прогрев включен в стоимость).\n\nПосле покупки запускаете прогрев через сайт, и по его завершению (через **3-5 дней**) откроется функционал для заказа товара.\n\n**Вы укажете:** адрес, способ получения и ссылку на товар.",
      icon: Play
    },
    {
      question: "Почему Яндекс усилил антифрод до паранойи?",
      answer: "**Любая смена IP, IMEI, геолокации или Device ID = фрод-флаг.**\n\nДаже если сбросил телефон до заводских — уникальные hardware-идентификаторы остаются:\n\n**IMEI, MEID, серийник**\n**Bluetooth MAC**\n**Базовые bootloader сигнатуры**\n\n**Прошивки и кастомные ROM больше не спасают** — Яндекс определяет \"ненативность\" железа. Даже смена IMEI через root не помогает — фиксируется повторяющийся usage-паттерн.",
      icon: Shield
    },
    {
      question: "Почему BlueStacks и эмуляторы больше не работают?",
      answer: "BlueStacks и аналоги **легко палятся** по:\n\n**build.prop, model name, DPI**\n**Ненастоящим сенсорам**\n**Отсутствию сотовой сети**\n**Шаблонному ядру Android-эмуляторов**\n\nВсе Android-эмуляторы имеют **шаблонное ядро**, которое Яндекс давно классифицировал как фрод.",
      icon: Smartphone
    },
    {
      question: "Почему веб-версия с ПК тоже не работает?",
      answer: "Веб-версия фродится **даже быстрее мобильной**:\n\n**1. Яндекс собирает детальный браузерный фингерпринт** (user-agent, canvas/WebGL, кэш шрифтов)\n\n**2. Антидетект-браузеры** (Dolphin, AdsPower, Indigo) всё равно палятся — они генерируют неестественные аномалии\n\n**3. Прокси не спасение:**\nОбычные IPv4 — статичные, дата-центр\nМобильные прокси палятся через отсутствие реальных сигналов сети\n**Если ПК + мобильный прокси = device и IP не бьются = теневой бан**",
      icon: AlertTriangle
    },
    {
      question: "Как работает новый ИИ инструмент автопрогрева?",
      answer: "**yasplit.ai** — полностью автономный инструмент с промышленной эмуляцией:\n\n**Что делает софт:**\n\n**Имитирует естественную активность** на всех сервисах Яндекса\n**Каждый слот имеет уникальный** IMEI/Device ID/Android ID\n**Реалистичный профиль железа** и прошивки\n**Живёт на отдельной мобильной сети** с уникальной симкой\n**Геолокация** — симуляция вышек и перемещения\n\n**Почему Яндекс не палит:**\n\n**Тонко настроенная эмуляция** настоящих телефонов\n**Эмуляция полного радиотрафика** с шумами\n**Нет пересечений между слотами** по IP, device ID, usage-профилю",
      icon: Cpu
    },
    {
      question: "Что происходит после прогрева?",
      answer: "Когда лимит на аккаунте активен — **нельзя логиниться с других устройств** (Яндекс видит смену IP и device ID).\n\n**Бот сам оформляет заказ с того же виртуального телефона**, где шёл прогрев. Это исключает **99% вероятности отлета** по антифроду.\n\n**Всё автоматом:**\n\nПрогрев\nПроверка статуса\nПокупка в сплит\nДоставка",
      icon: CheckCircle
    },
    {
      question: "Заключение: почему ручной прогрев устарел?",
      answer: "**Ручками греть — устарело и опасно.** Яндекс выносит даже тех, кто \"всё правильно сделал\" и \"прошивку менял\".\n\n**Нужен бот, который:**\n\nЖивёт как реальный человек\nШифруется как реальное железо\nПокупает как реальный юзер\n\n**И он уже есть — yasplit.ai**\n\n**P.S.** Функционал выбора и заказа товара на ваш адрес станет доступным после окончания прогрева купленного аккаунта.",
      icon: TrendingUp
    },
    {
      question: "А тема вообще белая?",
      answer: "**Мы используем только обычные сплит аккаунты** (не улучшенные) - они не попадают под УК, так как **сплит без документов не является кредитным продуктом.**",
      icon: Gavel
    },
    {
      question: "А можно прогреть через ваш софт свой личный аккаунт?",
      answer: "**Для прогрева в нашей ферме мы используем только личные аккаунты.**",
      icon: Users
    }
  ];

  const headerVariants = {
    normal: {
      background: "linear-gradient(135deg, #1e293b, #334155, #475569, #1e293b)",
      boxShadow: "0 0 20px rgba(59, 130, 246, 0.3)",
      border: "1px solid rgba(59, 130, 246, 0.4)"
    },
    active: {
      background: [
        "linear-gradient(135deg, #1e293b, #334155, #475569, #1e293b)",
        "linear-gradient(135deg, #334155, #475569, #3b82f6, #334155)",
        "linear-gradient(135deg, #475569, #1e293b, #334155, #475569)",
        "linear-gradient(135deg, #1e293b, #334155, #475569, #1e293b)"
      ],
      boxShadow: [
        "0 0 20px rgba(59, 130, 246, 0.3)",
        "0 0 40px rgba(59, 130, 246, 0.6)",
        "0 0 60px rgba(59, 130, 246, 0.8)",
        "0 0 20px rgba(59, 130, 246, 0.3)"
      ],
      border: [
        "1px solid rgba(59, 130, 246, 0.4)",
        "1px solid rgba(59, 130, 246, 0.8)",
        "1px solid rgba(59, 130, 246, 0.6)",
        "1px solid rgba(59, 130, 246, 0.4)"
      ],
      transition: { duration: 0.3, times: [0, 0.33, 0.66, 1] }
    }
  };

  return (
    <div className="space-y-6 p-6">
      {/* Control Panel */}
      <Card className="bg-slate-900/90 border-blue-500/30 backdrop-blur-sm">
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-bold text-blue-400">Частые вопросы</h2>
            <div className="flex items-center space-x-4">
              <Button
                onClick={() => setIsPlaying(!isPlaying)}
                variant="outline"
                className="border-blue-500/50 text-blue-400 hover:bg-blue-500/20"
              >
                {isPlaying ? (
                  <>
                    <Pause className="w-4 h-4 mr-2" />
                    Выключить анимации
                  </>
                ) : (
                  <>
                    <Play className="w-4 h-4 mr-2" />
                    Включить анимации
                  </>
                )}
              </Button>
              <div className="flex items-center space-x-2">
                <motion.div
                  animate={isPlaying ? {
                    scale: [1, 1.3, 1],
                    opacity: [0.7, 1, 0.7]
                  } : {}}
                  transition={{ duration: 1.5, repeat: Infinity }}
                  className="w-3 h-3 bg-blue-400 rounded-full"
                />
                <span className="text-sm text-muted-foreground">
                  {isPlaying ? "Анимации включены" : "Статичный режим"}
                </span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* FAQ Header */}
      <motion.div
        variants={headerVariants}
        animate={animationsActive && isPlaying ? "active" : "normal"}
        className="relative p-6 rounded-lg overflow-hidden"
      >
        {/* Animated background particles */}
        <div className="absolute inset-0 overflow-hidden">
          {isPlaying && [...Array(6)].map((_, i) => (
            <motion.div
              key={i}
              className="absolute w-1 h-1 bg-blue-400 rounded-full"
              animate={{
                x: [Math.random() * 100 + "%", Math.random() * 100 + "%"],
                y: [Math.random() * 100 + "%", Math.random() * 100 + "%"],
                opacity: [0, 1, 0],
                scale: [0, 1.5, 0]
              }}
              transition={{
                duration: 3 + Math.random() * 2,
                repeat: Infinity,
                delay: Math.random() * 2
              }}
            />
          ))}
          
          {/* Scanning line */}
          {isPlaying && (
            <motion.div
              className="absolute inset-x-0 h-0.5 bg-gradient-to-r from-transparent via-blue-400 to-transparent opacity-60"
              animate={{ y: ["0%", "100%"] }}
              transition={{ duration: 4, repeat: Infinity, ease: "linear" }}
            />
          )}
        </div>

        <div className="relative z-10">
          <motion.div
            className="flex items-center justify-center mb-4"
            animate={animationsActive && isPlaying ? {
              scale: [1, 1.05, 1]
            } : {}}
            transition={{ duration: 0.3 }}
          >
            <HelpCircle className="w-8 h-8 text-blue-400 mr-3" />
            <motion.h2
              animate={animationsActive && isPlaying ? {
                textShadow: [
                  "0 0 10px rgba(59, 130, 246, 0.5)",
                  "0 0 30px rgba(59, 130, 246, 1)",
                  "0 0 50px rgba(30, 41, 59, 0.8)",
                  "0 0 10px rgba(59, 130, 246, 0.5)"
                ],
                color: ["#ffffff", "#3b82f6", "#ffffff", "#ffffff"],
                scale: [1, 1.05, 1, 1]
              } : {}}
              transition={{ duration: 0.3 }}
              className="text-2xl font-bold text-center text-white"
            >
              База знаний Яндекс Сплит
            </motion.h2>
            <Zap className="w-6 h-6 text-blue-400 ml-3" />
          </motion.div>
          <motion.p 
            animate={isPlaying ? {
              opacity: [0.6, 1, 0.6]
            } : {}}
            transition={{ duration: 2, repeat: Infinity }}
            className="text-center text-blue-200/80 text-sm"
          >
            {isPlaying ? "Автоматические ответы на популярные вопросы" : "Ответы на самые частые вопросы"}
          </motion.p>
        </div>
      </motion.div>

      {/* FAQ Items */}
      {faqData.map((item, index) => (
        <motion.div
          key={index}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: index * 0.1 }}
        >
          <motion.div
            className="relative overflow-hidden rounded-lg cursor-pointer"
            whileHover={{ scale: 1.02 }}
            animate={isPlaying ? {
              boxShadow: [
                "0 0 20px rgba(59, 130, 246, 0.2)",
                "0 0 40px rgba(59, 130, 246, 0.4)",
                "0 0 20px rgba(59, 130, 246, 0.2)"
              ]
            } : {}}
            transition={{ duration: 2, repeat: Infinity, delay: index * 0.2 }}
            style={{
              background: "linear-gradient(135deg, rgba(30, 41, 59, 0.8), rgba(51, 65, 85, 0.6), rgba(71, 85, 105, 0.4))",
              border: "1px solid rgba(59, 130, 246, 0.2)"
            }}
            onClick={() => setActiveIndex(activeIndex === index ? null : index)}
          >
            {/* Animated background effect */}
            <motion.div
              className="absolute inset-0 opacity-20"
              animate={isPlaying ? {
                background: [
                  "radial-gradient(circle at 20% 50%, #3b82f6, transparent 50%)",
                  "radial-gradient(circle at 80% 50%, #1e40af, transparent 50%)",
                  "radial-gradient(circle at 50% 80%, #2563eb, transparent 50%)",
                  "radial-gradient(circle at 20% 50%, #3b82f6, transparent 50%)"
                ]
              } : {}}
              transition={{ duration: 4, repeat: Infinity }}
            />

            <div className="relative z-10 p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <item.icon className="w-5 h-5 text-primary flex-shrink-0" />
                  <motion.h3 
                    className="text-white font-medium pr-4"
                    animate={isPlaying ? {
                      textShadow: [
                        "0 0 5px rgba(255, 255, 255, 0.5)",
                        "0 0 15px rgba(59, 130, 246, 0.8)",
                        "0 0 5px rgba(255, 255, 255, 0.5)"
                      ]
                    } : {}}
                    transition={{ duration: 3, repeat: Infinity, delay: index * 0.3 }}
                    style={{ textShadow: "2px 2px 4px rgba(0, 0, 0, 0.8)" }}
                  >
                    {item.question}
                  </motion.h3>
                </div>
                <motion.div
                  animate={{ 
                    rotate: activeIndex === index ? 180 : 0,
                    color: isPlaying && activeIndex === index ? ["#3b82f6", "#60a5fa", "#3b82f6"] : "#3b82f6"
                  }}
                  transition={{ 
                    rotate: { duration: 0.3 },
                    color: { duration: 1, repeat: Infinity }
                  }}
                >
                  <ChevronDown className="w-5 h-5" />
                </motion.div>
              </div>

              <AnimatePresence>
                {activeIndex === index && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: "auto", opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.3 }}
                    className="overflow-hidden"
                  >
                    <motion.div
                      initial={{ y: -10 }}
                      animate={{ y: 0 }}
                      className="pt-4 mt-4 border-t border-blue-400/30"
                    >
                      <motion.div 
                        className="text-blue-100/90 leading-relaxed"
                        animate={isPlaying ? {
                          textShadow: [
                            "0 0 5px rgba(59, 130, 246, 0.3)",
                            "0 0 10px rgba(59, 130, 246, 0.6)",
                            "0 0 5px rgba(59, 130, 246, 0.3)"
                          ]
                        } : {}}
                        transition={{ duration: 2.5, repeat: Infinity }}
                        style={{ textShadow: "1px 1px 3px rgba(0, 0, 0, 0.8)" }}
                        dangerouslySetInnerHTML={{
                          __html: item.answer
                            .replace(/\*\*(.*?)\*\*/g, '<strong style="color: #60a5fa; font-weight: 600;">$1</strong>')
                            .replace(/\n/g, '<br>')
                        }}
                      />
                      
                      {/* Response indicator */}
                      <motion.div
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: 0.2 }}
                        className="flex items-center mt-3 text-xs text-blue-400/70"
                      >
                        <motion.div
                          animate={isPlaying ? { 
                            scale: [1, 1.4, 1],
                            opacity: [0.7, 1, 0.7]
                          } : { scale: 1, opacity: 0.7 }}
                          transition={{ duration: 1.5, repeat: Infinity }}
                          className="w-2 h-2 bg-blue-400 rounded-full mr-2"
                        />
                        <motion.span
                          animate={isPlaying ? {
                            opacity: [0.7, 1, 0.7]
                          } : {}}
                          transition={{ duration: 2, repeat: Infinity }}
                        >
                          {isPlaying ? "Автоматический ответ системы" : "Информация из базы знаний"}
                        </motion.span>
                      </motion.div>
                    </motion.div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            {/* Edge glow effect */}
            <motion.div
              className="absolute inset-0 rounded-lg pointer-events-none"
              animate={activeIndex === index && isPlaying ? {
                boxShadow: [
                  "inset 0 0 20px rgba(59, 130, 246, 0.1)",
                  "inset 0 0 40px rgba(59, 130, 246, 0.3)",
                  "inset 0 0 60px rgba(59, 130, 246, 0.5)",
                  "inset 0 0 40px rgba(59, 130, 246, 0.3)",
                  "inset 0 0 20px rgba(59, 130, 246, 0.1)"
                ]
              } : {}}
              transition={{ duration: 2, repeat: Infinity }}
            />
          </motion.div>
        </motion.div>
      ))}

      {/* Footer */}
      <motion.div
        className="text-center py-6"
        animate={isPlaying ? {
          opacity: [0.5, 1, 0.5]
        } : { opacity: 0.6 }}
        transition={{ duration: 3, repeat: Infinity }}
      >
        <motion.p 
          className="text-blue-400/60 text-sm"
          animate={isPlaying ? {
            textShadow: [
              "0 0 5px rgba(59, 130, 246, 0.3)",
              "0 0 15px rgba(59, 130, 246, 0.7)",
              "0 0 5px rgba(59, 130, 246, 0.3)"
            ]
          } : {}}
          transition={{ duration: 4, repeat: Infinity }}
        >
          {isPlaying ? "◊ Система постоянно обновляет базу знаний ◊" : "◊ Нужна дополнительная помощь? Обратитесь в поддержку ◊"}
        </motion.p>
      </motion.div>
    </div>
  );
};

export default FAQPage;