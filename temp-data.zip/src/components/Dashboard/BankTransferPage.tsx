import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Copy, Upload, X, CheckCircle, Clock } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { Progress } from '@/components/ui/progress';
import { useAuthContext } from '@/providers/AuthProvider';

export const BankTransferPage = () => {
  const [amount, setAmount] = useState('');
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string>('');
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const navigate = useNavigate();
  const { toast } = useToast();
  
  const { user, session, isAuthenticated, isLoading } = useAuthContext();

  const bankDetails = {
    cardNumber: '2202 2063 8832 5674',
    bankName: 'Сбербанк'
  };

  const copyToClipboard = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      toast({
        title: "Успешно",
        description: "Скопировано в буфер обмена",
      });
    } catch (err) {
      toast({
        title: "Ошибка",
        description: "Не удалось скопировать",
        variant: "destructive",
      });
    }
  };

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    // Clean up previous preview URL to prevent memory leaks
    if (previewUrl) {
      URL.revokeObjectURL(previewUrl);
    }

    // Validate file type and size
    const allowedTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/webp'];
    if (!allowedTypes.includes(file.type)) {
      toast({
        title: "Ошибка",
        description: "Поддерживаются только изображения: JPG, PNG, WebP",
        variant: "destructive",
      });
      return;
    }

    if (file.size > 5 * 1024 * 1024) {
      toast({
        title: "Ошибка",
        description: "Максимальный размер файла: 5 МБ",
        variant: "destructive",
      });
      return;
    }

    setSelectedFile(file);
    const url = URL.createObjectURL(file);
    setPreviewUrl(url);
  };

  const handleSubmit = async () => {
    if (!amount || !selectedFile) {
      toast({
        title: "Ошибка",
        description: "Пожалуйста, укажите сумму и загрузите чек",
        variant: "destructive",
      });
      return;
    }

    const numericAmount = parseFloat(amount);
    if (isNaN(numericAmount) || numericAmount < 100) {
      toast({
        title: "Ошибка",
        description: "Минимальная сумма пополнения: 100 рублей",
        variant: "destructive",
      });
      return;
    }

    // Check authentication state
    if (!isAuthenticated || !user) {
      toast({
        title: "Ошибка",
        description: "Пожалуйста, войдите в систему",
        variant: "destructive",
      });
      return;
    }

    try {
      setIsUploading(true);
      setUploadProgress(10);

      const formData = new FormData();
      formData.append('amount', amount);
      formData.append('receipt', selectedFile);

      setUploadProgress(30);

      // Get auth headers
      let authHeaders: Record<string, string> = {};
      let telegramId: string | null = null;
      
      const authMethod = localStorage.getItem('auth_method');
      
      if (authMethod === 'telegram') {
        const unifiedSession = localStorage.getItem('unified_auth_session');
        if (unifiedSession) {
          try {
            const sessionData = JSON.parse(unifiedSession);
            
            // Детальное логирование для отладки
            console.log('[BankTransfer] Полная сессия:', sessionData);
            console.log('[BankTransfer] Структура user:', sessionData.user);
            console.log('[BankTransfer] user_metadata:', sessionData.user?.user_metadata);
            
            // Правильное извлечение telegram_id из sessionData.user.user_metadata.telegram_id
            let rawTelegramId = null;
            
            // Проверяем несколько возможных мест где может быть telegram_id
            if (sessionData.user?.user_metadata?.telegram_id) {
              rawTelegramId = sessionData.user.user_metadata.telegram_id;
              console.log('[BankTransfer] Найден telegram_id в user_metadata:', rawTelegramId);
            } else if (sessionData.telegram_id) {
              rawTelegramId = sessionData.telegram_id;
              console.log('[BankTransfer] Найден telegram_id в корне сессии:', rawTelegramId);
            }
            
            if (rawTelegramId) {
              // Convert scientific notation to proper integer string
              if (typeof rawTelegramId === 'number') {
                telegramId = Math.floor(rawTelegramId).toString();
                console.log('[BankTransfer] Конвертирован number в string:', telegramId);
              } else if (typeof rawTelegramId === 'string') {
                const parsed = parseFloat(rawTelegramId);
                telegramId = !isNaN(parsed) ? Math.floor(parsed).toString() : rawTelegramId;
                console.log('[BankTransfer] Обработан string, результат:', telegramId);
              }
              
              authHeaders['x-telegram-id'] = telegramId;
              authHeaders['Authorization'] = `Bearer telegram_session_${telegramId}`;
              console.log('[BankTransfer] Установлены заголовки авторизации для telegram_id:', telegramId);
            } else {
              console.error('[BankTransfer] telegram_id не найден в сессии!');
            }
          } catch (error) {
            console.error('[BankTransfer] Ошибка парсинга сессии:', error);
          }
        } else {
          console.error('[BankTransfer] unified_auth_session не найдена в localStorage');
        }
      } else {
        // Supabase auth
        const { data: { session: currentSession } } = await supabase.auth.getSession();
        if (currentSession?.access_token) {
          authHeaders['Authorization'] = `Bearer ${currentSession.access_token}`;
        }
      }
      
      if (!authHeaders['Authorization']) {
        toast({
          title: "Ошибка авторизации",
          description: "Попробуйте войти в систему заново.",
          variant: "destructive",
        });
        setIsUploading(false);
        return;
      }

      setUploadProgress(50);

      // Call the Supabase edge function
      const response = await fetch(
        `https://xonxdkvdbjmxawdyeemt.supabase.co/functions/v1/create-deposit-request`,
        {
          method: 'POST',
          headers: authHeaders,
          body: formData,
        }
      );

      setUploadProgress(80);

      const result = await response.json();

      if (!response.ok) {
        throw new Error(result.error || 'Ошибка при создании запроса на пополнение');
      }

      setUploadProgress(100);
      
      toast({
        title: "Успешно!",
        description: "Запрос на пополнение успешно отправлен! Вскоре администратор проверит ваш чек.",
      });

      // Navigate to status page with the deposit request ID
      navigate('/dashboard/deposit-status', { 
        state: { depositId: result.data?.id } 
      });

    } catch (error: any) {
      console.error('Error submitting deposit request:', error);
      
      let errorMessage = 'Произошла ошибка при отправке запроса';
      
      if (error.message.includes('Authorization')) {
        errorMessage = 'Ошибка авторизации. Попробуйте войти в систему заново.';
      } else if (error.message.includes('413') || error.message.includes('File too large')) {
        errorMessage = 'Файл слишком большой. Максимальный размер: 5 МБ';
      } else if (error.message.includes('network') || error.message.includes('fetch')) {
        errorMessage = 'Ошибка сети. Проверьте подключение к интернету.';
      } else if (error.message) {
        errorMessage = error.message;
      }
      
      toast({
        title: "Ошибка",
        description: errorMessage,
        variant: "destructive",
      });
    } finally {
      setIsUploading(false);
      setUploadProgress(0);
    }
  };

  // Clean up preview URL on component unmount
  React.useEffect(() => {
    return () => {
      if (previewUrl) {
        URL.revokeObjectURL(previewUrl);
      }
    };
  }, [previewUrl]);

  return (
    <div className="container mx-auto px-4 py-6 max-w-2xl">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
        className="space-y-6"
      >
        <div className="text-center">
          <h1 className="text-2xl font-bold text-foreground mb-2">
            Пополнение баланса
          </h1>
          <p className="text-muted-foreground">
            Переведите средства на указанную карту и загрузите чек
          </p>
        </div>

        {/* Bank Details Card */}
        <div className="bg-card border rounded-lg p-6 space-y-4">
          <h2 className="text-lg font-semibold text-foreground flex items-center gap-2">
            <CheckCircle className="h-5 w-5 text-green-500" />
            Реквизиты для перевода
          </h2>
          
          <div className="space-y-3">
            <div className="flex items-center justify-between p-3 bg-muted rounded-lg">
              <div>
                <Label className="text-sm text-muted-foreground">Номер карты</Label>
                <p className="font-mono text-lg font-semibold">{bankDetails.cardNumber}</p>
              </div>
              <Button
                variant="outline"
                size="sm"
                onClick={() => copyToClipboard(bankDetails.cardNumber.replace(/\s/g, ''))}
              >
                <Copy className="h-4 w-4" />
              </Button>
            </div>
            
            <div className="flex items-center justify-between p-3 bg-muted rounded-lg">
              <div>
                <Label className="text-sm text-muted-foreground">Банк</Label>
                <p className="font-semibold">{bankDetails.bankName}</p>
              </div>
            </div>
          </div>
        </div>

        {/* Transfer Form */}
        <div className="bg-card border rounded-lg p-6 space-y-4">
          <h2 className="text-lg font-semibold text-foreground">
            Подтвердите перевод
          </h2>
          
          <div className="space-y-4">
            <div>
              <Label htmlFor="amount">Сумма перевода (руб.)</Label>
              <Input
                id="amount"
                type="number"
                placeholder="Введите сумму"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                min="100"
                className="mt-1"
              />
              <p className="text-sm text-muted-foreground mt-1">
                Минимальная сумма: 100 рублей
              </p>
            </div>

            {/* File Upload */}
            <div>
              <Label htmlFor="receipt">Чек об оплате</Label>
              <div className="mt-1">
                {!selectedFile ? (
                  <label
                    htmlFor="receipt"
                    className="flex flex-col items-center justify-center w-full h-32 border-2 border-dashed border-muted-foreground/25 rounded-lg cursor-pointer hover:border-muted-foreground/50 transition-colors"
                  >
                    <div className="flex flex-col items-center justify-center pt-5 pb-6">
                      <Upload className="h-8 w-8 text-muted-foreground mb-2" />
                      <p className="text-sm text-muted-foreground">
                        <span className="font-semibold">Нажмите для загрузки</span> или перетащите файл
                      </p>
                      <p className="text-xs text-muted-foreground">
                        PNG, JPG, WebP до 5MB
                      </p>
                    </div>
                    <input
                      id="receipt"
                      type="file"
                      accept="image/*"
                      onChange={handleFileSelect}
                      className="hidden"
                    />
                  </label>
                ) : (
                  <div className="relative">
                    <div className="flex items-center justify-between p-3 bg-muted rounded-lg">
                      <div className="flex items-center gap-3">
                        <div className="h-12 w-12 rounded-lg overflow-hidden bg-background">
                          <img
                            src={previewUrl}
                            alt="Preview"
                            className="h-full w-full object-cover"
                          />
                        </div>
                        <div>
                          <p className="font-medium">{selectedFile.name}</p>
                          <p className="text-sm text-muted-foreground">
                            {(selectedFile.size / 1024 / 1024).toFixed(2)} MB
                          </p>
                        </div>
                      </div>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => {
                          setSelectedFile(null);
                          if (previewUrl) {
                            URL.revokeObjectURL(previewUrl);
                          }
                          setPreviewUrl('');
                        }}
                      >
                        <X className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Upload Progress */}
            {isUploading && (
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <p className="text-sm text-muted-foreground">Отправка запроса...</p>
                  <p className="text-sm text-muted-foreground">{uploadProgress}%</p>
                </div>
                <Progress value={uploadProgress} className="w-full" />
              </div>
            )}

            {/* Submit Button */}
            <Button
              onClick={handleSubmit}
              disabled={!amount || !selectedFile || isUploading}
              className="w-full"
              size="lg"
            >
              {isUploading ? (
                <>
                  <Clock className="h-4 w-4 mr-2 animate-spin" />
                  Отправка...
                </>
              ) : (
                'Отправить запрос на пополнение'
              )}
            </Button>
          </div>
        </div>

        {/* Instructions */}
        <div className="bg-muted/50 border border-muted rounded-lg p-4">
          <h3 className="font-semibold text-foreground mb-2">Инструкция:</h3>
          <ol className="text-sm text-muted-foreground space-y-1">
            <li>1. Переведите нужную сумму на указанную карту</li>
            <li>2. Сделайте скриншот или фото чека</li>
            <li>3. Загрузите чек и укажите сумму перевода</li>
            <li>4. Дождитесь подтверждения от администратора</li>
          </ol>
        </div>
      </motion.div>
    </div>
  );
};