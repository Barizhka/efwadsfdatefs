import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { useAppStore } from '@/store/appStore';
import WarmupLogs from './WarmupLogs';
import DynamicMetrics from './DynamicMetrics';
import { 
  Activity, 
  Users, 
  BarChart3, 
  Zap, 
  CheckCircle, 
  Clock, 
  TrendingUp,
  Timer
} from 'lucide-react';

const WarmupPage = () => {
  const { purchasedAccounts, sessions, warmupTab, setWarmupTab, isWarmupActive } = useAppStore();

  // Динамические стадии прогрева на основе активности
  const calculateStageProgress = (baseProgress: number) => {
    if (!isWarmupActive || activeAccounts.length === 0) return 0;
    const avgAccountProgress = activeAccounts.length > 0 ? 
      activeAccounts.reduce((sum, acc) => sum + acc.warmupProgress, 0) / activeAccounts.length : 0;
    return Math.round((avgAccountProgress / 100) * baseProgress);
  };

  const warmupStages = [
    {
      name: 'Начальная активность',
      duration: '2 часа',
      progress: calculateStageProgress(85),
      description: 'Базовые операции и регистрация активности'
    },
    {
      name: 'Социальные взаимодействия',
      duration: '6 часов',
      progress: calculateStageProgress(67),
      description: 'Подписки, лайки, комментарии'
    },
    {
      name: 'Контент-генерация',
      duration: '12 часов',
      progress: calculateStageProgress(43),
      description: 'Создание оригинального контента'
    },
    {
      name: 'Продвинутые функции',
      duration: '2 дня',
      progress: calculateStageProgress(12),
      description: 'Сложные операции и API интеграции'
    }
  ];

  const activeAccounts = purchasedAccounts.filter(acc => acc.warmupStarted);

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'active':
        return <Badge className="bg-green-500/20 text-green-400 border-green-500/30">Завершение</Badge>;
      case 'warming':
        return <Badge className="bg-yellow-500/20 text-yellow-400 border-yellow-500/30">В процессе</Badge>;
      default:
        return <Badge variant="secondary">Пауза</Badge>;
    }
  };

  const activeWarmupCount = activeAccounts.filter(acc => acc.warmupProgress < 100).length;
  const completedTodayCount = activeAccounts.filter(acc => acc.warmupProgress === 100).length;
  const avgProgress = activeAccounts.length > 0 ? 
    Math.round(activeAccounts.reduce((sum, acc) => sum + acc.warmupProgress, 0) / activeAccounts.length) : 0;
  
  const stats = [
    {
      title: 'Активных прогревов',
      value: activeWarmupCount.toString(),
      icon: Activity,
      color: 'text-green-400'
    },
    {
      title: 'Завершено сегодня',
      value: completedTodayCount.toString(),
      icon: CheckCircle,
      color: 'text-blue-400'
    },
    {
      title: 'Средняя скорость',
      value: `${avgProgress}%`,
      icon: TrendingUp,
      color: 'text-purple-400'
    },
    {
      title: 'Время до завершения',
      value: activeWarmupCount > 0 ? '2ч 15м' : '—',
      icon: Timer,
      color: 'text-orange-400'
    }
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-white">Прогрев аккаунтов</h1>
          <p className="text-gray-400 mt-1">Мониторинг процесса адаптации AI аккаунтов</p>
        </div>
      </div>

      {/* Tabs */}
      <Tabs defaultValue="monitoring" className="w-full">
        <TabsList className="grid w-fit grid-cols-4 bg-gray-800/50 border-gray-700">
          <TabsTrigger value="monitoring" className="data-[state=active]:bg-primary data-[state=active]:text-white">
            <Activity className="w-4 h-4 mr-2" />
            Мониторинг
          </TabsTrigger>
          <TabsTrigger value="logs" className="data-[state=active]:bg-primary data-[state=active]:text-white">
            <Timer className="w-4 h-4 mr-2" />
            Логи
          </TabsTrigger>
          <TabsTrigger value="accounts" className="data-[state=active]:bg-primary data-[state=active]:text-white">
            <Users className="w-4 h-4 mr-2" />
            Аккаунты
          </TabsTrigger>
          <TabsTrigger value="analytics" className="data-[state=active]:bg-primary data-[state=active]:text-white">
            <BarChart3 className="w-4 h-4 mr-2" />
            Аналитика
          </TabsTrigger>
        </TabsList>

        <TabsContent value="monitoring" className="space-y-6">
          {/* Динамические метрики */}
          <DynamicMetrics 
            isActive={isWarmupActive && activeAccounts.length > 0} 
            accountsCount={activeAccounts.filter(acc => acc.warmupProgress < 100).length}
          />

          {(isWarmupActive && activeAccounts.length > 0) && (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Общий прогресс прогрева */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
              >
                <Card className="bg-gray-800/50 border-gray-700 card-hover">
                  <CardHeader>
                    <CardTitle className="flex items-center text-white">
                      <Zap className="w-5 h-5 mr-2 text-primary" />
                      Стадии прогрева
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    {warmupStages.map((stage, index) => (
                      <div key={index} className="space-y-2">
                        <div className="flex justify-between items-center">
                          <span className="text-white font-medium">{stage.name}</span>
                          <div className="flex items-center space-x-2 text-sm text-gray-400">
                            <Clock className="w-4 h-4" />
                            <span>{stage.duration}</span>
                            <span className="text-primary font-semibold">{stage.progress}%</span>
                          </div>
                        </div>
                        <Progress 
                          value={stage.progress} 
                          className="h-2"
                        />
                      </div>
                    ))}
                  </CardContent>
                </Card>
              </motion.div>

              {/* Активные сессии */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.1 }}
              >
                <Card className="bg-gray-800/50 border-gray-700 card-hover">
                  <CardHeader>
                    <CardTitle className="flex items-center text-white">
                      <Activity className="w-5 h-5 mr-2 text-primary" />
                      Активные аккаунты
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {activeAccounts.slice(0, 4).map((account) => (
                      <div key={account.id} className="flex items-center justify-between p-3 bg-gray-700/30 rounded-lg">
                        <div className="flex items-center space-x-3">
                          <div className="w-8 h-8 bg-primary/20 rounded-full flex items-center justify-center">
                            <span className="text-primary font-semibold text-sm">
                              {account.username.substring(0, 1).toUpperCase()}
                            </span>
                          </div>
                          <div>
                            <p className="text-white font-medium">{account.username}</p>
                            <p className="text-sm text-gray-400">{account.model}</p>
                          </div>
                        </div>
                        <div className="flex items-center space-x-3">
                          {getStatusBadge(account.status)}
                          <div className="w-20">
                            <Progress value={account.warmupProgress} className="h-2" />
                          </div>
                          <span className="text-xs text-gray-400 w-10">{account.warmupProgress}%</span>
                        </div>
                      </div>
                    ))}
                  </CardContent>
                </Card>
              </motion.div>
            </div>
          )}

          {/* Statistics Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {stats.map((stat, index) => (
              <motion.div
                key={stat.title}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.2 + index * 0.1 }}
              >
                <Card className="bg-gray-800/50 border-gray-700 card-hover">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-gray-400">{stat.title}</p>
                        <p className={`text-2xl font-bold ${stat.color}`}>{stat.value}</p>
                      </div>
                      <stat.icon className={`w-8 h-8 ${stat.color}`} />
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="logs" className="space-y-6">
          <WarmupLogs />
        </TabsContent>

        <TabsContent value="accounts" className="space-y-6">
          <Card className="bg-gray-800/50 border-gray-700">
            <CardHeader>
              <CardTitle className="text-white">Управление аккаунтами</CardTitle>
            </CardHeader>
            <CardContent>
              {purchasedAccounts.length === 0 ? (
                <div className="text-center py-8">
                  <p className="text-gray-400 mb-4">У вас нет купленных аккаунтов для прогрева</p>
                  <Button variant="outline" onClick={() => window.location.href = '/accounts'}>
                    Купить аккаунты
                  </Button>
                </div>
              ) : (
                <div className="space-y-4">
                  {purchasedAccounts.map((account) => (
                    <div key={account.id} className="flex items-center justify-between p-4 bg-gray-700/30 rounded-lg">
                      <div className="flex items-center space-x-4">
                        <div className="w-10 h-10 bg-primary/20 rounded-full flex items-center justify-center">
                          <span className="text-primary font-semibold">
                            {account.username.substring(0, 1).toUpperCase()}
                          </span>
                        </div>
                        <div>
                          <p className="text-white font-medium">{account.name}</p>
                          <p className="text-sm text-gray-400">{account.username}</p>
                          <p className="text-xs text-gray-500">{account.model}</p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-4">
                        <div className="text-right">
                          <p className="text-sm text-gray-400">Прогресс</p>
                          <p className="text-white font-semibold">{account.warmupProgress}%</p>
                        </div>
                        <div className="w-20">
                          <Progress value={account.warmupProgress} className="h-2" />
                        </div>
                        <Badge className={account.warmupStarted ? "bg-green-500/20 text-green-400 border-green-500/30" : "bg-gray-500/20 text-gray-400 border-gray-500/30"}>
                          {account.warmupStarted ? "Прогревается" : "Ожидание"}
                        </Badge>
                        <Button size="sm" variant="outline">
                          Управление
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="analytics" className="space-y-6">
          <Card className="bg-gray-800/50 border-gray-700">
            <CardHeader>
              <CardTitle className="text-white">Аналитика прогрева</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <div className="space-y-2">
                  <p className="text-gray-400">Средняя скорость прогрева</p>
                  <p className="text-2xl font-bold text-primary">
                    {!isWarmupActive || activeAccounts.length === 0 ? '0%' : `${avgProgress}%`}
                  </p>
                  <Progress value={!isWarmupActive || activeAccounts.length === 0 ? 0 : avgProgress} className="h-2" />
                </div>
                <div className="space-y-2">
                  <p className="text-gray-400">Успешность</p>
                  <p className="text-2xl font-bold text-green-400">
                    {!isWarmupActive || activeAccounts.length === 0 ? '0%' : '94%'}
                  </p>
                  <Progress value={!isWarmupActive || activeAccounts.length === 0 ? 0 : 94} className="h-2" />
                </div>
                <div className="space-y-2">
                  <p className="text-gray-400">Среднее время</p>
                  <p className="text-2xl font-bold text-orange-400">
                    {!isWarmupActive || activeAccounts.length === 0 ? '0ч' : '18ч'}
                  </p>
                  <Progress value={!isWarmupActive || activeAccounts.length === 0 ? 0 : 75} className="h-2" />
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default WarmupPage;