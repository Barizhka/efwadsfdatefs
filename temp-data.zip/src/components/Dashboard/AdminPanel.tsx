import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useAppStore } from '@/store/appStore';
import { DepositsAdmin } from './Admin/DepositsAdmin';
import { AccountsAdmin } from './Admin/AccountsAdmin';
import { ProxiesAdmin } from './Admin/ProxiesAdmin';
import { DevicesAdmin } from './Admin/DevicesAdmin';
import { WarmupAdmin } from './Admin/WarmupAdmin';
import OrderPreparationAdmin from './Admin/OrderPreparationAdmin';
import { BankCardAdmin } from './Admin/BankCardAdmin';
import BalanceAdmin from './Admin/BalanceAdmin';
import HackerTerminal from './Admin/HackerTerminal';
import SystemMonitor from './Admin/SystemMonitor';
import DataMatrix from './Admin/DataMatrix';
import NetworkVisualizer from './Admin/NetworkVisualizer';
import TrafficEmulationAdmin from './Admin/TrafficEmulationAdmin';
import ContentCreationAdmin from './Admin/ContentCreationAdmin';
import { 
  Shield, 
  CreditCard, 
  Users, 
  Server, 
  Smartphone, 
  Zap,
  AlertTriangle,
  Wallet,
  Activity,
  Database,
  Network,
  Video,
  Radio
} from 'lucide-react';

const AdminPanel = () => {
  const [activeTab, setActiveTab] = useState('deposits');
  
  const tabs = [
    { id: 'deposits', label: 'Депозиты', icon: CreditCard, count: 23 },
    { id: 'balance', label: 'Баланс', icon: Wallet, count: null },
    { id: 'bankcard', label: 'Банковская карта', icon: CreditCard, count: null },
    { id: 'accounts', label: 'Аккаунты в наличии', icon: Users, count: 135 },
    { id: 'proxies', label: 'Прокси', icon: Server, count: 89 },
    { id: 'devices', label: 'Устройства', icon: Smartphone, count: 45 },
    { id: 'traffic', label: 'Эмуляция трафика', icon: Radio, count: 3 },
    { id: 'warmup', label: 'Прогрев', icon: Zap, count: 12 },
    { id: 'preparation', label: 'Подготовка к заказу', icon: Shield, count: 8 },
    { id: 'content', label: 'Content Creation', icon: Video, count: null },
    { id: 'terminal', label: 'Терминал', icon: AlertTriangle, count: null },
    { id: 'monitor', label: 'Системный монитор', icon: Activity, count: null },
    { id: 'matrix', label: 'Матрица данных', icon: Database, count: null },
    { id: 'network', label: 'Сетевая топология', icon: Network, count: null }
  ];

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
      className="space-y-6"
    >
      {/* Header */}
      <div className="flex items-center justify-between">
        <motion.h1 
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.2 }}
          className="text-3xl font-bold bg-gradient-to-r from-red-500 to-orange-400 bg-clip-text text-transparent"
        >
          Администраторская панель
        </motion.h1>
        
        <motion.div 
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.3 }}
          className="flex items-center space-x-3"
        >
          <Badge className="bg-red-500/20 text-red-400 border border-red-500/30">
            <Shield className="w-3 h-3 mr-1" />
            Режим администратора
          </Badge>
          <Badge className="bg-amber-500/20 text-amber-400 border border-amber-500/30">
            <AlertTriangle className="w-3 h-3 mr-1" />
            Конфиденциально
          </Badge>
        </motion.div>
      </div>

      {/* Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <div className="space-y-2">
          {/* First row of tabs */}
          <TabsList className="grid w-full grid-cols-6 bg-muted/20">
            {tabs.slice(0, 6).map((tab) => (
              <TabsTrigger 
                key={tab.id} 
                value={tab.id}
                className="flex items-center space-x-2 data-[state=active]:bg-primary/20 data-[state=active]:text-primary"
              >
                <tab.icon className="w-4 h-4" />
                <span className="hidden sm:inline">{tab.label}</span>
                {tab.count !== null && (
                  <Badge variant="secondary" className="ml-1 text-xs">
                    {tab.count}
                  </Badge>
                )}
              </TabsTrigger>
            ))}
          </TabsList>
          
          {/* Second row of tabs */}
          <TabsList className="grid w-full grid-cols-7 bg-muted/20">
            {tabs.slice(6).map((tab) => (
              <TabsTrigger 
                key={tab.id} 
                value={tab.id}
                className="flex items-center space-x-2 data-[state=active]:bg-primary/20 data-[state=active]:text-primary"
              >
                <tab.icon className="w-4 h-4" />
                <span className="hidden sm:inline">{tab.label}</span>
                {tab.count !== null && (
                  <Badge variant="secondary" className="ml-1 text-xs">
                    {tab.count}
                  </Badge>
                )}
              </TabsTrigger>
            ))}
          </TabsList>
        </div>

        <TabsContent value="deposits" className="mt-6">
          <DepositsAdmin />
        </TabsContent>

        <TabsContent value="balance" className="mt-6">
          <BalanceAdmin />
        </TabsContent>

        <TabsContent value="bankcard" className="mt-6">
          <BankCardAdmin />
        </TabsContent>

        <TabsContent value="accounts" className="mt-6">
          <AccountsAdmin />
        </TabsContent>

        <TabsContent value="proxies" className="mt-6">
          <ProxiesAdmin />
        </TabsContent>

        <TabsContent value="devices" className="mt-6">
          <DevicesAdmin />
        </TabsContent>

        <TabsContent value="traffic" className="mt-6">
          <TrafficEmulationAdmin />
        </TabsContent>

        <TabsContent value="warmup" className="mt-6">
          <WarmupAdmin />
        </TabsContent>

        <TabsContent value="preparation" className="mt-6">
          <OrderPreparationAdmin />
        </TabsContent>

        <TabsContent value="terminal" className="mt-6">
          <HackerTerminal />
        </TabsContent>

        <TabsContent value="monitor" className="mt-6">
          <SystemMonitor />
        </TabsContent>

        <TabsContent value="matrix" className="mt-6">
          <DataMatrix />
        </TabsContent>

        <TabsContent value="content" className="mt-6">
          <ContentCreationAdmin />
        </TabsContent>

        <TabsContent value="network" className="mt-6">
          <NetworkVisualizer />
        </TabsContent>
      </Tabs>
    </motion.div>
  );
};

export default AdminPanel;