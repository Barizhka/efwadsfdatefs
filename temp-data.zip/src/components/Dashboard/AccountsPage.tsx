import React, { useState, useMemo, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Checkbox } from '@/components/ui/checkbox';
import { useAppStore } from '@/store/appStore';
import { TOP_RUSSIAN_CITIES } from '@/data/cities';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { useAuthContext } from '@/providers/AuthProvider';
import { 
  Users, 
  Activity, 
  Zap, 
  MapPin,
  Search,
  Filter,
  Plus,
  CheckCircle,
  ShoppingCart,
  ArrowUpDown,
  ArrowUp,
  ArrowDown,
  Info
} from 'lucide-react';

type SortOrder = 'none' | 'asc' | 'desc';

const AccountsPage = () => {
  const { accounts, selectedAccounts, user, toggleAccountSelection, purchaseSelectedAccounts, loadAccounts } = useAppStore();
  const { user: authUser, isAuthenticated } = useAuthContext();
  const { toast } = useToast();
  const [selectedCity, setSelectedCity] = useState<string>('all');
  const [showReadyOnly, setShowReadyOnly] = useState<boolean>(false);
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [sortOrder, setSortOrder] = useState<SortOrder>('none');

  // Load accounts from Supabase on component mount
  useEffect(() => {
    loadAccounts();
  }, [loadAccounts]);

  const filteredAccounts = useMemo(() => {
    let filtered = accounts.filter(account => {
      const matchesCity = selectedCity === 'all' || 
                         (selectedCity === 'unknown' && account.city === 'Неизвестно') ||
                         account.city === selectedCity;
      const matchesReady = !showReadyOnly || account.emulationStatus === 'Готов к заказу - пассивный прогрев';
      const matchesSearch = account.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           account.username.toLowerCase().includes(searchTerm.toLowerCase());
      return matchesCity && matchesReady && matchesSearch;
    });

    // Применяем сортировку по сплиту
    if (sortOrder !== 'none') {
      filtered.sort((a, b) => {
        const splitA = typeof a.split === 'number' ? a.split : 0;
        const splitB = typeof b.split === 'number' ? b.split : 0;
        return sortOrder === 'asc' ? splitA - splitB : splitB - splitA;
      });
    }

    return filtered;
  }, [accounts, selectedCity, showReadyOnly, searchTerm, sortOrder]);

  const getStatusColor = (status: string) => {
    // Все статусы эмуляции отображаются зеленым цветом
    return 'text-green-400';
  };

  const stats = [
    { label: 'Всего аккаунтов', value: accounts.length, icon: Users, color: 'text-blue-400' },
    { label: 'Готовы к заказу', value: accounts.filter(acc => acc.emulationStatus === 'Готов к заказу - пассивный прогрев').length, icon: CheckCircle, color: 'text-green-400' },
    { label: 'По городам', value: new Set(accounts.map(acc => acc.city)).size, icon: MapPin, color: 'text-cyan-400' },
    { label: 'На прогреве', value: accounts.filter(acc => acc.status === 'warming').length, icon: Zap, color: 'text-yellow-400' }
  ];

  const selectedAccountsData = accounts.filter(account => selectedAccounts.includes(account.id));
  const totalCost = selectedAccountsData.reduce((sum, account) => sum + account.price, 0);

  const handlePurchase = async () => {
    // Check authentication using AuthProvider (supports both Telegram and Supabase)
    if (!isAuthenticated || !authUser) {
      toast({
        title: "Требуется авторизация",
        description: "Для покупки аккаунтов необходимо войти в систему",
        variant: "destructive",
        action: (
          <Button variant="outline" size="sm" onClick={() => window.location.href = '/auth'}>
            Войти
          </Button>
        )
      });
      return;
    }

    if (user.balance < totalCost) {
      toast({
        title: "Недостаточно средств",
        description: `Не хватает ${totalCost - user.balance} RUB для покупки. Текущий баланс: ${user.balance} RUB`,
        variant: "destructive",
        action: (
          <Button variant="outline" size="sm" onClick={() => window.location.href = '/dashboard/deposit'}>
            Пополнить баланс
          </Button>
        )
      });
      return;
    }
    
    try {
      // Use the existing store function which now supports both auth methods
      await purchaseSelectedAccounts();
      toast({
        title: "Покупка успешна",
        description: `Приобретено аккаунтов: ${selectedAccountsData.length} на сумму ${totalCost} RUB`,
        variant: "default"
      });
    } catch (error) {
      console.error('Purchase error:', error);
      const errorMessage = error instanceof Error ? error.message : "Не удалось завершить покупку. Попробуйте снова.";
      
      toast({
        title: "Ошибка покупки",
        description: errorMessage,
        variant: "destructive"
      });
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-white">Управление аккаунтами</h1>
          <p className="text-gray-400 mt-1">Мониторинг и управление AI аккаунтами</p>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat, index) => (
          <motion.div
            key={stat.label}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: index * 0.1 }}
          >
            <Card className="bg-gray-800/50 border-gray-700 hover:bg-gray-800/70 transition-colors">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-400">{stat.label}</p>
                    <p className={`text-2xl font-bold ${stat.color}`}>{stat.value}</p>
                  </div>
                  <stat.icon className={`w-8 h-8 ${stat.color}`} />
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      {/* Filters */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4 p-4 bg-gray-800/30 rounded-lg border border-gray-700">
          <div className="relative flex-1 max-w-sm">
            <Search className="w-4 h-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
            <input
              type="text"
              placeholder="Поиск аккаунтов..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 pr-4 py-2 w-full bg-gray-700 border border-gray-600 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
            />
          </div>
          
          <Select value={selectedCity} onValueChange={setSelectedCity}>
            <SelectTrigger className="w-48 bg-gray-700 border-gray-600 text-white">
              <SelectValue placeholder="Выберите город" />
            </SelectTrigger>
            <SelectContent className="bg-gray-700 border-gray-600 max-h-60 overflow-y-auto">
              <SelectItem value="all" className="text-white hover:bg-gray-600">Все города</SelectItem>
              <SelectItem value="unknown" className="text-white hover:bg-gray-600">Города нет в списке</SelectItem>
              {TOP_RUSSIAN_CITIES.slice(0, 50).map((city) => (
                <SelectItem key={city} value={city} className="text-white hover:bg-gray-600">
                  {city}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          {/* Сортировка по сплиту */}
          <div className="flex items-center space-x-1">
            <span className="text-sm text-gray-400">Сплит:</span>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setSortOrder(sortOrder === 'asc' ? 'none' : 'asc')}
              className={`p-1 ${sortOrder === 'asc' ? 'text-primary' : 'text-gray-400'}`}
            >
              <ArrowUp className="w-4 h-4" />
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setSortOrder(sortOrder === 'desc' ? 'none' : 'desc')}
              className={`p-1 ${sortOrder === 'desc' ? 'text-primary' : 'text-gray-400'}`}
            >
              <ArrowDown className="w-4 h-4" />
            </Button>
          </div>

          <Button
            variant={showReadyOnly ? "default" : "outline"}
            onClick={() => setShowReadyOnly(!showReadyOnly)}
            className={showReadyOnly ? "bg-green-600 hover:bg-green-700" : ""}
          >
            <CheckCircle className="w-4 h-4 mr-2" />
            Готовы к заказу
          </Button>

          <div className="text-sm text-gray-400">
            Показано: {filteredAccounts.length} из {accounts.length}
          </div>
        </div>

        {/* Кнопка покупки */}
        {selectedAccounts.length > 0 && (
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 20 }}
            className="bg-gray-800/50 p-4 rounded-lg border border-gray-700"
          >
            <div className="text-right space-y-2">
              <div className="text-sm text-gray-400">
                Выбрано: {selectedAccounts.length} аккаунтов
              </div>
              <div className="text-lg font-bold text-white">
                Итого: {totalCost.toLocaleString()} RUB
              </div>
              <Button 
                onClick={handlePurchase}
                className="bg-green-600 hover:bg-green-700"
                disabled={totalCost > user.balance}
              >
                <ShoppingCart className="w-4 h-4 mr-2" />
                Купить
              </Button>
            </div>
          </motion.div>
        )}
      </div>

      {/* Информационная плашка для неизвестного ГЕО */}
      {selectedCity === 'unknown' && (
        <Alert className="bg-blue-900/20 border-blue-700">
          <Info className="h-4 w-4" />
          <AlertDescription className="text-blue-200">
            Показанные аккаунты можно догреть на любое ГЕО
          </AlertDescription>
        </Alert>
      )}

      {/* Accounts Grid */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.4 }}
        className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4"
      >
        {filteredAccounts.map((account, index) => {
          const isSelected = selectedAccounts.includes(account.id);
          return (
            <motion.div
              key={account.id}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.3, delay: index * 0.05 }}
            >
              <Card 
                className={`cursor-pointer transition-all duration-300 hover:scale-105 ${
                  isSelected 
                    ? 'bg-primary/20 border-primary ring-2 ring-primary/50' 
                    : 'bg-gray-800/50 border-gray-700 hover:bg-gray-800/70'
                }`}
                onClick={() => toggleAccountSelection(account.id)}
              >
                <CardContent className="p-4">
                  <div className="space-y-3">
                    {/* Header with Checkbox */}
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <Checkbox 
                          checked={isSelected}
                          onChange={() => {}}
                          className="data-[state=checked]:bg-primary data-[state=checked]:border-primary"
                        />
                        <h3 className="text-white font-medium text-sm">{account.name}</h3>
                      </div>
                      {account.emulationStatus === 'Готов к заказу - пассивный прогрев' && (
                        <CheckCircle className="w-4 h-4 text-green-400" />
                      )}
                    </div>

                    {/* Account ID */}
                    <div className="text-left">
                      <p className="text-xs text-gray-400 mb-1">ID:</p>
                      <p className="text-white font-mono text-xs">{account.id}</p>
                    </div>
                    
                    {/* Split Amount */}
                    <div className="text-left">
                      <div className="flex items-center gap-1 mb-1">
                        <img src="/assets/split-logo.png" alt="Split" className="w-4 h-4" />
                        <p className="text-xs text-gray-400">SPLIT:</p>
                      </div>
                      <p className="text-white font-semibold">
                        {typeof account.split === 'number' ? account.split.toLocaleString() : account.split}
                      </p>
                    </div>

                    {/* Price */}
                    <div className="text-left">
                      <p className="text-xs text-gray-400 mb-1">Цена:</p>
                      <p className="text-green-400 font-semibold">{account.price.toLocaleString()} RUB</p>
                    </div>
                    
                    {/* City */}
                    <div className="flex items-center space-x-2">
                      <MapPin className="w-3 h-3 text-gray-400" />
                      <span className="text-xs text-gray-300">{account.city}</span>
                    </div>
                    
                    {/* Emulation Status */}
                    <div>
                      <p className="text-xs text-gray-400 mb-1">Эмуляция:</p>
                      <p className={`text-xs font-medium ${getStatusColor(account.emulationStatus)}`}>
                        {account.emulationStatus}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          );
        })}
      </motion.div>

      {filteredAccounts.length === 0 && (
        <div className="text-center py-12">
          <p className="text-gray-400">Нет аккаунтов, соответствующих выбранным фильтрам</p>
        </div>
      )}
    </div>
  );
};

export default AccountsPage;