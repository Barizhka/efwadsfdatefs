import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { 
  Server,
  Globe,
  Zap,
  AlertCircle,
  Plus,
  Trash2,
  Settings,
  Activity
} from 'lucide-react';

interface Proxy {
  id: string;
  ip: string;
  port: number;
  country: string;
  city: string;
  type: 'HTTP' | 'SOCKS5';
  status: 'active' | 'inactive' | 'error';
  speed: number;
  uptime: number;
  usage: number;
}

const mockProxies: Proxy[] = [
  {
    id: 'px_001',
    ip: '185.234.123.45',
    port: 8080,
    country: 'Россия',
    city: 'Москва',
    type: 'HTTP',
    status: 'active',
    speed: 95,
    uptime: 99.8,
    usage: 67
  },
  {
    id: 'px_002',
    ip: '94.156.78.234',
    port: 1080,
    country: 'Россия',
    city: 'Санкт-Петербург',
    type: 'SOCKS5',
    status: 'active',
    speed: 87,
    uptime: 98.5,
    usage: 23
  },
  {
    id: 'px_003',
    ip: '176.234.156.89',
    port: 3128,
    country: 'Россия',
    city: 'Екатеринбург',
    type: 'HTTP',
    status: 'error',
    speed: 0,
    uptime: 45.2,
    usage: 0
  }
];

export const ProxiesAdmin = () => {
  const [proxies, setProxies] = useState(mockProxies);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'text-green-400 bg-green-400/20';
      case 'inactive': return 'text-yellow-400 bg-yellow-400/20';
      case 'error': return 'text-red-400 bg-red-400/20';
      default: return 'text-gray-400 bg-gray-400/20';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'active': return 'Активен';
      case 'inactive': return 'Неактивен';
      case 'error': return 'Ошибка';
      default: return status;
    }
  };

  const stats = [
    { label: 'Всего прокси', value: proxies.length, icon: Server, color: 'text-blue-400' },
    { label: 'Активные', value: proxies.filter(p => p.status === 'active').length, icon: Zap, color: 'text-green-400' },
    { label: 'С ошибками', value: proxies.filter(p => p.status === 'error').length, icon: AlertCircle, color: 'text-red-400' },
    { label: 'Среднее время отклика', value: '45ms', icon: Activity, color: 'text-primary' }
  ];

  return (
    <div className="space-y-6">
      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat, index) => (
          <motion.div
            key={stat.label}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: index * 0.1 }}
          >
            <Card className="bg-card/80 backdrop-blur-sm border-border/50">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">{stat.label}</p>
                    <p className={`text-2xl font-bold ${stat.color}`}>{stat.value}</p>
                  </div>
                  <stat.icon className={`w-8 h-8 ${stat.color}`} />
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      {/* Proxy Management */}
      <Card className="bg-card/80 backdrop-blur-sm border-border/50">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>Управление прокси</CardTitle>
            <div className="flex items-center space-x-3">
              <Button className="bg-primary hover:bg-primary/90">
                <Plus className="w-4 h-4 mr-2" />
                Добавить прокси
              </Button>
              <Button variant="outline">
                <Settings className="w-4 h-4 mr-2" />
                Настройки
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {proxies.map((proxy) => (
              <motion.div
                key={proxy.id}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.3 }}
              >
                <Card className="bg-card/60 border-border/30 hover:bg-card/80 transition-colors">
                  <CardContent className="p-4">
                    <div className="space-y-3">
                      {/* Header */}
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-2">
                          <Server className="w-4 h-4 text-primary" />
                          <span className="font-mono text-sm">{proxy.ip}:{proxy.port}</span>
                        </div>
                        <Badge className={`${getStatusColor(proxy.status)} text-xs`}>
                          {getStatusText(proxy.status)}
                        </Badge>
                      </div>

                      {/* Location */}
                      <div className="flex items-center space-x-2">
                        <Globe className="w-3 h-3 text-muted-foreground" />
                        <span className="text-sm text-muted-foreground">
                          {proxy.city}, {proxy.country}
                        </span>
                      </div>

                      {/* Type */}
                      <div>
                        <Badge variant="outline" className="text-xs">
                          {proxy.type}
                        </Badge>
                      </div>

                      {/* Metrics */}
                      <div className="space-y-2">
                        <div className="flex justify-between items-center">
                          <span className="text-xs text-muted-foreground">Скорость:</span>
                          <span className="text-xs font-medium">{proxy.speed}%</span>
                        </div>
                        <div className="w-full bg-muted/30 rounded-full h-2">
                          <div 
                            className="bg-primary h-2 rounded-full transition-all duration-300" 
                            style={{ width: `${proxy.speed}%` }}
                          />
                        </div>

                        <div className="flex justify-between items-center">
                          <span className="text-xs text-muted-foreground">Аптайм:</span>
                          <span className="text-xs font-medium">{proxy.uptime}%</span>
                        </div>

                        <div className="flex justify-between items-center">
                          <span className="text-xs text-muted-foreground">Использование:</span>
                          <span className="text-xs font-medium">{proxy.usage}%</span>
                        </div>
                      </div>

                      {/* Actions */}
                      <div className="flex items-center space-x-2 pt-2">
                        <Button size="sm" variant="outline" className="flex-1 h-8">
                          <Settings className="w-3 h-3 mr-1" />
                          Настроить
                        </Button>
                        <Button size="sm" variant="destructive" className="h-8 px-3">
                          <Trash2 className="w-3 h-3" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};