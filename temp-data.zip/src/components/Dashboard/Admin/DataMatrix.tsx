import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { useAppStore } from '@/store/appStore';
import { 
  Database, 
  Globe, 
  MapPin, 
  User, 
  Clock,
  TrendingUp,
  Shield,
  Wifi
} from 'lucide-react';

interface AccountData {
  id: string;
  email: string;
  city: string;
  proxy: string;
  status: 'active' | 'warming' | 'idle' | 'error';
  split: string;
  actions: number;
  lastActivity: string;
  browser: string;
  temperature: number;
}

const DataMatrix = () => {
  const { purchasedAccounts, isWarmupActive } = useAppStore();
  const [accounts, setAccounts] = useState<AccountData[]>([]);
  const [selectedAccount, setSelectedAccount] = useState<AccountData | null>(null);

  const cities = ['Москва', 'СПб', 'Казань', 'Екатеринбург', 'Новосибирск', 'Ростов-на-Дону', 'Самара', 'Уфа', 'Красноярск', 'Пермь'];
  const browsers = ['Chrome', 'Firefox', 'Yandex', 'Edge', 'Safari'];
  const splits = ['50k', '75k', '100k'];

  useEffect(() => {
    const hasActiveWarmup = purchasedAccounts.some(account => account.warmupStarted) || isWarmupActive;
    
    if (!hasActiveWarmup) {
      setAccounts([]);
      setSelectedAccount(null);
      return;
    }

    // Generate account data based on actual purchased accounts with warmup
    const warmupAccounts = purchasedAccounts.filter(account => account.warmupStarted);
    
    if (warmupAccounts.length === 0) {
      setAccounts([]);
      return;
    }

    const initialAccounts = warmupAccounts.map((account, i) => ({
      id: account.id,
      email: `${account.username.substring(0, 4)}***@yandex.ru`,
      city: account.selectedCity || account.city || cities[Math.floor(Math.random() * cities.length)],
      proxy: `${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}:${8000 + Math.floor(Math.random() * 2000)}`,
      status: 'warming' as AccountData['status'],
      split: typeof account.split === 'number' ? `${Math.round(account.split / 1000)}k` : splits[Math.floor(Math.random() * splits.length)],
      actions: Math.max(12, Math.min(99, Math.floor(Math.random() * 100))),
      lastActivity: `${Math.floor(Math.random() * 60)}s`,
      browser: browsers[Math.floor(Math.random() * browsers.length)],
      temperature: Math.max(25, Math.min(65, Math.floor(Math.random() * 40 + 25)))
    }));

    setAccounts(initialAccounts);

    // Update accounts periodically
    const interval = setInterval(() => {
      setAccounts(prev => prev.map(acc => ({
        ...acc,
        actions: acc.actions + Math.floor(Math.random() * 3),
        temperature: Math.max(0, Math.min(100, acc.temperature + (Math.random() - 0.5) * 10)),
        lastActivity: `${Math.floor(Math.random() * 300)}s`,
        status: Math.random() > 0.95 ? 
          (['active', 'warming', 'idle', 'error'][Math.floor(Math.random() * 4)] as AccountData['status']) : 
          acc.status
      })));
    }, 3000);

    return () => clearInterval(interval);
  }, [purchasedAccounts, isWarmupActive]);

  const getStatusColor = (status: AccountData['status']) => {
    switch (status) {
      case 'active': return 'text-green-400 bg-green-400/20';
      case 'warming': return 'text-yellow-400 bg-yellow-400/20';
      case 'idle': return 'text-gray-400 bg-gray-400/20';
      case 'error': return 'text-red-400 bg-red-400/20';
    }
  };

  const getTemperatureColor = (temp: number) => {
    if (temp >= 80) return 'text-red-400';
    if (temp >= 60) return 'text-yellow-400';
    if (temp >= 40) return 'text-green-400';
    return 'text-blue-400';
  };

  const matrixChars = '0123456789ABCDEF';
  const [matrixLines, setMatrixLines] = useState<string[]>([]);

  useEffect(() => {
    const generateMatrixLine = () => {
      return Array.from({ length: 40 }, () => 
        matrixChars[Math.floor(Math.random() * matrixChars.length)]
      ).join('');
    };

    const lines = Array.from({ length: 20 }, generateMatrixLine);
    setMatrixLines(lines);

    const interval = setInterval(() => {
      setMatrixLines(prev => {
        const newLines = [...prev];
        const randomIndex = Math.floor(Math.random() * newLines.length);
        newLines[randomIndex] = generateMatrixLine();
        return newLines;
      });
    }, 500);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="space-y-6">
      {/* Matrix Background */}
      <Card className="bg-black/90 border border-green-500/30 backdrop-blur-sm overflow-hidden relative">
        <div className="absolute inset-0 opacity-10">
          <div className="font-mono text-xs text-green-400 leading-tight p-2">
            <AnimatePresence>
              {matrixLines.map((line, index) => (
                <motion.div
                  key={`${index}-${line}`}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  transition={{ duration: 0.1 }}
                  className="overflow-hidden"
                >
                  {line}
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        </div>
        
        <CardHeader className="relative z-10">
          <CardTitle className="flex items-center space-x-2">
            <Database className="w-5 h-5 text-green-400" />
            <span className="text-green-400 font-mono">DATA_MATRIX_v2.1.7</span>
            <Badge className="bg-green-400/20 text-green-400 border border-green-400/30 font-mono">
              ACTIVE
            </Badge>
          </CardTitle>
        </CardHeader>
        
        <CardContent className="relative z-10">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Account List */}
            <div className="lg:col-span-2">
              <ScrollArea className="h-80">
                <div className="space-y-1 font-mono text-xs">
                  {accounts.slice(0, 20).map((account, index) => (
                    <motion.div
                      key={account.id}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: index * 0.02 }}
                      className={`p-2 rounded border cursor-pointer transition-colors ${
                        selectedAccount?.id === account.id 
                          ? 'bg-green-400/20 border-green-400/50' 
                          : 'bg-background/20 border-border/20 hover:bg-background/30'
                      }`}
                      onClick={() => setSelectedAccount(account)}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-3">
                          <span className="text-green-400">{account.id}</span>
                          <span className="text-muted-foreground">{account.email}</span>
                          <Badge variant="outline" className={getStatusColor(account.status)}>
                            {account.status.toUpperCase()}
                          </Badge>
                        </div>
                        <div className="flex items-center space-x-2">
                          <span className={`${getTemperatureColor(account.temperature)}`}>
                            {account.temperature.toFixed(0)}°
                          </span>
                          <span className="text-cyan-400">{account.actions}</span>
                        </div>
                      </div>
                      <div className="flex items-center space-x-4 mt-1 text-xs text-muted-foreground">
                        <span className="flex items-center space-x-1">
                          <MapPin className="w-3 h-3" />
                          <span>{account.city}</span>
                        </span>
                        <span className="flex items-center space-x-1">
                          <Globe className="w-3 h-3" />
                          <span>{account.browser}</span>
                        </span>
                        <span className="flex items-center space-x-1">
                          <TrendingUp className="w-3 h-3" />
                          <span>{account.split}</span>
                        </span>
                        <span className="flex items-center space-x-1">
                          <Clock className="w-3 h-3" />
                          <span>{account.lastActivity}</span>
                        </span>
                      </div>
                    </motion.div>
                  ))}
                </div>
              </ScrollArea>
            </div>

            {/* Account Details */}
            <div className="space-y-4">
              {selectedAccount ? (
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="space-y-4"
                >
                  <div className="p-4 rounded-lg bg-background/30 border border-border/30">
                    <h3 className="text-sm font-medium text-green-400 mb-3 font-mono">
                      ACCOUNT_DETAILS
                    </h3>
                    <div className="space-y-2 text-xs">
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">ID:</span>
                        <span className="text-green-400 font-mono">{selectedAccount.id}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Email:</span>
                        <span className="text-cyan-400">{selectedAccount.email}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Location:</span>
                        <span className="text-yellow-400">{selectedAccount.city}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Proxy:</span>
                        <span className="text-purple-400 font-mono">{selectedAccount.proxy}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Browser:</span>
                        <span className="text-blue-400">{selectedAccount.browser}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Split:</span>
                        <span className="text-orange-400">{selectedAccount.split}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Actions:</span>
                        <span className="text-cyan-400">{selectedAccount.actions}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Temperature:</span>
                        <span className={getTemperatureColor(selectedAccount.temperature)}>
                          {selectedAccount.temperature.toFixed(1)}°C
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Last Activity:</span>
                        <span className="text-green-400">{selectedAccount.lastActivity}</span>
                      </div>
                    </div>
                  </div>

                  <div className="p-4 rounded-lg bg-background/30 border border-border/30">
                    <h3 className="text-sm font-medium text-green-400 mb-3 font-mono">
                      SYSTEM_STATUS
                    </h3>
                    <div className="space-y-2">
                      <div className="flex items-center space-x-2">
                        <Wifi className="w-4 h-4 text-green-400" />
                        <span className="text-xs text-green-400">CONNECTION_STABLE</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Shield className="w-4 h-4 text-green-400" />
                        <span className="text-xs text-green-400">SECURITY_ACTIVE</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <User className="w-4 h-4 text-green-400" />
                        <span className="text-xs text-green-400">PROFILE_VALIDATED</span>
                      </div>
                    </div>
                  </div>
                </motion.div>
              ) : (
                <div className="p-8 text-center text-muted-foreground">
                  <Database className="w-8 h-8 mx-auto mb-2 opacity-50" />
                  <p className="text-sm font-mono">SELECT_ACCOUNT_FOR_DETAILS</p>
                </div>
              )}
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default DataMatrix;