import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { useAppStore } from '@/store/appStore';
import { TOP_RUSSIAN_CITIES } from '@/data/cities';
import { 
  Plus,
  Trash2,
  Users,
  MapPin,
  Settings,
  CheckCircle,
  AlertTriangle,
  Pause
} from 'lucide-react';

export const AccountsAdmin = () => {
  const { accounts, addAccount, removeAccount } = useAppStore();
  const [selectedAccounts, setSelectedAccounts] = useState<string[]>([]);
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  
  // New account form state
  const [newAccount, setNewAccount] = useState({
    geoCity: '',
    status: '',
    limit: '',
    type: '',
    emulationStatus: ''
  });

  const handleSelectAccount = (accountId: string) => {
    setSelectedAccounts(prev => 
      prev.includes(accountId) 
        ? prev.filter(id => id !== accountId)
        : [...prev, accountId]
    );
  };

  const handleSelectAll = () => {
    setSelectedAccounts(
      selectedAccounts.length === accounts.length 
        ? [] 
        : accounts.map(acc => acc.id)
    );
  };

  const handleDeleteSelected = () => {
    selectedAccounts.forEach(id => removeAccount(id));
    setSelectedAccounts([]);
  };

  const handleCreateAccount = () => {
    if (!newAccount.geoCity || !newAccount.status || !newAccount.limit || !newAccount.type) {
      return;
    }

    const splitValue = parseInt(newAccount.limit);
    const getPrice = (split: number) => {
      if (split >= 140000) return Math.floor(Math.random() * 270) + 1150; // Premium: 1150-1420
      if (split >= 70000) return Math.floor(Math.random() * 100) + 500;   // Standard: 500-600
      return Math.floor(Math.random() * 60) + 240;                       // Basic: 240-300
    };

    const names = ["Алексей Иванов", "Мария Петрова", "Дмитрий Смирнов", "Елена Кузнецова", "Андрей Козлов", "Ольга Новикова"];
    
    addAccount({
      name: names[Math.floor(Math.random() * names.length)],
      username: `user_${Date.now()}`,
      status: newAccount.status as any,
      type: newAccount.type,
      proxy: `${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}:${3000 + Math.floor(Math.random() * 5000)}`,
      model: splitValue >= 70000 ? "GPT-4o" : "GPT-4o-mini",
      progress: Math.floor(Math.random() * 100),
      lastActivity: `${Math.floor(Math.random() * 60)} мин назад`,
      temperature: splitValue >= 70000 ? 0.7 + Math.random() * 0.2 : 0.6,
      maxTokens: splitValue >= 70000 ? 4096 : 2048,
      antiDetection: splitValue >= 70000,
      twoFA: splitValue >= 70000,
      operator: splitValue >= 70000 ? "OpenAI" : "OpenAI",
      balance: Math.floor(Math.random() * 100),
      tasks: Math.floor(Math.random() * 300),
      city: newAccount.geoCity,
      split: splitValue,
      emulationStatus: newAccount.emulationStatus,
      readyForOrders: newAccount.emulationStatus === "Готов к заказу - пассивный прогрев",
      price: getPrice(splitValue),
      selected: false,
      purchased: false
    });

    setNewAccount({
      geoCity: '',
      status: '',
      limit: '',
      type: '',
      emulationStatus: ''
    });
    setIsCreateDialogOpen(false);
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'active': return <CheckCircle className="w-4 h-4 text-green-400" />;
      case 'warming': return <Settings className="w-4 h-4 text-yellow-400" />;
      case 'paused': return <Pause className="w-4 h-4 text-blue-400" />;
      case 'banned': return <AlertTriangle className="w-4 h-4 text-red-400" />;
      default: return <CheckCircle className="w-4 h-4 text-gray-400" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'text-green-400 bg-green-400/20';
      case 'warming': return 'text-yellow-400 bg-yellow-400/20';
      case 'paused': return 'text-blue-400 bg-blue-400/20';
      case 'banned': return 'text-red-400 bg-red-400/20';
      default: return 'text-gray-400 bg-gray-400/20';
    }
  };

  const stats = [
    { label: 'Всего аккаунтов', value: accounts.length, icon: Users, color: 'text-blue-400' },
    { label: 'Готовы к заказу', value: accounts.filter(acc => acc.readyForOrders).length, icon: CheckCircle, color: 'text-green-400' },
    { label: 'На прогреве', value: accounts.filter(acc => acc.status === 'warming').length, icon: Settings, color: 'text-yellow-400' },
    { label: 'Выбрано', value: selectedAccounts.length, icon: CheckCircle, color: 'text-primary' }
  ];

  return (
    <div className="space-y-6">
      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat, index) => (
          <motion.div
            key={stat.label}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: index * 0.1 }}
          >
            <Card className="bg-card/80 backdrop-blur-sm border-border/50">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">{stat.label}</p>
                    <p className={`text-2xl font-bold ${stat.color}`}>{stat.value}</p>
                  </div>
                  <stat.icon className={`w-8 h-8 ${stat.color}`} />
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      {/* Controls */}
      <Card className="bg-card/80 backdrop-blur-sm border-border/50">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>Управление аккаунтами</CardTitle>
            <div className="flex items-center space-x-3">
              <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
                <DialogTrigger asChild>
                  <Button className="bg-primary hover:bg-primary/90">
                    <Plus className="w-4 h-4 mr-2" />
                    Создать аккаунт
                  </Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-md">
                  <DialogHeader>
                    <DialogTitle>Создание нового аккаунта</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4 py-4">
                    <div>
                      <label className="text-sm font-medium mb-2 block">ГЕО (город)</label>
                      <Select value={newAccount.geoCity} onValueChange={(value) => setNewAccount(prev => ({ ...prev, geoCity: value }))}>
                        <SelectTrigger>
                          <SelectValue placeholder="Выберите город" />
                        </SelectTrigger>
                        <SelectContent className="max-h-60">
                          {TOP_RUSSIAN_CITIES.slice(0, 50).map((city) => (
                            <SelectItem key={city} value={city}>{city}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <label className="text-sm font-medium mb-2 block">Статус</label>
                      <Select value={newAccount.status} onValueChange={(value) => setNewAccount(prev => ({ ...prev, status: value }))}>
                        <SelectTrigger>
                          <SelectValue placeholder="Выберите статус" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="active">Активен</SelectItem>
                          <SelectItem value="warming">На прогреве</SelectItem>
                          <SelectItem value="paused">Приостановлен</SelectItem>
                          <SelectItem value="banned">Заблокирован</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <label className="text-sm font-medium mb-2 block">Лимит</label>
                      <Select value={newAccount.limit} onValueChange={(value) => setNewAccount(prev => ({ ...prev, limit: value }))}>
                        <SelectTrigger>
                          <SelectValue placeholder="Выберите лимит" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="50000">50 000 (Basic)</SelectItem>
                          <SelectItem value="75000">75 000 (Standard)</SelectItem>
                          <SelectItem value="100000">100 000 (Standard)</SelectItem>
                          <SelectItem value="120000">120 000 (Premium)</SelectItem>
                          <SelectItem value="150000">150 000 (Premium)</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <label className="text-sm font-medium mb-2 block">Тип</label>
                      <Select value={newAccount.type} onValueChange={(value) => setNewAccount(prev => ({ ...prev, type: value }))}>
                        <SelectTrigger>
                          <SelectValue placeholder="Выберите тип" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="Basic">Basic</SelectItem>
                          <SelectItem value="Standard">Standard</SelectItem>
                          <SelectItem value="Premium">Premium</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <label className="text-sm font-medium mb-2 block">Статус эмуляции</label>
                      <Select value={newAccount.emulationStatus} onValueChange={(value) => setNewAccount(prev => ({ ...prev, emulationStatus: value }))}>
                        <SelectTrigger>
                          <SelectValue placeholder="Выберите статус эмуляции" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="Готов к заказу - пассивный прогрев">Готов к заказу - пассивный прогрев</SelectItem>
                          <SelectItem value="Прогрев аккаунта на ГЕО">Прогрев аккаунта на ГЕО</SelectItem>
                          <SelectItem value="Предварительный прогрев">Предварительный прогрев</SelectItem>
                          <SelectItem value="Техническое обслуживание">Техническое обслуживание</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <Button 
                      onClick={handleCreateAccount} 
                      className="w-full"
                      disabled={!newAccount.geoCity || !newAccount.status || !newAccount.limit || !newAccount.type || !newAccount.emulationStatus}
                    >
                      Создать аккаунт
                    </Button>
                  </div>
                </DialogContent>
              </Dialog>

              {selectedAccounts.length > 0 && (
                <Button variant="destructive" onClick={handleDeleteSelected}>
                  <Trash2 className="w-4 h-4 mr-2" />
                  Удалить выбранные ({selectedAccounts.length})
                </Button>
              )}
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="mb-4">
            <div className="flex items-center space-x-2">
              <Checkbox 
                checked={selectedAccounts.length === accounts.length && accounts.length > 0}
                onCheckedChange={handleSelectAll}
              />
              <span className="text-sm font-medium">Выбрать все</span>
            </div>
          </div>

          {/* Accounts Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {accounts.map((account) => (
              <motion.div
                key={account.id}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.3 }}
              >
                <Card 
                  className={`cursor-pointer transition-all duration-300 hover:scale-105 ${
                    selectedAccounts.includes(account.id)
                      ? 'bg-primary/20 border-primary ring-2 ring-primary/50' 
                      : 'bg-card/80 border-border/50 hover:bg-card/90'
                  }`}
                  onClick={() => handleSelectAccount(account.id)}
                >
                  <CardContent className="p-4">
                    <div className="space-y-3">
                      {/* Header with Checkbox */}
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-2">
                          <Checkbox 
                            checked={selectedAccounts.includes(account.id)}
                            onChange={() => {}}
                          />
                          <h3 className="text-sm font-medium truncate">{account.name}</h3>
                        </div>
                        {getStatusIcon(account.status)}
                      </div>

                      {/* Account details */}
                      <div className="space-y-2">
                        <div>
                          <p className="text-xs text-muted-foreground">ID:</p>
                          <p className="text-xs font-mono">{account.id}</p>
                        </div>
                        
                        <div>
                          <div className="flex items-center gap-1">
                            <img src="/assets/split-logo.png" alt="Split" className="w-4 h-4" />
                            <p className="text-xs text-muted-foreground">SPLIT:</p>
                          </div>
                          <p className="text-sm font-semibold">
                            {typeof account.split === 'number' ? account.split.toLocaleString() : account.split}
                          </p>
                        </div>

                        <div>
                          <p className="text-xs text-muted-foreground">Цена:</p>
                          <p className="text-sm font-semibold text-primary">{account.price.toLocaleString()} ₽</p>
                        </div>
                        
                        <div className="flex items-center space-x-1">
                          <MapPin className="w-3 h-3 text-muted-foreground" />
                          <span className="text-xs">{account.city}</span>
                        </div>

                        <div>
                          <Badge className={`${getStatusColor(account.status)} text-xs`}>
                            {account.status === 'active' ? 'Активен' :
                             account.status === 'warming' ? 'Прогрев' :
                             account.status === 'paused' ? 'Пауза' :
                             account.status === 'banned' ? 'Бан' : account.status}
                          </Badge>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};