import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import { useAppStore } from '@/store/appStore';
import { 
  DollarSign, 
  Plus, 
  Minus, 
  RefreshCw,
  Wallet,
  TrendingUp,
  AlertCircle
} from 'lucide-react';

const BalanceAdmin = () => {
  const { user, updateUser } = useAppStore();
  const { toast } = useToast();
  const [amount, setAmount] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleAddBalance = async () => {
    const addAmount = parseFloat(amount);
    if (!addAmount || addAmount <= 0) {
      toast({
        title: "Ошибка",
        description: "Введите корректную сумму",
        variant: "destructive"
      });
      return;
    }

    setIsLoading(true);
    try {
      const newBalance = user.balance + addAmount;
      updateUser({ balance: newBalance });
      
      toast({
        title: "Баланс пополнен",
        description: `Добавлено ${addAmount.toLocaleString()} ₽. Новый баланс: ${newBalance.toLocaleString()} ₽`,
        className: "bg-green-500/10 border-green-500/20 text-green-400"
      });
      
      setAmount('');
    } catch (error) {
      toast({
        title: "Ошибка",
        description: "Не удалось пополнить баланс",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleSubtractBalance = async () => {
    const subtractAmount = parseFloat(amount);
    if (!subtractAmount || subtractAmount <= 0) {
      toast({
        title: "Ошибка",
        description: "Введите корректную сумму",
        variant: "destructive"
      });
      return;
    }

    if (subtractAmount > user.balance) {
      toast({
        title: "Ошибка",
        description: "Недостаточно средств для списания",
        variant: "destructive"
      });
      return;
    }

    setIsLoading(true);
    try {
      const newBalance = user.balance - subtractAmount;
      updateUser({ balance: newBalance });
      
      toast({
        title: "Баланс списан",
        description: `Списано ${subtractAmount.toLocaleString()} ₽. Новый баланс: ${newBalance.toLocaleString()} ₽`,
        className: "bg-orange-500/10 border-orange-500/20 text-orange-400"
      });
      
      setAmount('');
    } catch (error) {
      toast({
        title: "Ошибка",
        description: "Не удалось списать баланс",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleSetBalance = async () => {
    const newAmount = parseFloat(amount);
    if (!newAmount || newAmount < 0) {
      toast({
        title: "Ошибка",
        description: "Введите корректную сумму",
        variant: "destructive"
      });
      return;
    }

    setIsLoading(true);
    try {
      updateUser({ balance: newAmount });
      
      toast({
        title: "Баланс установлен",
        description: `Баланс установлен на ${newAmount.toLocaleString()} ₽`,
        className: "bg-blue-500/10 border-blue-500/20 text-blue-400"
      });
      
      setAmount('');
    } catch (error) {
      toast({
        title: "Ошибка",
        description: "Не удалось установить баланс",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  const quickAmounts = [1000, 5000, 10000, 50000, 100000, 500000];

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="space-y-6"
    >
      {/* Current Balance Card */}
      <Card className="bg-gradient-to-br from-green-500/10 to-emerald-500/5 border-green-500/20">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium text-muted-foreground">
            Текущий баланс администратора
          </CardTitle>
          <Wallet className="h-4 w-4 text-green-500" />
        </CardHeader>
        <CardContent>
          <div className="flex items-center space-x-2">
            <span className="text-3xl font-bold text-green-400">
              {user.balance.toLocaleString()} ₽
            </span>
            <Badge className="bg-green-500/20 text-green-400 border-green-500/30">
              <TrendingUp className="w-3 h-3 mr-1" />
              Админ
            </Badge>
          </div>
        </CardContent>
      </Card>

      {/* Balance Management */}
      <Card className="bg-muted/20 border-muted/30">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <DollarSign className="w-5 h-5 text-primary" />
            <span>Управление балансом</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Amount Input */}
          <div className="space-y-2">
            <Label htmlFor="amount">Сумма (₽)</Label>
            <Input
              id="amount"
              type="number"
              placeholder="Введите сумму..."
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              className="text-lg"
            />
          </div>

          {/* Quick Amount Buttons */}
          <div className="space-y-2">
            <Label>Быстрый выбор суммы</Label>
            <div className="grid grid-cols-3 gap-2">
              {quickAmounts.map((quickAmount) => (
                <Button
                  key={quickAmount}
                  variant="outline"
                  size="sm"
                  onClick={() => setAmount(quickAmount.toString())}
                  className="hover:bg-primary/10"
                >
                  {quickAmount.toLocaleString()} ₽
                </Button>
              ))}
            </div>
          </div>

          {/* Action Buttons */}
          <div className="grid grid-cols-3 gap-3">
            <Button
              onClick={handleAddBalance}
              disabled={isLoading || !amount}
              className="bg-green-600 hover:bg-green-700 text-white"
            >
              {isLoading ? (
                <RefreshCw className="w-4 h-4 animate-spin mr-2" />
              ) : (
                <Plus className="w-4 h-4 mr-2" />
              )}
              Добавить
            </Button>

            <Button
              onClick={handleSubtractBalance}
              disabled={isLoading || !amount}
              className="bg-orange-600 hover:bg-orange-700 text-white"
            >
              {isLoading ? (
                <RefreshCw className="w-4 h-4 animate-spin mr-2" />
              ) : (
                <Minus className="w-4 h-4 mr-2" />
              )}
              Списать
            </Button>

            <Button
              onClick={handleSetBalance}
              disabled={isLoading || !amount}
              className="bg-blue-600 hover:bg-blue-700 text-white"
            >
              {isLoading ? (
                <RefreshCw className="w-4 h-4 animate-spin mr-2" />
              ) : (
                <RefreshCw className="w-4 h-4 mr-2" />
              )}
              Установить
            </Button>
          </div>

          {/* Warning */}
          <div className="flex items-start space-x-2 p-3 rounded-lg bg-amber-500/10 border border-amber-500/20">
            <AlertCircle className="w-5 h-5 text-amber-400 mt-0.5 flex-shrink-0" />
            <div className="text-sm text-amber-400">
              <p className="font-medium">Внимание!</p>
              <p className="text-amber-400/80">
                Изменения баланса сохраняются автоматически и применяются немедленно.
                Будьте осторожны при использовании этих функций.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default BalanceAdmin;