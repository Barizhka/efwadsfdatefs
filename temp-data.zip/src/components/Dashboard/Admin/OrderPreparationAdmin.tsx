import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { 
  Shield, 
  Activity, 
  CheckCircle,
  AlertTriangle,
  Zap,
  Bot,
  ShoppingCart,
  Package,
  Smartphone,
  CreditCard,
  Music,
  Gift,
  RefreshCw,
  Play,
  Pause,
  Settings,
  TrendingUp,
  DollarSign,
  Server,
  Wifi,
  Database
} from 'lucide-react';

const OrderPreparationAdmin = () => {
  const [farmStatus, setFarmStatus] = useState('active');
  const [selectedProcess, setSelectedProcess] = useState('yandex-plus');
  
  const processStages = [
    {
      id: 'yandex-plus',
      name: 'Яндекс Плюс',
      description: 'Бесплатное оформление подписки',
      icon: Shield,
      status: 'active',
      progress: 85,
      accounts: 42,
      success_rate: 96
    },
    {
      id: 'scooters',
      name: 'Самокаты',
      description: 'Подписка через обход за копейки',
      icon: Smartphone,
      status: 'active',
      progress: 73,
      accounts: 38,
      success_rate: 94
    },
    {
      id: 'music',
      name: 'Яндекс.Музыка',
      description: 'Копеечные донаты',
      icon: Music,
      status: 'active',
      progress: 91,
      accounts: 45,
      success_rate: 98
    },
    {
      id: 'digital-goods',
      name: 'Цифровые товары',
      description: 'Покупка и подготовка к перепродаже',
      icon: Gift,
      status: 'active',
      progress: 67,
      accounts: 28,
      success_rate: 89
    },
    {
      id: 'fanpe',
      name: 'Fanpe',
      description: 'Перепродажа на площадке',
      icon: Package,
      status: 'waiting',
      progress: 12,
      accounts: 8,
      success_rate: 92
    },
    {
      id: 'pvz-orders',
      name: 'ПВЗ заказы',
      description: 'Дорогие покупки в ожидании',
      icon: ShoppingCart,
      status: 'pending',
      progress: 34,
      accounts: 15,
      success_rate: 88
    }
  ];

  const farmMetrics = {
    total_accounts: 156,
    active_processes: 6,
    success_rate: 94.2,
    daily_revenue: 47280,
    profit_margin: 73.5,
    automation_level: 98
  };

  const systemLogs = [
    { time: '14:23:42', level: 'success', message: 'Аккаунт user_4891 успешно оформил Яндекс Плюс' },
    { time: '14:22:15', level: 'info', message: 'Запущен процесс прогрева для 12 новых аккаунтов' },
    { time: '14:21:03', level: 'warning', message: 'Превышен лимит запросов для прокси 192.168.1.45' },
    { time: '14:19:58', level: 'success', message: 'Завершена перепродажа цифрового товара на Fanpe' },
    { time: '14:18:22', level: 'error', message: 'Ошибка верификации аккаунта user_7234' },
    { time: '14:17:11', level: 'info', message: 'Автоматический возврат ПВЗ заказа #45782' }
  ];

  const getStatusColor = (status) => {
    switch (status) {
      case 'active': return 'bg-green-500/20 text-green-400 border-green-500/30';
      case 'waiting': return 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30';
      case 'pending': return 'bg-blue-500/20 text-blue-400 border-blue-500/30';
      case 'error': return 'bg-red-500/20 text-red-400 border-red-500/30';
      default: return 'bg-gray-500/20 text-gray-400 border-gray-500/30';
    }
  };

  const getLogColor = (level) => {
    switch (level) {
      case 'success': return 'text-green-400';
      case 'warning': return 'text-yellow-400';
      case 'error': return 'text-red-400';
      default: return 'text-blue-400';
    }
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
      className="space-y-6"
    >
      {/* Header */}
      <div className="flex items-center justify-between">
        <motion.h2 
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.2 }}
          className="text-2xl font-bold bg-gradient-to-r from-green-500 to-blue-400 bg-clip-text text-transparent"
        >
          Управление фермой
        </motion.h2>
        
        <motion.div 
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.3 }}
          className="flex items-center space-x-3"
        >
          <Badge className="bg-green-500/20 text-green-400 border border-green-500/30">
            <Bot className="w-3 h-3 mr-1" />
            Автоматизация {farmMetrics.automation_level}%
          </Badge>
          <Button size="sm" className="bg-blue-600 hover:bg-blue-700">
            <Settings className="w-4 h-4 mr-2" />
            Настройки
          </Button>
        </motion.div>
      </div>

      {/* Farm Overview */}
      <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-6 gap-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
        >
          <Card className="bg-card/50 border-primary/30">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs text-muted-foreground">Аккаунты</p>
                  <p className="text-xl font-bold text-primary">{farmMetrics.total_accounts}</p>
                </div>
                <Server className="w-6 h-6 text-primary" />
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
        >
          <Card className="bg-card/50 border-green-500/30">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs text-muted-foreground">Процессы</p>
                  <p className="text-xl font-bold text-green-400">{farmMetrics.active_processes}</p>
                </div>
                <Activity className="w-6 h-6 text-green-400" />
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
        >
          <Card className="bg-card/50 border-blue-500/30">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs text-muted-foreground">Успешность</p>
                  <p className="text-xl font-bold text-blue-400">{farmMetrics.success_rate}%</p>
                </div>
                <TrendingUp className="w-6 h-6 text-blue-400" />
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.7 }}
        >
          <Card className="bg-card/50 border-yellow-500/30">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs text-muted-foreground">Доход/день</p>
                  <p className="text-xl font-bold text-yellow-400">₽{farmMetrics.daily_revenue.toLocaleString()}</p>
                </div>
                <DollarSign className="w-6 h-6 text-yellow-400" />
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.8 }}
        >
          <Card className="bg-card/50 border-purple-500/30">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs text-muted-foreground">Маржа</p>
                  <p className="text-xl font-bold text-purple-400">{farmMetrics.profit_margin}%</p>
                </div>
                <TrendingUp className="w-6 h-6 text-purple-400" />
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.9 }}
        >
          <Card className="bg-card/50 border-orange-500/30">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs text-muted-foreground">Статус</p>
                  <p className="text-sm font-bold text-orange-400">АКТИВНА</p>
                </div>
                <Wifi className="w-6 h-6 text-orange-400" />
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Process Management */}
        <Card className="bg-card/50 border-muted/50">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2 text-lg">
              <Zap className="w-5 h-5" />
              <span>Процессы фермы</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {processStages.map((process) => (
                <motion.div
                  key={process.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  className="p-4 rounded-lg bg-muted/20 border border-muted/30 hover:border-primary/30 transition-colors cursor-pointer"
                  onClick={() => setSelectedProcess(process.id)}
                >
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center space-x-3">
                      <process.icon className="w-5 h-5 text-primary" />
                      <div>
                        <h4 className="font-medium">{process.name}</h4>
                        <p className="text-xs text-muted-foreground">{process.description}</p>
                      </div>
                    </div>
                    <Badge className={getStatusColor(process.status)}>
                      {process.status === 'active' && 'Активен'}
                      {process.status === 'waiting' && 'Ожидание'}
                      {process.status === 'pending' && 'В очереди'}
                    </Badge>
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <span>Прогресс</span>
                      <span>{process.progress}%</span>
                    </div>
                    <Progress value={process.progress} className="h-2" />
                    
                    <div className="flex items-center justify-between text-xs text-muted-foreground">
                      <span>Аккаунты: {process.accounts}</span>
                      <span>Успех: {process.success_rate}%</span>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* System Logs */}
        <Card className="bg-card/50 border-muted/50">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2 text-lg">
              <Database className="w-5 h-5" />
              <span>Системные логи</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2 font-mono text-sm">
              {systemLogs.map((log, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className="flex items-start space-x-3 p-2 rounded bg-muted/10"
                >
                  <span className="text-muted-foreground text-xs">{log.time}</span>
                  <span className={`text-xs ${getLogColor(log.level)}`}>
                    [{log.level.toUpperCase()}]
                  </span>
                  <span className="text-xs flex-1">{log.message}</span>
                </motion.div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Control Panel */}
      <Card className="bg-card/50 border-muted/50">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2 text-lg">
            <Shield className="w-5 h-5" />
            <span>Панель управления</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <Button className="bg-green-600 hover:bg-green-700">
              <Play className="w-4 h-4 mr-2" />
              Запустить все
            </Button>
            <Button variant="outline" className="border-yellow-500/30 text-yellow-400 hover:bg-yellow-500/10">
              <Pause className="w-4 h-4 mr-2" />
              Приостановить
            </Button>
            <Button variant="outline" className="border-blue-500/30 text-blue-400 hover:bg-blue-500/10">
              <RefreshCw className="w-4 h-4 mr-2" />
              Перезапуск
            </Button>
            <Button variant="outline" className="border-red-500/30 text-red-400 hover:bg-red-500/10">
              <AlertTriangle className="w-4 h-4 mr-2" />
              Экстренная остановка
            </Button>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default OrderPreparationAdmin;