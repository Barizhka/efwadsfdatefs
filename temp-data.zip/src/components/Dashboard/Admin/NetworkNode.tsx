import React from 'react';
import { motion } from 'framer-motion';
import { 
  Server, 
  Shield,
  Eye,
  Globe
} from 'lucide-react';

interface NetworkNode {
  id: string;
  type: 'server' | 'proxy' | 'account' | 'service';
  label: string;
  x: number;
  y: number;
  status: 'active' | 'warning' | 'error';
  connections: string[];
}

interface NetworkNodeProps {
  node: NetworkNode;
  index: number;
}

const NetworkNode: React.FC<NetworkNodeProps> = ({ node, index }) => {
  const getNodeIcon = (type: NetworkNode['type']) => {
    switch (type) {
      case 'server': return Server;
      case 'proxy': return Shield;
      case 'account': return Eye;
      case 'service': return Globe;
    }
  };

  const getStatusConfig = (status: string) => {
    switch (status) {
      case 'active':
        return {
          border: 'border-primary/60',
          bg: 'bg-primary/5',
          text: 'text-primary',
          indicator: 'bg-primary'
        };
      case 'warning':
        return {
          border: 'border-warning/60',
          bg: 'bg-warning/5',
          text: 'text-warning',
          indicator: 'bg-warning'
        };
      case 'error':
        return {
          border: 'border-destructive/60',
          bg: 'bg-destructive/5',
          text: 'text-destructive',
          indicator: 'bg-destructive'
        };
      default:
        return {
          border: 'border-muted-foreground/30',
          bg: 'bg-muted/20',
          text: 'text-muted-foreground',
          indicator: 'bg-muted-foreground'
        };
    }
  };

  const getNodeSize = (type: NetworkNode['type']) => {
    switch (type) {
      case 'server': return 'w-12 h-12';
      case 'proxy': return 'w-10 h-10';
      case 'account': return 'w-8 h-8';
      case 'service': return 'w-6 h-6';
    }
  };

  const IconComponent = getNodeIcon(node.type);
  const config = getStatusConfig(node.status);
  const size = getNodeSize(node.type);

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ 
        delay: index * 0.05,
        duration: 0.3,
        ease: "easeOut"
      }}
      className="absolute transform -translate-x-1/2 -translate-y-1/2 cursor-pointer group"
      style={{ left: `${node.x}%`, top: `${node.y}%` }}
      whileHover={{ scale: 1.1 }}
      whileTap={{ scale: 0.95 }}
    >
      {/* Node container */}
      <div className={`
        relative ${size} rounded-lg border backdrop-blur-sm transition-all duration-200
        ${config.border} ${config.bg}
        hover:border-opacity-80 hover:bg-opacity-80
      `}>
        {/* Status indicator */}
        {node.status === 'active' && (
          <motion.div 
            className={`absolute -top-1 -right-1 w-3 h-3 rounded-full ${config.indicator}`}
            animate={{ 
              scale: [1, 1.2, 1],
              opacity: [0.8, 1, 0.8]
            }}
            transition={{
              duration: 2,
              repeat: Infinity,
              ease: "easeInOut"
            }}
          />
        )}
        
        {/* Icon */}
        <div className="absolute inset-0 flex items-center justify-center">
          <IconComponent 
            className={`w-4 h-4 transition-colors duration-200 ${config.text}`} 
          />
        </div>
      </div>
      
      {/* Label */}
      <div className="absolute top-full left-1/2 transform -translate-x-1/2 mt-2 whitespace-nowrap">
        <span className={`
          text-xs font-mono tracking-wide transition-colors duration-200
          ${config.text} group-hover:opacity-100 opacity-70
        `}>
          {node.label}
        </span>
      </div>
    </motion.div>
  );
};

export default NetworkNode;