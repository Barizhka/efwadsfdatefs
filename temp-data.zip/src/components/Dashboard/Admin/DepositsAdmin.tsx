import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Input } from '@/components/ui/input';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { 
  Search,
  Filter,
  CheckCircle,
  XCircle,
  Clock,
  TrendingUp,
  CreditCard,
  User,
  Calendar,
  FileImage,
  Eye
} from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

interface DepositRequest {
  id: string;
  user_id: string;
  amount: number;
  status: string;
  payment_method: string;
  receipt_image_url: string | null;
  created_at: string;
  updated_at: string;
  reviewed_at: string | null;
  reviewed_by: string | null;
  rejection_reason: string | null;
  profiles?: {
    display_name: string;
    email: string;
  };
}

export const DepositsAdmin = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [deposits, setDeposits] = useState<DepositRequest[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedReceipt, setSelectedReceipt] = useState<string | null>(null);
  const [rejectionReason, setRejectionReason] = useState('');

  useEffect(() => {
    fetchDeposits();
    
    // Set up real-time subscription
    const channel = supabase
      .channel('deposits-admin')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'deposit_requests'
        },
        () => {
          fetchDeposits();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  const fetchDeposits = async () => {
    try {
      const { data, error } = await supabase
        .from('academic_discount_verifications')
        .select(`
          *,
          profiles (
            display_name,
            email
          )
        `)
        .order('created_at', { ascending: false });

      if (error) {
        console.error('Error fetching deposits:', error);
        toast.error('Ошибка загрузки депозитов');
        return;
      }

      // Преобразуем данные в нужный формат
      const formattedDeposits = (data || []).map(item => ({
        id: item.id,
        user_id: item.user_id,
        amount: 100,
        status: item.verification_status || 'pending',
        payment_method: 'bank_transfer',
        receipt_image_url: item.verification_document_url,
        admin_notes: '',
        created_at: item.created_at,
        updated_at: item.updated_at,
        reviewed_at: item.verified_at,
        reviewed_by: null,
        rejection_reason: '',
        profiles: {
          display_name: item.email,
          email: item.email
        }
      }));

      setDeposits(formattedDeposits);
    } catch (error) {
      console.error('Error:', error);
      toast.error('Ошибка загрузки депозитов');
    } finally {
      setLoading(false);
    }
  };

  const filteredDeposits = deposits.filter(deposit => {
    const searchLower = searchTerm.toLowerCase();
    const matchesSearch = 
      (deposit.profiles?.display_name?.toLowerCase().includes(searchLower) || false) ||
      (deposit.profiles?.email?.toLowerCase().includes(searchLower) || false) ||
      deposit.id.toLowerCase().includes(searchLower);
    const matchesStatus = statusFilter === 'all' || deposit.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const handleConfirmDeposit = async (id: string) => {
    try {
      const { error } = await supabase.functions.invoke('manage-deposit-request', {
        body: {
          depositId: id,
          action: 'approve'
        }
      });

      if (error) {
        throw error;
      }

      toast.success('Депозит подтвержден');
      fetchDeposits();
    } catch (error) {
      console.error('Error confirming deposit:', error);
      toast.error('Ошибка при подтверждении депозита');
    }
  };

  const handleRejectDeposit = async (id: string, reason?: string) => {
    try {
      const { error } = await supabase.functions.invoke('manage-deposit-request', {
        body: {
          depositId: id,
          action: 'reject',
          rejectionReason: reason
        }
      });

      if (error) {
        throw error;
      }

      toast.success('Депозит отклонен');
      setRejectionReason('');
      fetchDeposits();
    } catch (error) {
      console.error('Error rejecting deposit:', error);
      toast.error('Ошибка при отклонении депозита');
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'approved': return 'text-green-400 bg-green-400/20';
      case 'rejected': return 'text-red-400 bg-red-400/20';
      case 'pending': return 'text-yellow-400 bg-yellow-400/20';
      default: return 'text-gray-400 bg-gray-400/20';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'approved': return 'Подтвержден';
      case 'rejected': return 'Отклонен';
      case 'pending': return 'Ожидает';
      default: return status;
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleString('ru-RU', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const stats = [
    { label: 'Всего заявок', value: deposits.length, icon: CreditCard, color: 'text-blue-400' },
    { label: 'Ожидают подтверждения', value: deposits.filter(d => d.status === 'pending').length, icon: Clock, color: 'text-yellow-400' },
    { label: 'Подтверждено сегодня', value: deposits.filter(d => d.status === 'approved').length, icon: CheckCircle, color: 'text-green-400' },
    { label: 'Общая сумма', value: `${deposits.reduce((sum, d) => sum + d.amount, 0).toLocaleString()} ₽`, icon: TrendingUp, color: 'text-primary' }
  ];

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {[...Array(4)].map((_, i) => (
            <Card key={i} className="bg-card/80 backdrop-blur-sm border-border/50">
              <CardContent className="p-6">
                <div className="animate-pulse">
                  <div className="h-4 bg-muted rounded w-1/2 mb-2"></div>
                  <div className="h-8 bg-muted rounded w-3/4"></div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
        <Card>
          <CardContent className="p-6">
            <div className="animate-pulse space-y-4">
              <div className="h-4 bg-muted rounded w-1/4"></div>
              <div className="h-32 bg-muted rounded"></div>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat, index) => (
          <motion.div
            key={stat.label}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: index * 0.1 }}
          >
            <Card className="bg-card/80 backdrop-blur-sm border-border/50">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">{stat.label}</p>
                    <p className={`text-2xl font-bold ${stat.color}`}>{stat.value}</p>
                  </div>
                  <stat.icon className={`w-8 h-8 ${stat.color}`} />
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      {/* Filters */}
      <Card className="bg-card/80 backdrop-blur-sm border-border/50">
        <CardHeader>
          <CardTitle>Управление депозитами</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center space-x-4 mb-6">
            <div className="relative flex-1 max-w-sm">
              <Search className="w-4 h-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground" />
              <Input
                placeholder="Поиск по пользователю, номеру заявки..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="bg-background border border-border rounded-md px-3 py-2 text-sm"
            >
              <option value="all">Все статусы</option>
              <option value="pending">Ожидает</option>
              <option value="approved">Подтвержден</option>
              <option value="rejected">Отклонен</option>
            </select>
          </div>

          {/* Deposits Table */}
          <div className="rounded-md border border-border/50 overflow-hidden">
            <Table>
              <TableHeader>
                <TableRow className="border-border/50">
                  <TableHead>№ Заявки</TableHead>
                  <TableHead>Пользователь</TableHead>
                  <TableHead>Сумма</TableHead>
                  <TableHead>Метод</TableHead>
                  <TableHead>Статус</TableHead>
                  <TableHead>Дата заявки</TableHead>
                  <TableHead>Чек</TableHead>
                  <TableHead>Действия</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredDeposits.map((deposit) => (
                  <TableRow key={deposit.id} className="border-border/50">
                    <TableCell className="font-mono text-sm">#{deposit.id.slice(-8).toUpperCase()}</TableCell>
                    <TableCell>
                      <div className="flex items-center space-x-2">
                        <User className="w-4 h-4 text-muted-foreground" />
                        <div>
                          <p className="font-medium">{deposit.profiles?.display_name || 'Не указано'}</p>
                          <p className="text-xs text-muted-foreground">{deposit.profiles?.email}</p>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell className="font-semibold">{deposit.amount.toLocaleString()} ₽</TableCell>
                    <TableCell>
                      <Badge variant="outline" className="text-xs">
                        {deposit.payment_method === 'bank_transfer' ? 'Банковский перевод' : deposit.payment_method}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <Badge className={`${getStatusColor(deposit.status)} text-xs`}>
                        {getStatusText(deposit.status)}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-sm text-muted-foreground">{formatDate(deposit.created_at)}</TableCell>
                    <TableCell>
                      {deposit.receipt_image_url && (
                        <Dialog>
                          <DialogTrigger asChild>
                            <Button size="sm" variant="outline" className="h-8 px-3">
                              <Eye className="w-3 h-3 mr-1" />
                              Просмотр
                            </Button>
                          </DialogTrigger>
                          <DialogContent className="max-w-2xl">
                            <DialogHeader>
                              <DialogTitle>Чек об оплате</DialogTitle>
                            </DialogHeader>
                            <div className="flex justify-center">
                              <img 
                                src={deposit.receipt_image_url} 
                                alt="Чек об оплате"
                                className="max-w-full max-h-96 object-contain rounded-lg"
                              />
                            </div>
                          </DialogContent>
                        </Dialog>
                      )}
                    </TableCell>
                    <TableCell>
                      {deposit.status === 'pending' && (
                        <div className="flex items-center space-x-2">
                          <Button
                            size="sm"
                            onClick={() => handleConfirmDeposit(deposit.id)}
                            className="bg-green-600 hover:bg-green-700 text-white h-8 px-3"
                          >
                            <CheckCircle className="w-3 h-3 mr-1" />
                            Подтвердить
                          </Button>
                          <Dialog>
                            <DialogTrigger asChild>
                              <Button
                                size="sm"
                                variant="destructive"
                                className="h-8 px-3"
                              >
                                <XCircle className="w-3 h-3 mr-1" />
                                Отклонить
                              </Button>
                            </DialogTrigger>
                            <DialogContent>
                              <DialogHeader>
                                <DialogTitle>Отклонить заявку</DialogTitle>
                              </DialogHeader>
                              <div className="space-y-4">
                                <div>
                                  <Label htmlFor="reason">Причина отклонения</Label>
                                  <Textarea
                                    id="reason"
                                    placeholder="Укажите причину отклонения заявки..."
                                    value={rejectionReason}
                                    onChange={(e) => setRejectionReason(e.target.value)}
                                  />
                                </div>
                                <Button
                                  onClick={() => handleRejectDeposit(deposit.id, rejectionReason)}
                                  variant="destructive"
                                  className="w-full"
                                >
                                  Отклонить заявку
                                </Button>
                              </div>
                            </DialogContent>
                          </Dialog>
                        </div>
                      )}
                      {deposit.status === 'rejected' && deposit.rejection_reason && (
                        <div className="text-xs text-red-400 max-w-32 truncate" title={deposit.rejection_reason}>
                          {deposit.rejection_reason}
                        </div>
                      )}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};