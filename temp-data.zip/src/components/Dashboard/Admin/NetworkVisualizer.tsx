import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import NetworkTopology from './NetworkTopology';
import NetworkNode from './NetworkNode';
import { Activity, AlertTriangle, CheckCircle, XCircle, Zap, Globe, Shield, Server } from 'lucide-react';

// Enhanced types for network monitoring
interface NetworkNodeType {
  id: string;
  type: 'server' | 'proxy' | 'account' | 'service';
  label: string;
  x: number;
  y: number;
  status: 'active' | 'warning' | 'error';
  connections: string[];
  load: number;
  latency: number;
  uptime: number;
}

interface NetworkConnection {
  from: string;
  to: string;
  status: 'active' | 'warning' | 'error';
  bandwidth: number;
  packets: number;
}

interface NetworkLog {
  id: string;
  timestamp: Date;
  level: 'info' | 'warning' | 'error';
  source: string;
  message: string;
  details?: string;
}

interface NetworkMetric {
  label: string;
  value: string;
  status: 'good' | 'warning' | 'critical';
  icon: React.ComponentType<any>;
}

const NetworkVisualizer: React.FC = () => {
  const [nodes, setNodes] = useState<NetworkNodeType[]>([]);
  const [connections, setConnections] = useState<NetworkConnection[]>([]);
  const [logs, setLogs] = useState<NetworkLog[]>([]);
  const [metrics, setMetrics] = useState<NetworkMetric[]>([]);

  // Generate realistic network logs
  const generateLog = (): NetworkLog => {
    const levels: Array<'info' | 'warning' | 'error'> = ['info', 'warning', 'error'];
    const sources = ['CORE-SRV', 'PROXY-MSK', 'PROXY-SPB', 'AUTH-SVC', 'MON-SYS'];
    const messages = {
      info: [
        'Connection established successfully',
        'Data packet transmitted',
        'Heartbeat received',
        'Session authenticated',
        'Bandwidth optimized'
      ],
      warning: [
        'High latency detected',
        'Connection retry attempt',
        'Buffer overflow warning',
        'Rate limit approaching'
      ],
      error: [
        'Connection timeout',
        'Authentication failed',
        'Packet loss detected',
        'Service unavailable'
      ]
    };

    const level = levels[Math.floor(Math.random() * levels.length)];
    const source = sources[Math.floor(Math.random() * sources.length)];
    const messageList = messages[level];
    const message = messageList[Math.floor(Math.random() * messageList.length)];

    return {
      id: Math.random().toString(36).substr(2, 9),
      timestamp: new Date(),
      level,
      source,
      message,
      details: level === 'error' ? 'Check network configuration' : undefined
    };
  };

  useEffect(() => {
    // Initialize enhanced network topology
    const initialNodes: NetworkNodeType[] = [
      {
        id: 'core-srv',
        type: 'server',
        label: 'CORE-SRV-01',
        x: 15,
        y: 50,
        status: 'active',
        connections: ['proxy-msk', 'proxy-spb'],
        load: 45,
        latency: 12,
        uptime: 99.8
      },
      {
        id: 'proxy-msk',
        type: 'proxy',
        label: 'PROXY-MSK',
        x: 40,
        y: 25,
        status: 'active',
        connections: ['acc-pool-1'],
        load: 67,
        latency: 28,
        uptime: 99.2
      },
      {
        id: 'proxy-spb',
        type: 'proxy',
        label: 'PROXY-SPB',
        x: 40,
        y: 75,
        status: 'warning',
        connections: ['acc-pool-2'],
        load: 89,
        latency: 45,
        uptime: 97.3
      },
      {
        id: 'acc-pool-1',
        type: 'account',
        label: 'ACC-POOL-1',
        x: 70,
        y: 25,
        status: 'active',
        connections: ['yandex-api'],
        load: 34,
        latency: 67,
        uptime: 98.9
      },
      {
        id: 'acc-pool-2',
        type: 'account',
        label: 'ACC-POOL-2',
        x: 70,
        y: 75,
        status: 'error',
        connections: [],
        load: 0,
        latency: 999,
        uptime: 45.2
      },
      {
        id: 'yandex-api',
        type: 'service',
        label: 'YANDEX-API',
        x: 90,
        y: 50,
        status: 'active',
        connections: [],
        load: 23,
        latency: 156,
        uptime: 99.9
      }
    ];

    const initialConnections: NetworkConnection[] = [
      { from: 'core-srv', to: 'proxy-msk', status: 'active', bandwidth: 120, packets: 1450 },
      { from: 'core-srv', to: 'proxy-spb', status: 'warning', bandwidth: 80, packets: 890 },
      { from: 'proxy-msk', to: 'acc-pool-1', status: 'active', bandwidth: 90, packets: 670 },
      { from: 'proxy-spb', to: 'acc-pool-2', status: 'error', bandwidth: 0, packets: 0 },
      { from: 'acc-pool-1', to: 'yandex-api', status: 'active', bandwidth: 200, packets: 2340 }
    ];

    setNodes(initialNodes);
    setConnections(initialConnections);

    // Initialize metrics
    setMetrics([
      { label: 'Network Load', value: '67%', status: 'warning', icon: Activity },
      { label: 'Active Nodes', value: '5/6', status: 'warning', icon: Globe },
      { label: 'Security Level', value: 'HIGH', status: 'good', icon: Shield },
      { label: 'Throughput', value: '2.3 Gb/s', status: 'good', icon: Zap }
    ]);

    // Generate initial logs
    const initialLogs = Array.from({ length: 10 }, generateLog).sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime());
    setLogs(initialLogs);

    // Real-time updates
    const logInterval = setInterval(() => {
      const newLog = generateLog();
      setLogs(prev => [newLog, ...prev.slice(0, 49)]);
    }, 2000);

    const metricsInterval = setInterval(() => {
      setMetrics(prev => prev.map(metric => {
        const change = (Math.random() - 0.5) * 0.1;
        let newValue = metric.value;
        
        if (metric.label === 'Network Load') {
          const currentLoad = parseInt(metric.value);
          const newLoad = Math.max(0, Math.min(100, currentLoad + Math.floor(change * 100)));
          newValue = `${newLoad}%`;
        }
        
        return { ...metric, value: newValue };
      }));
    }, 5000);

    return () => {
      clearInterval(logInterval);
      clearInterval(metricsInterval);
    };
  }, []);

  const getLogIcon = (level: string) => {
    switch (level) {
      case 'info': return CheckCircle;
      case 'warning': return AlertTriangle;
      case 'error': return XCircle;
      default: return Activity;
    }
  };

  const getLogColor = (level: string) => {
    switch (level) {
      case 'info': return 'text-chart-2';
      case 'warning': return 'text-chart-3';
      case 'error': return 'text-destructive';
      default: return 'text-muted-foreground';
    }
  };

  const getMetricColor = (status: string) => {
    switch (status) {
      case 'good': return 'text-chart-2';
      case 'warning': return 'text-chart-3';
      case 'critical': return 'text-destructive';
      default: return 'text-muted-foreground';
    }
  };

  return (
    <div className="space-y-6">
      {/* Network Status Overview */}
      <div className="grid grid-cols-4 gap-4">
        {metrics.map((metric, index) => (
          <Card key={index}>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">{metric.label}</p>
                  <p className={`text-xl font-mono font-bold ${getMetricColor(metric.status)}`}>
                    {metric.value}
                  </p>
                </div>
                <metric.icon className={`h-6 w-6 ${getMetricColor(metric.status)}`} />
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Network Topology */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Server className="h-5 w-5" />
              Network Topology
              <Badge variant="outline" className="ml-auto">LIVE</Badge>
            </CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <div className="relative">
              <NetworkTopology nodes={nodes} connections={connections} />
              
              {/* Node overlays */}
              {nodes.map((node, index) => (
                <NetworkNode 
                  key={node.id} 
                  node={node} 
                  index={index}
                />
              ))}
            </div>
          </CardContent>
        </Card>

        {/* System Logs */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Activity className="h-5 w-5" />
                System Logs
              </div>
              <Button variant="outline" size="sm">
                Export
              </Button>
            </CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <ScrollArea className="h-[300px]">
              <div className="p-4 space-y-2">
                {logs.map((log) => {
                  const LogIcon = getLogIcon(log.level);
                  return (
                    <div key={log.id} className="flex items-start gap-3 text-sm p-2 rounded hover:bg-muted/50">
                      <LogIcon className={`h-4 w-4 mt-0.5 ${getLogColor(log.level)}`} />
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <span className="font-mono text-xs text-muted-foreground">
                            {log.timestamp.toLocaleTimeString()}
                          </span>
                          <Badge variant="outline" className="text-xs">
                            {log.source}
                          </Badge>
                        </div>
                        <p className="mt-1">{log.message}</p>
                        {log.details && (
                          <p className="text-xs text-muted-foreground mt-1">{log.details}</p>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </ScrollArea>
          </CardContent>
        </Card>
      </div>

      {/* Connection Management */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            Connection Management
            <div className="flex gap-2">
              <Button variant="outline" size="sm">
                Restart Failed
              </Button>
              <Button variant="outline" size="sm">
                Optimize Routes
              </Button>
            </div>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {connections.map((conn, index) => {
              const fromNode = nodes.find(n => n.id === conn.from);
              const toNode = nodes.find(n => n.id === conn.to);
              
              return (
                <div key={index} className="flex items-center justify-between p-3 rounded border border-border">
                  <div className="flex items-center gap-4">
                    <div className={`w-3 h-3 rounded-full ${
                      conn.status === 'active' ? 'bg-chart-2' :
                      conn.status === 'warning' ? 'bg-chart-3' : 'bg-destructive'
                    }`} />
                    <div>
                      <p className="font-medium">
                        {fromNode?.label} → {toNode?.label}
                      </p>
                      <p className="text-sm text-muted-foreground">
                        {conn.bandwidth} MB/s • {conn.packets.toLocaleString()} packets/s
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant={conn.status === 'active' ? 'default' : 'destructive'}>
                      {conn.status.toUpperCase()}
                    </Badge>
                    <Button variant="ghost" size="sm">
                      Details
                    </Button>
                  </div>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default NetworkVisualizer;