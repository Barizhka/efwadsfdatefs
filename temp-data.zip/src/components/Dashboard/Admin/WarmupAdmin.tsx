import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { 
  Zap,
  PlayCircle,
  PauseCircle,
  StopCircle,
  Clock,
  TrendingUp,
  Users,
  Settings
} from 'lucide-react';

interface WarmupSession {
  id: string;
  accountId: string;
  accountName: string;
  city: string;
  startTime: string;
  duration: string;
  progress: number;
  status: 'running' | 'paused' | 'completed' | 'stopped';
  requests: number;
  successRate: number;
  temperature: number;
}

const mockSessions: WarmupSession[] = [
  {
    id: 'warm_001',
    accountId: 'ACC-1234567890',
    accountName: 'Алексей Иванов',
    city: 'Москва',
    startTime: '2024-09-14 09:30',
    duration: '2ч 45м',
    progress: 67,
    status: 'running',
    requests: 234,
    successRate: 94.5,
    temperature: 0.7
  },
  {
    id: 'warm_002',
    accountId: 'ACC-1234567891',
    accountName: 'Мария Петрова',
    city: 'Санкт-Петербург',
    startTime: '2024-09-14 08:15',
    duration: '4ч 0м',
    progress: 89,
    status: 'running',
    requests: 456,
    successRate: 96.2,
    temperature: 0.6
  },
  {
    id: 'warm_003',
    accountId: 'ACC-1234567892',
    accountName: 'Дмитрий Смирнов',
    city: 'Екатеринбург',
    startTime: '2024-09-14 07:00',
    duration: '5ч 15м',
    progress: 100,
    status: 'completed',
    requests: 678,
    successRate: 98.1,
    temperature: 0.8
  }
];

export const WarmupAdmin = () => {
  const [sessions, setSessions] = useState(mockSessions);

  const handlePauseSession = (id: string) => {
    setSessions(prev => prev.map(session => 
      session.id === id && session.status === 'running' 
        ? { ...session, status: 'paused' as const } 
        : session
    ));
  };

  const handleResumeSession = (id: string) => {
    setSessions(prev => prev.map(session => 
      session.id === id && session.status === 'paused' 
        ? { ...session, status: 'running' as const } 
        : session
    ));
  };

  const handleStopSession = (id: string) => {
    setSessions(prev => prev.map(session => 
      session.id === id 
        ? { ...session, status: 'stopped' as const } 
        : session
    ));
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'running': return 'text-green-400 bg-green-400/20';
      case 'paused': return 'text-yellow-400 bg-yellow-400/20';
      case 'completed': return 'text-blue-400 bg-blue-400/20';
      case 'stopped': return 'text-red-400 bg-red-400/20';
      default: return 'text-gray-400 bg-gray-400/20';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'running': return 'Активен';
      case 'paused': return 'Пауза';
      case 'completed': return 'Завершен';
      case 'stopped': return 'Остановлен';
      default: return status;
    }
  };

  const stats = [
    { label: 'Активных сессий', value: sessions.filter(s => s.status === 'running').length, icon: Zap, color: 'text-green-400' },
    { label: 'На паузе', value: sessions.filter(s => s.status === 'paused').length, icon: PauseCircle, color: 'text-yellow-400' },
    { label: 'Завершено сегодня', value: sessions.filter(s => s.status === 'completed').length, icon: TrendingUp, color: 'text-blue-400' },
    { label: 'Средний прогресс', value: `${Math.round(sessions.filter(s => s.status !== 'completed').reduce((avg, s) => avg + s.progress, 0) / sessions.filter(s => s.status !== 'completed').length || 0)}%`, icon: Clock, color: 'text-primary' }
  ];

  return (
    <div className="space-y-6">
      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat, index) => (
          <motion.div
            key={stat.label}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: index * 0.1 }}
          >
            <Card className="bg-card/80 backdrop-blur-sm border-border/50">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">{stat.label}</p>
                    <p className={`text-2xl font-bold ${stat.color}`}>{stat.value}</p>
                  </div>
                  <stat.icon className={`w-8 h-8 ${stat.color}`} />
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      {/* Warmup Sessions */}
      <Card className="bg-card/80 backdrop-blur-sm border-border/50">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>Активные сессии прогрева</CardTitle>
            <div className="flex items-center space-x-3">
              <Button variant="outline">
                <Settings className="w-4 h-4 mr-2" />
                Настройки прогрева
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {sessions.map((session) => (
              <motion.div
                key={session.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3 }}
              >
                <Card className="bg-card/60 border-border/30">
                  <CardContent className="p-4">
                    <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
                      {/* Account Info */}
                      <div className="space-y-2">
                        <div className="flex items-center space-x-2">
                          <Users className="w-4 h-4 text-primary" />
                          <span className="font-medium text-sm">{session.accountName}</span>
                        </div>
                        <p className="text-xs text-muted-foreground font-mono">{session.accountId}</p>
                        <p className="text-xs text-muted-foreground">{session.city}</p>
                        <Badge className={`${getStatusColor(session.status)} text-xs w-fit`}>
                          {getStatusText(session.status)}
                        </Badge>
                      </div>

                      {/* Progress */}
                      <div className="space-y-2">
                        <div className="flex justify-between items-center">
                          <span className="text-sm font-medium">Прогресс</span>
                          <span className="text-sm font-bold text-primary">{session.progress}%</span>
                        </div>
                        <Progress value={session.progress} className="h-2" />
                        <div className="grid grid-cols-2 gap-2 text-xs text-muted-foreground">
                          <span>Время: {session.duration}</span>
                          <span>Запросов: {session.requests}</span>
                        </div>
                      </div>

                      {/* Metrics */}
                      <div className="space-y-2">
                        <div className="text-sm">
                          <p className="text-muted-foreground">Успешность:</p>
                          <p className="font-semibold text-green-400">{session.successRate}%</p>
                        </div>
                        <div className="text-sm">
                          <p className="text-muted-foreground">Температура:</p>
                          <p className="font-semibold">{session.temperature}</p>
                        </div>
                        <div className="text-sm">
                          <p className="text-muted-foreground">Начало:</p>
                          <p className="font-mono text-xs">{session.startTime}</p>
                        </div>
                      </div>

                      {/* Actions */}
                      <div className="flex flex-col space-y-2">
                        {session.status === 'running' && (
                          <>
                            <Button 
                              size="sm" 
                              variant="outline"
                              onClick={() => handlePauseSession(session.id)}
                              className="w-full"
                            >
                              <PauseCircle className="w-3 h-3 mr-1" />
                              Пауза
                            </Button>
                            <Button 
                              size="sm" 
                              variant="destructive"
                              onClick={() => handleStopSession(session.id)}
                              className="w-full"
                            >
                              <StopCircle className="w-3 h-3 mr-1" />
                              Остановить
                            </Button>
                          </>
                        )}
                        {session.status === 'paused' && (
                          <>
                            <Button 
                              size="sm" 
                              onClick={() => handleResumeSession(session.id)}
                              className="w-full bg-green-600 hover:bg-green-700"
                            >
                              <PlayCircle className="w-3 h-3 mr-1" />
                              Продолжить
                            </Button>
                            <Button 
                              size="sm" 
                              variant="destructive"
                              onClick={() => handleStopSession(session.id)}
                              className="w-full"
                            >
                              <StopCircle className="w-3 h-3 mr-1" />
                              Остановить
                            </Button>
                          </>
                        )}
                        {session.status === 'completed' && (
                          <Badge className="bg-blue-400/20 text-blue-400 text-xs justify-center py-2">
                            Прогрев завершен
                          </Badge>
                        )}
                        {session.status === 'stopped' && (
                          <Badge className="bg-red-400/20 text-red-400 text-xs justify-center py-2">
                            Остановлен
                          </Badge>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};