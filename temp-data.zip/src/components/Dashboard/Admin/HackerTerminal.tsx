import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Play, Square, Terminal, Activity } from 'lucide-react';

interface LogEntry {
  id: string;
  timestamp: string;
  type: 'info' | 'success' | 'warning' | 'error' | 'system';
  message: string;
  details?: string;
}

const HackerTerminal = () => {
  const [isRunning, setIsRunning] = useState(false);
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [currentProcess, setCurrentProcess] = useState('');
  const terminalRef = useRef<HTMLDivElement>(null);

  const mockLogs = [
    { type: 'system', message: '>>> Инициализация модуля прогрева...', details: 'Загрузка логов из файла' },
    { type: 'info', message: '[CORE] Поиск доступных прокси-серверов...', details: 'Сканирование портов и соединений' },
    { type: 'success', message: '[CORE] ✓ Найдено 247 активных прокси', details: 'Проверка скорости и анонимности' },
    { type: 'info', message: '[PROXY] Инициализация аккаунтов...', details: 'Парсинг конфигураций' },
    { type: 'success', message: '[PROXY] ✓ Загружено 847 аккаунтов', details: 'Все аккаунты валидированы' },
    { type: 'info', message: '[NETWORK] Установление защищённого соединения...', details: 'SSL/TLS handshake' },
    { type: 'success', message: '[NETWORK] ✓ Соединение установлено', details: 'Шифрование активно' },
    { type: 'info', message: '[SYSTEM] Синхронизация сетевых модулей...', details: 'Загрузка компонентов' },
    { type: 'success', message: '[SYSTEM] ✓ Модули синхронизированы', details: 'Все компоненты готовы' },
    { type: 'info', message: '[EMULATOR] Генерация профилей устройств...', details: 'Создание уникальных отпечатков' },
    { type: 'success', message: '[EMULATOR] ✓ 847 профилей создано', details: 'Chrome, Firefox, Yandex Browser' },
    { type: 'info', message: '[YANDEX] Подключение к серверам Яндекс...', details: 'Тестирование API endpoints' },
    { type: 'success', message: '[YANDEX] ✓ Все сервисы доступны', details: 'Почта, Карты, Маркет, Музыка' },
    { type: 'info', message: '[WARMUP] Начало прогрева аккаунтов...', details: 'Фаза 1: Базовая симуляция' },
    
    // Москва
    { type: 'info', message: '[dmitr***@yandex.ru] ПРИВЯЗАН К Москва | ПРОКСИ: 185.178.10.142:8080', details: 'Москва, Chrome browser' },
    { type: 'info', message: '[dmitr***@yandex.ru] УСТАНОВЛЕНО СОЕДИНЕНИЕ С СЕРВЕРОМ YANDEX', details: 'Response time: 23ms' },
    { type: 'info', message: '[dmitr***@yandex.ru] | Дмитрий | Москва Открытие Яндекс.Почты', details: 'Split: 75k' },
    { type: 'info', message: '[dmitr***@yandex.ru] | Дмитрий | Москва Чтение новых писем', details: 'Обработка входящих' },
    { type: 'info', message: '[dmitr***@yandex.ru] | Дмитрий | Москва Ответ на письмо от службы поддержки', details: 'Генерация ответа' },
    
    // Санкт-Петербург
    { type: 'info', message: '[maria***@yandex.ru] ПРИВЯЗАН К Санкт-Петербург | ПРОКСИ: 78.46.89.73:3128', details: 'Санкт-Петербург, Firefox browser' },
    { type: 'info', message: '[maria***@yandex.ru] УСТАНОВЛЕНО СОЕДИНЕНИЕ С СЕРВЕРОМ YANDEX', details: 'Response time: 31ms' },
    { type: 'info', message: '[maria***@yandex.ru] | Мария | Санкт-Петербург Открытие Яндекс.Карт', details: 'Split: 50k' },
    { type: 'info', message: '[maria***@yandex.ru] | Мария | Санкт-Петербург Поиск ближайших кафе на Яндекс.Картах', details: 'Геолокация активна' },
    { type: 'info', message: '[maria***@yandex.ru] | Мария | Санкт-Петербург Просмотр пробок в районе проживания', details: 'Трафик анализ' },
    
    // Казань
    { type: 'info', message: '[alex***@yandex.ru] ПРИВЯЗАН К Казань | ПРОКСИ: 188.243.183.91:9090', details: 'Казань, Yandex Browser' },
    { type: 'info', message: '[alex***@yandex.ru] УСТАНОВЛЕНО СОЕДИНЕНИЕ С СЕРВЕРОМ YANDEX', details: 'Response time: 28ms' },
    { type: 'info', message: '[alex***@yandex.ru] | Алексей | Казань Открытие Яндекс.Маркета', details: 'Split: 100k' },
    { type: 'info', message: '[alex***@yandex.ru] | Алексей | Казань Поиск смартфона по фильтрам', details: 'Цена до 50000₽' },
    { type: 'info', message: '[alex***@yandex.ru] | Алексей | Казань Добавление товара в избранное', details: 'Samsung Galaxy S24' },
    
    // Екатеринбург
    { type: 'info', message: '[elena***@yandex.ru] ПРИВЯЗАН К Екатеринбург | ПРОКСИ: 92.223.85.156:8888', details: 'Екатеринбург, Edge browser' },
    { type: 'info', message: '[elena***@yandex.ru] УСТАНОВЛЕНО СОЕДИНЕНИЕ С СЕРВЕРОМ YANDEX', details: 'Response time: 35ms' },
    { type: 'info', message: '[elena***@yandex.ru] | Елена | Екатеринбург Открытие Яндекс.Музыки', details: 'Split: 75k' },
    { type: 'info', message: '[elena***@yandex.ru] | Елена | Екатеринбург Воспроизведение альбома Популярное', details: 'Streaming активен' },
    { type: 'info', message: '[elena***@yandex.ru] | Елена | Екатеринбург Добавление трека в плейлист', details: 'Мой плейлист' },
    
    // Новосибирск
    { type: 'info', message: '[ivan***@yandex.ru] ПРИВЯЗАН К Новосибирск | ПРОКСИ: 109.195.23.67:1080', details: 'Новосибирск, Chrome browser' },
    { type: 'info', message: '[ivan***@yandex.ru] УСТАНОВЛЕНО СОЕДИНЕНИЕ С СЕРВЕРОМ YANDEX', details: 'Response time: 42ms' },
    { type: 'info', message: '[ivan***@yandex.ru] | Иван | Новосибирск Открытие Яндекс.Дзена', details: 'Split: 50k' },
    { type: 'info', message: '[ivan***@yandex.ru] | Иван | Новосибирск Прокрутка ленты рекомендаций', details: 'Персонализация' },
    { type: 'info', message: '[ivan***@yandex.ru] | Иван | Новосибирск Чтение статьи о путешествиях', details: 'Время чтения: 3мин' },
    
    { type: 'success', message: '[BATCH-1] ✓ Первая группа прогрета (50 аккаунтов)', details: 'Температура: Оптимальная' },
    
    // Дополнительные аккаунты
    { type: 'info', message: '[sergey***@yandex.ru] | Сергей | Ростов-на-Дону Открытие Яндекс.Браузера', details: 'Split: 100k' },
    { type: 'info', message: '[sergey***@yandex.ru] | Сергей | Ростов-на-Дону Ввод запроса: Погода Москва на завтра', details: 'Поисковый запрос' },
    { type: 'info', message: '[anna***@yandex.ru] | Анна | Самара Вход в Яндекс.Облако', details: 'Split: 75k' },
    { type: 'info', message: '[anna***@yandex.ru] | Анна | Самара Загрузка PDF-файла в облако', details: 'Размер: 2.3MB' },
    { type: 'info', message: '[pavel***@yandex.ru] | Павел | Уфа Переход на Яндекс.Деньги (ЮMoney)', details: 'Split: 50k' },
    { type: 'info', message: '[pavel***@yandex.ru] | Павел | Уфа Проверка баланса счета', details: 'Финансовый сервис' },
    
    { type: 'warning', message: '[MONITOR] Обнаружено ограничение на olga***@yandex.ru', details: 'Rate limit detected, переключение прокси' },
    { type: 'info', message: '[RECOVERY] Переключение на резервный прокси 213.***.***.98:3128', details: 'Failover protocol' },
    { type: 'success', message: '[RECOVERY] ✓ Соединение восстановлено', details: 'Операции возобновлены' },
    
    { type: 'info', message: '[mikhail***@yandex.ru] | Михаил | Красноярск Открытие Яндекс.Новости', details: 'Split: 100k' },
    { type: 'info', message: '[mikhail***@yandex.ru] | Михаил | Красноярск Чтение статьи о политике', details: 'Время чтения: 5мин' },
    { type: 'info', message: '[svetla***@yandex.ru] | Светлана | Пермь Поиск вакансий через Яндекс.Работа', details: 'Split: 75k' },
    { type: 'info', message: '[svetla***@yandex.ru] | Светлана | Пермь Добавление резюме в профиль', details: 'CV uploaded' },
    
    { type: 'success', message: '[BATCH-2] ✓ Вторая группа прогрета (100 аккаунтов)', details: 'Температура: Отличная' },
    
    { type: 'info', message: '[ACTIONS] Выполнение кампаний лайков...', details: 'Распределение активности' },
    { type: 'success', message: '[ACTIONS] ✓ Распределено 3,247 лайков', details: 'Естественные паттерны поведения' },
    { type: 'info', message: '[ACTIONS] Генерация комментариев...', details: 'AI-powered content creation' },
    { type: 'success', message: '[ACTIONS] ✓ Создано 847 комментариев', details: 'Уникальность 95%' },
    
    { type: 'info', message: '[AI] Анализ поведенческих паттернов...', details: 'Machine learning optimization' },
    { type: 'success', message: '[AI] ✓ Модели обучены и калиброваны', details: 'Точность предсказаний: 94.7%' },
    
    { type: 'info', message: '[SPLIT] Обработка сплитов 50k/75k/100k...', details: 'Split testing configuration' },
    { type: 'success', message: '[SPLIT] ✓ Все сплиты настроены и активны', details: 'Трафик распределен равномерно' },
    
    { type: 'info', message: '[ANALYTICS] Генерация отчета производительности...', details: 'Сбор метрик за последние 24ч' },
    { type: 'success', message: '[ANALYTICS] ✓ Отчет создан и сохранен', details: 'Конверсия: 89.2%, CTR: 12.4%' },
    
    { type: 'info', message: '[MONITOR] Проверка качества трафика...', details: 'Анализ bounce rate и времени сессий' },
    { type: 'success', message: '[MONITOR] ✓ Качество трафика подтверждено', details: 'Все метрики в норме' },
    
    { type: 'info', message: '[CLEANUP] Очистка временных файлов и логов...', details: 'Освобождение дискового пространства' },
    { type: 'success', message: '[CLEANUP] ✓ Система очищена', details: 'Освобождено 847MB' },
    
    { type: 'success', message: '[BATCH-3] ✓ Финальная группа завершена (150 аккаунтов)', details: 'Общая эффективность: 97.3%' },
    { type: 'success', message: '[SYSTEM] ✓ Полный цикл прогрева завершен', details: 'Всего обработано: 847 аккаунтов' },
    { type: 'system', message: '>>> Система готова к боевому режиму', details: 'Все аккаунты готовы к деплою' }
  ];

  const processNames = [
    'PROXY_MANAGER',
    'ACCOUNT_LOADER', 
    'WARMUP_ENGINE',
    'EMULATOR_CORE',
    'AI_PROCESSOR',
    'ACTION_EXECUTOR',
    'MONITOR_DAEMON'
  ];

  const yandexActions = [
    "Открытие Яндекс.Почты",
    "Чтение новых писем",
    "Ответ на письмо от службы поддержки",
    "Удаление спама из Яндекс.Почты",
    "Переход по ссылке в письме",
    "Скачивание вложения из письма",
    "Открытие Яндекс.Карт",
    "Поиск ближайших кафе на Яндекс.Картах",
    "Просмотр пробок в районе проживания",
    "Прокладка маршрута на автомобиле",
    "Изучение отзывов на заведение",
    "Построение пешего маршрута",
    "Поиск остановок общественного транспорта",
    "Открытие Яндекс.Маркета",
    "Поиск смартфона по фильтрам",
    "Добавление товара в избранное",
    "Добавление товара в корзину",
    "Чтение отзывов о товаре",
    "Сравнение цен в разных магазинах",
    "Просмотр характеристик товара",
    "Открытие Яндекс.Музыки",
    "Воспроизведение альбома 'Популярное'",
    "Добавление трека в плейлист",
    "Скачивание трека в кэш",
    "Поиск новых исполнителей",
    "Создание персональной станции",
    "Открытие Яндекс.Дзена",
    "Прокрутка ленты рекомендаций",
    "Чтение статьи о путешествиях",
    "Переход на встроенное видео в Дзене",
    "Лайк статьи в Дзене",
    "Подписка на канал",
    "Открытие Яндекс.Видео",
    "Просмотр короткого ролика",
    "Поиск видео по названию фильма",
    "Лайк видео на платформе",
    "Добавление видео в избранное",
    "Вход в Яндекс.Облако",
    "Загрузка PDF-файла в облако",
    "Просмотр списка ранее загруженных файлов",
    "Создание новой папки",
    "Удаление старого документа",
    "Синхронизация файлов с устройством",
    "Открытие Яндекс.Новости",
    "Чтение статьи о политике",
    "Переход на источник новости",
    "Поиск новостей по теме",
    "Открытие Яндекс.Браузера",
    "Просмотр вкладок",
    "Поиск информации через Яндекс.Поиск",
    "Ввод запроса: 'Погода Москва на завтра'",
    "Открытие прогноза погоды",
    "Ввод запроса: 'Как сварить борщ'",
    "Чтение рецепта на кулинарном портале",
    "Открытие Яндекс.Рекламы",
    "Клик по рекламному баннеру",
    "Заполнение формы заказа на стороннем сайте",
    "Авторизация через Яндекс ID",
    "Обновление данных профиля",
    "Вход в Яндекс.Паспорт",
    "Проверка безопасности аккаунта",
    "Активация двухфакторной аутентификации",
    "Подтверждение номера телефона",
    "Ввод поискового запроса: 'Билеты на поезд до Казани'",
    "Открытие Яндекс.Расписания",
    "Поиск рейсов и поездов",
    "Выбор места в поезде",
    "Бронирование билета на автобус",
    "Запись в Яндекс.Заметках",
    "Создание напоминания",
    "Чтение комментариев на Дзене",
    "Поиск вакансий через Яндекс.Работа",
    "Добавление резюме в профиль",
    "Просмотр Яндекс.Кью — вопрос-ответ",
    "Ответ на популярный вопрос в категории IT",
    "Переход на Яндекс.Деньги (ЮMoney)",
    "Проверка баланса счета",
    "Перевод денег по номеру телефона",
    "Открытие Яндекс.Такси",
    "Заказ поездки в центр города",
    "Оценка поездки и водителя",
    "Открытие Яндекс.Еда",
    "Заказ пиццы с доставкой",
    "Просмотр меню ресторана",
    "Добавление ресторана в избранное",
    "Открытие Яндекс.Лавка",
    "Заказ продуктов на дом",
    "Открытие Яндекс.Дом",
    "Управление умными устройствами",
    "Настройка сценариев автоматизации",
    "Открытие Яндекс.Переводчика",
    "Перевод текста с английского на русский",
    "Голосовой перевод фразы",
    "Открытие Яндекс.Дисков",
    "Загрузка фотографий с отпуска",
    "Создание альбома",
    "Открытие Яндекс.Телемост",
    "Присоединение к видеозвонку",
    "Демонстрация экрана коллегам",
    "Открытие Алисы",
    "Вопрос о погоде на завтра",
    "Включение музыки через голосовую команду",
    "Открытие Яндекс.Учебник",
    "Прохождение урока по математике",
    "Проверка домашнего задания",
    "Открытие Яндекс.Здоровье",
    "Запись к врачу через приложение",
    "Просмотр результатов анализов",
    "Открытие Яндекс.Кинопоиск",
    "Поиск фильма для просмотра",
    "Чтение рецензий на фильм",
    "Добавление фильма в список 'Хочу посмотреть'",
    "Открытие Яндекс.Афиша",
    "Поиск концертов в городе",
    "Покупка билета на спектакль",
    "Открытие Яндекс.Авто",
    "Поиск автомобиля для покупки",
    "Сравнение характеристик машин",
    "Открытие Яндекс.Недвижимость",
    "Поиск квартиры для аренды",
    "Просмотр фотографий квартиры",
    "Открытие Яндекс.Путешествия",
    "Поиск отеля для отпуска",
    "Бронирование номера в гостинице",
    "Открытие Яндекс.Погода",
    "Просмотр прогноза на неделю",
    "Проверка давления и влажности"
  ];

  const cities = [
    "Москва", "Санкт-Петербург", "Новосибирск", "Екатеринбург", "Казань", "Нижний Новгород", 
    "Челябинск", "Самара", "Омск", "Ростов-на-Дону", "Уфа", "Красноярск", "Пермь", "Воронеж", 
    "Волгоград", "Саратов", "Тюмень", "Тольятти", "Ижевск", "Барнаул", "Иркутск", "Кемерово", 
    "Ярославль", "Томск", "Оренбург", "Курск", "Киров", "Ставрополь", "Липецк", "Тула"
  ];

  useEffect(() => {
    if (terminalRef.current) {
      terminalRef.current.scrollTop = terminalRef.current.scrollHeight;
    }
  }, [logs]);

  useEffect(() => {
    if (isRunning) {
      let logIndex = 0;
      let processIndex = 0;
      
      const addLog = () => {
        if (logIndex < mockLogs.length) {
          // Initial setup logs
          const log = mockLogs[logIndex];
          const newLog: LogEntry = {
            id: Date.now().toString() + logIndex,
            timestamp: new Date().toLocaleTimeString(),
            type: log.type as LogEntry['type'],
            message: log.message,
            details: log.details
          };
          
          setLogs(prev => [...prev, newLog]);
          logIndex++;
          
          // Update current process
          if (Math.random() > 0.7) {
            setCurrentProcess(processNames[processIndex % processNames.length]);
            processIndex++;
          }
          
          const delay = Math.random() * 1700 + 800;
          setTimeout(addLog, delay);
        } else {
          // Switch to continuous account activity logs
          setCurrentProcess('ACTIVE_MONITORING');
          startContinuousLogs();
        }
      };
      
      const startContinuousLogs = () => {
        const addAccountLog = () => {
          if (!isRunning) return;
          
          const accountId = Math.floor(Math.random() * 130) + 1;
          const paddedId = accountId.toString().padStart(8, '0');
          const action = yandexActions[Math.floor(Math.random() * yandexActions.length)];
          const city = cities[Math.floor(Math.random() * cities.length)];
          const split = [50, 75, 100][Math.floor(Math.random() * 3)] + 'k';
          
          const logTypes = ['info', 'success', 'warning'];
          const weights = [0.8, 0.15, 0.05];
          const randomType = logTypes[
            weights.reduce((acc, weight, i) => 
              Math.random() < acc + weight ? i : acc + weight, 0
            )
          ];
          
          const newLog: LogEntry = {
            id: Date.now().toString() + Math.random(),
            timestamp: new Date().toLocaleTimeString(),
            type: randomType as LogEntry['type'],
            message: `[ACC-${paddedId}] | ${city} | ${action}`,
            details: `Split: ${split}, Browser: ${['Chrome', 'Firefox', 'Yandex Browser', 'Edge'][Math.floor(Math.random() * 4)]}`
          };
          
          setLogs(prev => {
            const newLogs = [...prev, newLog];
            // Keep only last 100 logs for performance
            return newLogs.length > 100 ? newLogs.slice(-100) : newLogs;
          });
          
          // Ultra fast interval between 38-88ms (в 4 раза быстрее)
          const delay = Math.random() * 50 + 38;
          setTimeout(addAccountLog, delay);
        };
        
        addAccountLog();
      };
      
      addLog();
    }
  }, [isRunning]);

  const startWarmup = () => {
    setLogs([]);
    setIsRunning(true);
    setCurrentProcess('INITIALIZING');
  };

  const stopWarmup = () => {
    setIsRunning(false);
    setCurrentProcess('STOPPED');
  };

  const getLogColor = (type: LogEntry['type']) => {
    switch (type) {
      case 'success': return 'text-green-400';
      case 'error': return 'text-red-400';
      case 'warning': return 'text-yellow-400';
      case 'system': return 'text-cyan-400';
      default: return 'text-gray-300';
    }
  };

  const getLogIcon = (type: LogEntry['type']) => {
    switch (type) {
      case 'success': return '✓';
      case 'error': return '✗';
      case 'warning': return '⚠';
      case 'system': return '⚡';
      default: return '→';
    }
  };

  return (
    <div className="space-y-4">
      {/* Control Panel */}
      <Card className="bg-gray-900 border-gray-700">
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle className="text-green-400 font-mono flex items-center gap-2">
              <Terminal className="w-5 h-5" />
              WARMUP CONTROL TERMINAL
            </CardTitle>
            <div className="flex items-center gap-3">
              <Badge 
                variant={isRunning ? "default" : "secondary"}
                className={`font-mono ${isRunning ? 'bg-green-500/20 text-green-400 border-green-500/30' : 'bg-gray-500/20 text-gray-400 border-gray-500/30'}`}
              >
                <Activity className={`w-3 h-3 mr-1 ${isRunning ? 'animate-pulse' : ''}`} />
                {isRunning ? 'RUNNING' : 'IDLE'}
              </Badge>
              {currentProcess && (
                <Badge className="bg-blue-500/20 text-blue-400 border-blue-500/30 font-mono">
                  {currentProcess}
                </Badge>
              )}
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="flex gap-3">
            <Button
              onClick={startWarmup}
              disabled={isRunning}
              className="bg-green-600 hover:bg-green-700 text-white font-mono"
            >
              <Play className="w-4 h-4 mr-2" />
              START WARMUP
            </Button>
            <Button
              onClick={stopWarmup}
              disabled={!isRunning}
              variant="destructive"
              className="font-mono"
            >
              <Square className="w-4 h-4 mr-2" />
              STOP
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Terminal Window */}
      <Card className="bg-black border-green-500/30 shadow-lg shadow-green-500/10">
        <CardHeader className="bg-gray-900 border-b border-green-500/30 py-2">
          <div className="flex items-center gap-2">
            <div className="flex gap-1">
              <div className="w-3 h-3 rounded-full bg-red-500"></div>
              <div className="w-3 h-3 rounded-full bg-yellow-500"></div>
              <div className="w-3 h-3 rounded-full bg-green-500"></div>
            </div>
            <span className="text-green-400 font-mono text-sm ml-2">
              root@warmup-server:~$
            </span>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <div 
            ref={terminalRef}
            className="h-96 overflow-y-auto bg-black p-4 font-mono text-sm leading-relaxed scrollbar-thin scrollbar-track-gray-900 scrollbar-thumb-green-500/30"
          >
            <AnimatePresence>
              {logs.map((log, index) => (
                <motion.div
                  key={log.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.3 }}
                  className="mb-2"
                >
                  <div className="flex items-start gap-2">
                    <span className="text-gray-500 text-xs min-w-[80px]">
                      [{log.timestamp}]
                    </span>
                    <span className={`${getLogColor(log.type)} min-w-[20px]`}>
                      {getLogIcon(log.type)}
                    </span>
                    <span className={getLogColor(log.type)}>
                      {log.message}
                    </span>
                  </div>
                  {log.details && (
                    <div className="ml-[110px] text-gray-500 text-xs mt-1">
                      └─ {log.details}
                    </div>
                  )}
                </motion.div>
              ))}
            </AnimatePresence>
            
            {/* Blinking cursor when running */}
            {isRunning && (
              <motion.div 
                className="flex items-center gap-2 mt-2"
                animate={{ opacity: [1, 0] }}
                transition={{ duration: 1, repeat: Infinity }}
              >
                <span className="text-gray-500 text-xs">[{new Date().toLocaleTimeString()}]</span>
                <span className="text-green-400">▊</span>
              </motion.div>
            )}
            
            {/* Welcome message when empty */}
            {logs.length === 0 && !isRunning && (
              <div className="text-green-400">
                <div className="mb-2">╔══════════════════════════════════════════════════════════╗</div>
                <div className="mb-2">║           WARMUP TERMINAL v2.1.0 - READY               ║</div>
                <div className="mb-2">║                                                          ║</div>
                <div className="mb-2">║  Press 'START WARMUP' to begin account warmup process   ║</div>
                <div className="mb-2">║  Status: System ready for deployment                     ║</div>
                <div className="mb-2">╚══════════════════════════════════════════════════════════╝</div>
                <div className="mt-4 text-gray-500">
                  root@warmup-server:~$ _
                </div>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default HackerTerminal;