import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { CreditCard, Save, Copy, Check } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

const BankCardAdmin = () => {
  const { toast } = useToast();
  const [bankCard, setBankCard] = useState('2202208256650426');
  const [newCard, setNewCard] = useState('');
  const [copied, setCopied] = useState(false);

  const handleSave = () => {
    if (newCard.length >= 16) {
      setBankCard(newCard);
      setNewCard('');
      toast({
        title: "Карта обновлена",
        description: "Номер банковской карты успешно изменен",
        variant: "default"
      });
    } else {
      toast({
        title: "Ошибка",
        description: "Номер карты должен содержать минимум 16 цифр",
        variant: "destructive"
      });
    }
  };

  const copyToClipboard = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
      toast({
        title: "Скопировано",
        description: "Номер карты скопирован в буфер обмена",
        variant: "default"
      });
    } catch (err) {
      console.error('Failed to copy: ', err);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center space-x-3">
        <CreditCard className="w-6 h-6 text-primary" />
        <h2 className="text-2xl font-bold">Управление банковской картой</h2>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Current Card */}
        <Card>
          <CardHeader>
            <CardTitle>Текущая карта для пополнений</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between p-4 bg-muted/20 rounded-lg border">
              <div className="flex items-center space-x-3">
                <CreditCard className="w-5 h-5 text-primary" />
                <div>
                  <p className="text-sm text-muted-foreground">Номер карты</p>
                  <p className="text-lg font-mono font-bold">{bankCard}</p>
                </div>
              </div>
              <Button
                size="sm"
                variant="outline"
                onClick={() => copyToClipboard(bankCard)}
                className="border-primary/30 text-primary hover:bg-primary/10"
              >
                {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
              </Button>
            </div>
            
            <div className="p-3 bg-blue-500/10 rounded-lg border border-blue-500/20">
              <p className="text-sm text-blue-400">
                Эта карта используется для всех банковских переводов при пополнении баланса пользователями
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Update Card */}
        <Card>
          <CardHeader>
            <CardTitle>Изменить номер карты</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="newCard">Новый номер карты</Label>
              <Input
                id="newCard"
                type="text"
                placeholder="Введите новый номер карты"
                value={newCard}
                onChange={(e) => setNewCard(e.target.value.replace(/\D/g, ''))}
                maxLength={20}
                className="font-mono"
              />
              <p className="text-xs text-muted-foreground">
                Только цифры, минимум 16 символов
              </p>
            </div>

            <Button 
              onClick={handleSave}
              disabled={newCard.length < 16}
              className="w-full"
            >
              <Save className="w-4 h-4 mr-2" />
              Сохранить изменения
            </Button>

            <div className="p-3 bg-amber-500/10 rounded-lg border border-amber-500/20">
              <p className="text-sm text-amber-400">
                Внимание: После изменения номера карты, все новые пополнения будут использовать новые реквизиты
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export { BankCardAdmin };
export default BankCardAdmin;