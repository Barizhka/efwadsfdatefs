import React from 'react';

interface NetworkNodeType {
  id: string;
  type: 'server' | 'proxy' | 'account' | 'service';
  label: string;
  x: number;
  y: number;
  status: 'active' | 'warning' | 'error';
  connections: string[];
  load?: number;
  latency?: number;
}

interface NetworkConnection {
  from: string;
  to: string;
  status: 'active' | 'warning' | 'error';
  bandwidth: number;
  packets: number;
}

interface NetworkTopologyProps {
  nodes: NetworkNodeType[];
  connections: NetworkConnection[];
}

const NetworkTopology: React.FC<NetworkTopologyProps> = ({ nodes, connections }) => {
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'hsl(var(--chart-2))';
      case 'warning': return 'hsl(var(--chart-3))';
      case 'error': return 'hsl(var(--destructive))';
      default: return 'hsl(var(--muted))';
    }
  };

  const getNodeIcon = (type: string) => {
    switch (type) {
      case 'server': return '█';
      case 'proxy': return '▲';
      case 'account': return '●';
      case 'service': return '◆';
      default: return '■';
    }
  };

  return (
    <div className="relative w-full h-[300px] bg-background/50 rounded border border-border overflow-hidden">
      {/* Grid pattern */}
      <div className="absolute inset-0 opacity-20">
        <svg width="100%" height="100%">
          <defs>
            <pattern id="grid" width="20" height="20" patternUnits="userSpaceOnUse">
              <path d="M 20 0 L 0 0 0 20" fill="none" stroke="hsl(var(--muted-foreground))" strokeWidth="0.5"/>
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#grid)" />
        </svg>
      </div>

      {/* Connections */}
      <svg width="100%" height="100%" className="absolute inset-0">
        {connections.map((conn, index) => {
          const fromNode = nodes.find(n => n.id === conn.from);
          const toNode = nodes.find(n => n.id === conn.to);
          if (!fromNode || !toNode) return null;

          const x1 = (fromNode.x / 100) * 100;
          const y1 = (fromNode.y / 100) * 100;
          const x2 = (toNode.x / 100) * 100;
          const y2 = (toNode.y / 100) * 100;

          return (
            <g key={index}>
              <line
                x1={`${x1}%`}
                y1={`${y1}%`}
                x2={`${x2}%`}
                y2={`${y2}%`}
                stroke={getStatusColor(conn.status)}
                strokeWidth={Math.max(1, conn.bandwidth / 50)}
                opacity={0.7}
              />
              {/* Data flow indicator */}
              {conn.status === 'active' && (
                <circle r="1" fill={getStatusColor(conn.status)}>
                  <animateMotion
                    dur="2s"
                    repeatCount="indefinite"
                    path={`M${x1},${y1} L${x2},${y2}`}
                  />
                </circle>
              )}
            </g>
          );
        })}
      </svg>

      {/* Nodes */}
      {nodes.map((node) => (
        <div
          key={node.id}
          className="absolute transform -translate-x-1/2 -translate-y-1/2 group"
          style={{
            left: `${node.x}%`,
            top: `${node.y}%`,
          }}
        >
          <div 
            className="flex items-center justify-center w-4 h-4 text-xs font-mono"
            style={{ color: getStatusColor(node.status) }}
            title={`${node.label} (${node.status})`}
          >
            {getNodeIcon(node.type)}
          </div>
          
          {/* Node info on hover */}
          <div className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-1 px-2 py-1 bg-popover border border-border rounded text-xs opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap z-10">
            <div className="font-medium">{node.label}</div>
            {node.load !== undefined && <div>Load: {node.load}%</div>}
            {node.latency !== undefined && <div>Latency: {node.latency}ms</div>}
          </div>
        </div>
      ))}
    </div>
  );
};

export default NetworkTopology;