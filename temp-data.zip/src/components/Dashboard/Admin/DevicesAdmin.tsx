import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { 
  Smartphone,
  Tablet,
  Monitor,
  Plus,
  Settings,
  Trash2,
  Battery,
  Cpu,
  HardDrive
} from 'lucide-react';

interface Device {
  id: string;
  name: string;
  type: 'phone' | 'tablet' | 'desktop';
  model: string;
  os: string;
  osVersion: string;
  status: 'active' | 'inactive' | 'maintenance';
  battery: number;
  cpu: number;
  memory: number;
  storage: number;
  resolution: string;
  assignedAccounts: number;
}

const mockDevices: Device[] = [
  {
    id: 'dev_001',
    name: 'iPhone 14 Pro',
    type: 'phone',
    model: 'iPhone 14 Pro',
    os: 'iOS',
    osVersion: '16.4.1',
    status: 'active',
    battery: 89,
    cpu: 45,
    memory: 67,
    storage: 52,
    resolution: '2556×1179',
    assignedAccounts: 12
  },
  {
    id: 'dev_002',
    name: 'Samsung Galaxy S23',
    type: 'phone',
    model: 'Galaxy S23 Ultra',
    os: 'Android',
    osVersion: '13.0',
    status: 'active',
    battery: 76,
    cpu: 32,
    memory: 58,
    storage: 68,
    resolution: '3088×1440',
    assignedAccounts: 8
  },
  {
    id: 'dev_003',
    name: 'iPad Pro',
    type: 'tablet',
    model: 'iPad Pro 12.9"',
    os: 'iPadOS',
    osVersion: '16.4',
    status: 'maintenance',
    battery: 0,
    cpu: 0,
    memory: 0,
    storage: 45,
    resolution: '2732×2048',
    assignedAccounts: 0
  }
];

export const DevicesAdmin = () => {
  const [devices, setDevices] = useState(mockDevices);

  const getDeviceIcon = (type: string) => {
    switch (type) {
      case 'phone': return <Smartphone className="w-4 h-4" />;
      case 'tablet': return <Tablet className="w-4 h-4" />;
      case 'desktop': return <Monitor className="w-4 h-4" />;
      default: return <Smartphone className="w-4 h-4" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'text-green-400 bg-green-400/20';
      case 'inactive': return 'text-yellow-400 bg-yellow-400/20';
      case 'maintenance': return 'text-red-400 bg-red-400/20';
      default: return 'text-gray-400 bg-gray-400/20';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'active': return 'Активно';
      case 'inactive': return 'Неактивно';
      case 'maintenance': return 'Обслуживание';
      default: return status;
    }
  };

  const stats = [
    { label: 'Всего устройств', value: devices.length, icon: Smartphone, color: 'text-blue-400' },
    { label: 'Активные', value: devices.filter(d => d.status === 'active').length, icon: Battery, color: 'text-green-400' },
    { label: 'На обслуживании', value: devices.filter(d => d.status === 'maintenance').length, icon: Settings, color: 'text-red-400' },
    { label: 'Аккаунтов назначено', value: devices.reduce((sum, d) => sum + d.assignedAccounts, 0), icon: Cpu, color: 'text-primary' }
  ];

  return (
    <div className="space-y-6">
      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat, index) => (
          <motion.div
            key={stat.label}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: index * 0.1 }}
          >
            <Card className="bg-card/80 backdrop-blur-sm border-border/50">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">{stat.label}</p>
                    <p className={`text-2xl font-bold ${stat.color}`}>{stat.value}</p>
                  </div>
                  <stat.icon className={`w-8 h-8 ${stat.color}`} />
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      {/* Device Management */}
      <Card className="bg-card/80 backdrop-blur-sm border-border/50">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>Управление устройствами</CardTitle>
            <div className="flex items-center space-x-3">
              <Button className="bg-primary hover:bg-primary/90">
                <Plus className="w-4 h-4 mr-2" />
                Добавить устройство
              </Button>
              <Button variant="outline">
                <Settings className="w-4 h-4 mr-2" />
                Настройки
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {devices.map((device) => (
              <motion.div
                key={device.id}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.3 }}
              >
                <Card className="bg-card/60 border-border/30 hover:bg-card/80 transition-colors">
                  <CardContent className="p-4">
                    <div className="space-y-4">
                      {/* Header */}
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-2">
                          {getDeviceIcon(device.type)}
                          <div>
                            <p className="font-medium text-sm">{device.name}</p>
                            <p className="text-xs text-muted-foreground">{device.model}</p>
                          </div>
                        </div>
                        <Badge className={`${getStatusColor(device.status)} text-xs`}>
                          {getStatusText(device.status)}
                        </Badge>
                      </div>

                      {/* OS Info */}
                      <div className="text-sm">
                        <p className="text-muted-foreground">ОС: {device.os} {device.osVersion}</p>
                        <p className="text-muted-foreground">Разрешение: {device.resolution}</p>
                        <p className="text-muted-foreground">Аккаунтов: {device.assignedAccounts}</p>
                      </div>

                      {/* Performance Metrics */}
                      {device.status === 'active' && (
                        <div className="space-y-3">
                          {/* Battery */}
                          <div>
                            <div className="flex justify-between items-center mb-1">
                              <div className="flex items-center space-x-1">
                                <Battery className="w-3 h-3 text-muted-foreground" />
                                <span className="text-xs text-muted-foreground">Батарея</span>
                              </div>
                              <span className="text-xs font-medium">{device.battery}%</span>
                            </div>
                            <div className="w-full bg-muted/30 rounded-full h-1.5">
                              <div 
                                className="bg-green-400 h-1.5 rounded-full transition-all duration-300" 
                                style={{ width: `${device.battery}%` }}
                              />
                            </div>
                          </div>

                          {/* CPU */}
                          <div>
                            <div className="flex justify-between items-center mb-1">
                              <div className="flex items-center space-x-1">
                                <Cpu className="w-3 h-3 text-muted-foreground" />
                                <span className="text-xs text-muted-foreground">CPU</span>
                              </div>
                              <span className="text-xs font-medium">{device.cpu}%</span>
                            </div>
                            <div className="w-full bg-muted/30 rounded-full h-1.5">
                              <div 
                                className="bg-blue-400 h-1.5 rounded-full transition-all duration-300" 
                                style={{ width: `${device.cpu}%` }}
                              />
                            </div>
                          </div>

                          {/* Memory */}
                          <div>
                            <div className="flex justify-between items-center mb-1">
                              <div className="flex items-center space-x-1">
                                <HardDrive className="w-3 h-3 text-muted-foreground" />
                                <span className="text-xs text-muted-foreground">Память</span>
                              </div>
                              <span className="text-xs font-medium">{device.memory}%</span>
                            </div>
                            <div className="w-full bg-muted/30 rounded-full h-1.5">
                              <div 
                                className="bg-purple-400 h-1.5 rounded-full transition-all duration-300" 
                                style={{ width: `${device.memory}%` }}
                              />
                            </div>
                          </div>
                        </div>
                      )}

                      {/* Actions */}
                      <div className="flex items-center space-x-2 pt-2">
                        <Button size="sm" variant="outline" className="flex-1 h-8">
                          <Settings className="w-3 h-3 mr-1" />
                          Настроить
                        </Button>
                        <Button size="sm" variant="destructive" className="h-8 px-3">
                          <Trash2 className="w-3 h-3" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};