import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { useAppStore } from '@/store/appStore';
import { 
  Activity, 
  Cpu, 
  HardDrive, 
  Network, 
  Zap,
  Eye,
  Shield,
  AlertTriangle
} from 'lucide-react';

interface SystemMetric {
  label: string;
  value: number;
  max: number;
  unit: string;
  color: string;
  status: 'optimal' | 'warning' | 'critical';
}

const SystemMonitor = () => {
  const { purchasedAccounts, isWarmupActive } = useAppStore();
  const [metrics, setMetrics] = useState<SystemMetric[]>([
    { label: 'CPU Load', value: 0, max: 100, unit: '%', color: 'text-green-400', status: 'optimal' },
    { label: 'Memory Usage', value: 0, max: 100, unit: '%', color: 'text-yellow-400', status: 'warning' },
    { label: 'Network I/O', value: 0, max: 1000, unit: 'MB/s', color: 'text-blue-400', status: 'optimal' },
    { label: 'Active Accounts', value: 0, max: 1000, unit: '', color: 'text-purple-400', status: 'optimal' },
    { label: 'Proxy Pool', value: 0, max: 100, unit: '%', color: 'text-cyan-400', status: 'optimal' },
    { label: 'Success Rate', value: 0, max: 100, unit: '%', color: 'text-green-400', status: 'optimal' }
  ]);

  const [activeConnections, setActiveConnections] = useState([
    { id: 'yandex-mail', service: 'Яндекс.Почта', count: 0, status: 'inactive' },
    { id: 'yandex-maps', service: 'Яндекс.Карты', count: 0, status: 'inactive' },
    { id: 'yandex-market', service: 'Яндекс.Маркет', count: 0, status: 'inactive' },
    { id: 'yandex-music', service: 'Яндекс.Музыка', count: 0, status: 'inactive' },
    { id: 'yandex-dzen', service: 'Яндекс.Дзен', count: 0, status: 'inactive' },
    { id: 'yandex-browser', service: 'Яндекс.Браузер', count: 0, status: 'inactive' }
  ]);

  // Update metrics based on warmup status
  useEffect(() => {
    const hasActiveWarmup = purchasedAccounts.some(account => account.warmupStarted) || isWarmupActive;
    
    if (!hasActiveWarmup) {
      // Reset all metrics to 0 when no warmup is active
      setMetrics(prev => prev.map(metric => ({ ...metric, value: 0 })));
      setActiveConnections(prev => prev.map(conn => ({ ...conn, count: 0, status: 'inactive' })));
      return;
    }

    // Generate dynamic values when warmup is active
    const interval = setInterval(() => {
      setMetrics(prev => prev.map(metric => {
        let newValue;
        switch (metric.label) {
          case 'CPU Load':
            newValue = Math.max(12, Math.min(99, 45 + (Math.random() - 0.5) * 20));
            break;
          case 'Memory Usage':
            newValue = Math.max(12, Math.min(99, 58 + (Math.random() - 0.5) * 20));
            break;
          case 'Network I/O':
            newValue = Math.max(12, Math.min(800, 234 + (Math.random() - 0.5) * 100));
            break;
          case 'Active Accounts':
            newValue = Math.max(1, purchasedAccounts.filter(acc => acc.warmupStarted).length * (50 + Math.random() * 100));
            break;
          case 'Proxy Pool':
            newValue = Math.max(12, Math.min(99, 89 + (Math.random() - 0.5) * 10));
            break;
          case 'Success Rate':
            newValue = Math.max(85, Math.min(99, 97.3 + (Math.random() - 0.5) * 2));
            break;
          default:
            newValue = metric.value;
        }
        return { ...metric, value: newValue };
      }));

      // Update connection counts
      setActiveConnections(prev => prev.map(conn => ({
        ...conn,
        count: Math.max(12, Math.min(400, 156 + (Math.random() - 0.5) * 100)),
        status: 'active'
      })));
    }, 3000);

    return () => clearInterval(interval);
  }, [purchasedAccounts, isWarmupActive]);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'text-green-400';
      case 'warning': return 'text-yellow-400';
      case 'critical': return 'text-red-400';
      case 'inactive': return 'text-gray-400';
      default: return 'text-gray-400';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'optimal': return <Shield className="w-4 h-4 text-green-400" />;
      case 'warning': return <AlertTriangle className="w-4 h-4 text-yellow-400" />;
      case 'critical': return <Zap className="w-4 h-4 text-red-400" />;
      default: return <Activity className="w-4 h-4 text-gray-400" />;
    }
  };

  const hasActiveWarmup = purchasedAccounts.some(account => account.warmupStarted) || isWarmupActive;

  return (
    <div className="space-y-6">
      {/* System Metrics Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {metrics.map((metric, index) => (
          <motion.div
            key={metric.label}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
          >
            <Card className="bg-background/40 border border-border/50 backdrop-blur-sm">
              <CardContent className="p-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm text-muted-foreground">{metric.label}</span>
                  {getStatusIcon(metric.status)}
                </div>
                <div className="flex items-baseline space-x-2 mb-2">
                  <span className={`text-2xl font-mono font-bold ${hasActiveWarmup ? metric.color : 'text-gray-400'}`}>
                    {metric.value.toFixed(metric.unit === '%' ? 1 : 0)}
                  </span>
                  <span className="text-sm text-muted-foreground">{metric.unit}</span>
                </div>
                <Progress 
                  value={(metric.value / metric.max) * 100} 
                  className="h-2"
                />
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      {/* Active Services */}
      <Card className="bg-background/40 border border-border/50 backdrop-blur-sm">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Network className="w-5 h-5 text-blue-400" />
            <span>Активные подключения к сервисам</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          {!hasActiveWarmup ? (
            <div className="text-center py-8">
              <div className="w-16 h-16 bg-gray-700 rounded-full flex items-center justify-center mx-auto mb-4">
                <Network className="w-8 h-8 text-gray-500" />
              </div>
              <p className="text-gray-400">Подключения неактивны</p>
              <p className="text-sm text-gray-500">Сервисы активируются при запуске прогрева</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {activeConnections.map((connection, index) => (
                <motion.div
                  key={connection.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className="flex items-center justify-between p-3 rounded-lg bg-card/30 border border-border/30"
                >
                  <div className="flex items-center space-x-3">
                    <div className={`w-2 h-2 rounded-full ${connection.status === 'active' ? 'bg-green-400 animate-pulse' : 'bg-gray-400'}`} />
                    <span className="text-sm font-medium">{connection.service}</span>
                  </div>
                  <Badge variant="outline" className={getStatusColor(connection.status)}>
                    {connection.count}
                  </Badge>
                </motion.div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Real-time Activity Feed */}
      <Card className="bg-background/40 border border-border/50 backdrop-blur-sm">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Eye className="w-5 h-5 text-purple-400" />
            <span>Мониторинг активности в реальном времени</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          {!hasActiveWarmup ? (
            <div className="text-center py-8">
              <div className="w-16 h-16 bg-gray-700 rounded-full flex items-center justify-center mx-auto mb-4">
                <Eye className="w-8 h-8 text-gray-500" />
              </div>
              <p className="text-gray-400">Мониторинг неактивен</p>
              <p className="text-sm text-gray-500">Логи активности появятся при запуске прогрева</p>
            </div>
          ) : (
            <div className="space-y-2 max-h-60 overflow-y-auto font-mono text-xs">
              {Array.from({ length: 15 }, (_, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: i * 0.05 }}
                  className="flex items-center space-x-3 text-muted-foreground"
                >
                  <span className="text-green-400">{new Date().toLocaleTimeString()}</span>
                  <span className="text-cyan-400">[SRV-{(i % 5) + 1}]</span>
                  <span>Account #{String(Math.floor(Math.random() * 1000)).padStart(3, '0')} → {
                    ['Яндекс.Почта', 'Яндекс.Карты', 'Яндекс.Маркет', 'Яндекс.Музыка'][i % 4]
                  }</span>
                  <Badge variant="outline" className="text-green-400 text-xs">OK</Badge>
                </motion.div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default SystemMonitor;