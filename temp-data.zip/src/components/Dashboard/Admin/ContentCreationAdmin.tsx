import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Eye, Zap, Ghost, Skull, Play, Pause, Heart, Brain, DollarSign, Sparkles, Moon, Target, ChevronDown, ChevronUp } from 'lucide-react';

type StyleType = 'tokyo-ghoul' | 'light-anime' | 'depression' | 'emotionless' | 'rich-peace' | 'temshik';

// FAQ Component with Symbiot Edit Style
const SymbiotFAQ = () => {
  const [activeIndex, setActiveIndex] = useState<number | null>(null);
  const [symbiotActive, setSymbiotActive] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);

  useEffect(() => {
    if (isPlaying) {
      const interval = setInterval(() => {
        setSymbiotActive(true);
        setTimeout(() => setSymbiotActive(false), 300);
      }, 1500);
      return () => clearInterval(interval);
    }
  }, [isPlaying]);

  const faqData = [
    {
      question: "Мне нужно заходить в аккаунт и что то привязывать?",
      answer: "Все манипуляции с аккаунтом производятся через сайт. Все расходники на нас, и они уже включены в стоимость аккаунта."
    },
    {
      question: "А карту для оплаты сплита свою привязывать надо будет?",
      answer: "К каждому аккаунту уже подключен верифицированный Яндекс Пей, оплата производится оттуда, ваша карта не потребуется."
    },
    {
      question: "Как начать прогрев? Как заказать товар?",
      answer: "После покупки аккаунта вам откроется функционал для прогрева. Вы запускаете его, так же через сайт, и по его завершению (через 3-5 дней), в соответствующей вкладке вам откроется функционал для заказа товара. Вы укажете адрес, способ получения и ссылку на товар."
    },
    {
      question: "А тема вообще белая?",
      answer: "Мы используем только обычные сплит аккаунты (не улучшенные) - они не попадают под УК, так как сплит без документов не является кредитным продуктом."
    },
    {
      question: "А можно прогреть через ваш софт свой личный аккаунт?",
      answer: "Для прогрева в нашей ферме мы используем только личные аккаунты."
    }
  ];

  const symbiotVariants = {
    normal: {
      background: "linear-gradient(135deg, #1a0033, #2d1b69, #0f3460, #1a0033)",
      boxShadow: "0 0 20px rgba(45, 27, 105, 0.3)",
      border: "1px solid rgba(15, 52, 96, 0.4)"
    },
    active: {
      background: [
        "linear-gradient(135deg, #1a0033, #2d1b69, #0f3460, #1a0033)",
        "linear-gradient(135deg, #2d1b69, #0f3460, #00ffff, #2d1b69)",
        "linear-gradient(135deg, #0f3460, #1a0033, #2d1b69, #0f3460)",
        "linear-gradient(135deg, #1a0033, #2d1b69, #0f3460, #1a0033)"
      ],
      boxShadow: [
        "0 0 20px rgba(45, 27, 105, 0.3)",
        "0 0 40px rgba(0, 255, 255, 0.5)",
        "0 0 60px rgba(45, 27, 105, 0.7)",
        "0 0 20px rgba(45, 27, 105, 0.3)"
      ],
      border: [
        "1px solid rgba(15, 52, 96, 0.4)",
        "1px solid rgba(0, 255, 255, 0.8)",
        "1px solid rgba(45, 27, 105, 0.6)",
        "1px solid rgba(15, 52, 96, 0.4)"
      ],
      transition: { duration: 0.3, times: [0, 0.33, 0.66, 1] }
    }
  };

  return (
    <div className="space-y-4">
      {/* Control Panel for FAQ */}
      <Card className="bg-black/90 border-cyan-500/30 backdrop-blur-sm">
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-bold text-cyan-400">Symbiot FAQ Control</h2>
            <div className="flex items-center space-x-4">
              <Button
                onClick={() => setIsPlaying(!isPlaying)}
                variant="outline"
                className="border-cyan-500/50 text-cyan-400 hover:bg-cyan-500/20"
              >
                {isPlaying ? (
                  <>
                    <Pause className="w-4 h-4 mr-2" />
                    Деактивировать Симбиот
                  </>
                ) : (
                  <>
                    <Play className="w-4 h-4 mr-2" />
                    Активировать Симбиот
                  </>
                )}
              </Button>
              <div className="flex items-center space-x-2">
                <motion.div
                  animate={isPlaying ? {
                    scale: [1, 1.3, 1],
                    opacity: [0.7, 1, 0.7]
                  } : {}}
                  transition={{ duration: 1.5, repeat: Infinity }}
                  className="w-3 h-3 bg-cyan-400 rounded-full"
                />
                <span className="text-sm text-muted-foreground">
                  {isPlaying ? "Симбиот активен" : "Симбиот в режиме сна"}
                </span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Symbiot Header */}
      <motion.div
        variants={symbiotVariants}
        animate={symbiotActive && isPlaying ? "active" : "normal"}
        className="relative p-6 rounded-lg overflow-hidden"
      >
        {/* Animated background particles */}
        <div className="absolute inset-0 overflow-hidden">
          {isPlaying && [...Array(8)].map((_, i) => (
            <motion.div
              key={i}
              className="absolute w-1 h-1 bg-cyan-400 rounded-full"
              animate={{
                x: [Math.random() * 100 + "%", Math.random() * 100 + "%"],
                y: [Math.random() * 100 + "%", Math.random() * 100 + "%"],
                opacity: [0, 1, 0],
                scale: [0, 1.5, 0]
              }}
              transition={{
                duration: 3 + Math.random() * 2,
                repeat: Infinity,
                delay: Math.random() * 2
              }}
            />
          ))}
          
          {/* Scanning line */}
          {isPlaying && (
            <motion.div
              className="absolute inset-x-0 h-0.5 bg-gradient-to-r from-transparent via-cyan-400 to-transparent opacity-60"
              animate={{ y: ["0%", "100%"] }}
              transition={{ duration: 4, repeat: Infinity, ease: "linear" }}
            />
          )}
        </div>

        <div className="relative z-10">
          <motion.h2
            animate={symbiotActive && isPlaying ? {
              textShadow: [
                "0 0 10px rgba(0, 255, 255, 0.5)",
                "0 0 30px rgba(0, 255, 255, 1)",
                "0 0 50px rgba(45, 27, 105, 0.8)",
                "0 0 10px rgba(0, 255, 255, 0.5)"
              ],
              color: ["#ffffff", "#00ffff", "#ffffff", "#ffffff"],
              scale: [1, 1.05, 1, 1]
            } : {}}
            transition={{ duration: 0.3 }}
            className="text-2xl font-bold text-center text-white mb-2"
          >
            SYMBIOT FAQ SYSTEM
          </motion.h2>
          <motion.p 
            animate={isPlaying ? {
              opacity: [0.6, 1, 0.6]
            } : {}}
            transition={{ duration: 2, repeat: Infinity }}
            className="text-center text-cyan-200/80 text-sm"
          >
            {isPlaying ? "Нейронная база знаний — Симбиот отвечает" : "Симбиот в режиме ожидания"}
          </motion.p>
        </div>
      </motion.div>

      {/* FAQ Items */}
      {faqData.map((item, index) => (
        <motion.div
          key={index}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: index * 0.1 }}
        >
          <motion.div
            className="relative overflow-hidden rounded-lg cursor-pointer"
            whileHover={{ scale: 1.02 }}
            animate={isPlaying ? {
              boxShadow: [
                "0 0 20px rgba(0, 255, 255, 0.2)",
                "0 0 40px rgba(0, 255, 255, 0.4)",
                "0 0 20px rgba(0, 255, 255, 0.2)"
              ]
            } : {}}
            transition={{ duration: 2, repeat: Infinity, delay: index * 0.2 }}
            style={{
              background: "linear-gradient(135deg, rgba(26, 0, 51, 0.8), rgba(45, 27, 105, 0.6), rgba(15, 52, 96, 0.4))",
              border: "1px solid rgba(0, 255, 255, 0.2)"
            }}
            onClick={() => setActiveIndex(activeIndex === index ? null : index)}
          >
            {/* Liquid effect background */}
            <motion.div
              className="absolute inset-0 opacity-20"
              animate={isPlaying ? {
                background: [
                  "radial-gradient(circle at 20% 50%, #00ffff, transparent 50%)",
                  "radial-gradient(circle at 80% 50%, #2d1b69, transparent 50%)",
                  "radial-gradient(circle at 50% 80%, #0f3460, transparent 50%)",
                  "radial-gradient(circle at 20% 50%, #00ffff, transparent 50%)"
                ]
              } : {}}
              transition={{ duration: 4, repeat: Infinity }}
            />

            <div className="relative z-10 p-4">
              <div className="flex items-center justify-between">
                <motion.h3 
                  className="text-white font-medium pr-4"
                  animate={isPlaying ? {
                    textShadow: [
                      "0 0 5px rgba(255, 255, 255, 0.5)",
                      "0 0 15px rgba(0, 255, 255, 0.8)",
                      "0 0 5px rgba(255, 255, 255, 0.5)"
                    ]
                  } : {}}
                  transition={{ duration: 3, repeat: Infinity, delay: index * 0.3 }}
                  style={{ textShadow: "2px 2px 4px rgba(0, 0, 0, 0.8)" }}
                >
                  {item.question}
                </motion.h3>
                <motion.div
                  animate={{ 
                    rotate: activeIndex === index ? 180 : 0,
                    color: isPlaying && activeIndex === index ? ["#06b6d4", "#00ffff", "#06b6d4"] : "#06b6d4"
                  }}
                  transition={{ 
                    rotate: { duration: 0.3 },
                    color: { duration: 1, repeat: Infinity }
                  }}
                >
                  <ChevronDown className="w-5 h-5" />
                </motion.div>
              </div>

              <AnimatePresence>
                {activeIndex === index && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: "auto", opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.3 }}
                    className="overflow-hidden"
                  >
                    <motion.div
                      initial={{ y: -10 }}
                      animate={{ y: 0 }}
                      className="pt-4 mt-4 border-t border-cyan-400/30"
                    >
                      <motion.p 
                        className="text-cyan-100/90 leading-relaxed"
                        animate={isPlaying ? {
                          textShadow: [
                            "0 0 5px rgba(0, 255, 255, 0.3)",
                            "0 0 10px rgba(0, 255, 255, 0.6)",
                            "0 0 5px rgba(0, 255, 255, 0.3)"
                          ]
                        } : {}}
                        transition={{ duration: 2.5, repeat: Infinity }}
                        style={{ textShadow: "1px 1px 3px rgba(0, 0, 0, 0.8)" }}
                      >
                        {item.answer}
                      </motion.p>
                      
                      {/* Symbiot response indicator */}
                      <motion.div
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: 0.2 }}
                        className="flex items-center mt-3 text-xs text-cyan-400/70"
                      >
                        <motion.div
                          animate={isPlaying ? { 
                            scale: [1, 1.4, 1],
                            opacity: [0.7, 1, 0.7]
                          } : { scale: 1, opacity: 0.7 }}
                          transition={{ duration: 1.5, repeat: Infinity }}
                          className="w-2 h-2 bg-cyan-400 rounded-full mr-2"
                        />
                        <motion.span
                          animate={isPlaying ? {
                            opacity: [0.7, 1, 0.7]
                          } : {}}
                          transition={{ duration: 2, repeat: Infinity }}
                        >
                          {isPlaying ? "Ответ симбиота обработан" : "Симбиот в ожидании"}
                        </motion.span>
                      </motion.div>
                    </motion.div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            {/* Edge glow effect */}
            <motion.div
              className="absolute inset-0 rounded-lg pointer-events-none"
              animate={activeIndex === index && isPlaying ? {
                boxShadow: [
                  "inset 0 0 20px rgba(0, 255, 255, 0.1)",
                  "inset 0 0 40px rgba(0, 255, 255, 0.3)",
                  "inset 0 0 60px rgba(0, 255, 255, 0.5)",
                  "inset 0 0 40px rgba(0, 255, 255, 0.3)",
                  "inset 0 0 20px rgba(0, 255, 255, 0.1)"
                ]
              } : {}}
              transition={{ duration: 2, repeat: Infinity }}
            />
          </motion.div>
        </motion.div>
      ))}

      {/* Symbiot Footer */}
      <motion.div
        className="text-center py-4"
        animate={isPlaying ? {
          opacity: [0.5, 1, 0.5]
        } : { opacity: 0.3 }}
        transition={{ duration: 3, repeat: Infinity }}
      >
        <motion.p 
          className="text-cyan-400/60 text-sm"
          animate={isPlaying ? {
            textShadow: [
              "0 0 5px rgba(0, 255, 255, 0.3)",
              "0 0 15px rgba(0, 255, 255, 0.7)",
              "0 0 5px rgba(0, 255, 255, 0.3)"
            ]
          } : {}}
          transition={{ duration: 4, repeat: Infinity }}
        >
          {isPlaying ? "◊ Симбиот обучается на ваших запросах ◊" : "◊ Симбиот находится в спящем режиме ◊"}
        </motion.p>
      </motion.div>
    </div>
  );
};

const ContentCreationAdmin = () => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentFrame, setCurrentFrame] = useState(0);
  const [glitchActive, setGlitchActive] = useState(false);
  const [currentStyle, setCurrentStyle] = useState<StyleType>('tokyo-ghoul');
  const [moneyParticles, setMoneyParticles] = useState<Array<{id: number, x: number, y: number}>>([]);
  const [heartParticles, setHeartParticles] = useState<Array<{id: number, x: number, y: number}>>([]);

  const styles = {
    'tokyo-ghoul': {
      name: 'Токийский Гуль',
      icon: Ghost,
      textVariants: ["Яндекс Сплит", "Л У Ч Ш А Я", "Т Е М К А"],
      mainText: "Яндекс Сплит - Лучшая Темка",
      colors: ['#ff0000', '#ff6b6b', '#ff0000'],
      bgGradient: 'from-black via-red-950/20 to-black',
      particleEmoji: '🩸',
      textColor: '#ffffff'
    },
    'light-anime': {
      name: 'Лайт Аниме',
      icon: Sparkles,
      textVariants: ["✧ Яндекс Сплит ✧", "◊ Л У Ч Ш А Я ◊", "★ Т Е М К А ★"],
      mainText: "✨ Яндекс Сплит - Лучшая Темка ✨",
      colors: ['#ff69b4', '#ffb6c1', '#ffc0cb'],
      bgGradient: 'from-pink-950/30 via-purple-900/20 to-blue-950/30',
      particleEmoji: '💖',
      textColor: '#ffffff'
    },
    'depression': {
      name: 'Депрессия',
      icon: Brain,
      textVariants: ["яндекс сплит", "л у ч ш а я", "т е м к а"],
      mainText: "яндекс сплит - лучшая темка",
      colors: ['#9ca3af', '#d1d5db', '#f3f4f6'],
      bgGradient: 'from-gray-900 via-gray-800 to-black',
      particleEmoji: '💧',
      textColor: '#e5e7eb'
    },
    'emotionless': {
      name: 'Безэмоциональность',
      icon: Target,
      textVariants: ["ЯНДЕКС_СПЛИТ", "ЛУЧШАЯ_ТЕМКА", "ЭФФЕКТИВНОСТЬ"],
      mainText: "ЯНДЕКС СПЛИТ - ЛУЧШАЯ ТЕМКА",
      colors: ['#ffffff', '#f1f5f9', '#e2e8f0'],
      bgGradient: 'from-slate-900 via-slate-800 to-slate-900',
      particleEmoji: '▫️',
      textColor: '#ffffff'
    },
    'rich-peace': {
      name: 'Покой в Богатстве',
      icon: DollarSign,
      textVariants: ["💰 ЯНДЕКС СПЛИТ 💰", "🏆 ЛУЧШАЯ ТЕМКА 🏆", "💎 БОГАТСТВО 💎"],
      mainText: "💰 Яндекс Сплит - Лучшая Темка 💎",
      colors: ['#fbbf24', '#f59e0b', '#d97706'],
      bgGradient: 'from-yellow-900/30 via-amber-900/20 to-yellow-800/30',
      particleEmoji: '💰',
      textColor: '#ffffff'
    },
    'temshik': {
      name: 'Темщик',
      icon: Moon,
      textVariants: ["ЯНДЕКС СПЛИТ", "ТЕМНАЯ СТОРОНА", "ЛУЧШАЯ ТЕМКА"],
      mainText: "ЯНДЕКС СПЛИТ - ТЕМНАЯ СТОРОНА",
      colors: ['#a855f7', '#9333ea', '#7c3aed'],
      bgGradient: 'from-purple-950 via-violet-900/50 to-black',
      particleEmoji: '🌙',
      textColor: '#ffffff'
    }
  };

  const currentStyleConfig = styles[currentStyle];

  // Enhanced glitch effect trigger
  useEffect(() => {
    if (isPlaying) {
      const interval = setInterval(() => {
        setGlitchActive(true);
        setTimeout(() => setGlitchActive(false), currentStyle === 'tokyo-ghoul' ? 200 : 100);
      }, currentStyle === 'depression' ? 1500 : currentStyle === 'emotionless' ? 2000 : 800);
      return () => clearInterval(interval);
    }
  }, [isPlaying, currentStyle]);

  // Particle effects
  useEffect(() => {
    if (isPlaying && (currentStyle === 'rich-peace' || currentStyle === 'light-anime')) {
      const interval = setInterval(() => {
        const newParticle = {
          id: Date.now() + Math.random(),
          x: Math.random() * 100,
          y: Math.random() * 100
        };
        if (currentStyle === 'rich-peace') {
          setMoneyParticles(prev => [...prev.slice(-15), newParticle]);
        } else {
          setHeartParticles(prev => [...prev.slice(-12), newParticle]);
        }
      }, 300);
      return () => clearInterval(interval);
    }
  }, [isPlaying, currentStyle]);

  // Frame animation
  useEffect(() => {
    if (isPlaying) {
      const speed = currentStyle === 'emotionless' ? 1000 : currentStyle === 'depression' ? 800 : 500;
      const interval = setInterval(() => {
        setCurrentFrame(prev => (prev + 1) % currentStyleConfig.textVariants.length);
      }, speed);
      return () => clearInterval(interval);
    }
  }, [isPlaying, currentStyleConfig.textVariants.length, currentStyle]);

  // Style-specific variants with improved contrast
  const getTextVariants = () => {
    const baseVariants = {
      normal: { 
        x: 0, 
        opacity: 1, 
        scale: 1,
        rotateX: 0,
        rotateY: 0,
        z: 0
      }
    };

    switch (currentStyle) {
      case 'tokyo-ghoul':
        return {
          ...baseVariants,
          glitch: { 
            x: [-3, 3, -2, 2, 0], 
            opacity: [1, 0.7, 1, 0.8, 1],
            scale: [1, 1.05, 0.95, 1.02, 1],
            filter: [
              "hue-rotate(0deg) saturate(1) brightness(1) contrast(1.2)",
              "hue-rotate(90deg) saturate(2) brightness(1.3) contrast(1.5)",
              "hue-rotate(180deg) saturate(0.5) brightness(0.7) contrast(1.3)",
              "hue-rotate(270deg) saturate(1.8) brightness(1.2) contrast(1.4)",
              "hue-rotate(360deg) saturate(1) brightness(1) contrast(1.2)"
            ],
            textShadow: [
              "0 0 10px rgba(255, 0, 0, 0.8), 2px 2px 4px rgba(0, 0, 0, 0.8)",
              "3px 0 0px rgba(255, 0, 0, 1), -3px 0 0px rgba(0, 255, 255, 1), 0 0 20px rgba(0, 0, 0, 1)",
              "0 0 30px rgba(255, 255, 255, 1), 4px 4px 8px rgba(0, 0, 0, 0.9)",
              "-2px 0 0px rgba(255, 0, 0, 0.8), 2px 0 0px rgba(0, 255, 255, 0.8), 0 0 15px rgba(0, 0, 0, 0.8)",
              "0 0 15px rgba(255, 0, 0, 0.8), 2px 2px 4px rgba(0, 0, 0, 0.8)"
            ],
            transition: { duration: 0.2, times: [0, 0.25, 0.5, 0.75, 1] }
          }
        };

      case 'light-anime':
        return {
          ...baseVariants,
          glitch: {
            scale: [1, 1.1, 1.05, 1.08, 1],
            rotateZ: [0, 2, -1, 1, 0],
            filter: [
              "hue-rotate(0deg) saturate(1) brightness(1.2) contrast(1.3)",
              "hue-rotate(45deg) saturate(1.5) brightness(1.4) contrast(1.5)",
              "hue-rotate(90deg) saturate(1.8) brightness(1.6) contrast(1.7)",
              "hue-rotate(45deg) saturate(1.5) brightness(1.4) contrast(1.5)",
              "hue-rotate(0deg) saturate(1) brightness(1.2) contrast(1.3)"
            ],
            textShadow: [
              "0 0 20px rgba(255, 105, 180, 0.8), 2px 2px 6px rgba(0, 0, 0, 0.9)",
              "0 0 40px rgba(255, 182, 193, 1), 3px 3px 9px rgba(0, 0, 0, 1)",
              "0 0 60px rgba(255, 192, 203, 1), 4px 4px 12px rgba(0, 0, 0, 1)",
              "0 0 40px rgba(255, 182, 193, 1), 3px 3px 9px rgba(0, 0, 0, 1)",
              "0 0 20px rgba(255, 105, 180, 0.8), 2px 2px 6px rgba(0, 0, 0, 0.9)"
            ],
            transition: { duration: 0.15 }
          }
        };

      case 'depression':
        return {
          ...baseVariants,
          glitch: {
            y: [0, -2, 1, -1, 0],
            opacity: [0.9, 0.7, 0.8, 0.6, 0.9],
            filter: [
              "brightness(1.2) saturate(0.8) contrast(1.4)",
              "brightness(1.0) saturate(0.6) contrast(1.2)",
              "brightness(1.1) saturate(0.7) contrast(1.3)",
              "brightness(0.9) saturate(0.5) contrast(1.1)",
              "brightness(1.2) saturate(0.8) contrast(1.4)"
            ],
            textShadow: [
              "0 0 10px rgba(156, 163, 175, 0.8), 2px 2px 4px rgba(0, 0, 0, 0.9)",
              "0 0 15px rgba(209, 213, 219, 0.6), 1px 1px 3px rgba(0, 0, 0, 0.8)",
              "0 0 20px rgba(243, 244, 246, 0.4), 2px 2px 5px rgba(0, 0, 0, 0.9)",
              "0 0 15px rgba(209, 213, 219, 0.6), 1px 1px 3px rgba(0, 0, 0, 0.8)",
              "0 0 10px rgba(156, 163, 175, 0.8), 2px 2px 4px rgba(0, 0, 0, 0.9)"
            ],
            transition: { duration: 0.3 }
          }
        };

      case 'emotionless':
        return {
          ...baseVariants,
          glitch: {
            letterSpacing: ["0em", "0.1em", "0.05em", "0.08em", "0em"],
            opacity: [1, 0.9, 1, 0.95, 1],
            filter: [
              "contrast(1.5) brightness(1.3)",
              "contrast(1.7) brightness(1.5)",
              "contrast(1.6) brightness(1.4)",
              "contrast(1.65) brightness(1.45)",
              "contrast(1.5) brightness(1.3)"
            ],
            textShadow: [
              "0 0 15px rgba(255, 255, 255, 0.8), 2px 2px 6px rgba(0, 0, 0, 0.9)",
              "0 0 25px rgba(241, 245, 249, 0.9), 3px 3px 9px rgba(0, 0, 0, 1)",
              "0 0 20px rgba(226, 232, 240, 0.7), 2px 2px 7px rgba(0, 0, 0, 0.95)",
              "0 0 30px rgba(241, 245, 249, 0.85), 3px 3px 10px rgba(0, 0, 0, 1)",
              "0 0 15px rgba(255, 255, 255, 0.8), 2px 2px 6px rgba(0, 0, 0, 0.9)"
            ],
            transition: { duration: 0.1 }
          }
        };

      case 'rich-peace':
        return {
          ...baseVariants,
          glitch: {
            scale: [1, 1.15, 1.08, 1.12, 1],
            rotateY: [0, 5, -3, 2, 0],
            filter: [
              "hue-rotate(0deg) saturate(1.2) brightness(1.3) contrast(1.4)",
              "hue-rotate(15deg) saturate(1.7) brightness(1.5) contrast(1.6)",
              "hue-rotate(30deg) saturate(2.0) brightness(1.7) contrast(1.8)",
              "hue-rotate(15deg) saturate(1.7) brightness(1.5) contrast(1.6)",
              "hue-rotate(0deg) saturate(1.2) brightness(1.3) contrast(1.4)"
            ],
            textShadow: [
              "0 0 30px rgba(251, 191, 36, 1), 3px 3px 8px rgba(0, 0, 0, 0.9)",
              "0 0 60px rgba(245, 158, 11, 1), 4px 4px 12px rgba(0, 0, 0, 1)",
              "0 0 90px rgba(217, 119, 6, 1), 5px 5px 15px rgba(0, 0, 0, 1)",
              "0 0 60px rgba(245, 158, 11, 1), 4px 4px 12px rgba(0, 0, 0, 1)",
              "0 0 30px rgba(251, 191, 36, 1), 3px 3px 8px rgba(0, 0, 0, 0.9)"
            ],
            transition: { duration: 0.2 }
          }
        };

      case 'temshik':
        return {
          ...baseVariants,
          glitch: {
            x: [-1, 1, -0.5, 0.5, 0],
            rotateX: [0, 2, -1, 1, 0],
            filter: [
              "hue-rotate(0deg) saturate(1.3) brightness(1.2) contrast(1.4)",
              "hue-rotate(270deg) saturate(1.8) brightness(1.4) contrast(1.6)",
              "hue-rotate(300deg) saturate(2.1) brightness(1.6) contrast(1.8)",
              "hue-rotate(270deg) saturate(1.8) brightness(1.4) contrast(1.6)",
              "hue-rotate(0deg) saturate(1.3) brightness(1.2) contrast(1.4)"
            ],
            textShadow: [
              "0 0 20px rgba(168, 85, 247, 0.8), 2px 2px 6px rgba(0, 0, 0, 0.9)",
              "0 0 40px rgba(147, 51, 234, 1), 3px 3px 9px rgba(0, 0, 0, 1)",
              "0 0 60px rgba(124, 58, 237, 1), 4px 4px 12px rgba(0, 0, 0, 1)",
              "0 0 40px rgba(147, 51, 234, 1), 3px 3px 9px rgba(0, 0, 0, 1)",
              "0 0 20px rgba(168, 85, 247, 0.8), 2px 2px 6px rgba(0, 0, 0, 0.9)"
            ],
            transition: { duration: 0.18 }
          }
        };

      default:
        return baseVariants;
    }
  };

  const textVariants = getTextVariants();

  return (
    <div className="space-y-6">
      {/* Control Panel */}
      <Card className="bg-black/90 border-red-500/30 backdrop-blur-sm">
        <CardContent className="p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-bold text-red-400">Content Creation Studio</h2>
            <div className="flex items-center space-x-4">
              <Button
                onClick={() => setIsPlaying(!isPlaying)}
                variant="outline"
                className="border-red-500/50 text-red-400 hover:bg-red-500/20"
              >
                {isPlaying ? (
                  <>
                    <Pause className="w-4 h-4 mr-2" />
                    Остановить
                  </>
                ) : (
                  <>
                    <Play className="w-4 h-4 mr-2" />
                    Запустить
                  </>
                )}
              </Button>
              <div className="flex items-center space-x-2">
                <motion.div
                  animate={isPlaying ? {
                    scaleY: [1, 0.1, 1],
                    transition: { duration: 0.3, repeat: Infinity, repeatDelay: 2 }
                  } : {}}
                >
                  <Eye className="w-5 h-5 text-red-400" />
                </motion.div>
                <span className="text-sm text-muted-foreground">
                  {isPlaying ? "Режим записи" : "Ожидание"}
                </span>
              </div>
            </div>
          </div>
          
          {/* Style Selector */}
          <div className="flex items-center space-x-4">
            <span className="text-sm text-muted-foreground">Стиль эдита:</span>
            <Select value={currentStyle} onValueChange={(value: StyleType) => setCurrentStyle(value)}>
              <SelectTrigger className="w-64 bg-black/50 border-red-500/30">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-black/95 border-red-500/30">
                {Object.entries(styles).map(([key, style]) => (
                  <SelectItem key={key} value={key} className="text-white hover:bg-red-500/20">
                    <div className="flex items-center space-x-2">
                      <style.icon className="w-4 h-4" />
                      <span>{style.name}</span>
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Main Content with Tabs */}
      <Tabs defaultValue="editor" className="w-full">
        <TabsList className="grid w-full grid-cols-2 bg-black/50 border border-red-500/30">
          <TabsTrigger value="editor" className="text-white data-[state=active]:bg-red-500/20 data-[state=active]:text-red-400">
            TikTok Editor
          </TabsTrigger>
          <TabsTrigger value="faq" className="text-white data-[state=active]:bg-cyan-500/20 data-[state=active]:text-cyan-400">
            Symbiot FAQ
          </TabsTrigger>
        </TabsList>

        <TabsContent value="editor" className="mt-6">
          {/* Main Animation Area */}
          <Card className="bg-black/95 border-red-500/20 min-h-[600px] relative overflow-hidden">
            <CardContent className="p-0 relative">
              {/* Dynamic background based on style */}
              <div className={`absolute inset-0 bg-gradient-to-br ${currentStyleConfig.bgGradient}`} />
              
              {/* Background effects */}
              <AnimatePresence>
                {isPlaying && (
                  <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    className="absolute inset-0"
                  >
                    {/* Style-specific particles */}
                    {currentStyle === 'rich-peace' && moneyParticles.map((particle) => (
                      <motion.div
                        key={particle.id}
                        className="absolute text-2xl pointer-events-none"
                        initial={{ 
                          x: particle.x + "%", 
                          y: particle.y + "%",
                          opacity: 0,
                          scale: 0,
                          rotateZ: 0
                        }}
                        animate={{ 
                          y: "-20%",
                          opacity: [0, 1, 1, 0],
                          scale: [0, 1.2, 1, 0.8],
                          rotateZ: 360
                        }}
                        transition={{ 
                          duration: 3,
                          ease: "easeOut"
                        }}
                      >
                        💰
                      </motion.div>
                    ))}

                    {currentStyle === 'light-anime' && heartParticles.map((particle) => (
                      <motion.div
                        key={particle.id}
                        className="absolute text-xl pointer-events-none"
                        initial={{ 
                          x: particle.x + "%", 
                          y: particle.y + "%",
                          opacity: 0,
                          scale: 0
                        }}
                        animate={{ 
                          y: "-30%",
                          x: particle.x + Math.sin(Date.now()) * 10 + "%",
                          opacity: [0, 1, 1, 0],
                          scale: [0, 1, 1.2, 0]
                        }}
                        transition={{ 
                          duration: 4,
                          ease: "easeOut"
                        }}
                      >
                        💖
                      </motion.div>
                    ))}

                    {/* Enhanced particles for all styles */}
                    {[...Array(currentStyle === 'tokyo-ghoul' ? 12 : currentStyle === 'rich-peace' ? 6 : 8)].map((_, i) => (
                      <motion.div
                        key={`particle-${i}`}
                        className="absolute w-1 h-1 rounded-full"
                        style={{ backgroundColor: currentStyleConfig.colors[i % currentStyleConfig.colors.length] }}
                        initial={{ 
                          x: Math.random() * 100 + "%", 
                          y: Math.random() * 100 + "%",
                          opacity: 0,
                          scale: 0
                        }}
                        animate={{ 
                          x: Math.random() * 100 + "%", 
                          y: Math.random() * 100 + "%",
                          opacity: [0, 1, 0],
                          scale: [0, Math.random() * 2 + 1, 0]
                        }}
                        transition={{ 
                          duration: Math.random() * 3 + 2,
                          repeat: Infinity,
                          delay: Math.random() * 3
                        }}
                      />
                    ))}
                    
                    {/* Enhanced scanning lines */}
                    <motion.div
                      className="absolute inset-x-0 h-1 opacity-60"
                      style={{
                        background: `linear-gradient(to right, transparent, ${currentStyleConfig.colors[0]}, transparent)`
                      }}
                      animate={{ 
                        y: ["0%", "100%"],
                        opacity: [0.6, 1, 0.6]
                      }}
                      transition={{ 
                        duration: currentStyle === 'depression' ? 4 : currentStyle === 'emotionless' ? 5 : 2.5, 
                        repeat: Infinity, 
                        ease: "linear" 
                      }}
                    />

                    {/* 3D rotation effect for rich-peace style */}
                    {currentStyle === 'rich-peace' && (
                      <motion.div
                        className="absolute inset-0 pointer-events-none"
                        animate={{
                          rotateY: [0, 360],
                          opacity: [0.1, 0.3, 0.1]
                        }}
                        transition={{
                          duration: 8,
                          repeat: Infinity,
                          ease: "linear"
                        }}
                        style={{
                          background: "conic-gradient(from 0deg, transparent, rgba(251, 191, 36, 0.2), transparent)",
                          transformStyle: "preserve-3d"
                        }}
                      />
                    )}
                  </motion.div>
                )}
              </AnimatePresence>

              {/* Main Content */}
              <div className="relative z-10 flex items-center justify-center min-h-[600px] p-8">
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="text-center space-y-8"
                >
                  {/* Style-specific decorative icons */}
                  <div className="flex justify-center space-x-8 mb-8">
                    {[0, 1, 2].map((index) => {
                      const IconComponent = [currentStyleConfig.icon, Ghost, Skull][index] || Zap;
                      return (
                        <motion.div
                          key={index}
                          animate={isPlaying ? {
                            rotate: index % 2 === 0 ? 360 : -360,
                            scale: currentStyle === 'rich-peace' ? [1, 1.3, 1] : [1, 1.1, 1]
                          } : {}}
                          transition={{ 
                            duration: 3 + index, 
                            repeat: Infinity, 
                            ease: "linear" 
                          }}
                        >
                          <IconComponent 
                            className="w-8 h-8" 
                            style={{ 
                              color: currentStyleConfig.colors[index % currentStyleConfig.colors.length],
                              filter: "drop-shadow(2px 2px 4px rgba(0, 0, 0, 0.8))"
                            }}
                          />
                        </motion.div>
                      );
                    })}
                  </div>

                  {/* Enhanced Main Text Animation with better contrast */}
                  <div className="relative perspective-1000">
                    <motion.h1
                      variants={textVariants}
                      animate={glitchActive ? "glitch" : "normal"}
                      className="text-6xl md:text-8xl font-black text-center relative"
                      style={{
                        background: `linear-gradient(45deg, ${currentStyleConfig.colors[0]}, ${currentStyleConfig.colors[1]}, ${currentStyleConfig.colors[2] || currentStyleConfig.colors[0]})`,
                        WebkitBackgroundClip: "text",
                        WebkitTextFillColor: "transparent",
                        backgroundClip: "text",
                        fontFamily: currentStyle === 'emotionless' ? "monospace" : currentStyle === 'depression' ? "serif" : "Impact, Arial Black, sans-serif",
                        letterSpacing: currentStyle === 'emotionless' ? "0.1em" : "-0.02em",
                        transformStyle: "preserve-3d",
                        filter: "drop-shadow(2px 2px 6px rgba(0, 0, 0, 0.9))"
                      }}
                    >
                      {isPlaying ? currentStyleConfig.textVariants[currentFrame] : currentStyleConfig.mainText}
                    </motion.h1>

                    {/* Enhanced glitch overlay with better visibility */}
                    <AnimatePresence>
                      {glitchActive && (
                        <>
                          {/* Primary glitch layer */}
                          <motion.div
                            initial={{ opacity: 0 }}
                            animate={{ opacity: 1 }}
                            exit={{ opacity: 0 }}
                            className="absolute inset-0 mix-blend-screen"
                          >
                            <motion.h1
                              animate={{
                                x: currentStyle === 'tokyo-ghoul' ? [0, -6, 6, -3, 3, 0] : [0, -2, 2, -1, 1, 0],
                                opacity: [0.8, 0.5, 0.9, 0.6, 0.8],
                                skewX: currentStyle === 'temshik' ? [0, 2, -2, 1, 0] : 0
                              }}
                              transition={{ duration: 0.15 }}
                              className="text-6xl md:text-8xl font-black"
                              style={{
                                color: currentStyle === 'tokyo-ghoul' ? '#00ffff' : 
                                       currentStyle === 'light-anime' ? '#ffff00' :
                                       currentStyle === 'rich-peace' ? '#ffffff' :
                                       currentStyle === 'temshik' ? '#ff00ff' : '#ffffff',
                                fontFamily: currentStyle === 'emotionless' ? "monospace" : currentStyle === 'depression' ? "serif" : "Impact, Arial Black, sans-serif",
                                letterSpacing: currentStyle === 'emotionless' ? "0.1em" : "-0.02em",
                                textShadow: "0 0 10px rgba(0, 0, 0, 1), 2px 2px 4px rgba(0, 0, 0, 0.9)"
                              }}
                            >
                              {isPlaying ? currentStyleConfig.textVariants[currentFrame] : currentStyleConfig.mainText}
                            </motion.h1>
                          </motion.div>

                          {/* Secondary glitch layer for Tokyo Ghoul style */}
                          {currentStyle === 'tokyo-ghoul' && (
                            <motion.div
                              initial={{ opacity: 0 }}
                              animate={{ opacity: 0.6 }}
                              exit={{ opacity: 0 }}
                              className="absolute inset-0 mix-blend-multiply"
                            >
                              <motion.h1
                                animate={{
                                  x: [0, 4, -4, 2, -2, 0],
                                  y: [0, -1, 1, -0.5, 0.5, 0],
                                  opacity: [0.6, 0.3, 0.7, 0.4, 0.6]
                                }}
                                transition={{ duration: 0.2, delay: 0.05 }}
                                className="text-6xl md:text-8xl font-black text-red-600"
                                style={{
                                  fontFamily: "Impact, Arial Black, sans-serif",
                                  letterSpacing: "-0.02em",
                                  textShadow: "0 0 15px rgba(0, 0, 0, 1), 3px 3px 6px rgba(0, 0, 0, 0.9)"
                                }}
                              >
                                {isPlaying ? currentStyleConfig.textVariants[currentFrame] : currentStyleConfig.mainText}
                              </motion.h1>
                            </motion.div>
                          )}
                        </>
                      )}
                    </AnimatePresence>

                    {/* 3D Text Shadow for rich-peace style */}
                    {currentStyle === 'rich-peace' && (
                      <motion.h1
                        animate={isPlaying ? {
                          z: [0, -50, 0],
                          rotateX: [0, 5, 0],
                          opacity: [0.3, 0.5, 0.3]
                        } : {}}
                        transition={{ duration: 2, repeat: Infinity }}
                        className="absolute inset-0 text-6xl md:text-8xl font-black text-yellow-600/30 -z-10"
                        style={{
                          transform: "translateZ(-20px) translateY(4px) translateX(4px)",
                          fontFamily: "Impact, Arial Black, sans-serif",
                          letterSpacing: "-0.02em",
                          textShadow: "0 0 20px rgba(0, 0, 0, 0.8)"
                        }}
                      >
                        {isPlaying ? currentStyleConfig.textVariants[currentFrame] : currentStyleConfig.mainText}
                      </motion.h1>
                    )}
                  </div>

                  {/* Enhanced subtitle with better contrast */}
                  <motion.div
                    animate={isPlaying ? { 
                      opacity: currentStyle === 'depression' ? [0.8, 1, 0.8] : [0.9, 1, 0.9], 
                      scale: currentStyle === 'rich-peace' ? [1, 1.1, 1] : [1, 1.05, 1],
                      rotateY: currentStyle === 'temshik' ? [0, 5, 0] : 0
                    } : { opacity: 0.9 }}
                    transition={{ 
                      duration: currentStyle === 'depression' ? 2 : 1.5, 
                      repeat: Infinity 
                    }}
                    className="space-y-2"
                  >
                    <p className="text-lg font-medium tracking-wide" 
                       style={{ 
                         color: currentStyleConfig.colors[1],
                         textShadow: "0 0 10px rgba(0, 0, 0, 0.9), 2px 2px 4px rgba(0, 0, 0, 0.8)"
                       }}>
                      {currentStyle === 'tokyo-ghoul' && "★ ЭКСКЛЮЗИВНЫЙ КОНТЕНТ ★"}
                      {currentStyle === 'light-anime' && "✨ KAWAII EDIT ✨"}
                      {currentStyle === 'depression' && "• грустный контент •"}
                      {currentStyle === 'emotionless' && "[ СИСТЕМНЫЙ КОНТЕНТ ]"}
                      {currentStyle === 'rich-peace' && "💎 ПРЕМИУМ КОНТЕНТ 💎"}
                      {currentStyle === 'temshik' && "🌙 ТЕМНЫЙ КОНТЕНТ 🌙"}
                    </p>
                    <p className="text-sm text-white/80" style={{ textShadow: "1px 1px 2px rgba(0, 0, 0, 0.8)" }}>
                      {currentStyleConfig.name} × TikTok Style Edit
                    </p>
                  </motion.div>

                  {/* Enhanced stats with better visibility */}
                  {isPlaying && (
                    <motion.div
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="grid grid-cols-3 gap-4 mt-8 text-center"
                    >
                      {[
                        { value: "1.2M", label: "Просмотры" },
                        { value: "89K", label: "Лайки" },
                        { value: "15K", label: "Репосты" }
                      ].map((stat, index) => (
                        <div key={index} className="bg-black/40 backdrop-blur-sm rounded-lg p-3 border border-current/30" 
                             style={{ borderColor: currentStyleConfig.colors[0] }}>
                          <motion.div 
                            animate={{ 
                              textShadow: [
                                `0 0 5px ${currentStyleConfig.colors[0]}, 2px 2px 4px rgba(0, 0, 0, 0.9)`, 
                                `0 0 20px ${currentStyleConfig.colors[1]}, 3px 3px 6px rgba(0, 0, 0, 1)`, 
                                `0 0 5px ${currentStyleConfig.colors[0]}, 2px 2px 4px rgba(0, 0, 0, 0.9)`
                              ],
                              scale: currentStyle === 'rich-peace' ? [1, 1.1, 1] : [1, 1.05, 1]
                            }}
                            transition={{ 
                              duration: 2, 
                              repeat: Infinity, 
                              delay: index * 0.5 
                            }}
                            className="text-xl font-bold"
                            style={{ color: currentStyleConfig.colors[index % currentStyleConfig.colors.length] }}
                          >
                            {stat.value}
                          </motion.div>
                          <div className="text-xs text-white/70" style={{ textShadow: "1px 1px 2px rgba(0, 0, 0, 0.8)" }}>
                            {stat.label}
                          </div>
                        </div>
                      ))}
                    </motion.div>
                  )}
                </motion.div>
              </div>

              {/* Enhanced corner effects with better visibility */}
              <div className="absolute top-4 left-4">
                <motion.div
                  animate={isPlaying ? { rotate: 360 } : {}}
                  transition={{ duration: currentStyle === 'depression' ? 15 : 10, repeat: Infinity, ease: "linear" }}
                  className="w-6 h-6 border-2 border-current/50 border-t-current"
                  style={{ 
                    borderColor: currentStyleConfig.colors[0],
                    filter: "drop-shadow(1px 1px 2px rgba(0, 0, 0, 0.8))"
                  }}
                />
              </div>
              <div className="absolute bottom-4 right-4">
                <motion.div
                  animate={isPlaying ? { rotate: -360 } : {}}
                  transition={{ duration: currentStyle === 'emotionless' ? 12 : 8, repeat: Infinity, ease: "linear" }}
                  className="w-6 h-6 border-2 border-current/50 border-b-current"
                  style={{ 
                    borderColor: currentStyleConfig.colors[1],
                    filter: "drop-shadow(1px 1px 2px rgba(0, 0, 0, 0.8))"
                  }}
                />
              </div>
            </CardContent>
          </Card>

          {/* Enhanced technical info */}
          <Card className="bg-black/80 border-current/20 mt-6" style={{ borderColor: currentStyleConfig.colors[0] }}>
            <CardContent className="p-4">
              <div className="grid grid-cols-5 gap-4 text-center">
                <div>
                  <div className="text-sm font-medium" style={{ 
                    color: currentStyleConfig.colors[0],
                    textShadow: "1px 1px 2px rgba(0, 0, 0, 0.8)"
                  }}>Формат</div>
                  <div className="text-xs text-white/70">TikTok 9:16</div>
                </div>
                <div>
                  <div className="text-sm font-medium" style={{ 
                    color: currentStyleConfig.colors[1],
                    textShadow: "1px 1px 2px rgba(0, 0, 0, 0.8)"
                  }}>Стиль</div>
                  <div className="text-xs text-white/70">{currentStyleConfig.name}</div>
                </div>
                <div>
                  <div className="text-sm font-medium" style={{ 
                    color: currentStyleConfig.colors[0],
                    textShadow: "1px 1px 2px rgba(0, 0, 0, 0.8)"
                  }}>FPS</div>
                  <div className="text-xs text-white/70">60 кадров/сек</div>
                </div>
                <div>
                  <div className="text-sm font-medium" style={{ 
                    color: currentStyleConfig.colors[1],
                    textShadow: "1px 1px 2px rgba(0, 0, 0, 0.8)"
                  }}>Эффекты</div>
                  <div className="text-xs text-white/70">
                    {currentStyle === 'tokyo-ghoul' && "Кровавый Глитч"}
                    {currentStyle === 'light-anime' && "Kawaii Sparkle"}
                    {currentStyle === 'depression' && "Fade Blur"}
                    {currentStyle === 'emotionless' && "System Scan"}
                    {currentStyle === 'rich-peace' && "Gold 3D"}
                    {currentStyle === 'temshik' && "Purple Void"}
                  </div>
                </div>
                <div>
                  <div className="text-sm font-medium" style={{ 
                    color: currentStyleConfig.colors[0],
                    textShadow: "1px 1px 2px rgba(0, 0, 0, 0.8)"
                  }}>Качество</div>
                  <div className="text-xs text-white/70">4K HDR</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="faq" className="mt-6">
          <SymbiotFAQ />
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default ContentCreationAdmin;