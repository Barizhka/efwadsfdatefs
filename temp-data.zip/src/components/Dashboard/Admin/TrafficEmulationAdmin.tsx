import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { 
  Smartphone, 
  Radio, 
  Signal, 
  Waves, 
  Cpu,
  Shield,
  Zap,
  Users,
  Activity
} from 'lucide-react';

interface Device {
  id: string;
  name: string;
  model: string;
  signal: number;
  isActive: boolean;
  frequency: number;
  traffic: number;
}

interface RadioNoise {
  id: string;
  frequency: number;
  amplitude: number;
}

// 142 реальных модели смартфонов
const smartphoneModels = [
  // Samsung Galaxy серия
  'Samsung Galaxy S24 Ultra', 'Samsung Galaxy S24+', 'Samsung Galaxy S24', 
  'Samsung Galaxy S23 Ultra', 'Samsung Galaxy S23+', 'Samsung Galaxy S23',
  'Samsung Galaxy S22 Ultra', 'Samsung Galaxy S22+', 'Samsung Galaxy S22',
  'Samsung Galaxy A54', 'Samsung Galaxy A34', 'Samsung Galaxy A24',
  'Samsung Galaxy A14', 'Samsung Galaxy M54', 'Samsung Galaxy M34',
  'Samsung Galaxy Note 20 Ultra', 'Samsung Galaxy Z Fold5', 'Samsung Galaxy Z Flip5',
  
  // iPhone серия  
  'iPhone 15 Pro Max', 'iPhone 15 Pro', 'iPhone 15 Plus', 'iPhone 15',
  'iPhone 14 Pro Max', 'iPhone 14 Pro', 'iPhone 14 Plus', 'iPhone 14',
  'iPhone 13 Pro Max', 'iPhone 13 Pro', 'iPhone 13', 'iPhone 13 mini',
  'iPhone 12 Pro Max', 'iPhone 12 Pro', 'iPhone 12', 'iPhone 12 mini',
  'iPhone SE 3rd gen', 'iPhone 11', 'iPhone XR',
  
  // Xiaomi серия
  'Xiaomi 14 Ultra', 'Xiaomi 14 Pro', 'Xiaomi 14', 'Xiaomi 13T Pro',
  'Xiaomi 13T', 'Xiaomi 13 Pro', 'Xiaomi 13', 'Xiaomi 12T Pro',
  'Xiaomi 12T', 'Xiaomi 12 Pro', 'Xiaomi 12', 'Xiaomi Redmi Note 13 Pro',
  'Xiaomi Redmi Note 13', 'Xiaomi Redmi Note 12 Pro', 'Xiaomi Redmi Note 12',
  'Xiaomi Redmi 12', 'Xiaomi POCO X5 Pro', 'Xiaomi POCO X5', 'Xiaomi POCO F5',
  
  // OnePlus серия
  'OnePlus 12', 'OnePlus 11', 'OnePlus 10 Pro', 'OnePlus 9 Pro',
  'OnePlus 9', 'OnePlus Nord 3', 'OnePlus Nord CE 3', 'OnePlus Nord 2T',
  
  // Google Pixel серия
  'Google Pixel 8 Pro', 'Google Pixel 8', 'Google Pixel 7a',
  'Google Pixel 7 Pro', 'Google Pixel 7', 'Google Pixel 6a',
  'Google Pixel 6 Pro', 'Google Pixel 6',
  
  // Huawei серия
  'Huawei P60 Pro', 'Huawei P60', 'Huawei Mate 50 Pro', 'Huawei Mate 50',
  'Huawei nova 11', 'Huawei nova 10', 'Huawei P50 Pro', 'Huawei P50',
  
  // Honor серия
  'Honor Magic5 Pro', 'Honor Magic5', 'Honor 90', 'Honor 70',
  'Honor 50', 'Honor X9a', 'Honor X8a', 'Honor X7a',
  
  // Oppo серия
  'Oppo Find X6 Pro', 'Oppo Find X6', 'Oppo Reno10 Pro', 'Oppo Reno10',
  'Oppo Reno8 Pro', 'Oppo Reno8', 'Oppo A98', 'Oppo A78', 'Oppo A58',
  
  // Vivo серия
  'Vivo X90 Pro', 'Vivo X90', 'Vivo V29', 'Vivo V27', 'Vivo Y100',
  'Vivo Y36', 'Vivo Y27', 'Vivo Y16', 'Vivo T2x',
  
  // Realme серия
  'Realme GT Neo5', 'Realme GT Neo3', 'Realme 11 Pro+', 'Realme 11 Pro',
  'Realme 11', 'Realme 10 Pro+', 'Realme 10 Pro', 'Realme 10',
  'Realme C55', 'Realme C53', 'Realme C33',
  
  // Nothing серия
  'Nothing Phone (2)', 'Nothing Phone (1)',
  
  // Sony Xperia серия
  'Sony Xperia 1 V', 'Sony Xperia 5 V', 'Sony Xperia 10 V',
  'Sony Xperia 1 IV', 'Sony Xperia 5 IV', 'Sony Xperia 10 IV',
  
  // Asus серия
  'Asus ROG Phone 7', 'Asus ROG Phone 6', 'Asus Zenfone 10',
  'Asus Zenfone 9', 'Asus Zenfone 8',
  
  // Motorola серия
  'Motorola Edge 40 Pro', 'Motorola Edge 40', 'Motorola Edge 30',
  'Motorola Moto G73', 'Motorola Moto G53', 'Motorola Moto G23',
  'Motorola Moto E13', 'Motorola ThinkPhone',
  
  // Nokia серия
  'Nokia G60', 'Nokia G50', 'Nokia G21', 'Nokia X30', 'Nokia X20',
  'Nokia C31', 'Nokia C21', 'Nokia 2660 Flip'
];

const TrafficEmulationAdmin = () => {
  const [isActive, setIsActive] = useState(false);
  const [devices, setDevices] = useState<Device[]>([]);
  const [radioNoise, setRadioNoise] = useState<RadioNoise[]>([]);
  const [activeDeviceId, setActiveDeviceId] = useState<string>('1');

  // Generate 142 devices with real smartphone models
  useEffect(() => {
    const generateDevices = () => {
      const newDevices: Device[] = [];
      
      for (let i = 1; i <= 142; i++) {
        const randomModel = smartphoneModels[Math.floor(Math.random() * smartphoneModels.length)];
        newDevices.push({
          id: i.toString(),
          name: `Device-${i.toString().padStart(3, '0')}`,
          model: randomModel,
          signal: Math.random() * 100,
          isActive: i === 1,
          frequency: Math.random() * 2400 + 800,
          traffic: Math.random() * 100
        });
      }
      
      setDevices(newDevices);
    };
    
    generateDevices();
  }, []);

  // Generate radio noise
  useEffect(() => {
    if (!isActive) return;

    const interval = setInterval(() => {
      setRadioNoise(prev => {
        const newNoise: RadioNoise = {
          id: Date.now().toString(),
          frequency: Math.random() * 2400 + 400,
          amplitude: Math.random() * 100
        };
        return [...prev.slice(-50), newNoise];
      });
    }, 100);

    return () => clearInterval(interval);
  }, [isActive]);

  // Update device traffic
  useEffect(() => {
    if (!isActive) return;

    const interval = setInterval(() => {
      setDevices(prev => prev.map(device => ({
        ...device,
        signal: Math.max(10, Math.min(100, device.signal + (Math.random() - 0.5) * 10)),
        traffic: Math.max(0, Math.min(100, device.traffic + (Math.random() - 0.5) * 20))
      })));
    }, 2000);

    return () => clearInterval(interval);
  }, [isActive]);

  const activeDevice = devices.find(d => d.id === activeDeviceId);

  return (
    <div className="space-y-6">
      {/* Header */}
      <Card className="bg-black/90 border-green-500/30 backdrop-blur-sm">
        <CardContent className="p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-3">
              <Radio className="w-6 h-6 text-green-400" />
              <h2 className="text-xl font-bold text-green-400">Эмуляция трафика Android</h2>
              <motion.div
                animate={isActive ? { scale: [1, 1.2, 1] } : {}}
                transition={{ duration: 1.5, repeat: Infinity }}
                className={`w-3 h-3 rounded-full ${isActive ? 'bg-green-400' : 'bg-gray-500'}`}
              />
            </div>
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2 text-sm text-green-400">
                <Users className="w-4 h-4" />
                <span>{devices.length} смартфонов</span>
              </div>
              <Button
                onClick={() => setIsActive(!isActive)}
                variant="outline"
                className="border-green-500/50 text-green-400 hover:bg-green-500/20"
              >
                {isActive ? (
                  <>
                    <Shield className="w-4 h-4 mr-2" />
                    Остановить эмуляцию
                  </>
                ) : (
                  <>
                    <Zap className="w-4 h-4 mr-2" />
                    Запустить эмуляцию
                  </>
                )}
              </Button>
            </div>
          </div>

          {/* Description */}
          <div className="bg-slate-900/50 rounded-lg p-4 border border-green-500/20">
            <p className="text-sm text-green-100/90 leading-relaxed">
              Используется тонко настроенная эмуляция настоящих Android устройств, а не обычная виртуалка, которая палится 10/10.
              <br />
              Сеть не просто мобильный прокси — а эмуляция полного радиотрафика с шумами, как на реальном устройстве.
              <br />
              <span className="text-green-400 font-medium">Нет пересечений между слотами:</span> ни по IP, ни по device ID, ни по usage-профилю.
              <br />
              Каждый акк выглядит как уникальный физический пользователь. Активно: <span className="text-green-400 font-bold">{devices.length} Android смартфонов</span>
            </p>
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Minimalist Status Panel */}
        <Card className="bg-black/90 border-green-500/20">
          <CardContent className="p-4">
            <h3 className="text-sm font-semibold text-green-400 mb-4 flex items-center">
              <Activity className="w-4 h-4 mr-2" />
              Статус эмуляции
            </h3>
            
            {/* Simple status display */}
            <div className="space-y-3">
              <div className="flex justify-between items-center py-2 px-3 bg-slate-900/50 rounded border border-green-500/20">
                <span className="text-green-400 text-sm">Всего устройств</span>
                <span className="text-green-400 font-bold">{devices.length}</span>
              </div>
              
              <div className="flex justify-between items-center py-2 px-3 bg-slate-900/50 rounded border border-green-500/20">
                <span className="text-green-400 text-sm">Активных</span>
                <span className="text-green-400 font-bold">{isActive ? Math.floor(devices.length * 0.8) : 0}</span>
              </div>
              
              <div className="flex justify-between items-center py-2 px-3 bg-slate-900/50 rounded border border-green-500/20">
                <span className="text-green-400 text-sm">Радиошумов</span>
                <span className="text-green-400 font-bold">{radioNoise.length}</span>
              </div>
              
              <div className="flex justify-between items-center py-2 px-3 bg-slate-900/50 rounded border border-green-500/20">
                <span className="text-green-400 text-sm">Частот</span>
                <span className="text-green-400 font-bold">4 диапазона</span>
              </div>
            </div>

            {/* Active device info */}
            {activeDevice && (
              <div className="mt-4 p-3 bg-green-900/20 rounded border border-green-500/30">
                <div className="text-xs text-green-400/80 mb-1">Активное устройство</div>
                <div className="text-green-400 font-medium">{activeDevice.name}</div>
                <div className="text-xs text-green-300">{activeDevice.model}</div>
                <div className="text-xs text-green-400/70 mt-1">
                  Сигнал: {Math.round(activeDevice.signal)}% | Трафик: {Math.round(activeDevice.traffic)}%
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Device List */}
        <Card className="bg-black/90 border-green-500/20">
          <CardContent className="p-4">
            <h3 className="text-sm font-semibold text-green-400 mb-4 flex items-center">
              <Smartphone className="w-4 h-4 mr-2" />
              Список устройств
            </h3>

            {/* Device selection */}
            <div className="mb-4">
              <Select value={activeDeviceId} onValueChange={setActiveDeviceId}>
                <SelectTrigger className="bg-black/50 border-green-500/30">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-black/95 border-green-500/30 max-h-48">
                  {devices.slice(0, 20).map((device) => (
                    <SelectItem key={device.id} value={device.id} className="text-white hover:bg-green-500/20">
                      <div className="flex items-center justify-between w-full">
                        <div className="flex items-center space-x-2">
                          <Smartphone className="w-4 h-4 text-green-400" />
                          <span>{device.name}</span>
                        </div>
                        <span className="text-xs text-green-400/70 ml-2">{device.model}</span>
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Device models preview */}
            <div className="space-y-1 max-h-32 overflow-y-auto">
              {devices.slice(0, 10).map((device, index) => (
                <div key={device.id} className="flex items-center justify-between text-xs py-1 px-2 bg-slate-900/30 rounded">
                  <span className="text-green-400/80">{device.name}</span>
                  <span className="text-green-300/60 truncate ml-2" title={device.model}>
                    {device.model}
                  </span>
                </div>
              ))}
              {devices.length > 10 && (
                <div className="text-xs text-green-400/60 text-center py-1">
                  ... и еще {devices.length - 10} устройств
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Radio Noise Visualization */}
      <Card className="bg-black/90 border-green-500/20">
        <CardContent className="p-4">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-semibold text-green-400 flex items-center">
              <Waves className="w-4 h-4 mr-2" />
              Радиошумы и частоты
            </h3>
            {isActive && (
              <div className="flex items-center space-x-2 text-xs text-green-400">
                <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />
                <span>Мониторинг активен</span>
              </div>
            )}
          </div>

          {/* Dynamic frequency bands */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-4">
            {[
              { band: '700-900 MHz', baseActivity: 45 },
              { band: '1800-2100 MHz', baseActivity: 67 },
              { band: '2.4 GHz', baseActivity: 23 },
              { band: '5 GHz', baseActivity: 89 }
            ].map((freq, index) => {
              // Dynamic activity calculation
              const dynamicVariation = isActive ? 
                Math.sin(Date.now() / 1000 + index) * 15 + Math.random() * 10 : 0;
              const currentActivity = Math.max(12, Math.min(99, 
                freq.baseActivity + dynamicVariation
              ));
              
              return (
                <motion.div 
                  key={index} 
                  className="bg-slate-900/50 rounded p-3 border border-green-500/20"
                  animate={isActive ? {
                    borderColor: [`rgba(34, 197, 94, 0.2)`, `rgba(34, 197, 94, 0.4)`, `rgba(34, 197, 94, 0.2)`]
                  } : {}}
                  transition={{ duration: 2, repeat: Infinity, delay: index * 0.5 }}
                >
                  <div className="text-xs text-green-400 font-medium mb-2">{freq.band}</div>
                  <div className="w-full bg-black/50 rounded-full h-1.5 mb-1">
                    <motion.div
                      className="h-1.5 rounded-full bg-green-400"
                      initial={{ width: "0%" }}
                      animate={{ width: `${currentActivity}%` }}
                      transition={{ duration: 0.5, ease: "easeInOut" }}
                    />
                  </div>
                  <div className="text-xs text-green-400/70">{Math.round(currentActivity)}% загрузка</div>
                </motion.div>
              );
            })}
          </div>

          {/* Enhanced noise visualization */}
          <div className="h-20 bg-black/50 rounded border border-green-500/20 relative overflow-hidden p-2">
            {/* Background grid */}
            <div className="absolute inset-0 opacity-20">
              {Array.from({ length: 5 }).map((_, i) => (
                <div 
                  key={i} 
                  className="absolute border-t border-green-500/30" 
                  style={{ top: `${(i + 1) * 20}%`, left: 0, right: 0 }} 
                />
              ))}
            </div>
            
            {/* Dynamic noise bars */}
            <div className="flex items-end justify-center h-full space-x-px relative z-10">
              {radioNoise.slice(-80).map((noise, index) => {
                const opacity = isActive ? Math.max(0.3, 1 - (index / 80) * 0.7) : 0.1;
                const height = isActive ? `${Math.max(5, (noise.amplitude / 100) * 100)}%` : '5%';
                
                return (
                  <motion.div
                    key={noise.id}
                    className="bg-green-400 rounded-t"
                    initial={{ height: '0%', opacity: 0 }}
                    animate={{ 
                      height: height,
                      opacity: opacity,
                      backgroundColor: isActive ? 
                        `rgba(34, 197, 94, ${0.4 + (noise.amplitude / 100) * 0.6})` : 
                        'rgba(34, 197, 94, 0.2)'
                    }}
                    transition={{ duration: 0.1, ease: "easeOut" }}
                    style={{
                      width: '1.5px',
                      filter: isActive ? `blur(${Math.max(0, (100 - noise.amplitude) / 200)}px)` : 'none'
                    }}
                  />
                );
              })}
            </div>
            
            {/* Real-time indicators */}
            <div className="absolute top-2 left-3 text-xs text-green-400/70 flex items-center space-x-2">
              <div className={`w-1.5 h-1.5 rounded-full ${isActive ? 'bg-green-400 animate-pulse' : 'bg-gray-500'}`} />
              <span>Реальное время</span>
            </div>
            
            <div className="absolute top-2 right-3 text-xs text-green-400/70">
              {isActive ? `${radioNoise.length} шумов` : 'Неактивно'}
            </div>
            
            {/* Frequency marker */}
            {isActive && radioNoise.length > 0 && (
              <div className="absolute bottom-2 left-3 text-xs text-green-400/70">
                ~{Math.round(radioNoise[radioNoise.length - 1]?.frequency || 0)} MHz
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default TrafficEmulationAdmin;