import React from 'react';
import { motion } from 'framer-motion';
import { Search, Plus, Play, StopCircle, ShoppingCart, MapPin, CheckCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { useAppStore } from '@/store/appStore';
import { useNavigate } from 'react-router-dom';
import { WarmupCitySelector } from './WarmupCitySelector';
import { WarmupStopDialog } from './WarmupStopDialog';
import { WarmupProgress } from './WarmupProgress';
import { OrderTracker } from './OrderTracker';
import { AccountWarmupLogs } from './AccountWarmupLogs';

const MainDashboard = () => {
  const { purchasedAccounts, orders, startWarmup, loadWarmupState, checkWarmupProgress } = useAppStore();
  const navigate = useNavigate();
  const [selectedAccountLogs, setSelectedAccountLogs] = React.useState<{accountId: string, accountName: string} | null>(null);

  // Загружаем состояние прогрева при монтировании и устанавливаем интервал
  React.useEffect(() => {
    loadWarmupState();
    checkWarmupProgress();
    
    // Обновляем прогресс каждую секунду
    const interval = setInterval(() => {
      checkWarmupProgress();
    }, 1000);
    
    return () => clearInterval(interval);
  }, [loadWarmupState, checkWarmupProgress]);

  const stats = [
    { label: 'Купленные аккаунты', value: purchasedAccounts.length, color: 'text-primary' },
    { label: 'Готовы к заказу', value: purchasedAccounts.filter(acc => acc.emulationStatus === "Готов к заказу" || acc.emulationStatus === "Готов к заказу - пассивный прогрев").length, color: 'text-green-400' },
    { label: 'В прогреве', value: purchasedAccounts.filter(acc => acc.warmupStarted && acc.warmupProgress < 100).length, color: 'text-amber-400' },
    { label: 'Активные заказы', value: orders.filter(order => !['delivered', 'cancelled'].includes(order.status)).length, color: 'text-blue-400' }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Готов к заказу': 
      case 'Готов к заказу - пассивный прогрев': 
        return 'bg-green-500/20 text-green-400 border-green-500/30';
      case 'Прогрев аккаунта на ГЕО': return 'bg-amber-500/20 text-amber-400';
      case 'Предварительный прогрев': return 'bg-blue-500/20 text-blue-400';
      default: return 'bg-gray-500/20 text-gray-400';
    }
  };

  const handleStartWarmup = (accountId: string, selectedCity?: string) => {
    startWarmup(accountId, selectedCity);
  };

  const renderAccountActions = (account: any) => {
    // Для всех типов готовых аккаунтов
    if (account.emulationStatus === "Готов к заказу" || account.emulationStatus === "Готов к заказу - пассивный прогрев") {
      return (
        <Button 
          size="sm" 
          onClick={() => navigate('/order-product')}
          className="bg-green-600 hover:bg-green-700 shadow-lg shadow-green-500/20"
        >
          <ShoppingCart className="w-4 h-4 mr-2" />
          Заказать товар
        </Button>
      );
    }
    
    if (account.emulationStatus === "Предварительный прогрев" && !account.warmupStarted) {
      return (
        <WarmupCitySelector 
          accountId={account.id}
          onCitySelected={(city) => handleStartWarmup(account.id, city)}
        />
      );
    }
    
    if (account.emulationStatus === "Прогрев аккаунта на ГЕО") {
      if (!account.warmupStarted) {
        return (
          <Button 
            size="sm" 
            onClick={() => handleStartWarmup(account.id)}
            className="bg-amber-600 hover:bg-amber-700"
          >
            <Play className="w-4 h-4 mr-2" />
            Начать прогрев
          </Button>
        );
      }
    }
    
    if (account.warmupStarted && account.warmupProgress < 100) {
      return (
        <WarmupStopDialog>
          <Button size="sm" variant="destructive">
            <StopCircle className="w-4 h-4 mr-2" />
            Остановить
          </Button>
        </WarmupStopDialog>
      );
    }
    
    return null;
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
      className="space-y-6"
    >
      {/* Header */}
      <div className="flex items-center justify-between">
        <motion.h1 
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.2 }}
          className="text-3xl font-bold bg-gradient-to-r from-primary to-blue-400 bg-clip-text text-transparent"
        >
          yasplit.ai
        </motion.h1>
        
        <motion.div 
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.3 }}
          className="flex items-center space-x-4"
        >
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
            <Input 
              placeholder="Поиск аккаунтов..." 
              className="pl-10 w-80 bg-card/50 border-border/50 focus:bg-card transition-colors"
            />
          </div>
          <Button className="bg-gradient-to-r from-primary to-primary/80 hover:from-primary/90 hover:to-primary/70 shadow-glow">
            <Plus className="w-4 h-4 mr-2" />
            Добавить аккаунт
          </Button>
        </motion.div>
      </div>

      {/* Stats Cards */}
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="grid grid-cols-4 gap-6"
      >
        {stats.map((stat, index) => (
          <motion.div
            key={stat.label}
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.5 + index * 0.1 }}
            whileHover={{ scale: 1.02, y: -2 }}
          >
            <Card className="bg-card/80 backdrop-blur-sm border-border/50 hover:border-primary/30 transition-all duration-300">
              <CardContent className="p-6">
                <div className="text-center space-y-2">
                  <p className="text-sm text-muted-foreground">{stat.label}</p>
                  <p className={`text-3xl font-bold ${stat.color}`}>{stat.value}</p>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </motion.div>

      {/* Accounts Table */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.8 }}
      >
        <Card className="bg-card/80 backdrop-blur-sm border-border/50">
          <CardHeader>
            <h2 className="text-xl font-semibold">Купленные аккаунты</h2>
          </CardHeader>
          <CardContent className="p-0">
            {purchasedAccounts.length === 0 ? (
              <div className="p-8 text-center">
                <div className="text-muted-foreground mb-4">
                  <ShoppingCart className="w-12 h-12 mx-auto mb-2 opacity-50" />
                  <p>У вас пока нет купленных аккаунтов</p>
                  <p className="text-sm">Перейдите в раздел "Аккаунты" для покупки</p>
                </div>
                <Button onClick={() => navigate('/accounts')} className="mt-4">
                  Перейти к покупке аккаунтов
                </Button>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-border/50">
                      <th className="text-left p-4 text-sm font-medium text-muted-foreground">Имя</th>
                      <th className="text-left p-4 text-sm font-medium text-muted-foreground">ID</th>
                      <th className="text-left p-4 text-sm font-medium text-muted-foreground">Город</th>
                      <th className="text-left p-4 text-sm font-medium text-muted-foreground">Лимит</th>
                      <th className="text-left p-4 text-sm font-medium text-muted-foreground">Статус прогрева</th>
                      <th className="text-left p-4 text-sm font-medium text-muted-foreground">Прогресс</th>
                      <th className="text-left p-4 text-sm font-medium text-muted-foreground">Действия</th>
                    </tr>
                  </thead>
                  <tbody>
                    {purchasedAccounts.map((account, index) => {
                      const isReadyForOrder = account.emulationStatus === "Готов к заказу" || account.emulationStatus === "Готов к заказу - пассивный прогрев";
                      return (
                        <React.Fragment key={account.id}>
                          <motion.tr
                            initial={{ opacity: 0, x: -20 }}
                            animate={{ opacity: 1, x: 0 }}
                            transition={{ delay: 1 + index * 0.1 }}
                            className={`border-b border-border/30 hover:bg-muted/20 transition-colors cursor-pointer ${
                              isReadyForOrder ? 'bg-green-500/5 hover:bg-green-500/10' : ''
                            }`}
                            onClick={() => {
                              if (account.warmupStarted && account.warmupProgress < 100) {
                                setSelectedAccountLogs(selectedAccountLogs?.accountId === account.id ? null : {
                                  accountId: account.id,
                                  accountName: account.name
                                });
                              }
                            }}
                          >
                            <td className="p-4">
                              <div className="flex items-center space-x-3">
                                <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold text-primary-foreground ${
                                  isReadyForOrder 
                                    ? 'bg-gradient-to-br from-green-500 to-green-600' 
                                    : 'bg-gradient-to-br from-primary to-blue-400'
                                }`}>
                                  {account.name.charAt(0).toUpperCase()}
                                </div>
                                <div>
                                  <div className="flex items-center space-x-2">
                                    <span className="font-medium">{account.name}</span>
                                    {isReadyForOrder && (
                                      <Badge className="bg-green-500/20 text-green-400 text-xs px-2 py-0.5">
                                        <CheckCircle className="w-4 h-4 text-green-500 inline mr-1" />
                                        Готов
                                      </Badge>
                                    )}
                                  </div>
                                </div>
                              </div>
                            </td>
                            <td className="p-4 text-sm text-muted-foreground font-mono">
                              {account.id}
                            </td>
                            <td className="p-4">
                              <div className="flex items-center space-x-1">
                                <MapPin className="w-4 h-4 text-muted-foreground" />
                                <span className="text-sm">{account.selectedCity || account.city}</span>
                              </div>
                            </td>
                            <td className="p-4">
                              <Badge variant="outline" className="border-primary/30 text-primary">
                                {typeof account.split === 'number' ? `${account.split.toLocaleString()} ₽` : account.split}
                              </Badge>
                            </td>
                            <td className="p-4">
                              <Badge className={getStatusColor(account.emulationStatus)}>
                                {account.emulationStatus}
                              </Badge>
                            </td>
                            <td className="p-4">
                              {isReadyForOrder ? (
                                <Badge className="bg-green-500/20 text-green-400 border border-green-500/30">
                                  <CheckCircle className="w-4 h-4 text-green-500 inline mr-1" />
                                  100%
                                </Badge>
                              ) : (
                                <WarmupProgress 
                                  progress={account.warmupProgress}
                                  startTime={account.warmupStartTime}
                                  isActive={account.warmupStarted}
                                />
                              )}
                            </td>
                            <td className="p-4">
                              <div className="flex items-center space-x-2">
                                {renderAccountActions(account)}
                              </div>
                            </td>
                          </motion.tr>
                          {/* Show warmup logs if account is selected and in warmup */}
                          {selectedAccountLogs?.accountId === account.id && account.warmupStarted && account.warmupProgress < 100 && (
                            <motion.tr
                              initial={{ opacity: 0 }}
                              animate={{ opacity: 1 }}
                              exit={{ opacity: 0 }}
                            >
                              <td colSpan={7} className="p-0">
                                <AccountWarmupLogs
                                  accountId={account.id}
                                  accountName={account.name}
                                  isVisible={true}
                                  onClose={() => setSelectedAccountLogs(null)}
                                />
                              </td>
                            </motion.tr>
                          )}
                        </React.Fragment>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </CardContent>
        </Card>
      </motion.div>

      {/* Orders Section */}
      {orders.length > 0 && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.2 }}
        >
          <OrderTracker orders={orders} />
        </motion.div>
      )}
    </motion.div>
  );
};

export default MainDashboard;