import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { 
  Package, 
  Truck, 
  MapPin, 
  Clock, 
  CheckCircle, 
  AlertCircle,
  XCircle
} from 'lucide-react';
import { Order } from '@/store/appStore';

interface OrderTrackerProps {
  orders: Order[];
}

const OrderTracker: React.FC<OrderTrackerProps> = ({ orders }) => {
  const getStatusColor = (status: Order['status']) => {
    switch (status) {
      case 'processing': return 'bg-blue-500/20 text-blue-400';
      case 'confirmed': return 'bg-amber-500/20 text-amber-400';
      case 'shipped': return 'bg-purple-500/20 text-purple-400';
      case 'delivered': return 'bg-green-500/20 text-green-400';
      case 'cancelled': return 'bg-red-500/20 text-red-400';
      default: return 'bg-gray-500/20 text-gray-400';
    }
  };

  const getStatusIcon = (status: Order['status']) => {
    switch (status) {
      case 'processing': return <Clock className="w-4 h-4" />;
      case 'confirmed': return <CheckCircle className="w-4 h-4" />;
      case 'shipped': return <Truck className="w-4 h-4" />;
      case 'delivered': return <Package className="w-4 h-4" />;
      case 'cancelled': return <XCircle className="w-4 h-4" />;
      default: return <AlertCircle className="w-4 h-4" />;
    }
  };

  const getStatusProgress = (status: Order['status']) => {
    switch (status) {
      case 'processing': return 25;
      case 'confirmed': return 50;
      case 'shipped': return 75;
      case 'delivered': return 100;
      case 'cancelled': return 0;
      default: return 0;
    }
  };

  const getStatusText = (status: Order['status']) => {
    switch (status) {
      case 'processing': return 'Обработка';
      case 'confirmed': return 'Подтвержден';
      case 'shipped': return 'Отправлен';
      case 'delivered': return 'Доставлен';
      case 'cancelled': return 'Отменен';
      default: return 'Неизвестно';
    }
  };

  const getDeliveryMethodIcon = (method: Order['deliveryMethod']) => {
    switch (method) {
      case 'pickup': return <Package className="w-4 h-4" />;
      case 'courier': return <Truck className="w-4 h-4" />;
      case 'postmat': return <MapPin className="w-4 h-4" />;
    }
  };

  const getDeliveryMethodText = (method: Order['deliveryMethod']) => {
    switch (method) {
      case 'pickup': return 'Самовывоз (ПВЗ)';
      case 'courier': return 'Курьерская доставка';
      case 'postmat': return 'Постамат (24/7)';
    }
  };

  const formatDate = (timestamp: number) => {
    return new Date(timestamp).toLocaleDateString('ru-RU', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  if (orders.length === 0) {
    return (
      <Card className="bg-card/80 backdrop-blur-sm border-border/50">
        <CardContent className="p-8 text-center">
          <Package className="w-12 h-12 mx-auto mb-4 opacity-50 text-muted-foreground" />
          <p className="text-muted-foreground">У вас пока нет активных заказов</p>
          <p className="text-sm text-muted-foreground/70">Заказы появятся здесь после оформления</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-card/80 backdrop-blur-sm border-border/50">
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <Package className="w-5 h-5" />
          <span>Активные заказы</span>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {orders.map((order, index) => (
          <motion.div
            key={order.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className="p-4 rounded-lg bg-muted/20 border border-border/30 space-y-3"
          >
            {/* Order Header */}
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-gradient-to-br from-primary to-blue-400 rounded-full flex items-center justify-center text-sm font-bold text-primary-foreground">
                  {order.accountName.charAt(0).toUpperCase()}
                </div>
                <div>
                  <p className="font-medium">{order.productName}</p>
                  <p className="text-sm text-muted-foreground">
                    Заказ #{order.id.split('-').pop()?.toUpperCase()}
                  </p>
                </div>
              </div>
              <Badge className={getStatusColor(order.status)}>
                {getStatusIcon(order.status)}
                <span className="ml-1">{getStatusText(order.status)}</span>
              </Badge>
            </div>

            {/* Progress Bar */}
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Прогресс заказа</span>
                <span className="text-muted-foreground">{getStatusProgress(order.status)}%</span>
              </div>
              <Progress 
                value={getStatusProgress(order.status)} 
                className="h-2"
              />
            </div>

            {/* Order Details */}
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div className="space-y-1">
                <p className="text-muted-foreground">Аккаунт:</p>
                <p className="font-medium">{order.accountName}</p>
              </div>
              <div className="space-y-1">
                <p className="text-muted-foreground">Способ доставки:</p>
                <div className="flex items-center space-x-1">
                  {getDeliveryMethodIcon(order.deliveryMethod)}
                  <span>{getDeliveryMethodText(order.deliveryMethod)}</span>
                </div>
              </div>
              <div className="space-y-1">
                <p className="text-muted-foreground">Стоимость:</p>
                <p className="font-medium">{order.productPrice.toLocaleString()} RUB</p>
              </div>
              <div className="space-y-1">
                <p className="text-muted-foreground">Дата создания:</p>
                <p>{formatDate(order.createdAt)}</p>
              </div>
            </div>

            {/* Delivery Address */}
            <div className="space-y-1">
              <p className="text-sm text-muted-foreground">Адрес доставки:</p>
              <div className="flex items-center space-x-1 text-sm">
                <MapPin className="w-4 h-4 text-muted-foreground" />
                <span>{order.deliveryAddress}</span>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex justify-end space-x-2 pt-2">
              <Button variant="outline" size="sm" disabled>
                Отследить
              </Button>
              {order.status === 'processing' && (
                <Button variant="outline" size="sm" disabled>
                  Отменить заказ
                </Button>
              )}
            </div>
          </motion.div>
        ))}
      </CardContent>
    </Card>
  );
};

export { OrderTracker };