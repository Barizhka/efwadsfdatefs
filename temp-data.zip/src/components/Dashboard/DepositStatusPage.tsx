import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { ArrowLeft, CheckCircle, Clock, XCircle, FileImage, CreditCard } from "lucide-react";
import { useNavigate, useParams } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { supabase } from "@/integrations/supabase/client";

interface DepositRequest {
  id: string;
  user_id: string;
  amount: number;
  status: string;
  payment_method: string;
  receipt_image_url: string | null;
  created_at: string;
  updated_at: string;
  reviewed_at: string | null;
  reviewed_by: string | null;
  rejection_reason: string | null;
}

export const DepositStatusPage = () => {
  const navigate = useNavigate();
  const { requestId } = useParams<{ requestId: string }>();
  const [depositRequest, setDepositRequest] = useState<DepositRequest | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (requestId) {
      fetchDepositRequest();
      
      // Set up real-time subscription
      const channel = supabase
        .channel('deposit-status')
        .on(
          'postgres_changes',
          {
            event: 'UPDATE',
            schema: 'public',
            table: 'academic_discount_verifications',
            filter: `id=eq.${requestId}`
          },
          (payload) => {
            const formattedData = {
              id: payload.new.id,
              user_id: payload.new.user_id,
              amount: 100,
              status: payload.new.verification_status || 'pending',
              payment_method: 'bank_transfer',
              receipt_image_url: payload.new.verification_document_url,
              created_at: payload.new.created_at,
              updated_at: payload.new.updated_at,
              reviewed_at: payload.new.verified_at,
              reviewed_by: null,
              rejection_reason: ''
            };
            setDepositRequest(formattedData);
          }
        )
        .subscribe();

      return () => {
        supabase.removeChannel(channel);
      };
    }
  }, [requestId]);

  const fetchDepositRequest = async () => {
    if (!requestId) return;

    try {
      const { data, error } = await supabase
        .from('academic_discount_verifications')
        .select('*')
        .eq('id', requestId)
        .maybeSingle();

      if (error) {
        console.error('Error fetching deposit request:', error);
        return;
      }

      if (data) {
        // Преобразуем данные в нужный формат
        const formattedData = {
          id: data.id,
          user_id: data.user_id,
          amount: 100,
          status: data.verification_status || 'pending',
          payment_method: 'bank_transfer',
          receipt_image_url: data.verification_document_url,
          admin_notes: '',
          created_at: data.created_at,
          updated_at: data.updated_at,
          reviewed_at: data.verified_at,
          reviewed_by: null,
          rejection_reason: ''
        };
        setDepositRequest(formattedData);
      }
    } catch (error) {
      console.error('Error:', error);
    } finally {
      setLoading(false);
    }
  };

  const getStatusInfo = (status: string) => {
    switch (status) {
      case 'pending':
        return {
          icon: <Clock className="w-5 h-5" />,
          label: "На рассмотрении",
          color: "bg-orange-500/10 text-orange-500 border-orange-500/20",
          description: "Ваша заявка находится на рассмотрении администратором"
        };
      case 'approved':
        return {
          icon: <CheckCircle className="w-5 h-5" />,
          label: "Одобрена",
          color: "bg-green-500/10 text-green-500 border-green-500/20",
          description: "Заявка одобрена, средства зачислены на баланс"
        };
      case 'rejected':
        return {
          icon: <XCircle className="w-5 h-5" />,
          label: "Отклонена",
          color: "bg-red-500/10 text-red-500 border-red-500/20",
          description: "Заявка отклонена администратором"
        };
      default:
        return {
          icon: <Clock className="w-5 h-5" />,
          label: "Неизвестно",
          color: "bg-gray-500/10 text-gray-500 border-gray-500/20",
          description: ""
        };
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleString('ru-RU', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  if (loading) {
    return (
      <div className="container mx-auto p-6 max-w-4xl">
        <div className="animate-pulse space-y-6">
          <div className="h-8 bg-muted rounded w-1/3"></div>
          <div className="h-48 bg-muted rounded"></div>
        </div>
      </div>
    );
  }

  if (!depositRequest) {
    return (
      <div className="container mx-auto p-6 max-w-4xl">
        <Card>
          <CardContent className="text-center py-12">
            <XCircle className="w-16 h-16 mx-auto text-red-500 mb-4" />
            <h2 className="text-xl font-semibold mb-2">Заявка не найдена</h2>
            <p className="text-muted-foreground mb-4">
              Заявка с указанным ID не существует или у вас нет доступа к ней
            </p>
            <Button onClick={() => navigate("/deposit")}>
              Вернуться к пополнению
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const statusInfo = getStatusInfo(depositRequest.status);

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="container mx-auto p-6 max-w-4xl"
    >
      {/* Header */}
      <div className="flex items-center gap-4 mb-6">
        <Button
          variant="ghost"
          onClick={() => navigate("/deposit")}
          className="flex items-center gap-2"
        >
          <ArrowLeft className="w-4 h-4" />
          Назад
        </Button>
        <h1 className="text-2xl font-bold">Статус заявки на пополнение</h1>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main content */}
        <div className="lg:col-span-2 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <span>Заявка #{depositRequest.id.slice(-8).toUpperCase()}</span>
                <Badge variant="outline" className={statusInfo.color}>
                  <div className="flex items-center gap-2">
                    {statusInfo.icon}
                    {statusInfo.label}
                  </div>
                </Badge>
              </CardTitle>
              <CardDescription>
                {statusInfo.description}
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-muted-foreground">Сумма</p>
                  <p className="text-2xl font-bold">{depositRequest.amount} ₽</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Способ оплаты</p>
                  <div className="flex items-center gap-2">
                    <CreditCard className="w-4 h-4" />
                    <span>Банковский перевод</span>
                  </div>
                </div>
              </div>

              <div>
                <p className="text-sm text-muted-foreground">Дата создания</p>
                <p>{formatDate(depositRequest.created_at)}</p>
              </div>

              {depositRequest.reviewed_at && (
                <div>
                  <p className="text-sm text-muted-foreground">Дата рассмотрения</p>
                  <p>{formatDate(depositRequest.reviewed_at)}</p>
                </div>
              )}

              {depositRequest.rejection_reason && (
                <Alert>
                  <XCircle className="h-4 w-4" />
                  <AlertDescription>
                    <strong>Причина отклонения:</strong> {depositRequest.rejection_reason}
                  </AlertDescription>
                </Alert>
              )}
            </CardContent>
          </Card>

          {/* Receipt preview */}
          {depositRequest.receipt_image_url && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <FileImage className="w-5 h-5" />
                  Чек об оплате
                </CardTitle>
              </CardHeader>
              <CardContent>
                <img 
                  src={depositRequest.receipt_image_url} 
                  alt="Чек об оплате"
                  className="max-w-full h-auto rounded-lg border"
                />
              </CardContent>
            </Card>
          )}
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Что дальше?</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {depositRequest.status === 'pending' && (
                <Alert>
                  <Clock className="h-4 w-4" />
                  <AlertDescription>
                    Ваша заявка обрабатывается. Обычно это занимает от 15 минут до 24 часов.
                  </AlertDescription>
                </Alert>
              )}

              {depositRequest.status === 'approved' && (
                <Alert>
                  <CheckCircle className="h-4 w-4" />
                  <AlertDescription>
                    Отлично! Средства зачислены на ваш баланс. Можете приступать к покупкам.
                  </AlertDescription>
                </Alert>
              )}

              {depositRequest.status === 'rejected' && (
                <Alert>
                  <XCircle className="h-4 w-4" />
                  <AlertDescription>
                    К сожалению, заявка отклонена. Проверьте правильность реквизитов и попробуйте снова.
                  </AlertDescription>
                </Alert>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Поддержка</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground mb-3">
                Есть вопросы по заявке? Обратитесь в поддержку.
              </p>
              <Button variant="outline" className="w-full">
                Написать в поддержку
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </motion.div>
  );
};