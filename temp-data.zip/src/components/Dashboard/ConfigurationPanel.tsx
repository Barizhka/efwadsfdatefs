import React from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Slider } from '@/components/ui/slider';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Brain, Shield, Gamepad2, Clock } from 'lucide-react';

interface ConfigSectionProps {
  title: string;
  icon: React.ComponentType<{ className?: string }>;
  children: React.ReactNode;
}

const ConfigSection = ({ title, icon: Icon, children }: ConfigSectionProps) => (
  <Card className="p-6 card-gradient card-hover">
    <div className="flex items-center space-x-2 mb-4">
      <Icon className="w-5 h-5 text-primary" />
      <h3 className="text-lg font-semibold">{title}</h3>
    </div>
    {children}
  </Card>
);

const ConfigurationPanel = () => {
  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      {/* Neural Network Configuration */}
      <ConfigSection title="Нейронная архитектура" icon={Brain}>
        <div className="space-y-4">
          <div>
            <label className="text-sm font-medium text-muted-foreground">Архитектура нейросети</label>
            <Select defaultValue="transformer">
              <SelectTrigger className="mt-1">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="transformer">Transformer + LSTM (рекомендуется)</SelectItem>
                <SelectItem value="neural">Neural Human v3</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <div>
            <label className="text-sm font-medium text-muted-foreground">Модель поведения</label>
            <Select defaultValue="neural-human">
              <SelectTrigger className="mt-1">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="neural-human">Neural Human v3 (рекомендуется)</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <label className="text-sm font-medium text-muted-foreground mb-2 block">
              Глубина модели: 8 слоев
            </label>
            <Slider defaultValue={[8]} max={20} step={1} className="w-full" />
          </div>

          <div>
            <label className="text-sm font-medium text-muted-foreground mb-2 block">
              Learning Rate: 0.001
            </label>
            <Slider defaultValue={[0.001]} max={0.01} step={0.0001} className="w-full" />
          </div>

          <div>
            <label className="text-sm font-medium text-muted-foreground mb-2 block">
              Batch Size: 32
            </label>
            <Slider defaultValue={[32]} max={128} step={1} className="w-full" />
          </div>
        </div>
      </ConfigSection>

      {/* Behavior Emulation */}
      <ConfigSection title="Эмуляция поведения" icon={Gamepad2}>
        <div className="space-y-4">
          <div>
            <label className="text-sm font-medium text-muted-foreground">Модель движения мыши</label>
            <Select defaultValue="biomechanical">
              <SelectTrigger className="mt-1">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="biomechanical">Biomechanical v2</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <label className="text-sm font-medium text-muted-foreground mb-2 block">
              Точность касаний: 92%
            </label>
            <Slider defaultValue={[92]} max={100} step={1} className="w-full" />
          </div>

          <div>
            <label className="text-sm font-medium text-muted-foreground mb-2 block">
              Вариативность реакций: 35%
            </label>
            <Slider defaultValue={[35]} max={100} step={1} className="w-full" />
          </div>

          <div>
            <label className="text-sm font-medium text-muted-foreground">Биомеханическая модель касаний</label>
            <Select defaultValue="human-hand">
              <SelectTrigger className="mt-1">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="human-hand">Human Hand v2</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <label className="text-sm font-medium text-muted-foreground mb-2 block">
              Вариация отпечатков: 85%
            </label>
            <Slider defaultValue={[85]} max={100} step={1} className="w-full" />
          </div>
        </div>
      </ConfigSection>

      {/* Anti-Detection System */}
      <ConfigSection title="Система анти-детекции" icon={Shield}>
        <div className="space-y-4">
          <div>
            <label className="text-sm font-medium text-muted-foreground mb-2 block">
              Уровень анти-детекции: 90%
            </label>
            <Slider defaultValue={[90]} max={100} step={1} className="w-full" />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="flex items-center justify-between">
              <label className="text-sm font-medium text-muted-foreground">Отпечатки поведения</label>
              <Switch defaultChecked />
            </div>
            <div className="flex items-center justify-between">
              <label className="text-sm font-medium text-muted-foreground">Динамические паттерны</label>
              <Switch defaultChecked />
            </div>
            <div className="flex items-center justify-between">
              <label className="text-sm font-medium text-muted-foreground">Человеческие ошибки</label>
              <Switch defaultChecked />
            </div>
            <div className="flex items-center justify-between">
              <label className="text-sm font-medium text-muted-foreground">Симуляция усталости</label>
              <Switch defaultChecked />
            </div>
          </div>
        </div>
      </ConfigSection>

      {/* Machine Learning */}
      <ConfigSection title="Машинное обучение" icon={Brain}>
        <div className="space-y-4">
          <div>
            <label className="text-sm font-medium text-muted-foreground mb-2 block">
              Эпохи обучения: 100
            </label>
            <Slider defaultValue={[100]} max={1000} step={10} className="w-full" />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="flex items-center justify-between">
              <label className="text-sm font-medium text-muted-foreground">Обучение с подкреплением</label>
              <Switch defaultChecked />
            </div>
            <div className="flex items-center justify-between">
              <label className="text-sm font-medium text-muted-foreground">Распознавание паттернов</label>
              <Switch defaultChecked />
            </div>
            <div className="flex items-center justify-between">
              <label className="text-sm font-medium text-muted-foreground">A/B тестирование</label>
              <Switch defaultChecked />
            </div>
            <div className="flex items-center justify-between">
              <label className="text-sm font-medium text-muted-foreground">Адаптивная оптимизация</label>
              <Switch defaultChecked />
            </div>
          </div>

          <div className="mt-4 p-4 bg-success/10 border border-success/20 rounded-lg">
            <div className="flex items-center space-x-2 mb-2">
              <div className="w-2 h-2 bg-success rounded-full"></div>
              <span className="text-sm font-medium text-success">Статус нейросети</span>
            </div>
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <span className="text-muted-foreground">Обученность модели:</span>
                <span className="font-medium ml-2">87.4%</span>
              </div>
              <div>
                <span className="text-muted-foreground">Точность предсказаний:</span>
                <span className="font-medium ml-2">94.1%</span>
              </div>
            </div>
          </div>
        </div>
      </ConfigSection>
    </div>
  );
};

export default ConfigurationPanel;