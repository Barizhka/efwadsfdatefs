import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem } from '@/components/ui/command';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Check, ChevronsUpDown, MapPin, Play } from 'lucide-react';
import { cn } from '@/lib/utils';
import { TOP_RUSSIAN_CITIES } from '@/data/cities';

interface WarmupCitySelectorProps {
  accountId: string;
  onCitySelected: (city: string) => void;
}

export const WarmupCitySelector: React.FC<WarmupCitySelectorProps> = ({ 
  accountId, 
  onCitySelected 
}) => {
  const [open, setOpen] = useState(false);
  const [selectedCity, setSelectedCity] = useState<string>('');

  const handleCitySelect = (city: string) => {
    setSelectedCity(city);
    setOpen(false);
  };

  const handleStartWarmup = () => {
    if (selectedCity) {
      onCitySelected(selectedCity);
    }
  };

  return (
    <div className="flex items-center space-x-2">
      <Popover open={open} onOpenChange={setOpen}>
        <PopoverTrigger asChild>
          <Button
            variant="outline"
            role="combobox"
            aria-expanded={open}
            className="w-[180px] justify-between"
            size="sm"
          >
            <MapPin className="w-4 h-4 mr-2" />
            {selectedCity || "Выберите город"}
            <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-[200px] p-0" align="start">
          <Command>
            <CommandInput placeholder="Поиск города..." />
            <CommandEmpty>Город не найден.</CommandEmpty>
            <CommandGroup className="max-h-[200px] overflow-y-auto">
              {TOP_RUSSIAN_CITIES.map((city) => (
                <CommandItem
                  key={city}
                  value={city}
                  onSelect={() => handleCitySelect(city)}
                >
                  <Check
                    className={cn(
                      "mr-2 h-4 w-4",
                      selectedCity === city ? "opacity-100" : "opacity-0"
                    )}
                  />
                  {city}
                </CommandItem>
              ))}
            </CommandGroup>
          </Command>
        </PopoverContent>
      </Popover>

      <Button 
        size="sm" 
        onClick={handleStartWarmup}
        disabled={!selectedCity}
        className="bg-amber-600 hover:bg-amber-700"
      >
        <Play className="w-4 h-4 mr-2" />
        Начать прогрев
      </Button>
    </div>
  );
};