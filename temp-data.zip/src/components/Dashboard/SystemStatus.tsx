import React, { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Button } from '@/components/ui/button';
import { Cpu, HardDrive, Clock, Zap } from 'lucide-react';
import { useAppStore } from '@/store/appStore';

interface SystemMetric {
  label: string;
  value: number;
  unit: string;
  color: 'primary' | 'success' | 'warning' | 'info';
}

const SystemStatus = () => {
  const { purchasedAccounts, isWarmupActive } = useAppStore();
  const [cpuUsage, setCpuUsage] = useState(0);
  const [memoryUsage, setMemoryUsage] = useState(0);
  const [warmupStartTime, setWarmupStartTime] = useState<number | null>(null);
  const [currentTime, setCurrentTime] = useState(Date.now());

  // Check if there are any active warmups
  const hasActiveWarmup = purchasedAccounts.some(account => account.warmupStarted && account.warmupProgress < 100) || isWarmupActive;
  const activeWarmupAccounts = purchasedAccounts.filter(account => account.warmupStarted && account.warmupProgress < 100);

  // Set warmup start time
  useEffect(() => {
    if (hasActiveWarmup && warmupStartTime === null) {
      // Use the earliest warmup start time from active accounts
      const earliestStartTime = activeWarmupAccounts
        .filter(acc => acc.warmupStartTime)
        .reduce((earliest, acc) => {
          return !earliest || (acc.warmupStartTime && acc.warmupStartTime < earliest) 
            ? acc.warmupStartTime! 
            : earliest;
        }, null as number | null);
      
      setWarmupStartTime(earliestStartTime || Date.now());
    } else if (!hasActiveWarmup && purchasedAccounts.length === 0) {
      setWarmupStartTime(null);
      setCpuUsage(0);
      setMemoryUsage(0);
    }
  }, [hasActiveWarmup, warmupStartTime, purchasedAccounts.length, activeWarmupAccounts]);

  // Update time every second
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentTime(Date.now());
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  // Update CPU and memory dynamically when warmup is active
  useEffect(() => {
    if (!hasActiveWarmup || !warmupStartTime) return;

    const interval = setInterval(() => {
      const minutesSinceStart = (Date.now() - warmupStartTime) / (1000 * 60);
      
      if (minutesSinceStart < 10) {
        // Gradual increase during first 10 minutes
        const targetCpu = 45;
        const targetMemory = 61;
        const progress = minutesSinceStart / 10;
        
        setCpuUsage(Math.max(12, targetCpu * progress));
        setMemoryUsage(Math.max(12, targetMemory * progress));
      } else {
        // After 10 minutes - fluctuations within limits (45 ± 10% for CPU, 61 ± 10% for memory)
        setCpuUsage(prev => {
          const changePercent = Math.random() < 0.3 ? 
            (Math.random() - 0.5) * 14 : // Sometimes up to 7%
            (Math.random() - 0.5) * 12;  // Usually 2-6%
          const newValue = 45 + changePercent;
          return Math.max(12, Math.min(99, Math.max(35, Math.min(55, newValue)))); // 45 ± 10%, never below 12% or above 99%
        });
        setMemoryUsage(prev => {
          const changePercent = Math.random() < 0.3 ? 
            (Math.random() - 0.5) * 14 : // Sometimes up to 7%
            (Math.random() - 0.5) * 12;  // Usually 2-6%
          const newValue = 61 + changePercent;
          return Math.max(12, Math.min(99, Math.max(51, Math.min(71, newValue)))); // 61 ± 10%, never below 12% or above 99%
        });
      }
    }, 60000); // Every minute

    return () => clearInterval(interval);
  }, [hasActiveWarmup, warmupStartTime]);

  // Calculate uptime in minutes
  const uptimeMinutes = warmupStartTime ? 
    Math.floor((currentTime - warmupStartTime) / (1000 * 60)) : 0;

  // Get number of active emulators (matches with emulator page)
  const activeEmulators = activeWarmupAccounts.length;

  const systemMetrics: SystemMetric[] = [
    { label: 'CPU нагрузка', value: Math.round(cpuUsage), unit: '%', color: 'warning' },
    { label: 'Память', value: Math.round(memoryUsage), unit: '%', color: 'info' },
    { label: 'Время работы', value: uptimeMinutes, unit: 'мин', color: 'success' },
    { label: 'Эмуляторы', value: activeEmulators, unit: '', color: 'primary' }
  ];

  // Show waiting state if no active warmup
  if (!hasActiveWarmup) {
    return (
      <Card className="p-6 card-gradient card-hover">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-semibold">Статус системы</h3>
          <Badge variant="outline" className="text-muted-foreground border-muted-foreground/20 bg-muted-foreground/10">
            Ожидание
          </Badge>
        </div>
        
        <div className="text-center py-8">
          <div className="text-muted-foreground mb-4">
            Аккаунтов на прогреве не найдено
          </div>
          <Button 
            onClick={() => window.location.href = '/accounts'}
            variant="outline"
          >
            Перейти в Аккаунты
          </Button>
        </div>
      </Card>
    );
  }

  return (
    <Card className="p-6 card-gradient card-hover">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-lg font-semibold">Статус системы</h3>
        <Badge variant="outline" className="text-success border-success/20 bg-success/10">
          Активен
        </Badge>
      </div>
      
      <div className="grid grid-cols-2 gap-6">
        {systemMetrics.map((metric, index) => (
          <div key={index} className="space-y-2">
            <div className="flex justify-between items-center">
              <span className="text-sm font-medium text-muted-foreground">
                {metric.label}
              </span>
              <span className={`text-lg font-bold ${
                metric.color === 'primary' ? 'text-primary' :
                metric.color === 'success' ? 'text-success' :
                metric.color === 'warning' ? 'text-warning' : 'text-info'
              }`}>
                {metric.value}{metric.unit}
              </span>
            </div>
            {metric.unit === '%' && (
              <Progress 
                value={metric.value} 
                className="h-2"
              />
            )}
          </div>
        ))}
      </div>
      
      <div className="mt-6 pt-6 border-t border-border">
        <div className="flex items-center justify-between text-sm text-muted-foreground">
          <span>Последнее обновление</span>
          <span>2 минуты назад</span>
        </div>
      </div>
    </Card>
  );
};

export default SystemStatus;