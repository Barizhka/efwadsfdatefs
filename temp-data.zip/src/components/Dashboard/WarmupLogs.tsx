import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useAppStore } from '@/store/appStore';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { 
  Activity, 
  Play, 
  Pause, 
  Square,
  Smartphone,
  MapPin,
  Clock,
  Zap,
  Music,
  Video,
  Search,
  Mail,
  Navigation,
  BookOpen,
  CreditCard
} from 'lucide-react';

interface WarmupLog {
  id: string;
  timestamp: string;
  accountId: string;
  accountName: string;
  city: string;
  action: string;
  service: string;
  status: 'OK' | 'VERIFY' | 'BAD_PROXY' | 'AUTH_ERROR';
  details?: string;
  icon?: React.ReactNode;
}

interface WarmupSession {
  id: string;
  accountName: string;
  city: string;
  status: 'running' | 'paused' | 'stopped';
  progress: number;
  startTime: string;
  logs: WarmupLog[];
  lastActivity: string;
}

const YANDEX_SERVICES = [
  { name: 'Яндекс.Поиск', icon: <Search className="w-4 h-4" />, activities: ['поиск "рецепты борща"', 'поиск "погода завтра"', 'поиск "новости спорта"'] },
  { name: 'Яндекс.Карты', icon: <MapPin className="w-4 h-4" />, activities: ['построение маршрута до ТЦ', 'поиск ресторанов рядом', 'просмотр пробок'] },
  { name: 'Яндекс.Музыка', icon: <Music className="w-4 h-4" />, activities: ['прослушивание плейлиста', 'лайк трека', 'создание плейлиста'] },
  { name: 'Яндекс.Видео', icon: <Video className="w-4 h-4" />, activities: ['просмотр фильма', 'добавление в избранное', 'поиск сериала'] },
  { name: 'Яндекс.Почта', icon: <Mail className="w-4 h-4" />, activities: ['отправка письма', 'чтение входящих', 'создание папки'] },
  { name: 'Яндекс.Навигатор', icon: <Navigation className="w-4 h-4" />, activities: ['построение маршрута', 'добавление точки', 'голосовые подсказки'] },
  { name: 'Яндекс.Дзен', icon: <BookOpen className="w-4 h-4" />, activities: ['чтение статьи', 'лайк публикации', 'подписка на автора'] },
  { name: 'Я.Пей', icon: <CreditCard className="w-4 h-4" />, activities: ['донат автору в Я.Музыке 50₽', 'пополнение баланса', 'оплата подписки'] }
];

const RUSSIAN_CITIES = [
  'Москва', 'Санкт-Петербург', 'Новосибирск', 'Екатеринбург', 'Казань',
  'Нижний Новгород', 'Челябинск', 'Самара', 'Омск', 'Ростов-на-Дону',
  'Уфа', 'Красноярск', 'Воронеж', 'Пермь', 'Волгоград'
];

const WarmupLogs: React.FC = () => {
  const { purchasedAccounts, isWarmupActive } = useAppStore();
  const [sessions, setSessions] = useState<WarmupSession[]>([]);

  // Генерация случайных логов
  const generateRandomLog = (accountId: string, accountName: string, city: string): WarmupLog => {
    const service = YANDEX_SERVICES[Math.floor(Math.random() * YANDEX_SERVICES.length)];
    const activity = service.activities[Math.floor(Math.random() * service.activities.length)];
    const statuses: Array<'OK' | 'VERIFY' | 'BAD_PROXY' | 'AUTH_ERROR'> = ['OK', 'OK', 'OK', 'OK', 'OK', 'VERIFY', 'BAD_PROXY'];
    const status = statuses[Math.floor(Math.random() * statuses.length)];
    
    return {
      id: `log-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      timestamp: new Date().toLocaleTimeString('ru-RU'),
      accountId,
      accountName,
      city,
      action: activity,
      service: service.name,
      status,
      icon: service.icon,
      details: status === 'OK' ? 'Действие выполнено успешно' : 
               status === 'VERIFY' ? 'Требуется верификация аккаунта' :
               status === 'BAD_PROXY' ? 'Проблема с прокси-сервером' :
               'Ошибка аутентификации'
    };
  };

  // Инициализация сессий на основе купленных аккаунтов
  useEffect(() => {
    const hasActiveWarmup = purchasedAccounts.some(account => account.warmupStarted) || isWarmupActive;
    
    if (!hasActiveWarmup || purchasedAccounts.length === 0) {
      setSessions([]);
      return;
    }

    // Create sessions only for accounts that have started warmup
    const warmupAccounts = purchasedAccounts.filter(account => account.warmupStarted);
    
    const initialSessions: WarmupSession[] = warmupAccounts.map((account, index) => ({
      id: `session-${account.id}`,
      accountName: account.username,
      city: account.selectedCity || account.city || RUSSIAN_CITIES[Math.floor(Math.random() * RUSSIAN_CITIES.length)],
      status: 'running' as const,
      progress: Math.max(12, Math.min(99, account.warmupProgress || (Math.random() * 40 + 30))),
      startTime: new Date(Date.now() - Math.random() * 3600000).toLocaleTimeString('ru-RU', { 
        hour: '2-digit', 
        minute: '2-digit' 
      }),
      logs: [],
      lastActivity: 'только что'
    }));

    setSessions(initialSessions);
  }, [purchasedAccounts, isWarmupActive]);

  // Генерация логов с разными интервалами
  useEffect(() => {
    const intervals: NodeJS.Timeout[] = [];

    sessions.forEach((session) => {
      if (session.status === 'running') {
        // Быстрые действия (каждые 10-30 секунд)
        const fastInterval = setInterval(() => {
          const service = YANDEX_SERVICES[Math.floor(Math.random() * 3)]; // Поиск, Карты, Почта
          if (service.name.includes('Поиск') || service.name.includes('Карты') || service.name.includes('Почта')) {
            const newLog = generateRandomLog(session.id, session.accountName, session.city);
            setSessions(prev => 
              prev.map(s => 
                s.id === session.id 
                  ? { 
                      ...s, 
                      logs: [newLog, ...s.logs.slice(0, 49)], // Оставляем последние 50 логов
                      lastActivity: 'только что',
                      progress: Math.min(s.progress + Math.random() * 2, 100)
                    }
                  : s
              )
            );
          }
        }, Math.random() * 20000 + 10000); // 10-30 секунд

        // Средние действия (каждые 1-5 минут)
        const mediumInterval = setInterval(() => {
          const service = YANDEX_SERVICES.find(s => s.name.includes('Музыка') || s.name.includes('Дзен'));
          if (service) {
            const newLog = generateRandomLog(session.id, session.accountName, session.city);
            newLog.service = service.name;
            newLog.action = service.activities[Math.floor(Math.random() * service.activities.length)];
            newLog.icon = service.icon;
            
            setSessions(prev => 
              prev.map(s => 
                s.id === session.id 
                  ? { 
                      ...s, 
                      logs: [newLog, ...s.logs.slice(0, 49)],
                      lastActivity: 'только что',
                      progress: Math.min(s.progress + Math.random() * 1.5, 100)
                    }
                  : s
              )
            );
          }
        }, Math.random() * 240000 + 60000); // 1-5 минут

        // Долгие действия (каждые 10-30 минут)
        const slowInterval = setInterval(() => {
          const service = YANDEX_SERVICES.find(s => s.name.includes('Видео') || s.name.includes('Пей'));
          if (service) {
            const newLog = generateRandomLog(session.id, session.accountName, session.city);
            newLog.service = service.name;
            newLog.action = service.activities[Math.floor(Math.random() * service.activities.length)];
            newLog.icon = service.icon;
            
            // Особая обработка для Я.Пей
            if (service.name === 'Я.Пей') {
              newLog.action = 'донат автору в Я.Музыке 50₽';
              newLog.details = 'Донат успешно отправлен автору';
            }
            
            setSessions(prev => 
              prev.map(s => 
                s.id === session.id 
                  ? { 
                      ...s, 
                      logs: [newLog, ...s.logs.slice(0, 49)],
                      lastActivity: 'только что',
                      progress: Math.min(s.progress + Math.random() * 3, 100)
                    }
                  : s
              )
            );
          }
        }, Math.random() * 1200000 + 600000); // 10-30 минут

        intervals.push(fastInterval, mediumInterval, slowInterval);
      }
    });

    return () => {
      intervals.forEach(interval => clearInterval(interval));
    };
  }, [sessions.map(s => s.status).join(',')]);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'OK': return 'bg-green-500/20 text-green-400 border-green-500/30';
      case 'VERIFY': return 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30';
      case 'BAD_PROXY': return 'bg-red-500/20 text-red-400 border-red-500/30';
      case 'AUTH_ERROR': return 'bg-orange-500/20 text-orange-400 border-orange-500/30';
      default: return 'bg-gray-500/20 text-gray-400 border-gray-500/30';
    }
  };

  const getSessionStatusColor = (status: string) => {
    switch (status) {
      case 'running': return 'bg-green-500/20 text-green-400 border-green-500/30';
      case 'paused': return 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30';
      case 'stopped': return 'bg-red-500/20 text-red-400 border-red-500/30';
      default: return 'bg-gray-500/20 text-gray-400 border-gray-500/30';
    }
  };

  const toggleSession = (sessionId: string, action: 'play' | 'pause' | 'stop') => {
    setSessions(prev => 
      prev.map(session => 
        session.id === sessionId 
          ? { 
              ...session, 
              status: action === 'play' ? 'running' : action === 'pause' ? 'paused' : 'stopped' 
            }
          : session
      )
    );
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-white">Логи прогрева Яндекс</h2>
          <p className="text-gray-400 mt-1">Мониторинг активности аккаунтов в реальном времени</p>
        </div>
      </div>

      {sessions.length === 0 ? (
        <Card className="bg-gray-800/50 border-gray-700">
          <CardContent className="p-8 text-center">
            <p className="text-gray-400 mb-4">Нет активных прогревов аккаунтов</p>
            <p className="text-sm text-gray-500">Запустите прогрев в разделе "Аккаунты"</p>
          </CardContent>
        </Card>
      ) : (
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {sessions.map((session) => (
          <motion.div
            key={session.id}
            layout
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-4"
          >
            <Card className="bg-gray-800/50 border-gray-700">
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <div className="w-8 h-8 bg-primary/20 rounded-full flex items-center justify-center">
                      <Smartphone className="w-4 h-4 text-primary" />
                    </div>
                    <div>
                      <CardTitle className="text-sm text-white">{session.accountName}</CardTitle>
                      <div className="flex items-center space-x-1 text-xs text-gray-400">
                        <MapPin className="w-3 h-3" />
                        <span>{session.city}</span>
                      </div>
                    </div>
                  </div>
                  <Badge className={getSessionStatusColor(session.status)}>
                    {session.status === 'running' ? 'Активен' : 
                     session.status === 'paused' ? 'Пауза' : 'Остановлен'}
                  </Badge>
                </div>
                
                <div className="space-y-2">
                  <div className="flex justify-between text-xs">
                    <span className="text-gray-400">Прогресс</span>
                    <span className="text-primary font-semibold">{session.progress.toFixed(1)}%</span>
                  </div>
                  <div className="w-full bg-gray-700 rounded-full h-1.5">
                    <div 
                      className="bg-primary h-1.5 rounded-full transition-all duration-300"
                      style={{ width: `${session.progress}%` }}
                    />
                  </div>
                </div>

                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-1 text-xs text-gray-400">
                    <Clock className="w-3 h-3" />
                    <span>Старт: {session.startTime}</span>
                  </div>
                  <div className="flex space-x-1">
                    <Button
                      size="sm"
                      variant="ghost"
                      className="h-6 w-6 p-0"
                      onClick={() => toggleSession(session.id, 'play')}
                      disabled={session.status === 'running'}
                    >
                      <Play className="w-3 h-3" />
                    </Button>
                    <Button
                      size="sm"
                      variant="ghost"
                      className="h-6 w-6 p-0"
                      onClick={() => toggleSession(session.id, 'pause')}
                      disabled={session.status === 'paused'}
                    >
                      <Pause className="w-3 h-3" />
                    </Button>
                    <Button
                      size="sm"
                      variant="ghost"
                      className="h-6 w-6 p-0"
                      onClick={() => toggleSession(session.id, 'stop')}
                      disabled={session.status === 'stopped'}
                    >
                      <Square className="w-3 h-3" />
                    </Button>
                  </div>
                </div>
              </CardHeader>
              
              <CardContent className="pt-0">
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-gray-400">Активность</span>
                    <span className="text-xs text-gray-400">{session.lastActivity}</span>
                  </div>
                  
                  <ScrollArea className="h-64">
                    <div className="space-y-2">
                      <AnimatePresence>
                        {session.logs.map((log) => (
                          <motion.div
                            key={log.id}
                            initial={{ opacity: 0, x: -20 }}
                            animate={{ opacity: 1, x: 0 }}
                            exit={{ opacity: 0, x: 20 }}
                            className="p-2 bg-gray-700/30 rounded-lg border border-gray-600/30"
                          >
                            <div className="flex items-start justify-between space-x-2">
                              <div className="flex items-start space-x-2 flex-1">
                                <div className="text-gray-400 mt-0.5">
                                  {log.icon}
                                </div>
                                <div className="flex-1 min-w-0">
                                  <div className="text-xs text-white font-medium">
                                    {log.service}
                                  </div>
                                  <div className="text-xs text-gray-300 break-words">
                                    {log.action}
                                  </div>
                                  <div className="flex items-center justify-between mt-1">
                                    <span className="text-xs text-gray-500">{log.timestamp}</span>
                                    <Badge className={`text-xs py-0 px-1 ${getStatusColor(log.status)}`}>
                                      {log.status}
                                    </Badge>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </motion.div>
                        ))}
                      </AnimatePresence>
                      
                      {session.logs.length === 0 && (
                        <div className="text-center py-4">
                          <Activity className="w-8 h-8 text-gray-600 mx-auto mb-2" />
                          <p className="text-xs text-gray-500">Ожидание активности...</p>
                        </div>
                      )}
                    </div>
                  </ScrollArea>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>
      )}
    </div>
  );
};

export default WarmupLogs;