import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { 
  CreditCard, 
  Banknote, 
  QrCode, 
  CheckCircle,
  Wallet,
  Copy,
  Star,
  AlertTriangle,
  FileText,
  CheckCircle2,
  Gift,
  AlertCircle
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useAppStore } from '@/store/appStore';
import { useNavigate } from 'react-router-dom';

const DepositPage = () => {
  const { user, setUser } = useAppStore();
  const { toast } = useToast();
  const navigate = useNavigate();
  const [amount, setAmount] = React.useState('');
  const [selectedMethod, setSelectedMethod] = React.useState('bank');
  const [showBankTransfer, setShowBankTransfer] = React.useState(false);
  const [orderNumber] = React.useState(Math.floor(Math.random() * 1000) + 100);

  const paymentMethods = [
    { id: 'bank', title: 'Банковский перевод', icon: Banknote, fee: '0%', time: '5-20 мин' },
    { id: 'crypto', title: 'Cryptobot', icon: Wallet, fee: '-5%', time: 'Мгновенно', bonus: true },
    { id: 'qr', title: 'QR-код оплата', icon: QrCode, fee: '1.5%', time: 'Мгновенно', disabled: true }
  ];

  // Добавляем минимальную сумму и функции

  const MIN_DEPOSIT = 2000;
  const BANK_CARD_NUMBER = '2202208256650426';

  const copyToClipboard = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      // Можно добавить toast уведомление о копировании
    } catch (err) {
      console.error('Failed to copy: ', err);
    }
  };

  const handleDeposit = () => {
    if (selectedMethod === 'bank' && parseFloat(amount) >= MIN_DEPOSIT) {
      navigate('/deposit/bank-transfer');
    } else if (selectedMethod === 'crypto') {
      toast({
        title: "Cryptobot пополнение",
        description: "Функция Cryptobot скоро будет доступна",
        variant: "default"
      });
    }
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
      className="space-y-8"
    >

      {/* Page Title */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold bg-gradient-to-r from-primary to-blue-400 bg-clip-text text-transparent">
          Пополнение баланса
        </h1>
        <p className="text-muted-foreground mt-1">Выберите удобный способ пополнения</p>
      </div>

      {/* Main Content */}
      <div className="grid grid-cols-1 xl:grid-cols-5 gap-8">
        {/* Left Column - Amount & Payment */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.3 }}
          className="xl:col-span-3 space-y-6"
        >
          {/* Amount Selection */}
          <Card className="overflow-hidden">
            <CardHeader className="bg-muted/30 border-b">
              <CardTitle className="flex items-center space-x-2">
                <CreditCard className="w-5 h-5 text-primary" />
                <span>Сумма пополнения</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="p-6">
              <div className="space-y-4">
                <div>
                  <Label htmlFor="amount" className="text-sm font-medium">
                    Введите сумму (₽) - минимум {MIN_DEPOSIT}₽
                  </Label>
                  <Input
                    id="amount"
                    type="number"
                    placeholder="2000"
                    min={MIN_DEPOSIT}
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    className="text-xl font-semibold h-14 mt-2"
                  />
                </div>
                
                <div>
                  <p className="text-sm font-medium mb-3">Быстрый выбор:</p>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                    {[2000, 5000, 10000, 25000].map((preset) => (
                      <Button
                        key={preset}
                        variant={amount === preset.toString() ? "default" : "outline"}
                        onClick={() => setAmount(preset.toString())}
                        className="h-12 font-semibold"
                      >
                        {preset.toLocaleString()}₽
                      </Button>
                    ))}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
          {/* Payment Methods */}
          <Card className="overflow-hidden">
            <CardHeader className="bg-muted/30 border-b">
              <CardTitle className="flex items-center space-x-2">
                <Wallet className="w-5 h-5 text-primary" />
                <span>Способы оплаты</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="p-6">
              <div className="grid gap-4">
                {paymentMethods.map((method, index) => (
                  <motion.div
                    key={method.id}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.4 + index * 0.1 }}
                  >
                    <div
                      className={`relative p-4 rounded-xl border-2 transition-all duration-300 cursor-pointer group ${
                        method.disabled 
                          ? 'border-border/30 bg-muted/30 cursor-not-allowed opacity-60'
                          : selectedMethod === method.id
                          ? 'border-primary bg-primary/5 shadow-lg shadow-primary/10'
                          : 'border-border/50 hover:border-primary/50 hover:bg-primary/2'
                      }`}
                      onClick={() => {
                        if (method.disabled) {
                          toast({
                            title: "В разработке",
                            description: "Данный способ пополнения еще в разработке",
                            variant: "default"
                          });
                        } else {
                          setSelectedMethod(method.id);
                        }
                      }}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-4">
                          <div className={`p-3 rounded-lg transition-colors ${
                            selectedMethod === method.id ? 'bg-primary/20' : 'bg-muted/50 group-hover:bg-primary/10'
                          }`}>
                            <method.icon className={`w-6 h-6 transition-colors ${
                              selectedMethod === method.id ? 'text-primary' : 'text-muted-foreground group-hover:text-primary'
                            }`} />
                          </div>
                          <div>
                            <div className="flex items-center space-x-2">
                              <h3 className="font-semibold text-base">{method.title}</h3>
                              {method.disabled && (
                                <div className="flex items-center space-x-1 px-2 py-1 bg-orange-500/10 text-orange-400 rounded-full text-sm">
                                  <AlertCircle className="w-4 h-4" />
                                  <span>В разработке</span>
                                </div>
                              )}
                            </div>
                            <div className="flex items-center space-x-4 text-sm text-muted-foreground mt-1">
                              <span className="font-medium">{method.bonus ? 'Бонус пополнения 5%' : `Комиссия: ${method.fee}`}</span>
                              <span>•</span>
                              <span>{method.time}</span>
                            </div>
                          </div>
                        </div>
                        {selectedMethod === method.id && !method.disabled && (
                          <div className="w-6 h-6 bg-primary rounded-full flex items-center justify-center">
                            <CheckCircle className="w-4 h-4 text-white" />
                          </div>
                        )}
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Action Button */}
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.8 }}
          >
            <Button 
              className="w-full bg-gradient-to-r from-primary to-primary/80 hover:from-primary/90 hover:to-primary/70 shadow-lg shadow-primary/25 text-lg py-6 h-16 font-semibold transition-all duration-300"
              disabled={!amount || parseFloat(amount) < MIN_DEPOSIT}
              onClick={handleDeposit}
            >
              <CreditCard className="w-6 h-6 mr-3" />
              Пополнить на {amount ? parseFloat(amount).toLocaleString() : '0'}₽
            </Button>
          </motion.div>
        </motion.div>

        {/* Right Column - Help & Info */}
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.5 }}
          className="xl:col-span-2 space-y-6"
        >
          {/* Balance Card */}
          <Card className="bg-gradient-to-br from-primary/10 to-blue-500/5 border-primary/20 overflow-hidden">
            <CardContent className="p-6">
              <div className="text-center space-y-4">
                <div className="w-20 h-20 bg-gradient-to-br from-primary/20 to-blue-400/20 rounded-2xl flex items-center justify-center mx-auto">
                  <Wallet className="w-10 h-10 text-primary" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Текущий баланс</p>
                  <p className="text-3xl font-bold text-primary">{user.balance}₽</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Help Card */}
          <Card className="bg-gradient-to-br from-primary/5 to-blue-500/5 border-primary/20 overflow-hidden">
            <CardContent className="p-6">
              <div className="text-center space-y-4">
                <div className="w-20 h-20 bg-gradient-to-br from-primary/20 to-blue-400/20 rounded-2xl flex items-center justify-center mx-auto">
                  <Wallet className="w-10 h-10 text-primary" />
                </div>
                <div>
                  <h3 className="text-xl font-bold mb-2">Нужна помощь?</h3>
                  <p className="text-muted-foreground">
                    Наша служба поддержки готова помочь вам с любыми вопросами по пополнению баланса
                  </p>
                </div>
                <Button 
                  variant="outline" 
                  className="w-full border-primary/30 text-primary hover:bg-primary/10 h-12"
                >
                  Связаться с поддержкой
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Info Card */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <AlertTriangle className="w-5 h-5 text-amber-500" />
                <span>Важная информация</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3 text-sm">
              <div className="flex items-start space-x-2">
                <div className="w-2 h-2 bg-primary rounded-full mt-2 flex-shrink-0"></div>
                <p>Минимальная сумма пополнения: {MIN_DEPOSIT}₽</p>
              </div>
              <div className="flex items-start space-x-2">
                <div className="w-2 h-2 bg-primary rounded-full mt-2 flex-shrink-0"></div>
                <p>Средства зачисляются автоматически после подтверждения</p>
              </div>
              <div className="flex items-start space-x-2">
                <div className="w-2 h-2 bg-primary rounded-full mt-2 flex-shrink-0"></div>
                <p>При возникновении проблем обращайтесь в поддержку</p>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>

      {/* Bank Transfer Modal */}
      {showBankTransfer && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4"
          onClick={() => setShowBankTransfer(false)}
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            className="bg-card border border-border/50 rounded-lg p-6 max-w-md w-full mx-auto"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="space-y-6">
              {/* Header */}
              <div className="flex items-center space-x-3 pb-4 border-b border-border/30">
                <div className="w-10 h-10 bg-gradient-to-br from-primary/20 to-blue-400/20 rounded-full flex items-center justify-center">
                  <Banknote className="w-5 h-5 text-primary" />
                </div>
                <div>
                  <h3 className="text-lg font-semibold">Заявка №{orderNumber}</h3>
                  <p className="text-sm text-muted-foreground">Банковский перевод</p>
                </div>
              </div>

              {/* Amount */}
              <div className="flex items-center space-x-3 p-4 bg-gradient-to-r from-primary/10 to-blue-400/5 rounded-lg border border-primary/20">
                <Star className="w-5 h-5 text-primary" />
                <div>
                  <p className="text-sm text-muted-foreground">Для успешного оформления депозита переведите</p>
                  <p className="text-xl font-bold text-primary">{amount} RUB</p>
                  <p className="text-sm text-muted-foreground">на указанные реквизиты:</p>
                </div>
              </div>

              {/* Card Details */}
              <div className="space-y-3">
                <div className="flex items-center justify-between p-4 bg-muted/20 rounded-lg border border-border/30">
                  <div className="flex items-center space-x-3">
                    <CreditCard className="w-5 h-5 text-primary" />
                    <div>
                      <p className="text-sm font-medium">Реквизиты</p>
                      <p className="text-lg font-mono font-bold">{BANK_CARD_NUMBER}</p>
                    </div>
                  </div>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => copyToClipboard(BANK_CARD_NUMBER)}
                    className="border-primary/30 text-primary hover:bg-primary/10"
                  >
                    <Copy className="w-4 h-4" />
                  </Button>
                </div>

                {/* Warning */}
                <div className="flex items-start space-x-3 p-4 bg-amber-500/10 rounded-lg border border-amber-500/20">
                  <AlertTriangle className="w-5 h-5 text-amber-400 mt-0.5 flex-shrink-0" />
                  <div>
                    <p className="text-sm font-medium text-amber-400">Важная информация</p>
                    <p className="text-sm text-amber-400/80">Переводы со СберБанка не принимаются!</p>
                  </div>
                </div>

                {/* Receipt Info */}
                <div className="flex items-start space-x-3 p-4 bg-blue-500/10 rounded-lg border border-blue-500/20">
                  <FileText className="w-5 h-5 text-blue-400 mt-0.5 flex-shrink-0" />
                  <div>
                    <p className="text-sm font-medium text-blue-400">После оплаты</p>
                    <p className="text-sm text-blue-400/80">Необходимо предоставить чек в техническую поддержку</p>
                  </div>
                </div>
              </div>

              {/* Actions */}
              <div className="flex space-x-3 pt-4">
                <Button
                  variant="outline"
                  className="flex-1"
                  onClick={() => setShowBankTransfer(false)}
                >
                  Закрыть
                </Button>
                <Button
                  className="flex-1 bg-primary hover:bg-primary/90"
                  onClick={() => {
                    // Здесь можно добавить логику отправки в поддержку
                    setShowBankTransfer(false);
                  }}
                >
                  <CheckCircle2 className="w-4 h-4 mr-2" />
                  Понятно
                </Button>
              </div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </motion.div>
  );
};

export default DepositPage;