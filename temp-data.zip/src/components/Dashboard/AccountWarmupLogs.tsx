import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { 
  Activity, 
  Clock, 
  Wifi, 
  MapPin, 
  Monitor,
  ChevronRight,
  Eye,
  Server,
  Gauge
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';

interface AccountWarmupLogsProps {
  accountId: string;
  accountName: string;
  isVisible: boolean;
  onClose: () => void;
}

interface WarmupLog {
  id: string;
  timestamp: string;
  activity: string;
  status: 'success' | 'warning' | 'info';
  details: string;
}

export const AccountWarmupLogs: React.FC<AccountWarmupLogsProps> = ({ 
  accountId, 
  accountName, 
  isVisible, 
  onClose 
}) => {
  const navigate = useNavigate();
  const [logs, setLogs] = useState<WarmupLog[]>([]);

  // Generate consistent logs for the account
  useEffect(() => {
    if (!isVisible) return;

    const activities = [
      { activity: "Инициализация профиля", details: "Настройка базовых параметров аккаунта", status: 'success' as const },
      { activity: "Подключение к прокси", details: "Установлено соединение через российский IP", status: 'success' as const },
      { activity: "Проверка геолокации", details: "Определена локация: Москва", status: 'info' as const },
      { activity: "Активация браузера", details: "Запущен Chrome с профилем пользователя", status: 'success' as const },
      { activity: "Симуляция активности", details: "Выполнены базовые действия пользователя", status: 'success' as const },
      { activity: "Мониторинг температуры", details: "Температура в норме: 42°C", status: 'info' as const },
      { activity: "Обновление метрик", details: "Синхронизация данных с сервером", status: 'success' as const },
      { activity: "Проверка стабильности", details: "Соединение стабильное", status: 'success' as const }
    ];

    // Generate 5 recent logs with time intervals
    const now = new Date();
    const isNightTime = now.getHours() >= 21 || now.getHours() < 9;
    
    if (isNightTime) {
      // During night time, show fewer logs or "sleeping" status
      setLogs([
        {
          id: `${accountId}-sleep`,
          timestamp: `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`,
          activity: "Ночной режим",
          details: "Аккаунт в режиме ожидания до 9:00",
          status: 'info'
        }
      ]);
      return;
    }

    // Generate logs with random intervals (10-100 seconds)
    const newLogs = activities.slice(0, 5).map((activity, index) => {
      const logTime = new Date(now.getTime() - (index * (Math.random() * 90 + 10) * 1000));
      return {
        id: `${accountId}-${index}`,
        timestamp: `${String(logTime.getHours()).padStart(2, '0')}:${String(logTime.getMinutes()).padStart(2, '0')}:${String(logTime.getSeconds()).padStart(2, '0')}`,
        activity: activity.activity,
        details: activity.details,
        status: activity.status
      };
    }).reverse();

    setLogs(newLogs);

    // Update logs every 10-100 seconds
    const interval = setInterval(() => {
      const now = new Date();
      const isNight = now.getHours() >= 21 || now.getHours() < 9;
      
      if (isNight) {
        setLogs([
          {
            id: `${accountId}-sleep`,
            timestamp: `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`,
            activity: "Ночной режим",
            details: "Аккаунт в режиме ожидания до 9:00",
            status: 'info'
          }
        ]);
        return;
      }

      const randomActivity = activities[Math.floor(Math.random() * activities.length)];
      const newLog: WarmupLog = {
        id: `${accountId}-${Date.now()}`,
        timestamp: `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}:${String(now.getSeconds()).padStart(2, '0')}`,
        activity: randomActivity.activity,
        details: randomActivity.details,
        status: randomActivity.status
      };

      setLogs(prev => [newLog, ...prev.slice(0, 4)]);
    }, Math.random() * 90000 + 10000); // 10-100 seconds

    return () => clearInterval(interval);
  }, [accountId, isVisible]);

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'success': return <Wifi className="w-4 h-4 text-green-400" />;
      case 'warning': return <Activity className="w-4 h-4 text-yellow-400" />;
      case 'info': return <Server className="w-4 h-4 text-blue-400" />;
      default: return <Activity className="w-4 h-4 text-gray-400" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'success': return 'bg-green-500/20 text-green-400 border-green-500/30';
      case 'warning': return 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30';
      case 'info': return 'bg-blue-500/20 text-blue-400 border-blue-500/30';
      default: return 'bg-gray-500/20 text-gray-400 border-gray-500/30';
    }
  };

  if (!isVisible) return null;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      className="mt-4"
    >
      <Card className="bg-card/80 backdrop-blur-sm border-border/50">
        <CardHeader className="pb-4">
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center space-x-2">
              <Eye className="w-5 h-5 text-primary" />
              <span>Онлайн логи - {accountName}</span>
              <Badge className="bg-green-500/20 text-green-400 border-green-500/30">
                <Activity className="w-3 h-3 mr-1" />
                Активен
              </Badge>
            </CardTitle>
            <div className="flex items-center space-x-2">
              <Button 
                size="sm" 
                onClick={() => navigate('/warmup')}
                className="bg-primary/20 hover:bg-primary/30 text-primary border border-primary/30"
              >
                <Monitor className="w-4 h-4 mr-2" />
                Мониторинг прогрева
                <ChevronRight className="w-4 h-4 ml-1" />
              </Button>
              <Button size="sm" variant="ghost" onClick={onClose}>
                Скрыть
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent className="pt-0">
          <div className="space-y-3">
            <div className="grid grid-cols-3 gap-4 p-3 bg-muted/30 rounded-lg">
              <div className="flex items-center space-x-2">
                <MapPin className="w-4 h-4 text-muted-foreground" />
                <span className="text-sm text-muted-foreground">Москва</span>
              </div>
              <div className="flex items-center space-x-2">
                <Gauge className="w-4 h-4 text-muted-foreground" />
                <span className="text-sm text-muted-foreground">42°C</span>
              </div>
              <div className="flex items-center space-x-2">
                <Clock className="w-4 h-4 text-muted-foreground" />
                <span className="text-sm text-muted-foreground">Активен</span>
              </div>
            </div>
            
            <Separator />
            
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <h4 className="text-sm font-medium text-foreground">Последние 5 логов</h4>
                <Badge variant="outline" className="text-xs">
                  Обновление: 10-100 сек
                </Badge>
              </div>
              
              <AnimatePresence mode="popLayout">
                {logs.map((log, index) => (
                  <motion.div
                    key={log.id}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: 20 }}
                    transition={{ delay: index * 0.1 }}
                    className="flex items-start space-x-3 p-3 bg-background/50 rounded-lg border border-border/30"
                  >
                    <div className="flex-shrink-0 mt-0.5">
                      {getStatusIcon(log.status)}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between">
                        <h5 className="text-sm font-medium text-foreground">{log.activity}</h5>
                        <span className="text-xs text-muted-foreground font-mono">{log.timestamp}</span>
                      </div>
                      <p className="text-xs text-muted-foreground mt-1">{log.details}</p>
                    </div>
                    <Badge className={`${getStatusColor(log.status)} text-xs`}>
                      {log.status === 'success' ? 'OK' : log.status === 'warning' ? 'WARN' : 'INFO'}
                    </Badge>
                  </motion.div>
                ))}
              </AnimatePresence>
              
              {logs.length === 0 && (
                <div className="text-center py-6 text-muted-foreground">
                  <Activity className="w-8 h-8 mx-auto mb-2 opacity-50" />
                  <p className="text-sm">Загрузка логов...</p>
                </div>
              )}
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
};