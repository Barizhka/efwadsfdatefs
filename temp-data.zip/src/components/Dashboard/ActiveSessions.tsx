import React from 'react';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Pause, Square, MoreHorizontal, AlertTriangle } from 'lucide-react';
import { useAppStore } from '@/store/appStore';

interface SessionData {
  email: string;
  progress: number;
  status: 'active' | 'paused' | 'completed';
  timeLeft: string;
  account: string;
}

const sessions: SessionData[] = [
  {
    email: 'user123@example.com',
    progress: 75,
    status: 'active',
    timeLeft: '15 мин',
    account: 'Активен'
  },
  {
    email: 'demo456@example.com',
    progress: 45,
    status: 'paused',
    timeLeft: '22 мин',
    account: 'На паузе'
  }
];

const getStatusColor = (status: string) => {
  switch (status) {
    case 'active': return 'bg-success text-success-foreground';
    case 'paused': return 'bg-warning text-warning-foreground';
    case 'completed': return 'bg-muted text-muted-foreground';
    default: return 'bg-muted text-muted-foreground';
  }
};

const getStatusText = (status: string) => {
  switch (status) {
    case 'active': return 'Активен';
    case 'paused': return 'На паузе';
    case 'completed': return 'Завершен';
    default: return 'Неизвестно';
  }
};

const ActiveSessions = () => {
  const { isWarmupActive, purchasedAccounts } = useAppStore();
  
  // Динамические сессии на основе состояния прогрева
  const activeSessions = isWarmupActive && purchasedAccounts.length > 0 ? sessions : [];
  
  return (
    <Card className="p-6 card-gradient card-hover">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-lg font-semibold">Активные сессии ({activeSessions.length})</h3>
        <Button variant="outline" size="sm">
          Управление
        </Button>
      </div>
      
      <div className="space-y-4">
        {activeSessions.length === 0 ? (
          <div className="text-center py-8">
            <p className="text-muted-foreground">Нет активных сессий</p>
            <p className="text-sm text-muted-foreground mt-2">Запустите прогрев аккаунтов для отображения активности</p>
          </div>
        ) : (
          activeSessions.map((session, index) => (
          <div key={index} className="p-4 border border-border rounded-lg bg-card/50">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center space-x-3">
                <div className="w-2 h-2 bg-primary rounded-full"></div>
                <span className="font-medium">{session.email}</span>
              </div>
              <Badge className={getStatusColor(session.status)}>
                {getStatusText(session.status)}
              </Badge>
            </div>
            
            <div className="space-y-3">
              <div className="flex justify-between text-sm text-muted-foreground">
                <span>Прогресс: {session.progress}%</span>
                <span>Осталось: {session.timeLeft}</span>
              </div>
              
              <Progress value={session.progress} className="h-2" />
              
              <div className="flex justify-between items-center">
                <div className="flex space-x-2">
                  <Button size="sm" variant="outline" className="h-8">
                    <Pause className="w-4 h-4 mr-1" />
                    Пауза
                  </Button>
                  <Button size="sm" variant="outline" className="h-8 text-destructive hover:text-destructive">
                    <Square className="w-4 h-4 mr-1" />
                    Остановить
                  </Button>
                </div>
                <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                  <MoreHorizontal className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </div>
        ))
        )}
      </div>
      
      <div className="mt-4 p-3 bg-muted/30 rounded-lg">
        <p className="text-sm text-muted-foreground">
          <AlertTriangle className="w-4 h-4 text-amber-500 inline mr-2" />
          Управление сессиями заблокировано. Используйте основную панель.
        </p>
      </div>
    </Card>
  );
};

export default ActiveSessions;