import React from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card } from '@/components/ui/card';
import { Clock, Users, BarChart3, Zap } from 'lucide-react';

const tabItems = [
  { id: 'monitoring', label: 'Мониторинг', active: true },
  { id: 'accounts', label: 'Аккаунты', active: false },
  { id: 'analytics', label: 'Аналитика', active: false }
];

const TopNavigation = () => {
  return (
    <Card className="p-6 card-gradient border-0 rounded-none border-b border-border">
      <div className="space-y-6">
        {/* Title and Smart Config Button */}
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-bold">Умная конфигурация фермы</h1>
          <Button className="gradient-primary">
            Сохранить
          </Button>
        </div>
        
        {/* Subtitle */}
        <p className="text-sm text-muted-foreground">
          Адаптивные настройки на основе реальной статистики и машинного обучения
        </p>

        {/* Tab Navigation */}
        <div className="flex space-x-1 bg-muted/30 p-1 rounded-lg w-fit">
          {tabItems.map((tab) => (
            <Button
              key={tab.id}
              variant={tab.active ? "default" : "ghost"}
              size="sm"
              className={tab.active ? "gradient-primary" : ""}
            >
              {tab.label}
            </Button>
          ))}
        </div>
      </div>
    </Card>
  );
};

export default TopNavigation;