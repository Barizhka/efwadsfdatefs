import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Slider } from '@/components/ui/slider';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Progress } from '@/components/ui/progress';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { useToast } from '@/hooks/use-toast';
import SystemStatus from './SystemStatus';
import { 
  Settings, 
  Zap, 
  Brain, 
  Shield, 
  Activity,
  Clock,
  Cpu,
  Database,
  Target,
  MousePointer,
  Eye,
  BookOpen,
  BarChart,
  Calendar,
  Moon,
  Users,
  CheckCircle,
  AlertTriangle
} from 'lucide-react';

const FarmConfigPage = () => {
  const { toast } = useToast();
  const [isSaving, setIsSaving] = useState(false);
  const [isAccessDialogOpen, setIsAccessDialogOpen] = useState(false);
  const [accessKey, setAccessKey] = useState('');
  const [showAccessError, setShowAccessError] = useState(false);
  const [isAccessLoading, setIsAccessLoading] = useState(false);

  // Neural Architecture States
  const [neuralArchitecture, setNeuralArchitecture] = React.useState('transformer_lstm');
  const [behaviorModel, setBehaviorModel] = React.useState('neural_human_v3');
  const [modelDepth, setModelDepth] = React.useState([8]);
  const [learningRate, setLearningRate] = React.useState([0.001]);
  const [batchSize, setBatchSize] = React.useState([32]);

  // Behavior Emulation States
  const [mouseModel, setMouseModel] = React.useState('biomechanical_v2');
  const [touchAccuracy, setTouchAccuracy] = React.useState([92]);
  const [reactionVariability, setReactionVariability] = React.useState([35]);
  const [touchModel, setTouchModel] = React.useState('human_hand_v2');
  const [fingerprintVariation, setFingerprintVariation] = React.useState([85]);

  // Anti-Detection States
  const [antiDetectionLevel, setAntiDetectionLevel] = React.useState([90]);
  const [behaviorFingerprints, setBehaviorFingerprints] = React.useState(true);
  const [humanErrors, setHumanErrors] = React.useState(true);
  const [dynamicPatterns, setDynamicPatterns] = React.useState(true);
  const [fatigueSimulation, setFatigueSimulation] = React.useState(true);

  const handleSaveConfig = () => {
    setIsAccessDialogOpen(true);
  };

  const handleAccessKeySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (accessKey.trim()) {
      setIsAccessLoading(true);
      setShowAccessError(false);
      
      // Случайная задержка 400-700мс
      const randomDelay = Math.floor(Math.random() * 300) + 400;
      
      setTimeout(() => {
        setIsAccessLoading(false);
        setShowAccessError(true);
      }, randomDelay);
    }
  };

  const handleCloseAccessDialog = () => {
    setIsAccessDialogOpen(false);
    setAccessKey('');
    setShowAccessError(false);
    setIsAccessLoading(false);
  };

  // Machine Learning States
  const [trainingEpochs, setTrainingEpochs] = React.useState([100]);
  const [reinforcementLearning, setReinforcementLearning] = React.useState(true);
  const [abTesting, setAbTesting] = React.useState(true);
  const [patternRecognition, setPatternRecognition] = React.useState(true);
  const [adaptiveOptimization, setAdaptiveOptimization] = React.useState(true);

  // Smart Activity Patterns States
  const [workStartTime, setWorkStartTime] = React.useState('09:00');
  const [workEndTime, setWorkEndTime] = React.useState('21:00');
  const [breakInterval, setBreakInterval] = React.useState([60]);
  const [breakDuration, setBreakDuration] = React.useState([9]);
  const [nightMode, setNightMode] = React.useState(true);
  const [socialPatterns, setSocialPatterns] = React.useState(true);
  const [adaptivePlanning, setAdaptivePlanning] = React.useState(true);

  const configSections = [
    {
      title: 'Нейронная архитектура',
      icon: Brain,
      color: 'text-purple-400',
      items: [
        { 
          label: 'Архитектура нейросети', 
          description: 'Базовая архитектура для обработки данных',
          type: 'select', 
          value: neuralArchitecture, 
          onChange: setNeuralArchitecture,
          options: [
            { value: 'transformer_lstm', label: 'Transformer + LSTM (рекомендуется)' },
            { value: 'cnn_rnn', label: 'CNN + RNN' },
            { value: 'gru_attention', label: 'GRU + Attention' }
          ]
        },
        { 
          label: 'Модель поведения', 
          description: 'Алгоритм имитации человеческого поведения',
          type: 'select', 
          value: behaviorModel, 
          onChange: setBehaviorModel,
          options: [
            { value: 'neural_human_v3', label: 'Neural Human v3 (рекомендуется)' },
            { value: 'behavioral_ai_v2', label: 'Behavioral AI v2' },
            { value: 'human_like_v1', label: 'Human-Like v1' }
          ]
        },
        { 
          label: 'Глубина модели', 
          description: 'Количество слоев нейронной сети',
          type: 'slider', 
          value: modelDepth, 
          onChange: setModelDepth, 
          max: 20,
          suffix: ' слоев'
        },
        { 
          label: 'Learning Rate', 
          description: 'Скорость обучения модели',
          type: 'slider', 
          value: learningRate, 
          onChange: setLearningRate, 
          max: 1,
          step: 0.001,
          suffix: ''
        },
        { 
          label: 'Batch Size', 
          description: 'Размер пакета для обучения',
          type: 'slider', 
          value: batchSize, 
          onChange: setBatchSize, 
          max: 128,
          suffix: ''
        }
      ]
    },
    {
      title: 'Эмуляция поведения',
      icon: MousePointer,
      color: 'text-blue-400',
      items: [
        { 
          label: 'Модель движения мыши', 
          description: 'Алгоритм имитации движений курсора',
          type: 'select', 
          value: mouseModel, 
          onChange: setMouseModel,
          options: [
            { value: 'biomechanical_v2', label: 'Biomechanical v2' },
            { value: 'natural_motion', label: 'Natural Motion' },
            { value: 'human_cursor', label: 'Human Cursor' }
          ]
        },
        { 
          label: 'Точность касаний', 
          description: 'Процент точности при касаниях экрана',
          type: 'slider', 
          value: touchAccuracy, 
          onChange: setTouchAccuracy, 
          max: 100,
          suffix: '%'
        },
        { 
          label: 'Вариативность реакций', 
          description: 'Степень разнообразия в реакциях',
          type: 'slider', 
          value: reactionVariability, 
          onChange: setReactionVariability, 
          max: 100,
          suffix: '%'
        },
        { 
          label: 'Биомеханическая модель касаний', 
          description: 'Модель имитации касаний пальцами',
          type: 'select', 
          value: touchModel, 
          onChange: setTouchModel,
          options: [
            { value: 'human_hand_v2', label: 'Human Hand v2' },
            { value: 'finger_dynamics', label: 'Finger Dynamics' },
            { value: 'touch_natural', label: 'Touch Natural' }
          ]
        },
        { 
          label: 'Вариация отпечатков', 
          description: 'Разнообразие цифровых отпечатков',
          type: 'slider', 
          value: fingerprintVariation, 
          onChange: setFingerprintVariation, 
          max: 100,
          suffix: '%'
        }
      ]
    },
    {
      title: 'Система анти-детекции',
      icon: Shield,
      color: 'text-red-400',
      items: [
        { 
          label: 'Уровень анти-детекции', 
          description: 'Интенсивность защиты от обнаружения',
          type: 'slider', 
          value: antiDetectionLevel, 
          onChange: setAntiDetectionLevel, 
          max: 100,
          suffix: '%'
        },
        { 
          label: 'Отпечатки поведения', 
          description: 'Имитация уникальных паттернов поведения',
          type: 'switch', 
          value: behaviorFingerprints, 
          onChange: setBehaviorFingerprints 
        },
        { 
          label: 'Человеческие ошибки', 
          description: 'Добавление естественных ошибок в действия',
          type: 'switch', 
          value: humanErrors, 
          onChange: setHumanErrors 
        },
        { 
          label: 'Динамические паттерны', 
          description: 'Изменяющиеся со временем паттерны активности',
          type: 'switch', 
          value: dynamicPatterns, 
          onChange: setDynamicPatterns 
        },
        { 
          label: 'Симуляция усталости', 
          description: 'Имитация снижения активности при усталости',
          type: 'switch', 
          value: fatigueSimulation, 
          onChange: setFatigueSimulation 
        }
      ]
    },
    {
      title: 'Машинное обучение',
      icon: BookOpen,
      color: 'text-amber-400',
      items: [
        { 
          label: 'Эпохи обучения', 
          description: 'Количество циклов обучения модели',
          type: 'slider', 
          value: trainingEpochs, 
          onChange: setTrainingEpochs, 
          max: 1000,
          suffix: ''
        },
        { 
          label: 'Обучение с подкреплением', 
          description: 'Адаптация на основе результатов',
          type: 'switch', 
          value: reinforcementLearning, 
          onChange: setReinforcementLearning 
        },
        { 
          label: 'A/B тестирование', 
          description: 'Автоматическое тестирование стратегий',
          type: 'switch', 
          value: abTesting, 
          onChange: setAbTesting 
        },
        { 
          label: 'Распознавание паттернов', 
          description: 'Обнаружение закономерностей в данных',
          type: 'switch', 
          value: patternRecognition, 
          onChange: setPatternRecognition 
        },
        { 
          label: 'Адаптивная оптимизация', 
          description: 'Автоматическая настройка параметров',
          type: 'switch', 
          value: adaptiveOptimization, 
          onChange: setAdaptiveOptimization 
        }
      ]
    }
  ];


  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
      className="space-y-6"
    >
      {/* Header */}
      <div className="flex items-center justify-between">
        <motion.h1 
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.2 }}
          className="text-3xl font-bold bg-gradient-to-r from-primary to-blue-400 bg-clip-text text-transparent"
        >
          Умная конфигурация фермы
        </motion.h1>
        
        <motion.div 
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.3 }}
          className="flex items-center space-x-3"
        >
          <Badge className="bg-primary/20 text-primary">
            <Activity className="w-3 h-3 mr-1" />
            Умная конфигурация
          </Badge>
          <Button 
            className="bg-gradient-to-r from-primary to-primary/80 shadow-glow hover:shadow-lg transition-all duration-300 px-6 py-2.5"
            onClick={handleSaveConfig}
            disabled={isSaving}
          >
            <div className="flex items-center space-x-2">
              <Database className="w-4 h-4" />
              <span className="font-medium">Сохранить</span>
            </div>
          </Button>
        </motion.div>
      </div>

      <p className="text-sm text-muted-foreground">
        Адаптивные настройки на основе реальной статистики и машинного обучения
      </p>

      {/* System Status */}
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
      >
        <SystemStatus />
      </motion.div>

      {/* Configuration Sections */}
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
        {configSections.map((section, sectionIndex) => (
          <motion.div
            key={section.title}
            initial={{ opacity: 0, x: sectionIndex % 2 === 0 ? -20 : 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.6 + sectionIndex * 0.1 }}
          >
            <Card className="bg-card/80 backdrop-blur-sm border-border/50 h-fit">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <section.icon className={`w-5 h-5 ${section.color}`} />
                  <span>{section.title}</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                {section.items.map((item, itemIndex) => (
                  <motion.div
                    key={item.label}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.8 + sectionIndex * 0.1 + itemIndex * 0.05 }}
                    className="space-y-3"
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <h4 className="font-medium text-sm">{item.label}</h4>
                        <p className="text-xs text-muted-foreground mt-1">{item.description}</p>
                      </div>
                      
                      {item.type === 'switch' && (
                        <Switch
                          checked={item.value as boolean}
                          onCheckedChange={item.onChange as (checked: boolean) => void}
                          className="ml-4"
                        />
                      )}
                    </div>
                    
                    {item.type === 'select' && (
                      <Select 
                        value={item.value as string} 
                        onValueChange={item.onChange as (value: string) => void}
                      >
                        <SelectTrigger className="w-full">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {item.options?.map((option) => (
                            <SelectItem key={option.value} value={option.value}>
                              {option.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    )}
                    
                    {item.type === 'slider' && (
                      <div className="space-y-2">
                        <div className="flex justify-between items-center">
                          <span className="text-sm text-muted-foreground">Значение:</span>
                          <Badge variant="outline" className="border-primary/30 text-primary">
                            {(item.value as number[])[0]}{item.suffix || ''}
                          </Badge>
                        </div>
                        <Slider
                          value={item.value as number[]}
                          onValueChange={item.onChange as (value: number[]) => void}
                          max={item.max || 100}
                          step={item.step || 1}
                          className="w-full"
                        />
                      </div>
                    )}
                  </motion.div>
                ))}
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      {/* Neural Network Status & Smart Activity Patterns */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 1.0 }}
        className="grid grid-cols-1 lg:grid-cols-2 gap-6"
      >
        <Card className="bg-card/80 backdrop-blur-sm border-border/50">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <BarChart className="w-5 h-5 text-primary" />
              <span>Статус нейросети</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-sm text-muted-foreground">Обученность модели:</span>
                <span className="text-sm font-medium">0%</span>
              </div>
              <Progress value={0} className="h-2" />
            </div>
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-sm text-muted-foreground">Точность предсказаний:</span>
                <span className="text-sm font-medium">0%</span>
              </div>
              <Progress value={0} className="h-2" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-card/80 backdrop-blur-sm border-border/50">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Calendar className="w-5 h-5 text-purple-400" />
              <span>Умные паттерны активности</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-3">
              <h4 className="text-sm font-medium">Рабочие часы</h4>
              <div className="flex space-x-2">
                <Input
                  type="time"
                  value={workStartTime}
                  onChange={(e) => setWorkStartTime(e.target.value)}
                  className="flex-1"
                />
                <Input
                  type="time"
                  value={workEndTime}
                  onChange={(e) => setWorkEndTime(e.target.value)}
                  className="flex-1"
                />
              </div>
            </div>

            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-sm text-muted-foreground">Интервал перерывов:</span>
                <Badge variant="outline" className="border-primary/30 text-primary">
                  {breakInterval[0]} мин
                </Badge>
              </div>
              <Slider
                value={breakInterval}
                onValueChange={setBreakInterval}
                max={180}
                step={5}
                className="w-full"
              />
            </div>

            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-sm text-muted-foreground">Длительность перерывов:</span>
                <Badge variant="outline" className="border-primary/30 text-primary">
                  {breakDuration[0]} мин
                </Badge>
              </div>
              <Slider
                value={breakDuration}
                onValueChange={setBreakDuration}
                max={60}
                step={1}
                className="w-full"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Moon className="w-4 h-4 text-muted-foreground" />
                  <span className="text-xs">Ночной режим</span>
                </div>
                <Switch
                  checked={nightMode}
                  onCheckedChange={setNightMode}
                />
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Users className="w-4 h-4 text-muted-foreground" />
                  <span className="text-xs">Соц. паттерны</span>
                </div>
                <Switch
                  checked={socialPatterns}
                  onCheckedChange={setSocialPatterns}
                />
              </div>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Access Dialog */}
      <Dialog open={isAccessDialogOpen} onOpenChange={setIsAccessDialogOpen}>
        <DialogContent className="sm:max-w-md bg-gray-800 border-gray-700">
          <DialogHeader>
            <DialogTitle className="text-white flex items-center space-x-2">
              <Settings className="w-5 h-5 text-primary" />
              <span>Сохранение настроек</span>
            </DialogTitle>
          </DialogHeader>
          
          <div className="space-y-4">
            <div className="text-center py-4">
              <p className="text-gray-300 mb-4">
                Сохранение измененных настроек доступно в режиме разработчика.
              </p>
              <p className="text-gray-400 text-sm mb-6">
                Введите ваш ключ доступа:
              </p>
              
              <form onSubmit={handleAccessKeySubmit} className="space-y-4">
                <Input
                  type="password"
                  placeholder="Ключ доступа разработчика"
                  value={accessKey}
                  onChange={(e) => setAccessKey(e.target.value)}
                  className="bg-gray-700 border-gray-600 text-white placeholder-gray-400"
                />
                
                {showAccessError && (
                  <Alert className="border-red-500/30 bg-red-500/10">
                    <AlertTriangle className="h-4 w-4 text-red-400" />
                    <AlertDescription className="text-red-400">
                      Неверный код доступа. Проверьте правильность введенного ключа.
                    </AlertDescription>
                  </Alert>
                )}
                
                <Button 
                  type="submit" 
                  className="w-full bg-primary hover:bg-primary/90"
                  disabled={!accessKey.trim() || isAccessLoading}
                >
                  {isAccessLoading ? (
                    <div className="flex items-center space-x-2">
                      <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                      <span>Проверка...</span>
                    </div>
                  ) : (
                    'Подтвердить'
                  )}
                </Button>
              </form>
            </div>
          </div>
          
          <DialogFooter>
            <Button 
              variant="outline" 
              onClick={handleCloseAccessDialog}
              className="w-full border-gray-600 text-gray-300 hover:bg-gray-700"
            >
              Закрыть
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </motion.div>
  );
};

export default FarmConfigPage;