import React from 'react';
import { LucideIcon } from 'lucide-react';
import { cn } from '@/lib/utils';

interface StatsCardProps {
  title: string;
  value: string | number;
  subtitle?: string;
  icon?: LucideIcon;
  color?: 'primary' | 'success' | 'warning' | 'info';
  className?: string;
}

const colorClasses = {
  primary: 'text-primary',
  success: 'text-success',
  warning: 'text-warning',
  info: 'text-info'
};

const StatsCard = ({ 
  title, 
  value, 
  subtitle, 
  icon: Icon, 
  color = 'primary',
  className 
}: StatsCardProps) => {
  return (
    <div className={cn(
      "bg-card rounded-lg p-6 card-gradient card-hover border border-border",
      className
    )}>
      <div className="flex items-center justify-between">
        <div className="space-y-2">
          <p className="text-sm font-medium text-muted-foreground">{title}</p>
          <p className={cn("text-2xl font-bold", colorClasses[color])}>
            {value}
          </p>
          {subtitle && (
            <p className="text-xs text-muted-foreground">{subtitle}</p>
          )}
        </div>
        {Icon && (
          <div className={cn("p-2 rounded-lg bg-opacity-10", colorClasses[color])}>
            <Icon className={cn("w-6 h-6", colorClasses[color])} />
          </div>
        )}
      </div>
    </div>
  );
};

export default StatsCard;