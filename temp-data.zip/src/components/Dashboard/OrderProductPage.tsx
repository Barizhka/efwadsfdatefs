import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useAppStore } from '@/store/appStore';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { 
  ShoppingCart, 
  Truck, 
  Package, 
  MapPin, 
  AlertTriangle,
  CheckCircle,
  ArrowLeft,
  RefreshCw,
  Info,
  Rocket,
  DollarSign,
  Lightbulb,
  MessageCircle,
  Shield,
  HelpCircle,
  ArrowRight,
  Hand,
  Mail
} from 'lucide-react';

type DeliveryMethod = 'pickup' | 'courier' | 'postmat';

// Компонент для отображения заявки на подтверждение доставки
const DeliveryConfirmationItem = ({ order }: { order: any }) => {
  const { orders } = useAppStore();
  const { toast } = useToast();
  const [timeLeft, setTimeLeft] = useState<number>(0);
  const [hasError, setHasError] = useState<boolean>(false);

  useEffect(() => {
    if (!order.confirmationCreatedAt) return;

    const interval = setInterval(() => {
      const elapsed = Date.now() - order.confirmationCreatedAt;
      const remaining = Math.max(0, 20 * 60 * 1000 - elapsed); // 20 минут в миллисекундах
      setTimeLeft(remaining);

      if (remaining === 0 && !hasError) {
        setHasError(true);
        toast({
          title: "Ошибка подтверждения заявки",
          description: "Возникла ошибка при автоматическом подтверждении заявки на доставку. Свяжитесь с техподдержкой",
          variant: "destructive",
          action: (
            <Button 
              variant="outline" 
              size="sm" 
              onClick={() => window.open('https://t.me/grevsplitatp', '_blank')}
            >
              Техподдержка
            </Button>
          )
        });
      }
    }, 1000);

    return () => clearInterval(interval);
  }, [order.confirmationCreatedAt, hasError, toast]);

  const formatTime = (ms: number) => {
    const minutes = Math.floor(ms / 60000);
    const seconds = Math.floor((ms % 60000) / 1000);
    return `${minutes}:${seconds.toString().padStart(2, '0')}`;
  };

  return (
    <div className="bg-slate-800/50 rounded-lg p-4 border border-blue-500/30">
      <div className="flex justify-between items-start mb-3">
        <div>
          <h4 className="text-white font-medium">{order.productName}</h4>
          <p className="text-gray-400 text-sm">Аккаунт: {order.accountName}</p>
          <p className="text-gray-400 text-sm">Способ доставки: {order.deliveryMethod}</p>
        </div>
        <Badge className="bg-blue-600">
          На подтверждении
        </Badge>
      </div>
      
      {!hasError && timeLeft > 0 && (
        <div className="flex items-center space-x-2 text-blue-400 text-sm">
          <RefreshCw className="w-4 h-4 animate-spin" />
          <span>Автоматическое подтверждение через {formatTime(timeLeft)}</span>
        </div>
      )}
      
      {hasError && (
        <Alert className="bg-red-900/50 border-red-700 mt-3">
          <AlertTriangle className="h-4 w-4" />
          <AlertDescription className="text-red-200">
            <div className="space-y-2">
              <p>Возникла ошибка при автоматическом подтверждении заявки на доставку.</p>
              <p>Свяжитесь с техподдержкой: <a href="https://t.me/grevsplitatp" target="_blank" rel="noopener noreferrer" className="text-blue-400 underline">https://t.me/grevsplitatp</a></p>
            </div>
          </AlertDescription>
        </Alert>
      )}
    </div>
  );
};

// Функция для парсинга данных о товаре с Яндекс.Маркета
const parseProductData = async (url: string) => {
  try {
    console.log('Парсинг URL товара:', url);
    
    // Вызываем edge function для парсинга
    const { data, error } = await supabase.functions.invoke('parse-yandex-product', {
      body: { url }
    });

    if (error) {
      console.error('Ошибка edge function:', error);
      throw new Error('Не удалось загрузить данные товара');
    }

    if (!data.success) {
      throw new Error(data.error || 'Не удалось распознать товар по ссылке');
    }

    const product = data.product;
    const quarterPrice = Math.floor(product.price / 4); // 1/4 от цены товара
    
    return {
      name: product.name,
      color: 'Не указан',
      price: product.price,
      description: product.description,
      remainingAmount: quarterPrice,
      address: 'Москва, ул. ******, д. **',
      imageUrl: product.imageUrl,
      availability: product.availability
    };
  } catch (error) {
    console.error('Ошибка парсинга URL:', error);
    throw new Error('Не удалось распознать товар по ссылке');
  }
};

const OrderProductPage = () => {
  const { purchasedAccounts, user, updateUser, createOrder, orders } = useAppStore();
  const { toast } = useToast();
  const [selectedAccountId, setSelectedAccountId] = useState<string>('');
  const [productUrl, setProductUrl] = useState<string>('');
  const [isValidUrl, setIsValidUrl] = useState<boolean>(false);
  const [deliveryMethod, setDeliveryMethod] = useState<DeliveryMethod | ''>('');
  const [productData, setProductData] = useState<any>(null);
  const [isLoadingProduct, setIsLoadingProduct] = useState<boolean>(false);
  const [deliveryAddress, setDeliveryAddress] = useState<any>(null);
  const [showAddressForm, setShowAddressForm] = useState<boolean>(false);

  // Фильтруем аккаунты готовые к заказу (включая пассивный прогрев)
  const readyAccounts = purchasedAccounts.filter(account => 
    account.emulationStatus === "Готов к заказу" || account.emulationStatus === "Готов к заказу - пассивный прогрев"
  );

  // Фильтруем заказы на подтверждение доставки
  const deliveryConfirmationOrders = orders.filter(order => order.status === 'delivery_confirmation');

  const [showPayment, setShowPayment] = useState<boolean>(false);
  const [orderPlaced, setOrderPlaced] = useState<boolean>(false);

  const validateUrl = async (url: string) => {
    const isValid = url.includes('market.yandex.ru') || url.includes('ya.cc');
    setIsValidUrl(isValid);
    
    if (isValid) {
      setIsLoadingProduct(true);
      try {
        const productInfo = await parseProductData(url);
        setProductData(productInfo);
        
        if (!productInfo.availability) {
          toast({
            title: "Внимание",
            description: "Товар может быть недоступен для заказа",
            variant: "default"
          });
        }
      } catch (error) {
        console.error('Ошибка загрузки товара:', error);
        toast({
          title: "Ошибка",
          description: "Не удалось загрузить данные товара",
          variant: "destructive"
        });
      } finally {
        setIsLoadingProduct(false);
      }
    } else {
      setProductData(null);
    }
    
    return isValid;
  };

  const handleUrlChange = (url: string) => {
    setProductUrl(url);
    if (url.trim()) {
      validateUrl(url);
    } else {
      setIsValidUrl(false);
      setProductData(null);
    }
  };

  const handleDeliverySelect = (method: DeliveryMethod) => {
    setDeliveryMethod(method);
    if (method && selectedAccountId && isValidUrl) {
      setShowAddressForm(true);
    }
  };

  const handleAddressSubmit = (addressData: any) => {
    setDeliveryAddress(addressData);
    setShowAddressForm(false);
    setShowPayment(true);
  };

  const handlePayment = () => {
    const orderAmount = productData?.remainingAmount || 44990;
    
    if (user.balance < orderAmount) {
      const shortage = orderAmount - user.balance;
      toast({
        title: "Недостаточно средств",
        description: `На балансе не хватает ${shortage.toLocaleString()} RUB для покупки`,
        variant: "destructive",
        action: (
          <Button variant="outline" size="sm" onClick={() => window.location.href = '/deposit'}>
            Перейти к пополнению баланса
          </Button>
        )
      });
      return;
    }

    // Создаем заказ
    const selectedAccount = purchasedAccounts.find(acc => acc.id === selectedAccountId);
    if (selectedAccount && productData) {
      const deliveryMethods = {
        'pickup': 'Самовывоз (ПВЗ)',
        'courier': 'Курьерская доставка', 
        'postmat': 'Постамат (24/7)'
      };

      createOrder({
        accountId: selectedAccount.id,
        accountName: selectedAccount.name,
        productName: productData.name,
        productPrice: productData.price,
        remainingAmount: orderAmount,
        deliveryMethod: deliveryMethod as 'pickup' | 'courier' | 'postmat',
        deliveryAddress: deliveryAddress,
        status: 'delivery_confirmation', // Статус подтверждения доставки
        confirmationCreatedAt: Date.now() // Время создания заявки для таймера
      });
    }

    // Списываем средства
    updateUser({ balance: user.balance - orderAmount });
    setOrderPlaced(true);
    
    toast({
      title: "Оплата прошла успешно!",
      description: "Заявка на подтверждение доставки создана",
    });
  };

  const getDeliveryIcon = (method: DeliveryMethod) => {
    switch (method) {
      case 'pickup': return <Package className="w-5 h-5" />;
      case 'courier': return <Truck className="w-5 h-5" />;
      case 'postmat': return <MapPin className="w-5 h-5" />;
    }
  };

  if (orderPlaced) {
    return (
      <div className="space-y-6">
        <div className="text-center py-12">
          <CheckCircle className="w-16 h-16 text-green-500 mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-white mb-2 flex items-center">
            <CheckCircle className="w-6 h-6 text-green-500 mr-2" />
            Остаток суммы успешно оплачен!
          </h2>
          <div className="space-y-2 text-gray-300">
            <p className="flex items-center">
              <Package className="w-4 h-4 text-blue-400 mr-2" />
              Заявка отправлена на рассмотрение, ожидайте уведомления.
            </p>
            <p className="flex items-center">
              <RefreshCw className="w-4 h-4 text-blue-400 mr-2" />
              Вы можете отслеживать текущий статус доставки и управления аккаунтом в соответствующем разделе меню.
            </p>
            <p className="flex items-center">
              <Info className="w-4 h-4 text-blue-400 mr-2" />
              Если возникнут вопросы - обращайтесь в поддержку или в FAQ.
            </p>
          </div>
        </div>
      </div>
    );
  }

  // Address Form Component
  const AddressForm = () => {
    const [city, setCity] = useState('');
    const [street, setStreet] = useState('');
    const [house, setHouse] = useState('');
    const [entrance, setEntrance] = useState('');
    const [floor, setFloor] = useState('');
    const [apartment, setApartment] = useState('');
    const [doorCode, setDoorCode] = useState('');

    const handleSubmit = () => {
      let addressData;
      
      if (deliveryMethod === 'courier') {
        const fullAddress = `${city}, ${street}, д. ${house}${entrance ? `, подъезд ${entrance}` : ''}${floor ? `, этаж ${floor}` : ''}${apartment ? `, кв. ${apartment}` : ''}`;
        const courierComment = `Не звонить. Оставить у двери.${doorCode ? ` Код домофона: ${doorCode}` : ''}`;
        
        addressData = {
          type: 'courier',
          city,
          street,
          house,
          entrance,
          floor,
          apartment,
          doorCode,
          fullAddress,
          courierComment
        };
      } else {
        const pickupAddress = `${city}, ${street}, д. ${house}`;
        
        addressData = {
          type: deliveryMethod,
          city,
          street,
          house,
          pickupAddress
        };
      }
      
      handleAddressSubmit(addressData);
    };

    const isFormValid = city && street && house;

    return (
      <div className="space-y-6">
        <div className="flex items-center space-x-4">
          <Button variant="ghost" onClick={() => setShowAddressForm(false)}>
            <ArrowLeft className="w-4 h-4 mr-2" />
            Назад
          </Button>
          <h1 className="text-3xl font-bold text-white">Адрес доставки</h1>
        </div>

        <Card className="bg-gray-800/50 border-gray-700">
          <CardHeader>
            <CardTitle className="text-white flex items-center">
              <MapPin className="w-5 h-5 mr-2" />
              {deliveryMethod === 'courier' ? 'Адрес для курьерской доставки' : 'Адрес ПВЗ/Постамата'}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {deliveryMethod !== 'courier' && (
              <Alert className="bg-blue-900/50 border-blue-700">
                <Info className="h-4 w-4" />
                <AlertDescription className="text-blue-200">
                  Для ПВЗ/Постамата указывайте ближайший адрес. Вы можете найти точные координаты на Яндекс.Картах.
                </AlertDescription>
              </Alert>
            )}

            {deliveryMethod === 'courier' && (
              <Alert className="bg-yellow-900/50 border-yellow-700">
                <AlertTriangle className="h-4 w-4" />
                <AlertDescription className="text-yellow-200">
                  <div className="space-y-1">
                    <p><strong>Для курьерской доставки укажите полный адрес</strong></p>
                    <p className="text-sm">Автоматически добавляется комментарий: "Не звонить" и "Оставить у двери"</p>
                    <p className="text-sm">Можете заказать на соседний адрес и забрать заказ из-под чужой двери</p>
                  </div>
                </AlertDescription>
              </Alert>
            )}

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="city" className="text-white">Город *</Label>
                <Input
                  id="city"
                  value={city}
                  onChange={(e) => setCity(e.target.value)}
                  placeholder="Москва"
                  className="bg-gray-700 border-gray-600 text-white"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="street" className="text-white">Улица *</Label>
                <Input
                  id="street"
                  value={street}
                  onChange={(e) => setStreet(e.target.value)}
                  placeholder="ул. Ленина"
                  className="bg-gray-700 border-gray-600 text-white"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="house" className="text-white">Дом *</Label>
                <Input
                  id="house"
                  value={house}
                  onChange={(e) => setHouse(e.target.value)}
                  placeholder="15"
                  className="bg-gray-700 border-gray-600 text-white"
                />
              </div>

              {deliveryMethod === 'courier' && (
                <>
                  <div className="space-y-2">
                    <Label htmlFor="entrance" className="text-white">Подъезд</Label>
                    <Input
                      id="entrance"
                      value={entrance}
                      onChange={(e) => setEntrance(e.target.value)}
                      placeholder="2"
                      className="bg-gray-700 border-gray-600 text-white"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="floor" className="text-white">Этаж</Label>
                    <Input
                      id="floor"
                      value={floor}
                      onChange={(e) => setFloor(e.target.value)}
                      placeholder="5"
                      className="bg-gray-700 border-gray-600 text-white"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="apartment" className="text-white">Квартира</Label>
                    <Input
                      id="apartment"
                      value={apartment}
                      onChange={(e) => setApartment(e.target.value)}
                      placeholder="42"
                      className="bg-gray-700 border-gray-600 text-white"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="doorCode" className="text-white">Код домофона</Label>
                    <Input
                      id="doorCode"
                      value={doorCode}
                      onChange={(e) => setDoorCode(e.target.value)}
                      placeholder="1234"
                      className="bg-gray-700 border-gray-600 text-white"
                    />
                  </div>
                </>
              )}
            </div>

            {deliveryMethod === 'courier' && (
              <div className="mt-4 p-4 bg-gray-700/50 rounded-lg">
                <h4 className="text-white font-medium mb-2">Автоматический комментарий курьеру:</h4>
                <p className="text-gray-300 text-sm">
                  "Не звонить. Оставить у двери.{doorCode && ` Код домофона: ${doorCode}`}"
                </p>
              </div>
            )}

            <div className="flex space-x-4 pt-4">
              <Button
                onClick={handleSubmit}
                disabled={!isFormValid}
                className="bg-blue-600 hover:bg-blue-700"
              >
                Продолжить к оплате
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
              <Button variant="outline" onClick={() => setShowAddressForm(false)}>
                Изменить способ доставки
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  };

  if (showAddressForm && selectedAccountId && isValidUrl && deliveryMethod) {
    return <AddressForm />;
  }

  if (showPayment && selectedAccountId && isValidUrl && deliveryMethod && deliveryAddress) {
    return (
      <div className="space-y-6">
        <div className="flex items-center space-x-4">
          <Button variant="ghost" onClick={() => setShowPayment(false)}>
            <ArrowLeft className="w-4 h-4 mr-2" />
            Назад
          </Button>
          <h1 className="text-3xl font-bold text-white">Оплата заказа</h1>
        </div>

        <Card className="bg-gray-800/50 border-gray-700">
          <CardContent className="p-6">
            <div className="space-y-4">
              <h3 className="text-xl font-bold text-white flex items-center">
                <Rocket className="w-5 h-5 text-blue-400 mr-2" />
                Товар доступен к приобретению.
              </h3>
              
              <div className="space-y-2 text-gray-300">
                <p className="flex items-start">
                   <Info className="w-4 h-4 text-blue-400 mr-2 mt-0.5" />
                   <span><strong>Название товара:</strong> {productData?.name}</span>
                 </p>
                 {productData?.description && (
                   <p className="text-sm text-gray-400"><strong>Описание:</strong> {productData.description}</p>
                 )}
                 <p><strong>Цвет:</strong> {productData?.color}</p>
                <p className="flex items-center">
                  <DollarSign className="w-4 h-4 text-green-400 mr-2" />
                  <span><strong>Цена товара:</strong> {productData?.price?.toLocaleString() || "119990"} RUB</span>
                 </p>
                 <p className="flex items-start">
                   <MapPin className="w-4 h-4 text-purple-400 mr-2 mt-0.5" />
                   <span><strong>Способ доставки:</strong> {
                     deliveryMethod === 'pickup' ? 'Самовывоз (ПВЗ)' :
                     deliveryMethod === 'courier' ? 'Курьерская доставка' :
                     deliveryMethod === 'postmat' ? 'Постамат (24/7)' : ''
                   }</span>
                 </p>
                 <p className="flex items-start">
                   <MapPin className="w-4 h-4 text-purple-400 mr-2 mt-0.5" />
                   <span><strong>Адрес доставки:</strong> {deliveryAddress?.fullAddress || deliveryAddress?.pickupAddress}</span>
                 </p>
                 {deliveryMethod === 'courier' && deliveryAddress?.courierComment && (
                   <p className="flex items-start">
                     <MessageCircle className="w-4 h-4 text-blue-400 mr-2 mt-0.5" />
                     <span><strong>Комментарий курьеру:</strong> {deliveryAddress.courierComment}</span>
                   </p>
                 )}
              </div>

               <Alert className="bg-yellow-900/50 border-yellow-700">
                 <AlertTriangle className="h-4 w-4" />
                 <AlertDescription className="text-yellow-200">
                   <strong>Для получения товара необходимо оплатить 1/4 от стоимости: {productData?.remainingAmount?.toLocaleString()} RUB</strong>
                   <p className="text-sm mt-2">После оплаты заказ перейдет на стадию подтверждения доставки</p>
                 </AlertDescription>
               </Alert>

              <div className="space-y-2 text-sm text-gray-400">
                <p className="flex items-start">
                  <Lightbulb className="w-4 h-4 text-yellow-400 mr-2 mt-0.5" />
                  После оплаты вы получите товар на указанный адрес.
                </p>
                <p className="flex items-start">
                  <MessageCircle className="w-4 h-4 text-blue-400 mr-2 mt-0.5" />
                  Все детали и инструкции по оплате будут отправлены в следующем сообщении.
                </p>
                <p className="flex items-start">
                  <AlertTriangle className="w-4 h-4 text-amber-500 mr-2 mt-0.5" />
                  Если оплата не будет внесена в течение ограниченного времени, заявка будет аннулирована.
                </p>
                <p>Товар не бронируется без подтверждения доли участия.</p>
                <p className="flex items-start">
                  <Shield className="w-4 h-4 text-green-400 mr-2 mt-0.5" />
                  Мы заботимся о вашей безопасности: если заказ по каким-либо причинам не состоится, средства будут возвращены.
                </p>
              </div>

              <div className="flex space-x-4 pt-4">
                <Button onClick={handlePayment} className="bg-green-600 hover:bg-green-700">
                  Оплатить
                </Button>
                <Button variant="outline" onClick={() => setShowPayment(false)}>
                  Указать другой товар
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-white">Заказ товара</h1>
        <p className="text-gray-400 mt-1">Выберите аккаунт и товар для заказа</p>
      </div>

      {/* Delivery Confirmation Orders */}
      {deliveryConfirmationOrders.length > 0 && (
        <Card className="bg-blue-900/50 border-blue-700">
          <CardHeader>
            <CardTitle className="text-white flex items-center">
              <Package className="w-5 h-5 mr-2" />
              Заявки на подтверждение доставки
            </CardTitle>
          </CardHeader>
          <CardContent>
            {deliveryConfirmationOrders.map((order) => (
              <DeliveryConfirmationItem key={order.id} order={order} />
            ))}
          </CardContent>
        </Card>
      )}

      {readyAccounts.length === 0 && (
        <Alert className="bg-red-900/50 border-red-700">
          <AlertTriangle className="h-4 w-4" />
          <AlertDescription className="text-red-200">
            У вас нет готовых к заказу аккаунтов. Купите и прогрейте аккаунты в разделе "Аккаунты" или дождитесь завершения прогрева.
          </AlertDescription>
        </Alert>
      )}

      {readyAccounts.length > 0 && (
        <>
          {/* Account Selection */}
          <Card className="bg-gray-800/50 border-gray-700">
            <CardHeader>
              <CardTitle className="text-white">1. Выберите аккаунт</CardTitle>
            </CardHeader>
            <CardContent>
              <Select value={selectedAccountId} onValueChange={setSelectedAccountId}>
                <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                  <SelectValue placeholder="Выберите готовый к заказу аккаунт" />
                </SelectTrigger>
                <SelectContent className="bg-gray-700 border-gray-600">
                  {readyAccounts.map((account) => (
                    <SelectItem key={account.id} value={account.id} className="text-white hover:bg-gray-600">
                      {account.name} ({account.city}) - {typeof account.split === 'number' ? account.split.toLocaleString() : account.split} RUB
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </CardContent>
          </Card>

          {/* Product URL */}
          <Card className="bg-gray-800/50 border-gray-700">
            <CardHeader>
              <CardTitle className="text-white">2. Укажите товар</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <Alert className="bg-yellow-900/50 border-yellow-700">
                  <AlertTriangle className="h-4 w-4" />
                  <AlertDescription className="text-yellow-200">
                    <div className="space-y-2">
                      <p className="flex items-center">
                        <AlertTriangle className="w-4 h-4 text-amber-500 mr-2" />
                        <strong>Принимаются ссылки только с Yаndех Мapкeт</strong>
                      </p>
                      <p>Чтобы получить ссылку перейдите на страницу товара, нажмите кнопку 'Поделиться'</p>
                      <p>В такой ссылке указаны параметры товара, который вы выберите</p>
                      <p><strong>Формат ссылки должен быть только таким!</strong></p>
                      <code className="bg-gray-800 px-2 py-1 rounded">https://market.yandex.ru/cc/</code>
                    </div>
                  </AlertDescription>
                </Alert>

                <div className="space-y-2">
                  <Label htmlFor="productUrl" className="text-white">Ссылка на товар</Label>
                  <Input
                    id="productUrl"
                    value={productUrl}
                    onChange={(e) => handleUrlChange(e.target.value)}
                    placeholder="https://market.yandex.ru/cc/..."
                    className={`bg-gray-700 border-gray-600 text-white ${
                      productUrl && !isValidUrl ? 'border-red-500' : ''
                    } ${productUrl && isValidUrl ? 'border-green-500' : ''}`}
                  />
                  {productUrl && !isValidUrl && (
                    <p className="text-red-400 text-sm">Неверный формат ссылки. Используйте ссылки с Яндекс Маркет.</p>
                  )}
                   {productUrl && isValidUrl && !isLoadingProduct && (
                     <p className="text-green-400 text-sm">✓ Ссылка корректна, товар загружен</p>
                   )}
                   {isLoadingProduct && (
                     <p className="text-blue-400 text-sm flex items-center">
                       <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                       Загружаем данные товара...
                     </p>
                   )}
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Delivery Method */}
          {selectedAccountId && isValidUrl && (
            <Card className="bg-gray-800/50 border-gray-700">
              <CardHeader>
                <CardTitle className="text-white">3. Выберите способ доставки</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <p className="text-gray-300 flex items-center">
                    <HelpCircle className="w-4 h-4 text-blue-400 mr-2" />
                    Выберите способ доставки:
                  </p>
                  
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <Button
                      variant={deliveryMethod === 'pickup' ? 'default' : 'outline'}
                      onClick={() => handleDeliverySelect('pickup')}
                      className="h-auto p-4 text-left flex flex-col justify-start space-y-3 min-h-[140px]"
                    >
                      <div className="flex items-center space-x-2">
                        <Package className="w-5 h-5 flex-shrink-0" />
                        <span className="font-medium">Самовывоз (ПВЗ)</span>
                      </div>
                      <p className="text-sm text-muted-foreground">получите заказ в удобном пункте выдачи</p>
                      <div className="text-xs space-y-1">
                        <div className="flex items-center text-green-400">
                          <ArrowRight className="w-3 h-3 mr-1 flex-shrink-0" />
                          <span>ПВЗ — просите забрать знакомого/дропа</span>
                        </div>
                        <div className="flex items-center text-green-400">
                          <CheckCircle className="w-3 h-3 mr-1 flex-shrink-0" />
                          <span>безопасно</span>
                        </div>
                        <p className="text-muted-foreground">Главное — не забирайте по несколько раз в одном ПВЗ</p>
                      </div>
                    </Button>

                    <Button
                      variant={deliveryMethod === 'courier' ? 'default' : 'outline'}
                      onClick={() => handleDeliverySelect('courier')}
                      className="h-auto p-4 text-left flex flex-col justify-start space-y-3 min-h-[140px]"
                    >
                      <div className="flex items-center space-x-2">
                        <Truck className="w-5 h-5 flex-shrink-0" />
                        <span className="font-medium">Курьерская доставка</span>
                      </div>
                      <p className="text-sm text-muted-foreground">привезём прямо до двери</p>
                      <div className="text-xs space-y-1">
                        <div className="flex items-center text-green-400">
                          <ArrowRight className="w-3 h-3 mr-1 flex-shrink-0" />
                          <span>Курьер — комментарий "не звонить" и "оставить у двери"</span>
                        </div>
                        <div className="flex items-center text-green-400">
                          <CheckCircle className="w-3 h-3 mr-1 flex-shrink-0" />
                          <span>безопасно</span>
                        </div>
                        <div className="flex items-start text-muted-foreground">
                          <Hand className="w-3 h-3 mr-1 mt-0.5 flex-shrink-0" />
                          <span>Можно вызвать курьера на соседний этаж, дождаться на площадке</span>
                        </div>
                      </div>
                    </Button>

                    <Button
                      variant={deliveryMethod === 'postmat' ? 'default' : 'outline'}
                      onClick={() => handleDeliverySelect('postmat')}
                      className="h-auto p-4 text-left flex flex-col justify-start space-y-3 min-h-[140px]"
                    >
                      <div className="flex items-center space-x-2">
                        <MapPin className="w-5 h-5 flex-shrink-0" />
                        <span className="font-medium">Постамат (24/7)</span>
                      </div>
                      <p className="text-sm text-muted-foreground">заберите заказ в любое время суток</p>
                      <div className="text-xs space-y-1">
                        <div className="flex items-center text-green-400">
                          <ArrowRight className="w-3 h-3 mr-1 flex-shrink-0" />
                          <span>Постамат — в ковид маске и капюшоне</span>
                        </div>
                        <div className="flex items-center text-green-400">
                          <CheckCircle className="w-3 h-3 mr-1 flex-shrink-0" />
                          <span>безопасно</span>
                        </div>
                      </div>
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
        </>
      )}
    </div>
  );
};

export default OrderProductPage;