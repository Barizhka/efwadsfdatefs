import React from 'react';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Clock } from 'lucide-react';

interface WarmupProgressProps {
  progress: number;
  startTime?: number;
  isActive: boolean;
}

export const WarmupProgress: React.FC<WarmupProgressProps> = ({ 
  progress, 
  startTime, 
  isActive 
}) => {
  const getRemainingTime = () => {
    if (!isActive) return "Не начат";
    if (progress >= 100) return "Завершено";
    return "3-5 дней";
  };

  const getProgressColor = () => {
    if (progress >= 100) return "bg-green-500";
    if (progress >= 75) return "bg-blue-500";
    if (progress >= 50) return "bg-yellow-500";
    return "bg-orange-500";
  };

  if (!isActive) {
    return <span className="text-muted-foreground text-sm">Не начат</span>;
  }

  return (
    <div className="flex items-center space-x-2 min-w-[180px]">
      <div className="flex-1">
        <Progress 
          value={progress} 
          className="h-2"
        />
        <div className="flex justify-between items-center mt-1">
          <span className="text-xs font-medium">
            {Math.round(progress)}%
          </span>
          <div className="flex items-center space-x-1 text-xs text-muted-foreground">
            <Clock className="w-3 h-3" />
            <span>{getRemainingTime()}</span>
          </div>
        </div>
      </div>
      {progress >= 100 && (
        <Badge variant="outline" className="text-green-400 border-green-400">
          Готов
        </Badge>
      )}
    </div>
  );
};