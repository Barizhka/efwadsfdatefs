import React, { useState, useEffect } from 'react';
import { useAppStore } from '@/store/appStore';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Input } from '@/components/ui/input';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { useAdminAuth } from '@/hooks/useAdminAuth';
import { 
  Monitor, 
  Thermometer, 
  MapPin, 
  Cpu, 
  PlayCircle, 
  PauseCircle, 
  Settings, 
  Wifi,
  Battery,
  Clock,
  AlertTriangle,
  Flame,
  ShoppingCart,
  Package,
  MessageCircle,
  Smartphone,
  ChevronDown,
  Camera,
  ChevronLeft,
  ChevronRight
} from 'lucide-react';

// Import screenshots
// Lazy load screenshots to prevent blocking app startup
const loadScreenshot = async (path: string) => {
  try {
    const module = await import(path);
    return module.default;
  } catch (error) {
    console.warn(`Failed to load screenshot: ${path}`, error);
    return null;
  }
};

const EmulatorPage = () => {
  const { purchasedAccounts, isWarmupActive } = useAppStore();
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [accessKey, setAccessKey] = useState('');
  const [showError, setShowError] = useState(false);
  const [isChatLoading, setIsChatLoading] = useState(false);
  const [showChat, setShowChat] = useState(false);
  const [isConnecting, setIsConnecting] = useState(false);
  const [showDeviceDropdown, setShowDeviceDropdown] = useState(false);
  const [isEmulatorLoading, setIsEmulatorLoading] = useState(false);
  const [emulatorStarted, setEmulatorStarted] = useState(false);
  const [showScreenshots, setShowScreenshots] = useState(false);
  const [currentScreenshotIndex, setCurrentScreenshotIndex] = useState(0);
  const [screenshots, setScreenshots] = useState<string[]>([]);
  const [screenshotsLoaded, setScreenshotsLoaded] = useState(false);
  const [currentTime, setCurrentTime] = useState(new Date());
  const [dynamicTemperature, setDynamicTemperature] = useState(42);
  const [dynamicLatency, setDynamicLatency] = useState(24);
  const [dynamicMemory, setDynamicMemory] = useState(58);
  const [dynamicCpu, setDynamicCpu] = useState(67);
  const [dynamicBattery, setDynamicBattery] = useState(99);
  const [batteryDirection, setBatteryDirection] = useState(-1); // -1 for decreasing, 1 for increasing

  // Update current time every second for timer
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  // Update temperature dynamically when warmup is active
  useEffect(() => {
    const hasActiveWarmup = purchasedAccounts.some(account => account.warmupStarted) || isWarmupActive;
    
    if (hasActiveWarmup) {
      const temperatureTimer = setInterval(() => {
        setDynamicTemperature(prev => {
          // Small random change ±1°C to avoid big jumps
          const change = (Math.random() - 0.5) * 2; // -1 to +1
          const newTemp = prev + change;
          // Keep temperature within 37-47°C range (42 ± 5)
          return Math.max(37, Math.min(47, newTemp));
        });
      }, 3000); // Update every 3 seconds
      
      return () => clearInterval(temperatureTimer);
    }
  }, [purchasedAccounts, isWarmupActive]);

  // Update latency dynamically when warmup is active
  useEffect(() => {
    const hasActiveWarmup = purchasedAccounts.some(account => account.warmupStarted) || isWarmupActive;
    
    if (hasActiveWarmup) {
      const latencyTimer = setInterval(() => {
        setDynamicLatency(prev => {
          // Small random change ±2ms to avoid big jumps
          const change = (Math.random() - 0.5) * 4; // -2 to +2
          const newLatency = prev + change;
          // Keep latency within 14-34ms range (24 ± 10)
          return Math.max(14, Math.min(34, newLatency));
        });
      }, 2500); // Update every 2.5 seconds
      
      return () => clearInterval(latencyTimer);
    }
  }, [purchasedAccounts, isWarmupActive]);

  // Update memory and CPU dynamically when warmup is active
  useEffect(() => {
    const hasActiveWarmup = purchasedAccounts.some(account => account.warmupStarted) || isWarmupActive;
    
    if (hasActiveWarmup) {
      const memoryTimer = setInterval(() => {
        setDynamicMemory(prev => {
          // Small random change ±2% to avoid big jumps
          const change = (Math.random() - 0.5) * 4; // -2 to +2
          const newMemory = prev + change;
          // Keep memory within 48-68% range (58 ± 10), never below 12% or above 99%
          return Math.max(12, Math.min(99, Math.max(48, Math.min(68, newMemory))));
        });
        
        setDynamicCpu(prev => {
          // Small random change ±2% to avoid big jumps
          const change = (Math.random() - 0.5) * 4; // -2 to +2
          const newCpu = prev + change;
          // Keep CPU within 57-77% range (67 ± 10), never below 12% or above 99%
          return Math.max(12, Math.min(99, Math.max(57, Math.min(77, newCpu))));
        });
      }, 4000); // Update every 4 seconds
      
      return () => clearInterval(memoryTimer);
    }
  }, [purchasedAccounts, isWarmupActive]);

  // Update battery dynamically when warmup is active
  useEffect(() => {
    const hasActiveWarmup = purchasedAccounts.some(account => account.warmupStarted) || isWarmupActive;
    
    if (hasActiveWarmup) {
      const batteryTimer = setInterval(() => {
        setBatteryDirection(prevDirection => {
          setDynamicBattery(prev => {
            if (prevDirection === -1) {
              // Decreasing: 1% every 3-4 minutes (let's use 3.5 minutes = 210 seconds)
              // This timer runs every 30 seconds, so decrease by 1% every 7 iterations (210/30)
              const newBattery = prev - (1/7);
              if (newBattery <= 12) {
                return 12;
              }
              return newBattery;
            } else {
              // Increasing: 1% every minute (60 seconds)
              // This timer runs every 30 seconds, so increase by 1% every 2 iterations
              const newBattery = prev + (1/2);
              if (newBattery >= 99) {
                return 99;
              }
              return newBattery;
            }
          });
          
          // Change direction when reaching limits
          if (prevDirection === -1 && dynamicBattery <= 12) {
            return 1; // Start increasing
          } else if (prevDirection === 1 && dynamicBattery >= 99) {
            return -1; // Start decreasing
          }
          return prevDirection;
        });
      }, 30000); // Update every 30 seconds
      
      return () => clearInterval(batteryTimer);
    }
  }, [purchasedAccounts, isWarmupActive, dynamicBattery]);

  // Load screenshots on component mount
  useEffect(() => {
    const loadAllScreenshots = async () => {
      try {
        const paths = [
          '@/assets/screenshots/screenshot1.jpg',
          '@/assets/screenshots/screenshot2.jpg',
          '@/assets/screenshots/screenshot3.jpg'
        ];
        
        const loadedScreenshots = await Promise.all(
          paths.map(path => loadScreenshot(path))
        );
        
        // Filter out failed loads
        const validScreenshots = loadedScreenshots.filter(Boolean) as string[];
        setScreenshots(validScreenshots);
        setScreenshotsLoaded(true);
      } catch (error) {
        console.error('Failed to load screenshots:', error);
        setScreenshotsLoaded(true);
      }
    };

    loadAllScreenshots();
  }, []);
  const { login, isLoading, canAccessDeveloperMode } = useAdminAuth();

  // Определяем локацию на основе состояния прогрева
  const getEmulatorLocation = () => {
    // Проверяем есть ли купленные аккаунты с активным прогревом
    const activeWarmupAccount = purchasedAccounts.find(account => account.warmupStarted);
    
    if (!activeWarmupAccount) {
      return 'Неизвестно';
    }
    
    // Для "Предварительный прогрев" - город известен только после выбора пользователем при запуске
    if (activeWarmupAccount.emulationStatus === 'Предварительный прогрев') {
      return activeWarmupAccount.selectedCity || 'Неизвестно';
    }
    
    // Для "Прогрев аккаунта на ГЕО" и "Готов к заказу - пассивный прогрев" - город известен сразу после покупки
    if (activeWarmupAccount.emulationStatus === 'Прогрев аккаунта на ГЕО' || 
        activeWarmupAccount.emulationStatus === 'Готов к заказу - пассивный прогрев') {
      return activeWarmupAccount.city || activeWarmupAccount.selectedCity || 'Неизвестно';
    }
    
    // Fallback
    return activeWarmupAccount.selectedCity || activeWarmupAccount.city || 'Неизвестно';
  };

  // Получаем время работы эмулятора
  const getEmulatorUptime = () => {
    // Проверяем есть ли активный прогрев
    const activeWarmupAccount = purchasedAccounts.find(account => account.warmupStarted);
    
    if (!activeWarmupAccount || !isWarmupActive) {
      return 'Не запущен';
    }
    
    // Если есть время старта прогрева, показываем elapsed time
    if (activeWarmupAccount.warmupStartTime) {
      const startTime = activeWarmupAccount.warmupStartTime;
      const elapsed = currentTime.getTime() - startTime;
      const hours = Math.floor(elapsed / (1000 * 60 * 60));
      const minutes = Math.floor((elapsed % (1000 * 60 * 60)) / (1000 * 60));
      return `${hours}ч ${minutes}м`;
    }
    
    // Fallback если нет точного времени старта
    return '0ч 0м';
  };

  // Получаем отображение температуры
  const getTemperatureDisplay = () => {
    const hasActiveWarmup = purchasedAccounts.some(account => account.warmupStarted) || isWarmupActive;
    
    if (!hasActiveWarmup) {
      return 'Неизвестно';
    }
    
    return `${Math.round(dynamicTemperature)}°C`;
  };

  // Получаем числовое значение температуры для прогресс-бара
  const getTemperatureValue = () => {
    const hasActiveWarmup = purchasedAccounts.some(account => account.warmupStarted) || isWarmupActive;
    return hasActiveWarmup ? Math.round(dynamicTemperature) : 0;
  };

  // Получаем отображение задержки сети
  const getLatencyDisplay = () => {
    const hasActiveWarmup = purchasedAccounts.some(account => account.warmupStarted) || isWarmupActive;
    
    if (!hasActiveWarmup) {
      return 'Неизвестно';
    }
    
    return `${Math.round(dynamicLatency)}ms`;
  };

  // Получаем значения производительности
  const getPerformanceValues = () => {
    const hasActiveWarmup = purchasedAccounts.some(account => account.warmupStarted) || isWarmupActive;
    
    if (!hasActiveWarmup) {
      return {
        cpuLoad: 0,
        memoryUsage: 0,
        batteryLevel: 0,
        temperatureValue: 0
      };
    }
    
    return {
      cpuLoad: Math.round(dynamicCpu),
      memoryUsage: Math.round(dynamicMemory),
      batteryLevel: Math.round(dynamicBattery),
      temperatureValue: Math.round(dynamicTemperature)
    };
  };

  const performanceValues = getPerformanceValues();

  const emulatorData = {
    status: 'running',
    previewStatus: 'stopped',
    temperature: getTemperatureDisplay(),
    temperatureValue: performanceValues.temperatureValue,
    location: getEmulatorLocation(),
    cpuLoad: performanceValues.cpuLoad,
    memoryUsage: performanceValues.memoryUsage,
    batteryLevel: performanceValues.batteryLevel,
    networkLatency: getLatencyDisplay(),
    uptime: getEmulatorUptime()
  };

  const handleAccessKeySubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!accessKey.trim()) return;
    
    // Проверяем можем ли мы вообще попытаться войти
    if (!canAccessDeveloperMode) {
      setShowError(true);
      return;
    }
    
    setShowError(false);
    const success = await login(accessKey);
    if (success) {
      setIsSettingsOpen(false);
      setAccessKey('');
      setShowError(false);
    } else {
      setShowError(true);
    }
  };

  const handleCloseSettings = () => {
    setIsSettingsOpen(false);
    setAccessKey('');
    setShowError(false);
  };

  const handleTechSupportClick = () => {
    setIsChatLoading(true);
    setIsConnecting(true);
    
    setTimeout(() => {
      setIsChatLoading(false);
      setIsConnecting(false);
      setShowChat(true);
    }, 4000);
  };

  const handleScreenshotClick = () => {
    setShowChat(false);
    setEmulatorStarted(false);
    setShowScreenshots(true);
    setCurrentScreenshotIndex(0);
  };

  const nextScreenshot = () => {
    setCurrentScreenshotIndex((prev) => (prev + 1) % screenshots.length);
  };

  const prevScreenshot = () => {
    setCurrentScreenshotIndex((prev) => (prev - 1 + screenshots.length) % screenshots.length);
  };

  const deviceMenuItems = [
    { name: 'Приложения', disabled: true },
    { name: 'Память устройства', disabled: true },
    { name: 'Браузер', disabled: true },
    { name: 'Мониторинг потребления', disabled: true },
    { name: 'Системные настройки', disabled: true },
    { name: 'Контакты', disabled: true },
    { name: 'Календарь', disabled: true },
    { name: 'Камера', disabled: true },
    { name: 'Фотографии', disabled: true },
    { name: 'Скриншоты', disabled: false, action: handleScreenshotClick },
    { name: 'Заметки', disabled: true },
    { name: 'Сообщения', disabled: true },
    { name: 'Телефон', disabled: true },
    { name: 'Музыка', disabled: true },
    { name: 'Видео', disabled: true },
    { name: 'Погода', disabled: true },
    { name: 'Карты', disabled: true },
    { name: 'Файлы', disabled: true },
    { name: 'Диагностика системы', disabled: true }
  ];

  const deviceSpecs = [
    { label: 'Модель устройства', value: 'Samsung Galaxy S21' },
    { label: 'Android версия', value: '12.0' },
    { label: 'Разрешение экрана', value: '2400 × 1080' },
    { label: 'Прокси', value: 'US-NY-001 (Active)' }
  ];

  const performanceMetrics = [
    { label: 'CPU загрузка', value: emulatorData.cpuLoad, max: 100, color: 'text-blue-400' },
    { label: 'Память', value: emulatorData.memoryUsage, max: 100, color: 'text-purple-400' },
    { label: 'Батарея', value: emulatorData.batteryLevel, max: 100, color: 'text-primary' },
    { label: 'Температура', value: emulatorData.temperatureValue, max: 80, color: 'text-amber-400' }
  ];

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
      className="min-h-screen"
    >
      {/* Header with Title and Status */}
      <div className="flex items-center justify-between mb-4">
        <motion.h1 
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.2 }}
          className="text-3xl font-bold bg-gradient-to-r from-primary to-blue-400 bg-clip-text text-transparent"
        >
          Эмулятор управления
        </motion.h1>
        
        <motion.div 
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.3 }}
          className="flex items-center space-x-3"
        >
          <Badge 
            className={
              emulatorData.status === 'running' 
                ? 'bg-primary/20 text-primary' 
                : 'bg-gray-500/20 text-gray-400'
            }
          >
            <div className={`w-2 h-2 rounded-full mr-2 ${
              emulatorData.status === 'running' ? 'bg-primary animate-pulse' : 'bg-gray-400'
            }`} />
            {emulatorData.status === 'running' ? 'Активен' : 'Остановлен'}
          </Badge>
          
          <Button size="sm" variant="outline" onClick={() => setIsSettingsOpen(true)}>
            <Settings className="w-4 h-4 mr-2" />
            Настройки
          </Button>
        </motion.div>
      </div>

      {/* Three-column grid layout */}
      <div className="grid grid-cols-12 gap-6 h-full">
        {/* Left Column: Control Panel (280px width) */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.5 }}
          className="col-span-3"
        >
          <Card className="h-[580px] border-border bg-card/50 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Settings className="w-5 h-5 text-primary" />
                <span>Управление</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Warmup Control */}
              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Button 
                      className="w-full justify-start h-12"
                      variant="outline"
                      disabled
                    >
                      <Thermometer className="w-5 h-5 mr-3 text-amber-500" />
                      <div className="text-left">
                        <div className="font-medium">Прогрев</div>
                        <div className="text-xs text-muted-foreground">Система подготовки</div>
                      </div>
                    </Button>
                  </TooltipTrigger>
                  <TooltipContent>
                    <p>Функция находится в разработке</p>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>

              {/* Market Control */}
              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Button 
                      className="w-full justify-start h-12"
                      variant="outline"
                      disabled
                    >
                      <ShoppingCart className="w-5 h-5 mr-3 text-blue-500" />
                      <div className="text-left">
                        <div className="font-medium">Маркет</div>
                        <div className="text-xs text-muted-foreground">Торговая площадка</div>
                      </div>
                    </Button>
                  </TooltipTrigger>
                  <TooltipContent>
                    <p>Функция находится в разработке</p>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>

              {/* Device Control with Dropdown */}
              <div className="relative">
                <TooltipProvider>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <Button 
                        className="w-full justify-start h-12"
                        variant="outline"
                        onClick={() => setShowDeviceDropdown(!showDeviceDropdown)}
                        disabled
                      >
                        <Smartphone className="w-5 h-5 mr-3 text-green-500" />
                        <div className="text-left flex-1">
                          <div className="font-medium">Устройство</div>
                          <div className="text-xs text-muted-foreground">Управление эмулятором</div>
                        </div>
                        <ChevronDown className={`w-4 h-4 transition-transform ${showDeviceDropdown ? 'rotate-180' : ''}`} />
                      </Button>
                    </TooltipTrigger>
                    <TooltipContent>
                      <p>Функции управления устройством</p>
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>

                {/* Device Dropdown Menu */}
                {showDeviceDropdown && (
                  <motion.div
                    initial={{ opacity: 0, y: -10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    className="absolute top-full left-0 right-0 mt-2 bg-popover border border-border rounded-lg shadow-lg z-50 max-h-60 overflow-y-auto"
                  >
                    <div className="p-2">
                      {deviceMenuItems.map((item, index) => (
                        <Button
                          key={index}
                          variant="ghost"
                          className={`w-full justify-start h-10 text-sm ${
                            item.disabled 
                              ? 'text-muted-foreground cursor-not-allowed opacity-50' 
                              : 'hover:bg-accent'
                          }`}
                          disabled={item.disabled}
                          onClick={item.action}
                        >
                          {item.name}
                        </Button>
                      ))}
                    </div>
                  </motion.div>
                )}
              </div>

            </CardContent>
          </Card>
        </motion.div>

        {/* Middle Column: Emulator with Status Text Above */}
        <div className="col-span-6 flex flex-col items-center justify-start">
          {/* Status text centered above emulator */}
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="mb-6 text-center"
          >
            <div className="flex items-center justify-center space-x-2 mb-2">
              <div className="w-2 h-2 bg-primary rounded-full animate-pulse"></div>
              <span className="text-sm font-medium">
                {purchasedAccounts.some(account => account.warmupStarted) || isWarmupActive
                  ? "Эмулятор работает в фоновом режиме"
                  : "Аккаунта на прогреве не найдено.\nЭмулятор остановлен."
                }
              </span>
            </div>
            <div className="flex justify-center space-x-4 text-xs text-muted-foreground">
              <div className="flex items-center space-x-1">
                <Monitor className="w-3 h-3" />
                <span>Мониторинг</span>
              </div>
              <div className="flex items-center space-x-1">
                <Wifi className="w-3 h-3" />
                <span>Подключен</span>
              </div>
              <div className="flex items-center space-x-1">
                <Clock className="w-3 h-3" />
                <span>{emulatorData.uptime}</span>
              </div>
            </div>
          </motion.div>

          {/* Emulator centered in middle column */}
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.5 }}
            className="flex justify-center"
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.6, duration: 0.8, ease: "easeOut" }}
            >
              {/* iPhone 17 Emulator */}
              <div className="relative">
                {/* iPhone 17 Frame - Minimalistic design */}
                <div className="w-80 h-[580px] bg-gradient-to-br from-neutral-800 to-neutral-900 rounded-[48px] border border-neutral-700/30 shadow-[0_0_50px_rgba(0,0,0,0.5)] relative overflow-hidden backdrop-blur-sm">
                  {/* Dynamic Island */}
                  <div className="absolute top-3 left-1/2 transform -translate-x-1/2 w-32 h-6 bg-black rounded-full flex items-center justify-center">
                    <div className="w-2 h-2 bg-neutral-600 rounded-full mr-3"></div>
                    <div className="w-1 h-1 bg-neutral-700 rounded-full"></div>
                  </div>
                  
                  {/* Interactive Screen with minimal bezels */}
                  <div className="absolute top-2 left-2 right-2 bottom-2 bg-black rounded-[44px] overflow-hidden shadow-inner">
                    {isEmulatorLoading ? (
                      <div className="h-full bg-black flex items-center justify-center">
                        <div className="text-center text-gray-400">
                          <div className="mb-4">
                            <div className="animate-spin w-10 h-10 border-2 border-gray-600 border-t-blue-500 rounded-full mx-auto"></div>
                          </div>
                          <p className="text-sm">Подключение к эмулятору...</p>
                          <p className="text-xs mt-1">Запуск системы мониторинга</p>
                          <div className="mt-3 text-xs">
                            <div className="flex items-center justify-center space-x-1">
                              <span>●</span>
                              <span>●</span>
                              <span>●</span>
                            </div>
                          </div>
                        </div>
                      </div>
                    ) : isConnecting ? (
                      <div className="h-full bg-black flex items-center justify-center">
                        <div className="text-center text-gray-400">
                          <div className="mb-4">
                            <div className="animate-spin w-8 h-8 border-2 border-gray-600 border-t-orange-500 rounded-full mx-auto"></div>
                          </div>
                          <p className="text-sm">Подключение к эмулятору...</p>
                          <p className="text-xs mt-1">Инициализация сессии</p>
                        </div>
                      </div>
                     ) : emulatorStarted ? (
                       <div className="h-full bg-gradient-to-b from-blue-50 to-blue-100 flex items-center justify-center">
                         <div className="text-center">
                           <Camera className="w-12 h-12 text-blue-600 mx-auto mb-3" />
                           <p className="text-sm font-medium text-blue-900">Эмулятор запущен</p>
                           <p className="text-xs text-blue-700 mt-1">Режим мониторинга активен</p>
                         </div>
                       </div>
                     ) : showScreenshots ? (
                       /* Screenshots Gallery */
                       <>
                         {/* Status Bar */}
                         <div className="h-6 bg-white flex items-center justify-between px-3 text-xs border-b border-gray-200">
                           <span className="font-medium">7:09</span>
                           <div className="flex items-center space-x-1">
                             <span>🔵</span>
                             <span>📶</span>
                             <span>📶</span>
                             <span>📶</span>
                             <span>📶</span>
                             <span>🔋91</span>
                           </div>
                         </div>
                         
                         {/* App Header */}
                         <div className="h-12 bg-white border-b border-gray-200 flex items-center px-4">
                           <button className="mr-3">
                             <svg width="20" height="20" viewBox="0 0 24 24" fill="none" className="text-gray-600">
                               <path d="M19 12H5m7-7l-7 7 7 7" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                             </svg>
                           </button>
                           <span className="text-lg font-medium text-gray-900">Скриншоты</span>
                         </div>
                         
                         {/* Screenshot Display */}
                         <div className="flex-1 bg-black relative overflow-hidden">
                           <div className="absolute inset-0 flex items-center justify-center">
                             <img 
                               src={screenshots[currentScreenshotIndex]} 
                               alt={`Screenshot ${currentScreenshotIndex + 1}`}
                               className="max-w-full max-h-full object-contain"
                             />
                           </div>
                           
                           {/* Navigation buttons */}
                           {screenshots.length > 1 && (
                             <>
                               <button 
                                 onClick={prevScreenshot}
                                 className="absolute left-2 top-1/2 transform -translate-y-1/2 w-10 h-10 bg-black/50 hover:bg-black/70 rounded-full flex items-center justify-center text-white transition-colors"
                               >
                                 <ChevronLeft className="w-6 h-6" />
                               </button>
                               <button 
                                 onClick={nextScreenshot}
                                 className="absolute right-2 top-1/2 transform -translate-y-1/2 w-10 h-10 bg-black/50 hover:bg-black/70 rounded-full flex items-center justify-center text-white transition-colors"
                               >
                                 <ChevronRight className="w-6 h-6" />
                               </button>
                             </>
                           )}
                           
                           {/* Screenshot counter */}
                           <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 bg-black/70 text-white px-3 py-1 rounded-full text-sm">
                             {currentScreenshotIndex + 1} / {screenshots.length}
                           </div>
                         </div>
                       </>
                     ) : !showChat ? (
                      /* Default Screen - black with status message */
                      <div className="h-full bg-black flex items-center justify-center">
                        <div className="text-center text-gray-400 px-6">
                          <Monitor className="w-16 h-16 mx-auto mb-4 text-gray-500" />
                          <h3 className="text-lg font-medium text-gray-300 mb-2">Превью эмулятора остановлено</h3>
                          <p className="text-sm text-gray-500 mb-4">В данный момент находится на стадии разработки</p>
                          <div className="flex items-center justify-center space-x-2 text-xs">
                            <div className="w-2 h-2 bg-gray-600 rounded-full animate-pulse"></div>
                            <span>Ожидание активации</span>
                          </div>
                        </div>
                      </div>
                    ) : (
                      /* Chat Interface */
                      <>
                        {/* Status Bar */}
                        <div className="h-6 bg-white flex items-center justify-between px-3 text-xs">
                          <span className="font-medium">7:09</span>
                          <div className="flex items-center space-x-1">
                            <span>🔵</span>
                            <span>📶</span>
                            <span>📶</span>
                            <span>📶</span>
                            <span>📶</span>
                            <span>📶</span>
                            <span>🔋91</span>
                          </div>
                        </div>
                        
                        {/* App Header */}
                        <div className="h-12 bg-white border-b border-gray-200 flex items-center px-4">
                          <button className="mr-3">
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" className="text-gray-600">
                              <path d="M19 12H5m7-7l-7 7 7 7" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                            </svg>
                          </button>
                          <span className="text-lg font-medium text-gray-900">Чат с поддержкой</span>
                        </div>
                        
                        {/* Chat Messages */}
                        <div className="flex-1 bg-gray-50 overflow-y-auto px-4 py-3 space-y-4">
                          {/* Support Message 1 */}
                          <div className="flex items-start space-x-2">
                            <div className="w-6 h-6 bg-orange-500 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                              <span className="text-white text-xs font-bold">М</span>
                            </div>
                            <div>
                              <p className="text-xs text-gray-500 mb-1">Поддержка Маркета</p>
                              <div className="bg-white rounded-2xl rounded-tl-md p-3 max-w-[200px] shadow-sm">
                                <p className="text-sm text-gray-800">Привет! Я вижу, что у вас возникли вопросы по работе с платформой.</p>
                              </div>
                            </div>
                          </div>

                          {/* Support Message 2 */}
                          <div className="flex items-start space-x-2">
                            <div className="w-6 h-6 bg-orange-500 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                              <span className="text-white text-xs font-bold">М</span>
                            </div>
                            <div>
                              <div className="bg-white rounded-2xl rounded-tl-md p-3 max-w-[200px] shadow-sm">
                                <p className="text-sm text-gray-800">Какие именно трудности у вас возникли? Опишите подробнее, и я помогу разобраться.</p>
                              </div>
                            </div>
                          </div>

                          {/* User typing indicator */}
                          <div className="flex items-start space-x-2 opacity-70">
                            <div className="w-6 h-6 bg-gray-400 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                              <span className="text-white text-xs font-bold">Я</span>
                            </div>
                            <div>
                              <div className="bg-white rounded-2xl rounded-tl-md p-3 max-w-[200px] shadow-sm">
                                <div className="flex space-x-1">
                                  <div className="w-2 h-2 bg-gray-400 rounded-full animate-pulse"></div>
                                  <div className="w-2 h-2 bg-gray-400 rounded-full animate-pulse" style={{ animationDelay: '0.2s' }}></div>
                                  <div className="w-2 h-2 bg-gray-400 rounded-full animate-pulse" style={{ animationDelay: '0.4s' }}></div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                        
                        {/* Chat Input */}
                        <div className="h-14 bg-white border-t border-gray-200 flex items-center px-4">
                          <div className="flex-1 bg-gray-100 rounded-full px-4 py-2 mr-3">
                            <span className="text-sm text-gray-500">Сообщение...</span>
                          </div>
                          <button className="w-8 h-8 bg-orange-500 rounded-full flex items-center justify-center">
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" className="text-white">
                              <path d="M18 13l-1.5-7.5L2 2l3.5 14.5L13 18l5-5z" fill="currentColor"/>
                            </svg>
                          </button>
                        </div>
                      </>
                    )}
                  </div>
                </div>
              </div>
            </motion.div>
          </motion.div>
        </div>

        {/* Right Column: Statistics and Performance (300px width) */}
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.5 }}
          className="col-span-3 space-y-6"
        >
          {/* Device Status */}
          <Card className="bg-gradient-to-br from-card/50 to-card/80 backdrop-blur-sm border-border/50">
            <CardHeader className="pb-3">
              <CardTitle className="text-lg font-semibold flex items-center">
                <Smartphone className="w-5 h-5 mr-2 text-primary" />
                Состояние устройства
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                  <div className="text-center p-3 bg-background/50 rounded-lg">
                    <Thermometer className="w-8 h-8 mx-auto mb-2 text-amber-400" />
                    <div className="text-xs text-muted-foreground">Температура</div>
                    <div className="text-lg font-bold text-amber-400">{emulatorData.temperature}</div>
                  </div>
                <div className="text-center p-3 bg-background/50 rounded-lg">
                  <MapPin className="w-8 h-8 mx-auto mb-2 text-blue-400" />
                  <div className="text-xs text-muted-foreground">Локация</div>
                  <div className="text-sm font-semibold text-blue-400">{emulatorData.location}</div>
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="text-center p-3 bg-background/50 rounded-lg">
                  <Wifi className="w-8 h-8 mx-auto mb-2 text-primary" />
                  <div className="text-xs text-muted-foreground">Задержка сети</div>
                  <div className="text-lg font-bold text-primary">{emulatorData.networkLatency}</div>
                </div>
                <div className="text-center p-3 bg-background/50 rounded-lg">
                  <Clock className="w-8 h-8 mx-auto mb-2 text-purple-400" />
                  <div className="text-xs text-muted-foreground">Время работы</div>
                  <div className="text-sm font-semibold text-purple-400">{emulatorData.uptime}</div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Performance Metrics */}
          <Card className="bg-gradient-to-br from-card/50 to-card/80 backdrop-blur-sm border-border/50">
            <CardHeader className="pb-3">
              <CardTitle className="text-lg font-semibold flex items-center">
                <Cpu className="w-5 h-5 mr-2 text-primary" />
                Производительность
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {performanceMetrics.map((metric, index) => (
                <div key={index} className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="text-sm font-medium">{metric.label}</span>
                    <span className={`text-sm font-medium ${metric.color}`}>
                      {metric.value}{metric.max === 100 ? '%' : '°C'}
                    </span>
                  </div>
                  <Progress 
                    value={metric.value} 
                    max={metric.max}
                    className="h-2"
                  />
                </div>
              ))}
            </CardContent>
          </Card>

          {/* Device Specifications */}
          <Card className="bg-gradient-to-br from-card/50 to-card/80 backdrop-blur-sm border-border/50">
            <CardHeader className="pb-3">
              <CardTitle className="text-lg font-semibold flex items-center">
                <Package className="w-5 h-5 mr-2 text-primary" />
                Спецификации
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {deviceSpecs.map((spec, index) => (
                <div key={index} className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground">{spec.label}</span>
                  <span className="text-sm font-medium">{spec.value}</span>
                </div>
              ))}
            </CardContent>
          </Card>
        </motion.div>
      </div>

      {/* Settings Dialog */}
      <Dialog open={isSettingsOpen} onOpenChange={handleCloseSettings}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle className="flex items-center">
              <Settings className="w-5 h-5 mr-2" />
              Настройки разработчика
            </DialogTitle>
          </DialogHeader>
          
          <form onSubmit={handleAccessKeySubmit} className="space-y-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Ключ доступа</label>
              <Input
                type="password"
                placeholder="Введите ключ доступа разработчика"
                value={accessKey}
                onChange={(e) => setAccessKey(e.target.value)}
                disabled={isLoading}
              />
            </div>

            {showError && (
              <Alert variant="destructive">
                <AlertTriangle className="h-4 w-4" />
                <AlertDescription>
                  Неверный ключ доступа. Обратитесь к администратору.
                </AlertDescription>
              </Alert>
            )}

            <DialogFooter>
              <Button type="button" variant="outline" onClick={handleCloseSettings}>
                Отмена
              </Button>
              <Button type="submit" disabled={isLoading || !accessKey.trim()}>
                {isLoading ? 'Проверка...' : 'Войти'}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </motion.div>
  );
};

export default EmulatorPage;