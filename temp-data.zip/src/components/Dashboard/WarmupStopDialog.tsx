import React, { useState } from 'react';
import { AlertDialog, AlertDialogAction, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';
import { AlertTriangle } from 'lucide-react';

interface WarmupStopDialogProps {
  children: React.ReactNode;
}

export const WarmupStopDialog: React.FC<WarmupStopDialogProps> = ({ children }) => {
  return (
    <AlertDialog>
      <AlertDialogTrigger asChild>
        {children}
      </AlertDialogTrigger>
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle className="flex items-center space-x-2">
            <AlertTriangle className="w-5 h-5 text-amber-500" />
            <span>Остановка прогрева отключена</span>
          </AlertDialogTitle>
          <AlertDialogDescription className="text-left">
            Функция остановки прогрева отключена в целях безопасности, чтобы аккаунт не выключался в аварийном режиме, что могло бы привести к фроду.
            <br /><br />
            Прогрев будет продолжаться автоматически до завершения (100%).
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogAction>Понятно</AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
};