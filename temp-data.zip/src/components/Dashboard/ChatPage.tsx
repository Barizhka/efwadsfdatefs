import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { ScrollArea } from '@/components/ui/scroll-area';
import { 
  MessageSquare, 
  Send, 
  Bot, 
  User, 
  Clock, 
  CheckCircle,
  AlertCircle,
  Paperclip,
  Phone,
  Mail
} from 'lucide-react';

const ChatPage = () => {
  const [message, setMessage] = React.useState('');
  const [messages, setMessages] = React.useState([
    {
      id: 1,
      type: 'bot',
      content: 'Добро пожаловать в поддержку yasplit.ai! Я ваш AI-ассистент. Чем могу помочь?',
      timestamp: '14:30',
      status: 'delivered'
    },
    {
      id: 2,
      type: 'user',
      content: 'Привет! У меня вопрос по настройке прогрева аккаунтов.',
      timestamp: '14:32',
      status: 'read'
    },
    {
      id: 3,
      type: 'bot',
      content: 'Конечно! Расскажу о настройке прогрева. Какой именно аспект вас интересует - базовые параметры, продвинутые настройки или автоматическая оптимизация?',
      timestamp: '14:32',
      status: 'delivered'
    }
  ]);

  const sendMessage = () => {
    if (!message.trim()) return;
    
    const newMessage = {
      id: Date.now(),
      type: 'user' as const,
      content: message,
      timestamp: new Date().toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' }),
      status: 'sending' as const
    };
    
    setMessages(prev => [...prev, newMessage]);
    setMessage('');
    
    // Simulate bot response
    setTimeout(() => {
      const botResponse = {
        id: Date.now() + 1,
        type: 'bot' as const,
        content: 'Спасибо за ваш вопрос! Наш специалист рассмотрит его и ответит в ближайшее время.',
        timestamp: new Date().toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' }),
        status: 'delivered' as const
      };
      setMessages(prev => [...prev, botResponse]);
    }, 1000);
  };

  const supportContacts = [
    { type: 'Telegram', value: '@yasplit_support', icon: MessageSquare },
    { type: 'Email', value: 'support@yasplit.ai', icon: Mail },
    { type: 'Телефон', value: '+7 (800) 123-45-67', icon: Phone }
  ];

  const faqItems = [
    { question: 'Как настроить прогрев?', category: 'Настройки' },
    { question: 'Проблемы с эмулятором', category: 'Техническая' },
    { question: 'Пополнение баланса', category: 'Платежи' },
    { question: 'Настройка ИИ', category: 'Настройки' }
  ];

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
      className="space-y-6"
    >
      {/* Header */}
      <div className="flex items-center justify-between">
        <motion.h1 
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.2 }}
          className="text-3xl font-bold bg-gradient-to-r from-primary to-blue-400 bg-clip-text text-transparent"
        >
          Чат поддержки
        </motion.h1>
        
        <motion.div 
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.3 }}
          className="flex items-center space-x-2"
        >
          <Badge className="bg-primary/20 text-primary">
            <CheckCircle className="w-3 h-3 mr-1" />
            Онлайн
          </Badge>
          <Badge variant="outline">
            <Clock className="w-3 h-3 mr-1" />
            Ответ в течение 5 мин
          </Badge>
        </motion.div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 h-[calc(100vh-200px)]">
        {/* Chat Area */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.4 }}
          className="lg:col-span-3 flex flex-col"
        >
          <Card className="bg-card/80 backdrop-blur-sm border-border/50 flex-1 flex flex-col">
            <CardHeader className="border-b border-border/30">
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center space-x-2">
                  <Bot className="w-5 h-5 text-primary" />
                  <span>yasplit.ai Support</span>
                </CardTitle>
                <Badge className="bg-primary/20 text-primary text-xs">
                  AI-ассистент активен
                </Badge>
              </div>
            </CardHeader>
            
            <CardContent className="flex-1 flex flex-col p-0">
              <ScrollArea className="flex-1 p-4">
                <div className="space-y-4">
                  {messages.map((msg, index) => (
                    <motion.div
                      key={msg.id}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: index * 0.1 }}
                      className={`flex ${msg.type === 'user' ? 'justify-end' : 'justify-start'}`}
                    >
                      <div className={`flex items-start space-x-2 max-w-xs lg:max-w-md ${
                        msg.type === 'user' ? 'flex-row-reverse space-x-reverse' : ''
                      }`}>
                        <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                          msg.type === 'user' 
                            ? 'bg-primary text-primary-foreground' 
                            : 'bg-gradient-to-br from-primary/20 to-blue-400/20'
                        }`}>
                          {msg.type === 'user' ? (
                            <User className="w-4 h-4" />
                          ) : (
                            <Bot className="w-4 h-4 text-primary" />
                          )}
                        </div>
                        
                        <div className={`rounded-2xl px-4 py-2 ${
                          msg.type === 'user'
                            ? 'bg-primary text-primary-foreground'
                            : 'bg-muted/50 border border-border/30'
                        }`}>
                          <p className="text-sm">{msg.content}</p>
                          <div className="flex items-center justify-between mt-2">
                            <span className={`text-xs opacity-70`}>
                              {msg.timestamp}
                            </span>
                            {msg.type === 'user' && (
                              <div className="ml-2">
                                {msg.status === 'sending' && (
                                  <Clock className="w-3 h-3 opacity-70" />
                                )}
                                {msg.status === 'delivered' && (
                                  <CheckCircle className="w-3 h-3 opacity-70" />
                                )}
                                {msg.status === 'read' && (
                                  <CheckCircle className="w-3 h-3 text-primary" />
                                )}
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </div>
              </ScrollArea>
              
              {/* Message Input */}
              <div className="border-t border-border/30 p-4">
                <div className="flex items-center space-x-2">
                  <Button size="sm" variant="ghost" className="p-2">
                    <Paperclip className="w-4 h-4" />
                  </Button>
                  <Input
                    placeholder="Напишите ваше сообщение..."
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    onKeyPress={(e) => e.key === 'Enter' && sendMessage()}
                    className="flex-1"
                  />
                  <Button 
                    onClick={sendMessage}
                    disabled={!message.trim()}
                    size="sm"
                    className="bg-gradient-to-r from-primary to-primary/80"
                  >
                    <Send className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Sidebar */}
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.5 }}
          className="space-y-4"
        >
          {/* Quick Actions */}
          <Card className="bg-card/80 backdrop-blur-sm border-border/50">
            <CardHeader>
              <CardTitle className="text-lg">Быстрые действия</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              {faqItems.map((item, index) => (
                <motion.button
                  key={index}
                  initial={{ opacity: 0, y: 5 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.7 + index * 0.1 }}
                  whileHover={{ scale: 1.02 }}
                  className="w-full text-left p-3 rounded-lg bg-muted/20 hover:bg-muted/40 transition-colors border border-border/30 hover:border-primary/30"
                  onClick={() => setMessage(item.question)}
                >
                  <p className="text-sm font-medium">{item.question}</p>
                  <Badge variant="outline" className="text-xs mt-1">
                    {item.category}
                  </Badge>
                </motion.button>
              ))}
            </CardContent>
          </Card>

          {/* Contact Info */}
          <Card className="bg-card/80 backdrop-blur-sm border-border/50">
            <CardHeader>
              <CardTitle className="text-lg">Другие способы связи</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {supportContacts.map((contact, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: 10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.8 + index * 0.1 }}
                  className="flex items-center space-x-3 p-3 bg-muted/20 rounded-lg"
                >
                  <contact.icon className="w-4 h-4 text-primary" />
                  <div className="flex-1">
                    <p className="text-sm font-medium">{contact.type}</p>
                    <p className="text-xs text-muted-foreground">{contact.value}</p>
                  </div>
                </motion.div>
              ))}
            </CardContent>
          </Card>

          {/* Status */}
          <Card className="bg-gradient-to-br from-primary/10 to-blue-500/5 border-primary/20">
            <CardContent className="p-4 text-center">
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 1 }}
                className="space-y-3"
              >
                <div className="w-12 h-12 bg-gradient-to-br from-primary/20 to-blue-400/20 rounded-full flex items-center justify-center mx-auto">
                  <MessageSquare className="w-6 h-6 text-primary" />
                </div>
                <div>
                  <p className="text-sm font-medium">Поддержка 24/7</p>
                  <p className="text-xs text-muted-foreground">
                    ИИ-ассистент всегда готов помочь
                  </p>
                </div>
              </motion.div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </motion.div>
  );
};

export default ChatPage;