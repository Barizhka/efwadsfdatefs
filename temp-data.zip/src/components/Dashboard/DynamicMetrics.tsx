import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { ChartContainer } from '@/components/ui/chart';
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, AreaChart, Area } from 'recharts';
import { useAppStore } from '@/store/appStore';
import { 
  Thermometer, 
  Zap, 
  Activity, 
  Cpu, 
  Database,
  Clock,
  TrendingUp,
  BarChart3
} from 'lucide-react';

interface DynamicMetricsProps {
  isActive: boolean;
  accountsCount: number;
}

interface MetricData {
  timestamp: string;
  temperature: number;
  load: number;
  activity: number;
  requests: number;
}

const DynamicMetrics: React.FC<DynamicMetricsProps> = ({ isActive, accountsCount }) => {
  const { purchasedAccounts, isWarmupActive } = useAppStore();
  const [metrics, setMetrics] = useState<MetricData[]>([]);
  const [currentTemp, setCurrentTemp] = useState(22);
  const [currentLoad, setCurrentLoad] = useState(0);
  const [currentActivity, setCurrentActivity] = useState(0);
  const [requestsPerMin, setRequestsPerMin] = useState(0);

  // Генерация динамических данных
  useEffect(() => {
    const hasActiveWarmup = purchasedAccounts.some(account => account.warmupStarted) || isWarmupActive;
    
    if (!hasActiveWarmup || accountsCount === 0) {
      setCurrentTemp(22);
      setCurrentLoad(0);
      setCurrentActivity(0);
      setRequestsPerMin(0);
      setMetrics([]);
      return;
    }

    const interval = setInterval(() => {
      const now = new Date();
      const timeStr = now.toLocaleTimeString('ru-RU', { 
        hour: '2-digit', 
        minute: '2-digit' 
      });

      // Динамическое изменение метрик на основе количества аккаунтов
      const baseTemp = 25 + (accountsCount * 2);
      const baseLoad = 20 + (accountsCount * 5);
      const baseActivity = 10 + (accountsCount * 3);
      const baseRequests = accountsCount * 12;

      // Рандомизация с реалистичными колебаниями, но в пределах 12-99%
      const tempVariation = (Math.random() - 0.5) * 10;
      const loadVariation = (Math.random() - 0.5) * 20;
      const activityVariation = (Math.random() - 0.5) * 15;
      const requestsVariation = (Math.random() - 0.5) * 8;

      const newTemp = Math.max(22, Math.min(85, baseTemp + tempVariation));
      const newLoad = Math.max(12, Math.min(99, baseLoad + loadVariation));
      const newActivity = Math.max(12, Math.min(99, baseActivity + activityVariation));
      const newRequests = Math.max(0, baseRequests + requestsVariation);

      setCurrentTemp(Math.round(newTemp));
      setCurrentLoad(Math.round(newLoad));
      setCurrentActivity(Math.round(newActivity));
      setRequestsPerMin(Math.round(newRequests));

      const newDataPoint: MetricData = {
        timestamp: timeStr,
        temperature: newTemp,
        load: newLoad,
        activity: newActivity,
        requests: newRequests
      };

      setMetrics(prev => {
        const updated = [...prev, newDataPoint];
        return updated.slice(-20); // Последние 20 точек
      });
    }, 2000); // Обновление каждые 2 секунды

    return () => clearInterval(interval);
  }, [purchasedAccounts, isWarmupActive, accountsCount]);

  const getTemperatureColor = (temp: number) => {
    if (temp < 30) return 'text-blue-400';
    if (temp < 50) return 'text-green-400';
    if (temp < 70) return 'text-yellow-400';
    return 'text-red-400';
  };

  const getLoadColor = (load: number) => {
    if (load < 30) return 'text-green-400';
    if (load < 60) return 'text-yellow-400';
    return 'text-red-400';
  };

  const hasActiveWarmup = purchasedAccounts.some(account => account.warmupStarted) || isWarmupActive;

  if (!hasActiveWarmup || accountsCount === 0) {
    return (
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="grid grid-cols-1 lg:grid-cols-2 gap-6"
      >
        <Card className="bg-gray-800/50 border-gray-700">
          <CardHeader>
            <CardTitle className="flex items-center text-white">
              <Activity className="w-5 h-5 mr-2 text-gray-500" />
              Система мониторинга
            </CardTitle>
          </CardHeader>
          <CardContent className="text-center py-8">
            <div className="space-y-4">
              <div className="w-16 h-16 bg-gray-700 rounded-full flex items-center justify-center mx-auto">
                <Clock className="w-8 h-8 text-gray-500" />
              </div>
              <p className="text-gray-400">Аккаунты не прогреваются</p>
              <p className="text-sm text-gray-500">Метрики будут активированы при начале прогрева</p>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gray-800/50 border-gray-700">
          <CardHeader>
            <CardTitle className="flex items-center text-white">
              <BarChart3 className="w-5 h-5 mr-2 text-gray-500" />
              Графики активности
            </CardTitle>
          </CardHeader>
          <CardContent className="text-center py-8">
            <div className="space-y-4">
              <div className="w-16 h-16 bg-gray-700 rounded-full flex items-center justify-center mx-auto">
                <TrendingUp className="w-8 h-8 text-gray-500" />
              </div>
              <p className="text-gray-400">Данных нет</p>
              <p className="text-sm text-gray-500">Графики появятся при активном прогреве</p>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-6"
    >
      {/* Основные метрики */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <motion.div
          animate={{ scale: [1, 1.02, 1] }}
          transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
        >
          <Card className="bg-gray-800/50 border-gray-700">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-400">Температура</p>
                  <p className={`text-2xl font-bold ${getTemperatureColor(currentTemp)}`}>
                    {currentTemp}°C
                  </p>
                </div>
                <Thermometer className={`w-8 h-8 ${getTemperatureColor(currentTemp)}`} />
              </div>
              <Progress 
                value={(currentTemp / 85) * 100} 
                className="h-2 mt-2"
              />
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          animate={{ scale: [1, 1.02, 1] }}
          transition={{ duration: 2.2, repeat: Infinity, ease: "easeInOut" }}
        >
          <Card className="bg-gray-800/50 border-gray-700">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-400">Нагрузка CPU</p>
                  <p className={`text-2xl font-bold ${getLoadColor(currentLoad)}`}>
                    {currentLoad}%
                  </p>
                </div>
                <Cpu className={`w-8 h-8 ${getLoadColor(currentLoad)}`} />
              </div>
              <Progress 
                value={currentLoad} 
                className="h-2 mt-2"
              />
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          animate={{ scale: [1, 1.02, 1] }}
          transition={{ duration: 1.8, repeat: Infinity, ease: "easeInOut" }}
        >
          <Card className="bg-gray-800/50 border-gray-700">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-400">Активность</p>
                  <p className="text-2xl font-bold text-primary">
                    {currentActivity}%
                  </p>
                </div>
                <Activity className="w-8 h-8 text-primary" />
              </div>
              <Progress 
                value={currentActivity} 
                className="h-2 mt-2"
              />
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          animate={{ scale: [1, 1.02, 1] }}
          transition={{ duration: 2.5, repeat: Infinity, ease: "easeInOut" }}
        >
          <Card className="bg-gray-800/50 border-gray-700">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-400">Запросы/мин</p>
                  <p className="text-2xl font-bold text-cyan-400">
                    {requestsPerMin}
                  </p>
                </div>
                <Database className="w-8 h-8 text-cyan-400" />
              </div>
              <div className="flex items-center mt-2">
                <Badge className="bg-green-500/20 text-green-400 border-green-500/30 text-xs">
                  Активно
                </Badge>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>

      {/* Графики */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="bg-gray-800/50 border-gray-700">
          <CardHeader>
            <CardTitle className="flex items-center text-white">
              <Thermometer className="w-5 h-5 mr-2 text-primary" />
              Температура системы
            </CardTitle>
          </CardHeader>
          <CardContent>
            {metrics.length > 0 && (
              <ChartContainer config={{}} className="h-[200px] w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={metrics}>
                    <XAxis 
                      dataKey="timestamp" 
                      tick={{ fill: '#9CA3AF', fontSize: 12 }}
                      axisLine={false}
                    />
                    <YAxis 
                      tick={{ fill: '#9CA3AF', fontSize: 12 }}
                      axisLine={false}
                      domain={[20, 90]}
                    />
                    <Tooltip 
                      contentStyle={{ 
                        backgroundColor: '#1F2937', 
                        border: '1px solid #374151',
                        borderRadius: '8px'
                      }}
                    />
                    <Area
                      type="monotone"
                      dataKey="temperature"
                      stroke="hsl(var(--primary))"
                      fill="hsl(var(--primary))"
                      fillOpacity={0.2}
                      strokeWidth={2}
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </ChartContainer>
            )}
          </CardContent>
        </Card>

        <Card className="bg-gray-800/50 border-gray-700">
          <CardHeader>
            <CardTitle className="flex items-center text-white">
              <Zap className="w-5 h-5 mr-2 text-primary" />
              Нагрузка и активность
            </CardTitle>
          </CardHeader>
          <CardContent>
            {metrics.length > 0 && (
              <ChartContainer config={{}} className="h-[200px] w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={metrics}>
                    <XAxis 
                      dataKey="timestamp" 
                      tick={{ fill: '#9CA3AF', fontSize: 12 }}
                      axisLine={false}
                    />
                    <YAxis 
                      tick={{ fill: '#9CA3AF', fontSize: 12 }}
                      axisLine={false}
                      domain={[0, 100]}
                    />
                    <Tooltip 
                      contentStyle={{ 
                        backgroundColor: '#1F2937', 
                        border: '1px solid #374151',
                        borderRadius: '8px'
                      }}
                    />
                    <Line
                      type="monotone"
                      dataKey="load"
                      stroke="#EF4444"
                      strokeWidth={2}
                      dot={false}
                    />
                    <Line
                      type="monotone"
                      dataKey="activity"
                      stroke="hsl(var(--primary))"
                      strokeWidth={2}
                      dot={false}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </ChartContainer>
            )}
          </CardContent>
        </Card>
      </div>
    </motion.div>
  );
};

export default DynamicMetrics;