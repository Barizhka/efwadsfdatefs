import { Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useState, useEffect } from "react";

interface LoadingFallbackProps {
  message?: string;
  onSkip?: () => void;
}

export const LoadingFallback = ({ 
  message = "Загрузка данных...", 
  onSkip 
}: LoadingFallbackProps) => {
  const [showSkip, setShowSkip] = useState(false);
  const [dots, setDots] = useState('');

  useEffect(() => {
    const timer = setTimeout(() => setShowSkip(true), 5000);
    return () => clearTimeout(timer);
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      setDots(prev => prev.length >= 3 ? '' : prev + '.');
    }, 500);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="flex min-h-screen items-center justify-center bg-background">
      <div className="text-center space-y-4">
        <Loader2 className="h-8 w-8 animate-spin mx-auto text-primary" />
        <p className="text-lg text-foreground">{message}{dots}</p>
        
        {showSkip && onSkip && (
          <div className="space-y-2">
            <p className="text-sm text-muted-foreground">
              Загрузка занимает больше времени, чем обычно
            </p>
            <Button 
              variant="outline" 
              onClick={onSkip}
              className="mx-auto"
            >
              Пропустить загрузку
            </Button>
          </div>
        )}
      </div>
    </div>
  );
};