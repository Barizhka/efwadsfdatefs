import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { useAppStore } from '@/store/appStore';
import { useAuthContext } from '@/providers/AuthProvider';
import { useUserProfile } from '@/hooks/useUserProfile';
import { User, Mail, Calendar, CreditCard, LogOut, Shield, Package, AlertTriangle } from 'lucide-react';
import { useAdminAuth } from '@/hooks/useAdminAuth';
import { Alert, AlertDescription } from "@/components/ui/alert";

interface ProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ProfileModal: React.FC<ProfileModalProps> = ({ isOpen, onClose }) => {
  const { user, orders } = useAppStore();
  const { user: authUser, logout } = useAuthContext();
  const { profile, loading } = useUserProfile();
  const { isAuthenticated: isAdmin } = useAdminAuth();

  const handleLogout = async () => {
    await logout();
    onClose();
  };

  // Фильтруем заказы на подтверждение доставки
  const deliveryConfirmationOrders = orders.filter(order => order.status === 'delivery_confirmation');

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <User className="w-5 h-5" />
            Профиль пользователя
          </DialogTitle>
        </DialogHeader>
        
        <div className="space-y-6">
          {/* Avatar and Name */}
          <div className="flex items-center space-x-4">
            <Avatar className="w-16 h-16">
              <AvatarFallback className="bg-gradient-to-br from-primary to-blue-500 text-primary-foreground text-xl font-bold">
                {(profile?.displayName || 'Пользователь').charAt(0).toUpperCase()}
              </AvatarFallback>
            </Avatar>
            <div className="flex-1">
              <h3 className="font-semibold text-lg">
                {loading ? 'Загрузка...' : (profile?.displayName || 'Пользователь')}
              </h3>
              {profile?.telegramUsername && (
                <div className="flex items-center gap-1 text-sm text-muted-foreground">
                  <span>@{profile.telegramUsername}</span>
                </div>
              )}
              {/* Only show email if it's a real email (not telegram.local) */}
              {(authUser?.email || profile?.email) && 
               !(authUser?.email?.includes('@telegram.local') || profile?.email?.includes('@telegram.local')) && (
                <div className="flex items-center gap-1 text-sm text-muted-foreground">
                  <Mail className="w-3 h-3" />
                  {authUser?.email || profile?.email}
                </div>
              )}
              {isAdmin && (
                <Badge variant="destructive" className="mt-1">
                  <Shield className="w-3 h-3 mr-1" />
                  Администратор
                </Badge>
              )}
            </div>
          </div>

          <Separator />

          {/* Account Info */}
          <div className="space-y-4">
            <h4 className="font-medium text-sm text-muted-foreground uppercase tracking-wide">
              Информация об аккаунте
            </h4>
            
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <CreditCard className="w-4 h-4 text-muted-foreground" />
                  <span className="text-sm">Баланс</span>
                </div>
                <span className="font-semibold text-primary">₽{user.balance}</span>
              </div>

              {authUser?.created_at && (
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Calendar className="w-4 h-4 text-muted-foreground" />
                    <span className="text-sm">Дата регистрации</span>
                  </div>
                  <span className="text-sm text-muted-foreground">
                    {new Date(authUser.created_at).toLocaleDateString('ru-RU')}
                  </span>
                </div>
              )}

              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <User className="w-4 h-4 text-muted-foreground" />
                  <span className="text-sm">ID пользователя</span>
                </div>
                <span className="text-xs text-muted-foreground font-mono">
                  {authUser?.id?.slice(0, 8)}...
                </span>
              </div>
            </div>
          </div>

          <Separator />

          {/* Delivery Confirmation Orders */}
          {deliveryConfirmationOrders.length > 0 && (
            <div className="space-y-4">
              <h4 className="font-medium text-sm text-muted-foreground uppercase tracking-wide">
                Заявки на подтверждение доставки
              </h4>
              <div className="space-y-2">
                {deliveryConfirmationOrders.map((order) => (
                  <div key={order.id} className="p-3 bg-blue-900/20 rounded-lg border border-blue-500/30">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <Package className="w-4 h-4 text-blue-400" />
                        <span className="text-sm font-medium">{order.productName}</span>
                      </div>
                      <Badge className="bg-blue-600 text-xs">На подтверждении</Badge>
                    </div>
                    <div className="text-xs text-muted-foreground">
                      <p>Аккаунт: {order.accountName}</p>
                      <p>Сумма: {order.remainingAmount.toLocaleString()} ₽</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          <Separator />

          {/* Actions */}
          <div className="space-y-2">
            <Button 
              variant="destructive" 
              size="sm" 
              onClick={handleLogout}
              className="w-full"
            >
              <LogOut className="w-4 h-4 mr-2" />
              Выйти из аккаунта
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};