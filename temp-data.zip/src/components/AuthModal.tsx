import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Loader2, MessageCircle, CheckCircle, AlertCircle } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAuthenticated: () => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({ isOpen, onClose, onAuthenticated }) => {
  const [isLoading, setIsLoading] = useState(false);
  const [telegramUrl, setTelegramUrl] = useState<string>('');
  const [authToken, setAuthToken] = useState<string>('');
  const [pollInterval, setPollInterval] = useState<NodeJS.Timeout | null>(null);
  const [authStatus, setAuthStatus] = useState<'idle' | 'generating' | 'waiting' | 'success' | 'error'>('idle');

  // Генерация отображаемого имени пользователя
  const generateDisplayName = (
    firstName?: string,
    lastName?: string, 
    username?: string,
    telegramId?: number
  ) => {
    if (firstName) {
      if (lastName) {
        return `пользователь: ${firstName} ${lastName}`;
      } else {
        return `пользователь: ${firstName}`;
      }
    } else if (username) {
      return `пользователь: ${username}`;
    } else if (telegramId) {
      return `пользователь: id ${telegramId}`;
    } else {
      return 'Пользователь Telegram';
    }
  };

  // Очистка состояния при закрытии модала
  useEffect(() => {
    if (!isOpen) {
      setAuthStatus('idle');
      setTelegramUrl('');
      setAuthToken('');
      setIsLoading(false);
      if (pollInterval) {
        clearInterval(pollInterval);
        setPollInterval(null);
      }
    }
  }, [isOpen, pollInterval]);

  // Инициация авторизации через Telegram
  const handleTelegramAuth = async () => {
    try {
      setIsLoading(true);
      setAuthStatus('generating');

      console.log('Generating auth token...');
      
      const { data, error } = await supabase.functions.invoke('telegram-bot', {
        body: { action: 'generate-token' }
      });

      if (error) {
        console.error('Error generating token:', error);
        toast.error('Ошибка генерации токена');
        setAuthStatus('error');
        return;
      }

      console.log('Token generated:', data);
      setAuthToken(data.token);
      setTelegramUrl(data.telegram_url);
      setAuthStatus('waiting');
      
      // Открываем Telegram
      window.open(data.telegram_url, '_blank');
      
      // Начинаем проверку статуса
      startPolling(data.token);
    } catch (error) {
      console.error('Error in handleTelegramAuth:', error);
      toast.error('Ошибка при создании ссылки Telegram');
      setAuthStatus('error');
    } finally {
      setIsLoading(false);
    }
  };

  // Проверка статуса авторизации
  const pollTokenStatus = async (token: string) => {
    try {
      console.log('Checking token status:', token);
      
      const { data, error } = await supabase.functions.invoke('telegram-bot', {
        body: { action: 'check-token', token }
      });

      if (error) {
        console.error('Error checking token:', error);
        return false;
      }

      console.log('Token status:', data);

      if (data.status === 'authenticated') {
        setAuthStatus('success');
        
        // Создаем фейковую сессию для Telegram
        const supabaseUser = data.user;
        
        const telegramSession = {
          access_token: 'telegram_session',
          refresh_token: 'telegram_refresh',
          expires_in: 3600,
          expires_at: Date.now() + 3600000,
          token_type: 'bearer',
          user: supabaseUser
        } as any;

        // Генерируем красивое отображаемое имя
        const displayName = generateDisplayName(
          supabaseUser.user_metadata?.telegram_first_name,
          supabaseUser.user_metadata?.telegram_last_name,
          supabaseUser.user_metadata?.telegram_username,
          supabaseUser.user_metadata?.telegram_id
        );

        // Сохраняем сессию в localStorage для AuthProvider
        localStorage.setItem('unified_auth_session', JSON.stringify({
          session: telegramSession,
          user: supabaseUser,
          method: 'telegram',
          timestamp: Date.now()
        }));
        localStorage.setItem('auth_method', 'telegram');
        
        // Уведомляем AuthProvider о изменении авторизации
        window.dispatchEvent(new Event('authStateChange'));

        // Показываем уведомление только один раз
        if (localStorage.getItem('last_welcome_shown') !== supabaseUser.id) {
          toast.success(`Добро пожаловать, ${displayName}!`);
          localStorage.setItem('last_welcome_shown', supabaseUser.id);
        }
        
        onAuthenticated();
        onClose();
        return true;
      }

      return false;
    } catch (error) {
      console.error('Error polling token status:', error);
      return false;
    }
  };

  // Запуск периодической проверки
  const startPolling = (token: string) => {
    const interval = setInterval(async () => {
      const isAuthenticated = await pollTokenStatus(token);
      if (isAuthenticated) {
        clearInterval(interval);
        setPollInterval(null);
      }
    }, 2000); // Проверяем каждые 2 секунды

    setPollInterval(interval);

    // Останавливаем через 5 минут
    setTimeout(() => {
      clearInterval(interval);
      setPollInterval(null);
      if (authStatus === 'waiting') {
        setAuthStatus('error');
        toast.error('Время ожидания истекло. Попробуйте снова.');
      }
    }, 300000); // 5 минут
  };

  // Повторная попытка открытия Telegram
  const handleRetryTelegram = () => {
    if (telegramUrl) {
      window.open(telegramUrl, '_blank');
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="text-center">
            🔐 Авторизация через Telegram
          </DialogTitle>
        </DialogHeader>
        
        <div className="space-y-6">
          <div className="text-center space-y-2">
            <p className="text-muted-foreground">
              Единственный способ входа в приложение
            </p>
            <p className="text-sm text-muted-foreground">
              Безопасно и просто - используйте ваш Telegram аккаунт
            </p>
          </div>

          {authStatus === 'idle' && (
            <Button 
              onClick={handleTelegramAuth}
              disabled={isLoading}
              className="w-full"
              size="lg"
            >
              {isLoading ? (
                <>
                  <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                  Генерация ссылки...
                </>
              ) : (
                <>
                  <MessageCircle className="w-5 h-5 mr-2" />
                  Войти через Telegram
                </>
              )}
            </Button>
          )}

          {authStatus === 'generating' && (
            <div className="text-center space-y-3">
              <Loader2 className="w-8 h-8 mx-auto animate-spin text-primary" />
              <p className="text-sm text-muted-foreground">
                Создаем ссылку для авторизации...
              </p>
            </div>
          )}

          {authStatus === 'waiting' && (
            <div className="text-center space-y-4">
              <div className="animate-pulse">
                <MessageCircle className="w-12 h-12 mx-auto text-primary" />
              </div>
              <div className="space-y-2">
                <p className="font-medium">Ожидаем подтверждения в Telegram</p>
                <p className="text-sm text-muted-foreground">
                  Нажмите "Начать" в боте Telegram
                </p>
              </div>
              <Button 
                variant="outline" 
                onClick={handleRetryTelegram}
                className="w-full"
              >
                <MessageCircle className="w-4 h-4 mr-2" />
                Открыть Telegram снова
              </Button>
            </div>
          )}

          {authStatus === 'success' && (
            <div className="text-center space-y-3">
              <CheckCircle className="w-12 h-12 mx-auto text-green-500" />
              <div className="space-y-1">
                <p className="font-medium text-green-600">Авторизация успешна!</p>
                <p className="text-sm text-muted-foreground">
                  Добро пожаловать в приложение
                </p>
              </div>
            </div>
          )}

          {authStatus === 'error' && (
            <div className="text-center space-y-4">
              <AlertCircle className="w-12 h-12 mx-auto text-red-500" />
              <div className="space-y-2">
                <p className="font-medium text-red-600">Ошибка авторизации</p>
                <p className="text-sm text-muted-foreground">
                  Попробуйте еще раз
                </p>
              </div>
              <Button 
                onClick={handleTelegramAuth}
                className="w-full"
                disabled={isLoading}
              >
                <MessageCircle className="w-4 h-4 mr-2" />
                Попробовать снова
              </Button>
            </div>
          )}

          <div className="text-center">
            <p className="text-xs text-muted-foreground">
              Нажимая "Войти через Telegram", вы соглашаетесь с использованием 
              вашего Telegram аккаунта для авторизации
            </p>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};