import React from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Lock, LogIn, UserPlus } from 'lucide-react';

interface GuestModeOverlayProps {
  onOpenAuth: () => void;
}

export const GuestModeOverlay = ({ onOpenAuth }: GuestModeOverlayProps) => {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="absolute inset-0 bg-background/80 backdrop-blur-sm z-50 flex items-center justify-center"
    >
      <motion.div
        initial={{ scale: 0.8, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ delay: 0.1 }}
        className="text-center space-y-6 p-8 max-w-md"
      >
        <motion.div
          animate={{ rotate: [0, 10, -10, 0] }}
          transition={{ duration: 2, repeat: Infinity, repeatDelay: 3 }}
          className="mx-auto w-16 h-16 bg-gradient-to-br from-primary/20 to-primary/10 rounded-full flex items-center justify-center"
        >
          <Lock className="w-8 h-8 text-primary" />
        </motion.div>

        <div className="space-y-3">
          <h3 className="text-xl font-bold text-foreground">
            Раздел недоступен в гостевом режиме
          </h3>
          <p className="text-muted-foreground">
            Пожалуйста авторизуйтесь - это очень просто и удобно
          </p>
        </div>

        <div className="flex flex-col gap-3">
          <Button 
            onClick={onOpenAuth}
            className="gradient-primary group"
          >
            <LogIn className="w-4 h-4 mr-2 transition-transform group-hover:scale-110" />
            Войти
          </Button>
          <Button 
            onClick={onOpenAuth}
            variant="outline"
            className="group"
          >
            <UserPlus className="w-4 h-4 mr-2 transition-transform group-hover:scale-110" />
            Регистрация
          </Button>
        </div>
      </motion.div>
    </motion.div>
  );
};