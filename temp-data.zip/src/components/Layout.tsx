import React, { useState } from 'react';
import { Outlet, useLocation } from 'react-router-dom';
import { motion } from 'framer-motion';
import Sidebar from './Sidebar';
import ParticleBackground from './ParticleBackground';
import { GuestModeOverlay } from './GuestModeOverlay';
import { AuthModal } from './AuthModal';
import { useAuthContext } from '@/providers/AuthProvider';

const Layout = () => {
  const { isGuest, isLoading } = useAuthContext();
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const location = useLocation();

  // Routes that should show overlay for guests
  const restrictedRoutes = [
    '/warmup', 
    '/emulator', 
    '/farm-config', 
    '/deposit', 
    '/chat', 
    '/order-product', 
    '/admin',
    '/' // Main dashboard
  ];

  const isRestrictedRoute = restrictedRoutes.some(route => 
    route === '/' ? location.pathname === '/' : location.pathname.startsWith(route)
  );

  const shouldShowOverlay = isGuest && !isLoading && isRestrictedRoute && location.pathname !== '/accounts';

  // Debug logging
  console.log('🔍 Layout render:', {
    isGuest,
    isLoading,
    isRestrictedRoute,
    pathname: location.pathname,
    shouldShowOverlay
  });

  const handleAuthModalClose = () => {
    setIsAuthModalOpen(false);
  };

  const handleAuthenticated = () => {
    // Закрываем модал после успешной авторизации
    setIsAuthModalOpen(false);
  };

  return (
    <div className="flex h-screen bg-background relative overflow-hidden">
      <ParticleBackground />
      
      <Sidebar />
      
      <motion.main 
        initial={{ opacity: 0, scale: 0.98 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.5, delay: 0.2 }}
        className="flex-1 overflow-y-auto relative z-10"
      >
        <div className="p-8 relative">
          <Outlet />
          
          {shouldShowOverlay && (
            <GuestModeOverlay onOpenAuth={() => setIsAuthModalOpen(true)} />
          )}
        </div>
      </motion.main>

      <AuthModal 
        isOpen={isAuthModalOpen}
        onClose={handleAuthModalClose}
        onAuthenticated={handleAuthenticated}
      />
    </div>
  );
};

export default Layout;