import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { motion } from 'framer-motion';
import { cn } from '@/lib/utils';
import { useAppStore } from '@/store/appStore';
import { useAdminAuth } from '@/hooks/useAdminAuth';
import { useAuthContext } from '@/providers/AuthProvider';
import { useUserProfile } from '@/hooks/useUserProfile';
import { ProfileModal } from './ProfileModal';
import { 
  Home, 
  Zap, 
  Monitor, 
  Settings, 
  Users, 
  MessageSquare, 
  CreditCard, 
  Bell, 
  Shield, 
  Smartphone,
  Bot,
  ChevronRight,
  LogOut,
  UserCircle,
  HelpCircle
} from 'lucide-react';

interface SidebarProps {
  className?: string;
}

interface NavItem {
  title: string;
  icon: React.ComponentType<{ className?: string }>;
  href: string;
  badge?: string;
}

const navItems: NavItem[] = [
  { title: 'Главная', icon: Home, href: '/' },
  { title: 'Аккаунты', icon: Users, href: '/accounts' },
  { title: 'Заказ товара', icon: Bot, href: '/order-product' },
  { title: 'Прогрев', icon: Zap, href: '/warmup' },
  { title: 'Эмулятор', icon: Smartphone, href: '/emulator' },
  { title: 'FAQ', icon: HelpCircle, href: '/faq' }
];

const settingsItems: NavItem[] = [
  { title: 'Конфигурация фермы', icon: Settings, href: '/farm-config' },
  { title: 'Пополнение', icon: CreditCard, href: '/deposit', badge: 'Новое' },
  { title: 'Чат поддержки', icon: MessageSquare, href: '/chat' }
];

const Sidebar = ({ className }: SidebarProps) => {
  const location = useLocation();
  const { user } = useAppStore();
  const { isAuthenticated: isAdminAuthenticated } = useAdminAuth();
  const { isGuest, logout } = useAuthContext();
  const { profile, loading } = useUserProfile();
  const [isProfileModalOpen, setIsProfileModalOpen] = useState(false);

  const isActive = (href: string) => {
    if (href === '/') return location.pathname === '/';
    return location.pathname.startsWith(href);
  };

  return (
    <motion.div 
      initial={{ x: -250 }}
      animate={{ x: 0 }}
      transition={{ duration: 0.5, ease: "easeOut" }}
      className={cn(
        "w-64 bg-card/80 backdrop-blur-sm border-r border-border/50 flex flex-col h-full relative overflow-hidden",
        className
      )}
    >
      {/* Animated background */}
      <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-blue-500/5 pointer-events-none" />
      
      {/* Header */}
      <motion.div 
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="p-6 border-b border-border/30 relative z-10"
      >
        <div className="flex items-center space-x-3">
          <motion.div 
            whileHover={{ scale: 1.1, rotate: 5 }}
            transition={{ duration: 0.2 }}
            className="w-10 h-10 bg-gradient-to-br from-primary via-primary/80 to-blue-500 rounded-xl flex items-center justify-center shadow-glow"
          >
            <Bot className="w-6 h-6 text-primary-foreground" />
          </motion.div>
          <div>
            <motion.h1 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.3 }}
              className="font-bold text-xl bg-gradient-to-r from-primary to-blue-400 bg-clip-text text-transparent"
            >
              yasplit.ai
            </motion.h1>
            <p className="text-xs text-muted-foreground">AI управление</p>
          </div>
        </div>
      </motion.div>

      {/* Navigation */}
      <div className="flex-1 p-4 relative z-10">
        {/* Main Navigation */}
        <div className="mb-8">
          <motion.h3 
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.4 }}
            className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3"
          >
            ОСНОВНОЕ
          </motion.h3>
          <nav className="space-y-1">
            {navItems.map((item, index) => (
              <motion.div
                key={item.title}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.5 + index * 0.1 }}
                        whileHover={{ x: 5 }}
                      >
                        <Link
                          to={item.href}
                          className={cn(
                            "group flex items-center px-3 py-3 text-sm font-medium rounded-lg transition-all duration-200 relative",
                            isActive(item.href)
                              ? "bg-gradient-to-r from-primary/15 to-primary/5 text-primary border border-primary/30 shadow-lg"
                              : "text-muted-foreground hover:text-foreground hover:bg-muted/40"
                          )}
                        >
                          <item.icon className="w-5 h-5 mr-3 transition-transform group-hover:scale-110" />
                          {item.title}
                          {isActive(item.href) && (
                            <motion.div
                              layoutId="activeTab"
                              className="absolute right-2"
                            >
                              <ChevronRight className="w-4 h-4 text-primary" />
                            </motion.div>
                          )}
                        </Link>
                      </motion.div>
            ))}
          </nav>
        </div>

        {/* Admin Panel - только если есть доступ */}
        {isAdminAuthenticated && (
          <div className="mb-8">
            <motion.h3 
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.6 }}
              className="text-xs font-semibold text-red-400 uppercase tracking-wider mb-3"
            >
              АДМИНИСТРИРОВАНИЕ
            </motion.h3>
            <nav className="space-y-1">
              <motion.div
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.7 }}
                whileHover={{ x: 5 }}
              >
                <Link
                  to="/admin"
                  className={cn(
                    "group flex items-center px-3 py-3 text-sm font-medium rounded-lg transition-all duration-200 relative",
                    isActive('/admin')
                      ? "bg-gradient-to-r from-red-500/15 to-red-500/5 text-red-400 border border-red-500/30 shadow-lg"
                      : "text-muted-foreground hover:text-red-400 hover:bg-red-500/10"
                  )}
                >
                  <Shield className="w-5 h-5 mr-3 transition-transform group-hover:scale-110" />
                  Админ панель
                  {isActive('/admin') && (
                    <motion.div
                      layoutId="activeAdminTab"
                      className="absolute right-2"
                    >
                      <ChevronRight className="w-4 h-4 text-red-400" />
                    </motion.div>
                  )}
                </Link>
              </motion.div>
            </nav>
          </div>
        )}

        {/* Settings Navigation */}
        <div>
          <motion.h3 
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.8 }}
            className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3"
          >
            НАСТРОЙКИ
          </motion.h3>
          <nav className="space-y-1">
            {settingsItems.map((item, index) => (
              <motion.div
                key={item.title}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.9 + index * 0.1 }}
                whileHover={{ x: 5 }}
              >
                <Link
                  to={item.href}
                  className={cn(
                    "group flex items-center px-3 py-3 text-sm font-medium rounded-lg transition-all duration-200 relative",
                    isActive(item.href)
                      ? "bg-gradient-to-r from-primary/15 to-primary/5 text-primary border border-primary/30 shadow-lg"
                      : "text-muted-foreground hover:text-foreground hover:bg-muted/40"
                  )}
                >
                  <item.icon className="w-5 h-5 mr-3 transition-transform group-hover:scale-110" />
                  {item.title}
                  {isActive(item.href) && (
                    <motion.div
                      layoutId="activeSettingsTab"
                      className="absolute right-2"
                    >
                      <ChevronRight className="w-4 h-4 text-primary" />
                    </motion.div>
                  )}
                  {item.badge && (
                    <motion.span 
                      initial={{ scale: 0 }}
                      animate={{ scale: 1 }}
                      className="ml-auto text-xs bg-primary/30 text-primary px-2 py-1 rounded-full font-semibold shadow-sm"
                    >
                      {item.badge}
                    </motion.span>
                  )}
                </Link>
              </motion.div>
            ))}
          </nav>
        </div>
      </div>

      {/* User Profile */}
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 1.2 }}
        className="p-4 border-t border-border/30 relative z-10"
      >
        {isGuest ? (
          <motion.div 
            whileHover={{ scale: 1.02 }}
            className="p-3 rounded-xl bg-gradient-to-r from-muted/40 to-muted/20 backdrop-blur-sm border border-border/30 text-center"
          >
            <p className="text-sm font-semibold text-muted-foreground">Гостевой режим</p>
            <p className="text-xs text-muted-foreground">Ограниченный доступ</p>
          </motion.div>
        ) : (
          <motion.button
            onClick={() => setIsProfileModalOpen(true)}
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            className="w-full flex items-center space-x-3 p-3 rounded-xl bg-gradient-to-r from-muted/40 to-muted/20 backdrop-blur-sm border border-border/30 hover:border-primary/30 transition-colors"
          >
            <motion.div 
              whileHover={{ scale: 1.1 }}
              className="w-10 h-10 bg-gradient-to-br from-primary to-blue-500 rounded-xl flex items-center justify-center text-primary-foreground font-bold text-sm shadow-glow"
            >
            {(() => {
                const displayName = profile?.displayName || 'Пользователь';
                // Get first letter from any display name
                return displayName.charAt(0).toUpperCase();
              })()}
            </motion.div>
            <div className="flex-1 text-left">
              <p className="text-sm font-semibold">
                {loading ? 'Загрузка...' : (profile?.displayName || 'Пользователь')}
              </p>
              <p className="text-xs text-primary font-medium">₽{user.balance}</p>
            </div>
            <UserCircle className="w-5 h-5 text-muted-foreground" />
          </motion.button>
        )}
      </motion.div>

      {/* Profile Modal */}
      <ProfileModal 
        isOpen={isProfileModalOpen} 
        onClose={() => setIsProfileModalOpen(false)} 
      />
    </motion.div>
  );
};

export default Sidebar;