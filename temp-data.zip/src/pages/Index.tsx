import { Navigate } from "react-router-dom";

const Index = () => {
  // Redirect to main dashboard since that's the actual home page
  return <Navigate to="/" replace />;
};

export default Index;
